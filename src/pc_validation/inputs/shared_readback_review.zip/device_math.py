"""Independent stdlib scalar wire/pointwise/depthwise/requantization audit.

Does not import candidate arithmetic, NumPy, inference engines or board libraries.
"""
import argparse,hashlib,json,math,struct,tarfile
from pathlib import Path
H=Path(__file__).resolve().parent;C=H/'kit/core/frozen_process/frozen_shared/frozen_combo';F=C/'frozen_kit/core/driver/frozen_op4/frozen_op2/frozen/model'
INDICES=(0,30,60,90,120,150,180,210,240,270,300,400)
def need(ok,why):
    if not ok:raise AssertionError(why)
def sha(b):return hashlib.sha256(b).hexdigest()
def meta(b):return dict(bytes=len(b),sha256=sha(b))
def load(p):return json.loads(p.read_bytes())
def signed(raw):return list(struct.unpack('<%db'%len(raw),raw))
def ints(raw):need(len(raw)%4==0,'INT32 bytes');return list(struct.unpack('<%di'%(len(raw)//4),raw))
def quant(v,scale):
    need(math.isfinite(scale) and scale>0,'positive scale');f,e=math.frexp(scale);q=math.floor(f*(1<<31)+0.5)
    if q==(1<<31):q>>=1;e+=1
    if e<-31:q=e=0
    need(e<=30,'bounded shift');v*=1<<max(e,0);need(-(1<<31)<=v<(1<<31),'shifted INT32')
    p=v*q;n=p+((1<<30) if p>=0 else 1-(1<<30));high=(abs(n)//(1<<31))*(1 if n>=0 else -1)
    div=1<<max(-e,0);value,rem=divmod(high,div);value+=int(rem>(div-1)//2+int(high<0))
    return min(127,max(-128,value-128))
def parameters(index):
    descriptor=load(F/'descriptor.json');need(sha((F/'descriptor.json').read_bytes())=='8bd3019d159ea3264164f09e90622423c29650647e8b340fe933b70a9030be08','frozen descriptor')
    info=descriptor['info'];op=info['operators'][index];src,wi,bi=op['inputs'];dst=op['outputs'][0]
    blobs=[]
    for ti in [wi,bi]:
        pin=descriptor['constants'][str(ti)];b=(F/pin['file']).read_bytes();need(meta(b)=={k:pin[k] for k in ['bytes','sha256']},'frozen constant bytes');blobs.append(b)
    scales=[float(w)*info['tensors'][src]['scales'][0]/info['tensors'][dst]['scales'][0] for w in info['tensors'][wi]['scales']]
    need(info['tensors'][src]['zero_points']==[-128] and info['tensors'][dst]['zero_points']==[-128],'fixed zero points')
    weights=signed(blobs[0]);bias=ints(blobs[1]);return weights,bias,scales,blobs
def pw(a,w,bias,scales):
    raw=[];corr=[];out=[]
    for r in range(125):
        ar=a[r*64:(r+1)*64]
        for col in range(64):
            wc=w[col*64:(col+1)*64];value=sum(x*y for x,y in zip(ar,wc));center=value+128*sum(wc)+bias[col]
            need(-(1<<31)<=value<(1<<31) and -(1<<31)<=center<(1<<31),'pointwise INT32 bounds')
            raw.append(value);corr.append(center);out.append(quant(center,scales[col])&255)
    return raw,corr,bytes(out)
def dw(a,w,bias,scales):
    acc=[];out=[]
    for y in range(25):
        for x in range(5):
            for ch in range(64):
                value=bias[ch]
                for ky in range(3):
                    for kx in range(3):
                        iy,ix=y+ky-1,x+kx-1
                        av=a[(iy*5+ix)*64+ch] if 0<=iy<25 and 0<=ix<5 else -128
                        value+=(av+128)*w[(ky*3+kx)*64+ch]
                need(-(1<<31)<=value<(1<<31),'DW INT32 bounds');acc.append(value);out.append(quant(value,scales[ch])&255)
    return acc,bytes(out)
def decode(wire,first):
    need(len(wire)==16512,'wire length');a=[];weight=None
    for job,rows in enumerate((64,61)):
        pos=job*8256;h=struct.unpack_from('<16I',wire,pos)
        need(h==(0x4f4e5055,2+(64<<16),first+job,32+((1<<31) if job else 0),125,64,64,job*64,0,rows+(64<<8)+(64<<16),8192,rows*256,rows*256,0,0,0),'wire exact header')
        payload=signed(wire[pos+64:pos+8256]);aa=[];bb=[0]*4096
        for r in range(64):
            row=[payload[(r//8)*512+k*8+r%8] for k in range(64)]
            if r<rows:aa.extend(row)
            else:need(not any(row),'wire tail padding')
        for col in range(64):
            for k in range(64):bb[col*64+k]=payload[4096+(col//8)*512+k*8+col%8]
        if weight is not None:need(weight==bb,'duplicate weight panels')
        weight=bb;a.extend(aa)
    return a,weight
def metrics(m,first):
    fields=dict(mode=11,jobs=2,chain_jobs_completed=2,first_job_id=first,input_bytes=16512,input_payload_bytes=16384,input_header_bytes=128,output_bytes=32000,output_valid_bytes=32000,effective_macs=512000,error_code=0,failed_tile_index=65535,counter_contract_version=2)
    need(all(type(m.get(k)) is int and m[k]==v for k,v in fields.items()),'fake work counters')
    need(m['counter_contract']=='d007_global_work_v2' and m['mode11_counter_read_strategy']=='pynq_mmio_read' and m['status']&14==4,'fake inherited normal API')
    t,u,n,o=[m[k] for k in ['pl_total_cycles','pl_work_union_cycles','pl_no_work_cycles','pl_overlap_credit_cycles']]
    work=[m['pl_'+n+'_work_cycles'] for n in ['load','array','store','output']]
    need(t>0 and t==u+n and sum(work)==u+o and max(work)<=u<=sum(work),'fake cycle conservation')
    need(m['pl_array_output_work_overlap_cycles']<=min(work[1],work[3]),'fake overlap bounds')
def audit(root):
    banks={};source=C/'inputs/op2_board_original.tar.gz';need(sha(source.read_bytes())=='fba363e39ac2eed800dfbc2c0159774bc6f00963da90f930b0753a6808211177','original Op2 tar')
    with tarfile.open(source,'r:gz') as tar:
        for m in tar.getmembers():
            if '/window_' in m.name and m.isfile():banks[m.name]=tar.extractfile(m).read()
    p2=parameters(2);p3=parameters(3);p4=parameters(4);mode_reports={};normal_bytes={}
    cohort=load(F.parent/'data/cohort.json');features=(F.parent/'data/features.i8').read_bytes()
    for mode in ('replay','fixture'):
        folder=root/mode;summary=load(folder/'summary.json');need(summary['operation_success'] is True and summary['mode']==mode and summary['completed_indices']==list(INDICES) and len(summary['windows'])==12,'complete exact mode')
        for k in ['board_access','real_cross_layer_PL_execution','real_lock_access','real_DMA_executed','PL_simulated','performance_evaluated','energy_evaluated','promotion']:need(summary[k] is False,'honest offline boundary '+k)
        need(summary['fixture'] is True and summary['counters_synthetic'] is True,'declared fake interfaces')
        expected_calls=12 if mode=='replay' else 24
        need(summary['fixture_submissions']==expected_calls and summary['fixture_pointwise_jobs']==2*expected_calls and summary['fixture_pointwise_MACs']==512000*expected_calls,'mode actual fixture accounting')
        need(summary['historical_op2_replayed_windows']==(12 if mode=='replay' else 0) and summary['depthwise_executed_calls']==12 and summary['depthwise_executed_logical_MACs']==864000,'historical/current distinction')
        need([s['operator_index'] for s in summary['sessions']]==([4] if mode=='replay' else [2,4]),'separate layer sessions')
        expected_files={'summary.json'};rows=[]
        for n,row in enumerate(summary['windows']):
            idx=INDICES[n];need(type(row['cohort_index']) is int and row['cohort_index']==idx and row['op2_output_source']==mode,'window source identity')
            need(row['source_id']==cohort[idx]['source_id'] and row['feature_sha256']==sha(features[idx*490:(idx+1)*490]),'frozen window metadata')
            need(row['dynamic_payload_is_kernel_return'] is True and row['op4_wire_consumes_dynamic'] is True,'dynamic flow declarations')
            sub=folder/('window_%03d'%idx);need(load(sub/'result.json')==row,'published same row');expected_files.add(sub.name+'/result.json')
            data={}
            for name,pin in row['artifacts'].items():
                b=(sub/name).read_bytes();need(meta(b)==pin,'artifact pin '+name);data[name]=b;expected_files.add(sub.name+'/'+name)
            original='work/evidence/worker/window_%03d/'%idx
            a2,w2=decode(banks[original+'request_chain.bin'],1+2*n);need(w2==p2[0] and bytes(v&255 for v in a2)==data['op2_input.i8'],'source actual Op2 input and weights')
            r2,c2,out2=pw(a2,*p2[:3]);need(out2==data['op2_output.i8']==data['dw3_input.i8']==banks[original+'candidate_output.i8'],'actual upstream source, no golden substitution')
            need(row['op2_output_sha256']==sha(out2) and row['replay_archive_sha256']==(sha(source.read_bytes()) if mode=='replay' else None),'source hash attribution')
            if mode=='fixture':
                a,w=decode(data['op2_wire.bin'],1+2*n);need(a==a2 and w==p2[0] and ints(data['op2_raw.i32'])==r2 and ints(data['op2_corrected.i32'])==c2,'current Op2 fixture wire and raw/PS');metrics(row['op2_fake_metrics'],1+2*n)
            else:need(row['op2_first_job_id'] is None and row['op2_fake_metrics'] is None,'no fake Op2 counts in replay')
            # Parameters must equal frozen constants, never self-provided oracle weights.
            for layer,pars in [('op2',p2),('dw3',p3),('op4',p4)]:
                if layer=='dw3':expected_weights=pars[3][0]
                else:expected_weights=bytes(pars[0][col*64+k]&255 for k in range(64) for col in range(64))
                need(data[layer+'_weights.i8']==expected_weights and data[layer+'_bias.i32']==pars[3][1],'frozen layer parameters '+layer)
                need(list(struct.unpack('<64d',data[layer+'_scales.f64']))==pars[2],'frozen float scales '+layer)
            acc3,out3=dw(signed(out2),*p3[:3]);need(ints(data['dw3_acc.i32'])==acc3 and out3==data['dw3_output.i8']==data['op4_input.i8'],'independent scalar DW3 and input flow')
            a4,w4=decode(data['op4_wire.bin'],1+2*n);need(a4==signed(out3) and w4==p4[0] and row['op4_first_job_id']==1+2*n,'actual Op4 submission consumes dynamic DW3')
            r4,c4,out4=pw(a4,*p4[:3]);need(ints(data['op4_raw.i32'])==r4 and ints(data['op4_corrected.i32'])==c4 and data['op4_output.i8']==out4,'independent Op4 scalar raw/PS/INT8')
            need(out4==(C/'frozen_kit/core/golden'/sub.name/'candidate_output.i8').read_bytes(),'frozen terminal oracle after actual dataflow');metrics(row['op4_fake_metrics'],1+2*n)
            rows.append(dict(cohort_index=idx,Op2_INT8_values=8000,DW3_acc_values=8000,DW3_INT8_values=8000,Op4_raw_values=8000,Op4_corrected_values=8000,Op4_INT8_values=8000))
            for name in ['op2_output.i8','dw3_acc.i32','dw3_output.i8','op4_wire.bin','op4_raw.i32','op4_corrected.i32','op4_output.i8']:
                key=(idx,name)
                if mode=='replay':normal_bytes[key]=data[name]
                else:need(normal_bytes[key]==data[name],'two source modes equal, not more independent samples')
        need({p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()}==expected_files,'exact mode output set')
        mode_reports[mode]=dict(windows=12,current_fixture_calls=expected_calls,current_fixture_jobs=2*expected_calls,current_fixture_MACs=512000*expected_calls,depthwise_logical_MACs=864000,scalar_DW3_values=96000,scalar_Op4_raw_values=96000,scalar_Op4_INT8_values=96000)
    fault=load(root/'fault/summary.json');need(fault['operation_success'] is False and fault['completed_indices']==[0,30,60] and fault['not_completed_indices']==list(INDICES[3:]),'fault stop at90')
    need(fault['failure']['cohort_index']==90 and fault['failure']['stage']=='op4_call' and fault['failure']['automatic_retry'] is False and fault['fixture_submissions']==4 and fault['fixture_pointwise_jobs']==8 and fault['depthwise_executed_calls']==4,'fault accounting')
    payload=(root/'fault/first_failure.bin').read_bytes();need(meta(payload)==fault['failure']['payload'] and len(payload)==32000,'first failure payload bound')
    need(not (root/'fault/window_090').exists() and not (root/'fault/window_120').exists(),'no post-failure window publication')
    stop=load(root/'stop/summary.json');need(stop['operation_success'] is False and stop['completed_indices']==[0,30,60] and stop['failure']['stage']=='before_depthwise' and stop['failure']['error_type']=='ChainStop','stop at planned pre-DW boundary')
    need(stop['fixture_submissions']==3 and stop['depthwise_executed_calls']==3 and not (root/'stop/first_failure.bin').exists(),'no fourth DW/Op4 or fabricated stop payload')
    witness=load(root/'witnesses/witnesses.json');need(witness['operation_success'] and witness['board_access'] is False,'witness offline')
    base=(root/'replay/window_000');base_a=(base/'op2_output.i8').read_bytes();base_acc,base_out=dw(signed(base_a),*p3[:3])
    for kind,w in witness['witnesses'].items():
        wd=root/'witnesses'/kind;raw=(wd/'changed_op2_output.i8').read_bytes();xor=[x^y for x,y in zip(raw,base_a)]
        need(len(raw)==8000 and sum(v!=0 for v in xor)==1 and xor[w['position']]==1,'exact single input LSB witness')
        acc,out=dw(signed(raw),*p3[:3]);need(ints((wd/'changed_dw3_acc.i32').read_bytes())==acc and (wd/'changed_dw3_output.i8').read_bytes()==out,'scalar witness propagation')
        dc=sum(x!=y for x,y in zip(out,base_out));da=sum(x!=y for x,y in zip(acc,base_acc))
        need(da==w['accumulator_changed_values']>0 and dc==w['INT8_changed_values'] and (dc>0)==(kind=='observable'),'observable versus quantization-masked witness')
        need(w['upstream_gate_rejected'] is True,'corrupt data not accepted by full chain')
    return dict(operation_success=True,modes=mode_reports,unique_cohort_windows=12,source_modes_are_not_new_independent_samples=True,independent_scalar_math=True,NumPy_imported=False,inference_reexecuted=False,actual_board_access=False,real_cross_layer_PL_execution=False,fault_window=90,witnesses_checked=['observable','masked'],promotion=False)
def main():
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--output',required=True);a=p.parse_args();result=audit(Path(a.root))
    with Path(a.output).open('x',encoding='utf-8') as f:json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
    print(json.dumps(result))
if __name__=='__main__':main()
