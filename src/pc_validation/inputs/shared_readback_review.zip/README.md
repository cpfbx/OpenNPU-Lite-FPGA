# 固定12窗真实共享链回件复核包

先读 report.md 和 review_request.md。本包包含未改动的实板归档、已审运行ZIP、与ZIP263成员完全相同的kit、328成员安全解包、冻结标准库数学复算器及作者实际复核日志。

本包所有复核仅在PC读取已有证据；不得执行kit的run/preflight/prepare/stop等板端动作。只运行下述离线入口。

取得外部交付页给出的完整顶层MANIFEST SHA后，从包外空工作目录运行，输出必须为包外、父目录已存在且目标尚不存在的绝对路径：

```text
python -I -B /absolute/bundle/verify_bundle.py --manifest-sha FULL_TOP_MANIFEST_SHA
python -I -B /absolute/bundle/portable_checks.py --manifest-sha FULL_TOP_MANIFEST_SHA --output /absolute/fresh_external_results
```

Windows使用本机Python绝对路径即可。需要NumPy供冻结reader导入，标量复算器本身仅用标准库。portable_checks实际捕获三条命令的stdout/stderr和退出码：整包校验、异路径reader+标量复算、事后整包校验。不会重新推理或操作板卡/规范锁，也不运行实板fixture。

`validation_01`记录最初固定输出路径的作者复核，对应源码保留在historical/run_verify_initial.py；当前run_verify.py仅将输出改为显式包外参数，数学及冻结reader未改，当前源码结果见author_validation_02和实际ZIP便携日志。重复执行不增加独立样本或单测方法数。

原件intake.py只能用于全新隔离目录的初次取件，已有kit/extracted时会拒绝；不是便携复核入口。不在本包内新建输出，不覆盖作者日志。
