# One-session browser delegation approved by bx

2026-10-26: bx explicitly answered the scoped authorization question: `授权本次代操作，其余规则保持`.

This exception covers only the already reviewed single fixed12 shared-chain normal test: browser assistance with Jupyter preflight, original frozen missing-lock bootstrap if required, one launch, readback/archive and transfer assistance. Actual operator is Codex /root; approving human is bx. Prompts requiring bx personally must be left for bx to enter. No automatic retry, kill, unresolved hardware handling, expanded workload, default promotion or other permission change is authorized. The repository-wide sole-bx rule remains in force outside this one session.

Latest user-supplied read-only board snapshot: UTC 2026-10-26 13:01:26; boot `7afdaa81-e698-4c10-9b74-448dc3b4028c`; kernel `6.6.10-xilinx-v2024.1-g3c0eca68c652`; canonical lock absent. Python PID 738 has not yet been classified. Snapshot is historical, not current idle proof.

Browser launcher `create --task "KWS shared12 board assistance"` failed before connection with `CLI_REGISTRATION_UNAVAILABLE`, both before and after the explicit delegation reply. No browser task or board command was started. Read-only route diagnostics show whether installed components exist; no registration, ACL, runtime or browser configuration repair was performed. Pending user normal Browser restart, then reconnect and inspect current state before any board action.

This file is a later authorization addendum outside the previously sealed onsite-preparation manifest; no sealed package or prior manifest is modified.
