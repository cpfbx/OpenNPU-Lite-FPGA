# Approved onsite phase

2026-10-26: bx replied "可以" to the exact fixed-package single fixed12 shared-chain proposal and is connecting the board. Human owner and sole board operator bx; Codex /root prepares local scripts and audits returns only. Base fb6b2f7b94de81a821bb08ebde0660d12752ba66; existing branch/dirty retained.
Scope: one normal fixed12 Op2 -> CPU depthwise3 -> Op4 shared-device session, real startup/normal correctness/cleanup only. Current board boot/inode/idle/wiring are unknown and require fresh user observations. No remote or board command executed by Codex; no performance/energy/420 quality, fault injection, long-run, default or OS/permission/power change. Charts deferred.
Original reviewed runtime ZIP and kit remain unchanged. Local copied bootstrap is exact previously frozen bytes, separately operator-confirmed only if missing canonical lock; never repair or replace an existing inode. No upload/test is performed by creating these scripts.
