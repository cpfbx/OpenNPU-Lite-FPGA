"""Frozen standard-library scalar arithmetic, metric role names adapted only."""
import json,struct,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import device_math as m
def read_json(p):return json.loads(p.read_bytes())

def scalar_normal(folder):
    summary=read_json(folder/'summary.json'); p2,p3,p4=(m.parameters(i) for i in (2,3,4))
    for i,row in enumerate(summary['windows']):
        sub=folder/('window_%03d'%m.INDICES[i]);data={n:(sub/n).read_bytes() for n in row['artifacts']}
        a2,w2=m.decode(data['op2_wire.bin'],4*i+1);m.need(w2==p2[0] and m.signed(data['op2_input.i8'])==a2,'independent Op2 wire')
        r2,c2,o2=m.pw(a2,*p2[:3]);m.need(m.ints(data['op2_raw.i32'])==r2 and m.ints(data['op2_corrected.i32'])==c2 and data['op2_output.i8']==o2==data['dw3_input.i8'],'independent Op2 raw/PS/INT8')
        acc,dyn=m.dw(m.signed(o2),*p3[:3]);m.need(m.ints(data['dw3_acc.i32'])==acc and data['dw3_output.i8']==dyn==data['op4_input.i8'],'independent dynamic DW3')
        a4,w4=m.decode(data['op4_wire.bin'],4*i+3);m.need(a4==m.signed(dyn) and w4==p4[0],'independent dynamic Op4 wire')
        r4,c4,o4=m.pw(a4,*p4[:3]);m.need(m.ints(data['op4_raw.i32'])==r4 and m.ints(data['op4_corrected.i32'])==c4 and data['op4_output.i8']==o4,'independent Op4 raw/PS/INT8')
        m.metrics(row['op2_driver_metrics'],4*i+1);m.metrics(row['op4_driver_metrics'],4*i+3)
        for layer,pars in [('op2',p2),('dw3',p3),('op4',p4)]:
            w=pars[3][0] if layer=='dw3' else bytes(pars[0][col*64+k]&255 for k in range(64) for col in range(64))
            m.need(data[layer+'_weights.i8']==w and data[layer+'_bias.i32']==pars[3][1] and list(struct.unpack('<64d',data[layer+'_scales.f64']))==pars[2], 'frozen parameter identity')
    m.need(len(summary['windows'])==12,'scalar full12')
    return dict(Op2_raw_values=96000,Op2_corrected_values=96000,Op2_INT8_values=96000,DW3_acc_values=96000,DW3_INT8_values=96000,Op4_raw_values=96000,Op4_corrected_values=96000,Op4_INT8_values=96000)
