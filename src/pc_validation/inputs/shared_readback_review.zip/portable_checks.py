"""External fresh-output recheck, with captured actual subprocess exits."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
H=Path(__file__).resolve().parent
def main():
    p=argparse.ArgumentParser();p.add_argument('--manifest-sha',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    out=Path(a.output).resolve()
    if out==H or H in out.parents or out.exists() or not out.parent.is_dir():raise ValueError('fresh external output required')
    out.mkdir();(out/'empty_cwd').mkdir();rows=[]
    commands=[['verify_bundle.py','--manifest-sha',a.manifest_sha],['run_verify.py','--output',str(out/'validation')],['verify_bundle.py','--manifest-sha',a.manifest_sha]]
    for i,args in enumerate(commands):
        cmd=[sys.executable,'-I','-B',str(H/args[0]),*args[1:]];r=subprocess.run(cmd,cwd=out/'empty_cwd',stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        (out/('%02d.stdout.txt'%i)).write_bytes(r.stdout);(out/('%02d.stderr.txt'%i)).write_bytes(r.stderr)
        rows.append(dict(argv=cmd,actual_exit=r.returncode,stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_sha256=hashlib.sha256(r.stderr).hexdigest()))
        if r.returncode:break
    result=dict(operation_success=len(rows)==3 and all(r['actual_exit']==0 for r in rows),commands=rows,board_access=False,promotion=False)
    (out/'portable_receipt.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n',encoding='utf8')
    print(json.dumps(result));raise SystemExit(0 if result['operation_success'] else 1)
if __name__=='__main__':main()
