"""Verify every regular bundle member without importing delivered code."""
import argparse,hashlib,json
from pathlib import Path,PurePosixPath
H=Path(__file__).resolve().parent
def verify(expected):
    raw=(H/'MANIFEST.json').read_bytes()
    if hashlib.sha256(raw).hexdigest()!=expected:raise ValueError('external top manifest pin')
    files=json.loads(raw)['files'];actual={}
    for p in H.rglob('*'):
        if p.is_symlink():raise ValueError('bundle symlink')
        if p.is_file() and p!=H/'MANIFEST.json':
            n=p.relative_to(H).as_posix();r=p.read_bytes();actual[n]=dict(bytes=len(r),sha256=hashlib.sha256(r).hexdigest())
    if actual!=files:raise ValueError('bundle files/bytes drift')
    return dict(operation_success=True,indexed_files=len(files),top_manifest_sha256=expected,board_access=False)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--manifest-sha',required=True);a=p.parse_args();print(json.dumps(verify(a.manifest_sha)))
