"""Pinned byte intake only; no candidate imports or board operations."""
import argparse, hashlib, json, shutil, stat, tarfile, zipfile
from pathlib import Path, PurePosixPath

H=Path(__file__).resolve().parent
ARCHIVE_SHA='7786d5eee69b1cd17c1296beee522d324ca5d7fff9cc3e6e1a3aea39010651b7'
RUNTIME_SHA='68a39ff1994851f2c169fdd388ce7346929e60dc6930bcffb2d64fd19f3f7c16'
KIT_SHA='26747c4a3f4b31321708a0508c4a6d3111c5cb9e29faed997bba84f1b8bf5e03'

def need(ok,why):
    if not ok: raise ValueError(why)
def meta(raw): return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def name_ok(name):
    p=PurePosixPath(name)
    need(name and '\\' not in name and ':' not in name and not p.is_absolute() and all(v not in ('','..','.') for v in name.split('/')),'unsafe member name')
    return p
def write_new(path,raw):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f: f.write(raw)
def main():
    p=argparse.ArgumentParser();p.add_argument('--archive',required=True);p.add_argument('--runtime',required=True);a=p.parse_args()
    source=Path(a.archive);runtime=Path(a.runtime)
    need(source.is_file() and not source.is_symlink() and runtime.is_file() and not runtime.is_symlink(),'plain inputs')
    ar=source.read_bytes();zr=runtime.read_bytes()
    need(meta(ar)=={'bytes':1956826,'sha256':ARCHIVE_SHA},'board archive pin')
    need(meta(zr)=={'bytes':6374135,'sha256':RUNTIME_SHA},'runtime pin')
    need(not (H/'kit').exists() and not (H/'extracted').exists(),'fresh extraction only')
    tar_members={};zip_members={}
    with tarfile.open(source,'r:gz') as tar:
        members=tar.getmembers();need(len(members)<=1000,'archive member bound')
        seen=set();total=0
        for m in members:
            name_ok(m.name);need(m.isfile() and not m.issym() and not m.islnk(),'regular tar member only')
            need(m.name=='readback.json' or m.name.startswith('work/'),'expected work scope')
            need(m.name.casefold() not in seen and 0<=m.size<=4000000,'unique bounded tar member');seen.add(m.name.casefold())
            total+=m.size;need(total<=30000000,'expanded archive bound')
            raw=tar.extractfile(m).read();need(len(raw)==m.size,'complete member read')
            tar_members[m.name]=meta(raw)
            write_new(H/'extracted'/m.name,raw)
    with zipfile.ZipFile(runtime) as z:
        need(z.testzip() is None,'ZIP CRC')
        members=z.infolist();need(len(members)==263,'exact runtime member count');seen=set()
        for m in members:
            name_ok(m.filename);need(not m.is_dir() and stat.S_IFMT(m.external_attr>>16)!=stat.S_IFLNK,'plain runtime file')
            need(m.filename.casefold() not in seen and 0<=m.file_size<=7000000,'unique bounded runtime member');seen.add(m.filename.casefold())
            raw=z.read(m);zip_members[m.filename]=meta(raw);write_new(H/'kit'/m.filename,raw)
        need(zip_members['kit_manifest.json']['sha256']==KIT_SHA,'external kit manifest pin')
        man=json.loads(z.read('kit_manifest.json'));need(set(zip_members)==set(man['files'])|{'kit_manifest.json'},'exact indexed runtime')
        for n,pin in man['files'].items(): need(zip_members[n]==pin,'runtime member pin '+n)
    write_new(H/'inputs'/'shared12_evidence_v1.tar.gz',ar)
    write_new(H/'inputs'/'pynq_kws_shared12_launch_20261026_v1.zip',zr)
    result=dict(operation_success=True,archive=meta(ar),runtime=meta(zr),tar_members=len(tar_members),expanded_bytes=sum(v['bytes'] for v in tar_members.values()),runtime_members=len(zip_members),kit_manifest_sha256=KIT_SHA,source_origin_authenticated=False,board_access=False,promotion=False)
    write_new(H/'intake.json',(json.dumps(result,sort_keys=True,indent=2)+'\n').encode())
    write_new(H/'original_members.json',(json.dumps(tar_members,sort_keys=True,indent=2)+'\n').encode())
    need(meta(source.read_bytes())==meta(ar) and meta(runtime.read_bytes())==meta(zr),'inputs unchanged')
    print(json.dumps(result))
if __name__=='__main__': main()
