"""Seal this PC-only review bundle and verify every zipped file."""
import hashlib,json,zipfile
from pathlib import Path
H=Path(__file__).resolve().parent
D=H.parent/'KWS-shared-board-readback-delivery-20261026_01'
def meta(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def main():
    D.mkdir();files={}
    for p in sorted(H.rglob('*')):
        if p.is_symlink():raise ValueError('symlink in bundle')
        if p.is_file():
            n=p.relative_to(H).as_posix()
            if n=='MANIFEST.json':raise ValueError('already sealed')
            files[n]=meta(p.read_bytes())
    man=(json.dumps(dict(schema='shared12-board-return-review-bundle-v1',files=files),sort_keys=True,indent=2)+'\n').encode()
    with (H/'MANIFEST.json').open('xb') as f:f.write(man)
    files['MANIFEST.json']=meta(man)
    target=D/'opennpu_kws_shared_session_board_readback_v1_review.zip'
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n in sorted(files):z.write(H/n,n)
    with zipfile.ZipFile(target) as z:
        if z.testzip() is not None or set(z.namelist())!=set(files):raise ValueError('ZIP file set/CRC')
        for n,pin in files.items():
            if meta(z.read(n))!=pin:raise ValueError('ZIP bytes '+n)
    result=dict(review_zip=str(target),**meta(target.read_bytes()),members=len(files),top_manifest_sha256=meta(man)['sha256'],indexed_files=len(files)-1,board_archive_sha256='7786d5eee69b1cd17c1296beee522d324ca5d7fff9cc3e6e1a3aea39010651b7',independent_review_pending=True,board_access=False,promotion=False)
    with (D/'identity.json').open('x') as f:json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
    print(json.dumps(result))
if __name__=='__main__':main()
