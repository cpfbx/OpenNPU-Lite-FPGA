"""Offline readback plus frozen independent scalar arithmetic; no board access."""
import argparse,hashlib,json,subprocess,sys,time
from pathlib import Path
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H))
from scalar_math import scalar_normal

def need(ok,why):
    if not ok: raise ValueError(why)
def meta(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def inventory(root):
    out={}
    for p in sorted(root.rglob('*')):
        need(not p.is_symlink(),'plain tree')
        if p.is_file():out[p.relative_to(root).as_posix()]=meta(p.read_bytes())
    return out
def load(p):return json.loads(p.read_bytes())
def write_new(p,value):
    with p.open('x',encoding='utf8') as f:json.dump(value,f,sort_keys=True,indent=2);f.write('\n')
def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args()
    v=Path(a.output).resolve()
    need(v!=H and H not in v.parents,'external validation output only')
    need(not v.exists() and v.parent.is_dir() and not v.is_symlink(),'fresh external output')
    v.mkdir()
    before={n:inventory(H/n) for n in ('inputs','kit','extracted')}
    w=H/'extracted/work';plan=load(w/'plan.json');request=load(w/'request.json')
    expected_plan='5874317f809279569bf2c1a259bfc4aa3d3298ecdede1fe18b358faa5c715a14'
    need(meta((w/'plan.json').read_bytes())['sha256']==expected_plan,'external plan pin')
    need(meta((w/'request.json').read_bytes())['sha256']=='5a8af15e58d93921a092b463545cc23f5de10e8641fd788f0d27906c0f0140ae','external request pin')
    command=[sys.executable,'-I','-B',str(H/'kit/shared.py'),'--kit-manifest-sha','26747c4a3f4b31321708a0508c4a6d3111c5cb9e29faed997bba84f1b8bf5e03','readback','--work',str(w),'--plan-sha',expected_plan,'--output',str(v/'frozen_readback.json')]
    started=time.monotonic();proc=subprocess.run(command,cwd=v,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (v/'reader.stdout.txt').write_bytes(proc.stdout);(v/'reader.stderr.txt').write_bytes(proc.stderr)
    write_new(v/'reader_command.json',dict(argv=command,actual_exit=proc.returncode,elapsed_seconds=time.monotonic()-started,stdout=meta(proc.stdout),stderr=meta(proc.stderr)))
    need(proc.returncode==0,'frozen reader actual exit')
    need((v/'frozen_readback.json').read_bytes()==(H/'extracted/readback.json').read_bytes(),'relocated reader byte equality')
    values=scalar_normal(w/'evidence/worker/data')
    outer=load(w/'evidence/outer_receipt.json');terminal=load(w/'evidence/worker/terminal.json');summary=load(w/'evidence/worker/data/summary.json')
    need(outer['operation_success'] is True and terminal['operation_success'] is True,'normal success')
    need(terminal['session']['completed_driver_returns']==24 and terminal['session']['reuse_checks']==49 and terminal['session']['close_attempts']==1,'single reused owner and close')
    need(summary['completed_indices']==[0,30,60,90,120,150,180,210,240,270,300,400],'fixed12')
    need([row['operator_index'] for row in summary['calls']]==[2,4]*12,'alternating24')
    need([row['first_job_id'] for row in summary['calls']]==list(range(1,49,2)),'continuous jobs1..48')
    metric_rows=[]
    for row in summary['windows']:
        for op in (2,4):
            metric=row['op%d_driver_metrics'%op]
            need('counter_evidence' not in metric,'no synthetic counter label')
            need(type(metric['status']) is int and metric['status']==5,'exact normal status')
            need(metric['failed_tile_index']==65535 and metric['error_code']==0,'exact sentinel and no hardware error')
            metric_rows.append(dict(cohort_index=row['cohort_index'],operator_index=op,first_job_id=metric['first_job_id'],status=metric['status'],failed_tile_index=metric['failed_tile_index'],effective_macs=metric['effective_macs'],pl_total_cycles=metric['pl_total_cycles'],counter_contract_version=metric['counter_contract_version']))
    need(len(metric_rows)==24 and sum(r['effective_macs'] for r in metric_rows)==12288000,'actual fixed pointwise workload')
    binaries={n:pin for n,pin in before['extracted'].items() if n.startswith('work/evidence/worker/data/') and Path(n).suffix in ('.bin','.i8','.i32','.f64')}
    need(len(binaries)==264,'22 binary artifacts per window')
    unchanged=all(inventory(H/n)==pins for n,pins in before.items());need(unchanged,'frozen inputs unchanged')
    result=dict(operation_success=True,scope='fixed12 shared-chain board return offline readback and scalar recomputation',samples=12,pointwise_requests=24,jobs=48,pointwise_macs=12288000,depthwise_logical_macs=864000,scalar_checks=sum(values.values()),values=values,binary_files=len(binaries),reader_relocated_byte_identical=True,reader_actual_exit=proc.returncode,actual_child_exit=outer['actual_exit_code'],parent_pid=load(w/'evidence/launch.json')['parent']['pid'],child_pid=terminal['pid'],lock_identity=request['expected_lock'],same_inode_release=outer['lock_released_same_inode'],inputs_unchanged=unchanged,stored_real_cross_layer_execution=outer['real_cross_layer_PL_execution'],inference_reexecuted=False,actual_board_access_by_this_audit=False,source_origin_authenticated=False,operator_exit_record_authenticated=False,performance_evaluated=False,energy_evaluated=False,classification_quality_evaluated=False,promotion=False)
    write_new(v/'scalar_and_lifecycle.json',result);write_new(v/'metric_rows.json',metric_rows);write_new(v/'binary_index.json',binaries)
    print(json.dumps(result))
if __name__=='__main__':main()
