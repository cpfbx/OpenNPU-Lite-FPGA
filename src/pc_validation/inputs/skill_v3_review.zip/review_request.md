# candidate_03 增量审查单（只读，禁止实板）

负责人 bx；作者 Codex/root；2026-10-20。本包是离线候选，不是安装包、
新默认或正式发布批准。父版 v2 ZIP SHA256：
`8abddf3c6637de3eac0e16beaee07b5e357948906d9c3efff665b28226027ef9`。
新 ZIP 的 SHA 请从包外 `review_bundle_receipt.json` 或发送者独立提供值核验；
内部清单与 ZIP 自洽不等于认证作者/硬件真实性。

## 本轮事实与改动

收到 Linux/gVisor Python 3.11.2 的原始日志包，SHA256：
`ae3c30c03f85efd568caebec1bf3ca1d8df78d36ecb2c30d4fc7c02bea44a6c1`。
已核对其绑定 v2 身份；82 项中 81 通过、1 断言失败、0 跳过、exit 1。
失败时路径已拒绝，旧测试仍只匹配 `escapes`。不把该失败改写成 v2 通过。
日志来自外部执行，不是本作者在 Windows 上跑出的 Linux 结果。

三项窄修复：

1. `tests/test_helpers.py`：旧软链测试匹配明确的 symlink/reparse/escapes
   拒绝原因；不放宽 `local_path` 运行时策略。
2. `inspect_overlay_strict.py`：在读取任何输入前要求 `.bit` 后缀（不区分
   大小写）；同 stem 的 `.hwh` 仍用小写后缀。HWH-only 输入返回 JSON、exit 2。
3. 同一严格工具：参数解析纳入 JSON 错误出口；未知选项、缺位置参数或缺选项值
   返回 stderr JSON、exit 2；`--help` 保持文本、exit 0。

新增 8 个测试方法，总数 90。含模拟执行实际旧软链测试断言的跨平台回归、
`.hwh/.HWH` 与其它后缀拒绝、`.bit/.BIT` 有效配对、三类 CLI 参数失败与帮助。
子测试/嵌套断言不另计独立测试数量。模拟链接不是真实 OS 链接证据。
三个历史脚本字节保留，旧实例名欺骗与旧 JSON 适配器限制仍仅披露/回归。
没有扩展到父目录别名拒绝、BIT 格式解析、硬件认证或新项目门限。

## Linux/另一环境复核步骤

解压到新目录，日志存到 candidate 外，不往包内生成缓存。Python 3.10+
标准库即可。进入 `candidate/`，分别运行并保存每条 stdout/stderr/exit：

```text
python3 -I -B verify_candidate.py
python3 -I -B tests/run_tests.py
python3 -I -B skill/pynq-gemm-validation/scripts/validate_gemm_evidence.py --self-test
python3 -I -B skill/pynq-gemm-validation/scripts/validate_resilience_evidence.py --self-test
python3 -I -B skill/engineering-evidence-review/scripts/check_evidence_links.py evaluation/link_example.json --root evaluation/fixtures
python3 -I -B verify_candidate.py
```

回收 OS/架构、Python 版本、ZIP/manifest SHA、上述原始输出与退出码，
并确认 candidate 文件未变。90 项是当前实际方法数，不先写“90 全通过”；
若环境不允许真实软链/FIFO，保留 skip 及原因，不用模拟结果冲销。

可在包外临时目录重建三个反例；请勿把包含代码的审查附件当作执行授权。
重点检查异常断言是否仍检验拒绝而非简单吞异常，后缀是否在读取前拦截，
CLI 错误是否 stderr JSON/exit 2，以及正常配对和 --help 是否保持可用。

## 限制与后续

作者 Windows Python 3.12 首轮：90 项、85 通过、5 跳过、exit 0；
正式封装和换解释器结果在包外日志，不能当作独立审查或 Linux 新版通过。
本包不含实际 BIT/HWH、原始音频、私密路径日志或开发板运行入口。
真实陌生使用者试用、行为 A/B 未运行；也不将 A/B 伪称新增官方强制关口。
第三方评测若要盲测，请先独立做 evaluation/tasks.json，不预读作者测试或评分键；
已读本单及上下文者不能声称零上下文盲测。最终安装/发布由 bx 决定。
