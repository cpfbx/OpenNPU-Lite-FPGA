# KWS 固定 12 窗完整混合推理候选（`opennpu_kws_full_hybrid_candidate_v1`）离线实现与交接报告

**人类最终决定者**：`bx`  
**实现者**：Gemini 离线实现会话（Linux x86_64，Python `3.11.2` / NumPy `1.24.2`）  
**独立离线审查与复跑者**：Codex `/root`  
**当前状态**：`candidate_default_off`（1 窗冒烟 `smoke1`、固定 12 窗完整模式 `fixed12`、17 项正反例单测 `unit_tests` 及 5 项 CLI 负例门禁全部实跑通过，`promotion=false`，`board_access=false`，`vad_recomputed=false`）

---

## 1. 所用前置包与五份冻结源完整性核验（Baseline Pins）

本实现严格基于 `bx` 提供的《`opennpu_kws_full_hybrid_prerequisites_v1.zip`》前置包，在包外独立目录解包并全程保持五份 `source_bundles` **零字节改动**（`frozen_sources_unchanged = true`）：

| 资产 / 锚点路径 | 字节数 (Bytes) | SHA256 | 状态 |
|---|---:|---|---|
| `opennpu_kws_full_hybrid_prerequisites_v1.zip` | `22,299,839` | `fae95a89a7bbefc4a26f281e05997b1ff7df8e9b68d44735a954e61c6ac49bd4` | 原包核验一致 |
| 前置包 `manifest.json` | `4,295` | `524927755ea6e403c834fee7a518a0c9d2816b499a305a2c154a27b32f55e357` | `unpack_sources.py` 校验通过 |
| `cpu/review_manifest.json` | `59,682` | `b4967d0f13c75a621fa8b09aa08cf9d7f554ff3d900df3d7c3f0989885575c96` | 冻结未改 |
| `cpu/candidate_05/artifacts/manifest.json` | `2,953` | `9efcd1f5e766b0267f003f2ba4d5c9a409a81ebcdff056d573eb9cc63042f611` | 冻结未改 |
| `shared/kit_manifest.json` | `15,152` | `df730a4beeb5f8ba5ddadffef7f2259212101bc158eb388e5b0f473f597d1912` | 冻结未改 |
| `shared/kws_op2_op4_shared_driver_v1/manifest.json` | `1,896` | `7853b37a0c7f22503e3940254a97bb6581c04f1e6b6b51e437645c17691b9302` | 冻结未改 |
| `quality/MANIFEST.json` | `1,622` | `be2c921c7e73d5aa22c289882964cbefbd6fd63f3858a124202960ac85c94609` | 冻结未改 |
| `selection12.json` | `19,351` | `ca27035ec54d2b4534bb96e2cf68991d74021c0744e5e0a6e179129f6196e595` | 冻结未改 |
| `shared_board.tar.gz` | `12,188,805` | `c852e819a21f48e662b1008568f1cb40292d1fa0d7f9f5b4be3f7bf677fb4a20` | 冻结未改（实板留存核对通过） |
| `cpu420_board.tar.gz` | `924,524` | `66a69535432527e963d93f78b337bdad0c4d1912b38ab73bf920ecde2ef67da2` | 冻结未改（实板留存核对通过） |

---

## 2. 候选源码清单与外部 Pin（`candidate/`）

候选实现位于独立目录 `candidate/`，包含 5 份源码/文档文件及封板清单 `candidate/manifest.json`：

* **候选清单 `candidate/manifest.json` 外部 Pin SHA256**：
  `e9fe21968e8ba302799d747e63bd0fc0f18dcc041ad741db141b731943e6a2d6`（`1,244` Bytes）

| 文件名 | 字节数 (Bytes) | SHA256 | 职责说明 |
|---|---:|---|---|
| `hybrid_contract.py` | `15,868` | `62a9d22248155a9c18a3919fa7a32f9e0a5ff25bf4e0d8c709e40f258ab0c910` | 严格 JSON 解析、候选与五份冻结源完整性校验、21 份常量与模型描述符字节级交叉核对、板卡实板 tar.gz 留存核对、默认关闭门禁与新输出目录校验 |
| `hybrid_graph.py` | `30,084` | `dc23c31d7db53726c8ec07a5a753ef73ddcd5e3a4fa07b4212650b5db0a68148` | `HybridGraphExecutor`（WAV 前处理 `Frontend.process` → CPU 前缀 `Op0..Op1` → 单会话 `SharedDeviceSession` + `WireEnvironment` 驱动 `Op2` → CPU `DW3` → 驱动 `Op4` → CPU 后缀 `Op5..Op11` 产出 `tensor33` INT8 pre-softmax logits → 冻结策略与历史 PCM 绑定 VAD 门控评估） |
| `run_hybrid_candidate.py` | `8,546` | `db37881305c9f083e266de04f29ff849d61d7eb339784c90364592c920d36da2` | 默认关闭便携 CLI 入口，支持 `--mode {smoke1,fixed12,tests,all}`，强制校验 `--enable-hybrid-offline`、`--manifest-sha`、解包源完整性及包外新输出目录 |
| `test_hybrid_candidate.py` | `19,391` | `fb6bf52605db4b8be8dfef4282b86097a299b08eb0505b037cf7762de0a86dd0` | 17 项正反例与破坏性注入单元测试（覆盖 `acceptance.md` 全部正向硬门与负例类别，0 skip） |
| `readme.md` | `4,539` | `ff11f6b64ce9e1c3f8214459c7f818eb4dc28a4fc79c4c63d3f7fd2909352494` | 候选结构、算子接线范围、复现命令与诚实边界说明 |

---

## 3. 核心架构与防旁路（No-Golden-Substitution）证明

1. **端到端动态计算链路**：
   $$\text{Public WAV} \xrightarrow{\text{Frontend.process}} \text{tensor0 }(49\times 10\text{ INT8}) \xrightarrow{\text{CPU Op0, Op1}} \text{tensor23 }(125\times 64\text{ INT8}) \xrightarrow{\text{SharedCall Op2 (Wire)}} \text{tensor24} \xrightarrow{\text{CPU DW3}} \text{tensor25} \xrightarrow{\text{SharedCall Op4 (Wire)}} \text{tensor26} \xrightarrow{\text{CPU Op5..Op11}} \text{tensor33 }(1\times 12\text{ INT8 pre-softmax logits})$$
2. **严禁黄金替代（Zero Golden Substitution）**：
   * `Frontend.process` 直接从 `cpu/candidate_05/public_wav/` 读取 WAV 并按固定偏移截取 16,000 个 PCM 样本动态计算 `49×10` INT8 特征（单窗 `490` 标量，12 窗 `5,880` 标量），再与 `selection12.json` / `fixed_features.i8` 交叉核验。
   * `run_prefix` 仅接收动态计算的 `feat` 数组，依次执行 `Op0`（`CONV_2D`）和 `Op1`（`DEPTHWISE_CONV_2D`）生成全新 owning C-contiguous `int8(125, 64)` 张量 `tensor23`；绝不从 `REFERENCE.derive(2, idx)['a']` 回填。
   * `Op2` 与 `Op4` 通过单会话 `SharedDeviceSession` 和 `WireEnvironment` 软件夹具执行：`Op2` 消费动态 `tensor23` 产出 `tensor24`，`CPU DW3` 消费动态 `tensor24` 产出 `tensor25`（61 行尾块 + 3 行零填充，共 `864,000` 含填充逻辑 MAC），`Op4` 消费动态 `tensor25` 并通过 `unpack_jobs(env.last_send)` 逆向解包核实实际 wire 字节等于当前 `DW3` 动态输出 `tensor25`。
   * `run_suffix` 仅接收 `Op4` 真实返回的 `tensor26`，依次动态计算 `Op5(DW) -> Op6(PW) -> Op7(DW) -> Op8(PW) -> Op9(AVG_POOL) -> Op10(RESHAPE) -> Op11(FC)` 产出 `tensor33`（`1×12` INT8 pre-softmax logits），**不执行** TFLite 内部 quantized `SOFTMAX`（算子 12 / `tensor34`），且绝不直接读取 `expected_logits` 返回。
   * 在每个窗口的 `result.json` 中，`actual_dynamic_payload_identity` 与 `operator_trace` 记录了从 `tensor0` 到 `tensor33` 每个算子输入/输出缓冲区的动态内存对象属性与 SHA256 哈希，配合 `test_11`（扰动前端特征）、`test_12`（扰动前缀 `tensor23`）、`test_13`（扰动 `Op4` 输出 `tensor26` 并包含量化掩盖负对照）证实全链路不存在黄金值旁路。
3. **分类与冻结门控评估（历史 VAD 明确单列）**：
   * 使用动态计算的 `tensor33` INT8 logits 与固定量化参数（`scale = 0.14469251036643982`, `zero_point = 14`）反量化后送入 `quality/src/voice_gate_candidate.py` 的 `evaluate_gate`（冻结策略 `mode=0, min_voiced_frames=3, min_voiced_run=3, min_score=0.95, min_score_gap=0.0`）。
   * 门控所需的 VAD 侧输入使用 `quality/artifacts/results.json` 中通过 `(cohort_index, source_id, source_sha256, pcm_sha256)` 严格四重绑定的历史 `NativeVAD` 帧标记；所有产物与汇总 JSON 均显式记录 `vad_recomputed = false` 与 `vad_source = "historical_fixed_pcm"`，绝不声称重算了 `NativeVAD`。

---

## 4. 实跑结果汇总（`smoke1`、`fixed12`、`unit_tests` 与 CLI 负例）

### 4.1 统一验证入口实跑（`--mode all --enable-hybrid-offline`）

在空工作目录 `/tmp/empty_cwd` 下执行：
```bash
python3 -I -B /path/to/candidate/run_hybrid_candidate.py \
  --manifest-sha e9fe21968e8ba302799d747e63bd0fc0f18dcc041ad741db141b731943e6a2d6 \
  --sources /path/to/unpacked_sources \
  --output /path/to/run_all \
  --mode all \
  --enable-hybrid-offline
```
* **总退出码**：`0`（耗时 `296.36s`）
* **子阶段退出码**：`01_smoke1 = 0`，`02_fixed12 = 0`，`03_unit_tests = 0`
* **关键产物 SHA256**：
  * `validation_runs/run_all/receipt.json`：`44b48dc1c6b77f8e0706c5973b22ff4064a171c22e91f525bc3b55cc740254a5`（`2,477` B）
  * `validation_runs/run_all/smoke1/summary.json`：`67f65cc13300fb3e0c03a15a12b5f3a33aacc420b4f8c7d53e0d87da20a61486`（`29,317` B）
  * `validation_runs/run_all/smoke1/features.i8`：`6767321f1466d5e533f3e478ce8e1f87e3ba49891b49c0fdbd549490eedced6a`（`490` B）
  * `validation_runs/run_all/smoke1/logits.i8`：`0b95ef35a89a843866dbf8b13b46778fc484e6d06f631036c3c986f5361470bd`（`12` B）
  * `validation_runs/run_all/fixed12/summary.json`：`bb1dcdb912d5c7a3cc0bb82475fd345387f7e6e6ab1e0f365379da83b77b28fd`（`278,192` B）
  * `validation_runs/run_all/fixed12/features.i8`：`5435a1342b7040b12fed5711a0e9c8e2197f3ded2ad343e467bc091d74bd1b5d`（`5,880` B，与冻结特征 100% 一致）
  * `validation_runs/run_all/fixed12/logits.i8`：`aac5c4bda5d9124d49a09add9421f08e97475cbf740416a13bd419fb2641c19f`（`144` B，与冻结参考及 `cpu420_board.tar.gz` 实板留存 100% 一致）

### 4.2 固定 12 窗（`fixed12`）逐窗混合推理与门控结果表

单会话指标：`1` 次 `start`、`1` 次 `close`、交替 `24` 次 `SharedCall`（`12` 次 `Op2` + `12` 次 `Op4`）、`48` 个 jobs（连续 ID `1..48`）、`12,288,000` Pointwise MAC、`12` 次 `DW3`（`864,000` 含填充逻辑 MAC）、每层 `raw`/`corrected`/`INT8` 各 `96,000` 标量精确相等、`DW3` 累加器与 `INT8` 各 `96,000` 标量精确相等：

| 窗号 (`cohort_index`) | 真实标签 (`label`) | 动态 `tensor33` INT8 Logits (12 类) | 预测类别 (`prediction`) | Top-1 Softmax Score | Score Gap | 门控放行 (`action_allowed`) | 建议指令 (`suggested_command`) | 门控拒绝原因 (`rejection_reasons`) | `vad_recomputed` |
|---:|---|---|---|---:|---:|---|---|---|---|
| `0` | `down` | `[57, 6, -53, -16, -27, 21, -47, 3, -29, -34, -56, 27]` | `down` | `0.980816` | `0.968039` | `True` | `down` | `[]` | `False` |
| `30` | `go` | `[27, 31, -38, 50, -39, -35, -23, -44, -56, -32, -90, 35]` | `no` | `0.823705` | `0.729693` | `False` | `None` | `['low_score']` | `False` |
| `60` | `left` | `[-57, -16, 58, -3, 5, -74, -5, -42, -33, 15, -58, 21]` | `left` | `0.992590` | `0.987894` | `True` | `left` | `[]` | `False` |
| `90` | `no` | `[23, 19, -28, 96, -60, -63, -51, -69, -76, -9, -128, 24]` | `no` | `0.999929` | `0.999900` | `True` | `no` | `[]` | `False` |
| `120` | `off` | `[-32, -23, 7, -30, 82, 29, -53, -17, 22, 4, -53, 1]` | `off` | `0.999322` | `0.998856` | `True` | `off` | `[]` | `False` |
| `150` | `on` | `[61, 9, -85, -28, -21, 41, -46, -32, -35, -71, -97, 37]` | `down` | `0.920005` | `0.869071` | `False` | `None` | `['low_score']` | `False` |
| `180` | `right` | `[-52, -11, 9, -22, -53, -28, 97, -55, -23, -73, -40, 31]` | `right` | `0.999926` | `0.999854` | `True` | `right` | `[]` | `False` |
| `210` | `stop` | `[-28, 4, -40, -25, -6, -24, -40, 80, 0, -46, -83, 8]` | `stop` | `0.999939` | `0.999909` | `True` | `stop` | `[]` | `False` |
| `240` | `up` | `[-61, -32, -1, -41, 19, -12, -13, -2, 60, -40, -40, 18]` | `up` | `0.994748` | `0.992110` | `True` | `up` | `[]` | `False` |
| `270` | `yes` | `[-25, -15, 30, 33, -26, -62, -44, -49, -43, 80, -83, 16]` | `yes` | `0.998073` | `0.996962` | `True` | `yes` | `[]` | `False` |
| `300` | `_unknown_` | `[-13, -17, -59, -53, -40, 2, -13, -52, -26, -52, -68, 96]` | `_unknown_` | `0.999998` | `0.999997` | `False` | `None` | `['model_noncommand']` | `False` |
| `400` | `_silence_` | `[-4, -4, -8, -21, -18, 3, 8, -27, -14, 11, 80, 27]` | `_silence_` | `0.999427` | `0.998960` | `False` | `None` | `['model_noncommand']` | `False` |

### 4.3 17 项正反例单元测试（`test_hybrid_candidate.py`）与 5 项 CLI 负例日志

* **单元测试（`17/17 PASS`，`failures=0, errors=0, skipped=0`）**：
  1. `test_01_default_off_gates`：未传 `enabled=True` 时 `load_hybrid_bundle`、`HybridGraphExecutor`、`run_hybrid_session` 全部拒绝。
  2. `test_02_wrong_candidate_manifest_pin_rejected`：错误 `--manifest-sha` 立即拒绝。
  3. `test_03_existing_or_inside_output_rejected`：已存在目录、`candidate/` 内目录、解包源内目录全部拒绝。
  4. `test_04_modified_frozen_source_rejected`：篡改解包源内任意字节立即触发 `frozen source bundle modified` 拒绝。
  5. `test_05_strict_json_rejects_duplicate_keys_and_nan`：重复键或 `NaN`/`Infinity` 立即拒绝。
  6. `test_06_cross_window_or_wrong_layer_or_wrong_tensor_rejected`：跨窗、错层、错张量编号在派发前拒绝。
  7. `test_07_wrong_source_id_or_bool_index_rejected`：错误 `source_id` 或 `bool` 冒充 `cohort_index` 在派发前拒绝。
  8. `test_08_non_owning_or_wrong_dtype_input_rejected_before_dispatch`：非 owning 视图（`base is not None`）或非 `int8` 输入在派发前拒绝。
  9. `test_09_op2_op4_case_or_weight_swap_rejected`：同形状 `Op2`/`Op4` 的 `case` 或 `weights` 互换立即拒绝。
  10. `test_10_repeat_call_or_duplicate_permit_rejected`：同一 `SharedCall` 重复调用或重复消费 permit 立即拒绝。
  11. `test_11_perturbed_frontend_output_intercepted`：前端特征扰动 1 LSB 被特征门拦截，证明未旁路前端。
  12. `test_12_perturbed_prefix_output_intercepted_not_replaced_by_golden`：CPU 前缀 `tensor23` 扰动 1 LSB 被下游输入门拦截，证明未从 `derive(2, idx)['a']` 回填黄金输入。
  13. `test_13_perturbed_op4_output_consumed_by_suffix_with_quantization_masking_control`：在测试接缝注入大幅与微幅 `tensor26` 扰动，同时验证大幅扰动改变 `tensor27..tensor33`、微幅扰动改变 `Op5` 累加器但被重量化掩盖（保留量化掩盖负对照，证明后缀真实消费 `tensor26` 且不能仅凭最终 `argmax` 判定是否旁路）。
  14. `test_14_window90_raw_fault_rejected_before_relu_and_saves_first_failure`：窗 90 负值区最低位翻转（经 ReLU 会被掩盖为 0）仍在 `raw` 阶段拒绝并留存有界首错，已完成窗数 `= 3`（窗 `0, 30, 60`），不自动重试。
  15. `test_15_window90_stop_before_depthwise_cleanly_aborts`：窗 90 `stop_before_depthwise` 干净中止，`completed_indices = [0, 30, 60]`，正常释放会话。
  16. `test_16_window90_unsafe_start_failure_retains_owner_without_fake_close`：窗 90 `unsafe_start_failure` 保持 `held=True, lease_retained=True, safety_unresolved=True, owner_closed=False`，绝不假冒 `close`，并通过有限 supervisor 夹具退出而不死锁宿主机。
  17. `test_17_vad_cross_window_pcm_or_wrong_quantization_or_recomputed_claim_rejected`：跨窗串用 VAD、错误 `scale`/`zero_point`、或谎称 `claim_vad_recomputed=True` 全部拒绝。
* **5 项 CLI 负例实跑日志（位于归档包 `validation_runs/negative_cli_logs/`）**：
  * `01_missing_enable_flag`（未传 `--enable-hybrid-offline`）：`EXIT=1`，抛出 `ValueError: hybrid offline candidate is default-off (pass --enable-hybrid-offline)`
  * `02_wrong_manifest_sha`（错误 `--manifest-sha`）：`EXIT=1`，抛出 `ValueError: external candidate manifest pin mismatch`
  * `03_existing_output_dir`（已存在输出目录）：`EXIT=1`，抛出 `ValueError: fresh output directory required (already exists)`
  * `04_output_inside_candidate`（输出目录位于 `candidate/` 内）：`EXIT=1`，抛出 `ValueError: output directory must be outside candidate directory`
  * `05_output_inside_sources`（输出目录位于解包源目录内）：`EXIT=1`，抛出 `ValueError: output directory must be outside unpacked sources directory`

---

## 5. 诚实边界声明（Honest Boundaries）

* **本交接包证明的内容**：固定 12 窗完整 WAV 前处理、CPU 前缀（`Op0..Op1`）、已有共享驱动与实际 wire 软件夹具（`Op2` / `Op4`）、CPU 中间层（`DW3`）、CPU 后缀（`Op5..Op11` 至 `tensor33` INT8 pre-softmax logits）、分类及固定历史 PCM 绑定 VAD 侧输入下的冻结门控在离线 PC 软件环境中的完整接线与正反例门禁通过。
* **本交接包不声称的内容**：
  * 未在 Zynq 实板上执行本次新完整混合图（`board_access = false`, `real_DMA_executed = false`, `real_cross_layer_PL_execution = false`）；
  * 未重新执行 `NativeVAD` C 二进制（`vad_recomputed = false`, `vad_source = "historical_fixed_pcm"`）；
  * 未扩大到 420 窗共享执行、未改动量化或门控阈值、未声称分类质量提升（窗 `30` 与窗 `150` 仍保持原模型预测并由门控按 `low_score` 拦截）、未开启默认晋升（`promotion = false`, `run_ready = false`）。
