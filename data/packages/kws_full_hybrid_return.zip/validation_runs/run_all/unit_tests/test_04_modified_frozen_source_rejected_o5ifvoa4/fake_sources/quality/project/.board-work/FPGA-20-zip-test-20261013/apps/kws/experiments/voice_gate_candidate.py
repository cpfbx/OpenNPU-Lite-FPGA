"""Default-off action rejection candidate, leaving model predictions unchanged."""
from dataclasses import dataclass,asdict
import math

LABELS=('down','go','left','no','off','on','right','stop','up','yes','_silence_','_unknown_')

@dataclass(frozen=True)
class Policy:
    mode:int
    min_voiced_frames:int
    min_voiced_run:int
    min_score:float
    min_score_gap:float

    def __post_init__(self):
        for name,lo,hi in (('mode',0,3),('min_voiced_frames',1,50),('min_voiced_run',1,50)):
            value=getattr(self,name)
            if type(value) is not int or not lo<=value<=hi:raise ValueError('invalid policy '+name)
        for name in ('min_score','min_score_gap'):
            value=getattr(self,name)
            if type(value) not in (int,float) or not math.isfinite(value) or not 0<=value<=1:
                raise ValueError('invalid policy '+name)

def scores(logits):
    if not isinstance(logits,(tuple,list)) or len(logits)!=12:
        raise ValueError('exactly 12 original logits required')
    if any(type(x) not in (int,float) or not math.isfinite(x) for x in logits):
        raise ValueError('finite numeric logits required')
    maximum=max(logits);values=[math.exp(x-maximum) for x in logits];total=sum(values)
    probabilities=[x/total for x in values]
    order=sorted(range(12),key=lambda i:(-probabilities[i],i))
    return dict(index=order[0],label=LABELS[order[0]],score=probabilities[order[0]],
        score_gap=probabilities[order[0]]-probabilities[order[1]],
        interpretation='softmax scores, not calibrated probabilities')

def decide(logits,vad,policy,*,enabled=False,numeric_verified=False):
    if enabled is not True:raise ValueError('action rejection candidate default-off')
    if not isinstance(policy,Policy):raise ValueError('explicit frozen policy required')
    raw=scores(logits)
    if (vad.get('mode')!=policy.mode or vad.get('frame_ms')!=20 or vad.get('total_frames')!=50
            or not isinstance(vad.get('flags'),list) or len(vad['flags'])!=50
            or any(type(x) is not int or x not in (0,1) for x in vad['flags'])):
        raise ValueError('invalid/foreign VAD report')
    current=longest=0
    for flag in vad['flags']:
        current=current+1 if flag else 0;longest=max(longest,current)
    if vad.get('voiced_frames')!=sum(vad['flags']) or vad.get('longest_voiced_run')!=longest:
        raise ValueError('VAD aggregate drift')
    reasons=[]
    if numeric_verified is not True:reasons.append('numeric_unverified')
    if raw['index']>=10:reasons.append('model_noncommand')
    if sum(vad['flags'])<policy.min_voiced_frames or longest<policy.min_voiced_run:
        reasons.append('insufficient_voice')
    if raw['score']<policy.min_score:reasons.append('low_score')
    if raw['score_gap']<policy.min_score_gap:reasons.append('ambiguous_score')
    allow=not reasons
    return dict(raw_prediction=raw['label'],original_logits=list(logits),
        suggested_command=raw['label'] if allow else None,action_allowed=allow,
        rejection_reasons=reasons,score=raw['score'],score_gap=raw['score_gap'],
        score_interpretation=raw['interpretation'],policy=asdict(policy),
        production_changed=False,promotion=False,
        scope='offline proposed action only; original classification is never relabelled')
