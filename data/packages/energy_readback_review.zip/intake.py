"""Local-only safe intake. Never execute returned archive members."""
import hashlib
import argparse
import json
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import sys
import tarfile

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
ARCHIVE = BASE/'energy-activation-20261024_02/board_return_3f13083a36bc43e9919508d87110f96d/energy_AadlGFiu_evidence_v1.tar.gz'
EXPECTED = '0958892fc925f59b5a52afa40aab82ec2ad424ca98e8cf5b6b69816c523701ff'
KIT = BASE/'metrics-msaa-compat-20261024_01/candidate_01'
PC = BASE/'energy-activation-20261024_02/pc_snapshot_01/work'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(root):
    result = {}
    for p in sorted(root.rglob('*')):
        require(not p.is_symlink() and not getattr(p, 'is_junction', lambda: False)(), 'aliased input')
        s = p.lstat()
        require(stat.S_ISREG(s.st_mode) or stat.S_ISDIR(s.st_mode), 'special input')
        if p.is_file():
            result[p.relative_to(root).as_posix()] = dict(bytes=s.st_size, sha256=sha(p))
    return result


def main():
    global ARCHIVE, KIT, PC
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', type=Path, default=ARCHIVE)
    parser.add_argument('--kit', type=Path, default=KIT)
    parser.add_argument('--pc-work', type=Path, default=PC)
    parser.add_argument('--output', type=Path, default=HERE/'intake_01')
    args = parser.parse_args()
    ARCHIVE, KIT, PC = [p.resolve(strict=True) for p in (args.archive, args.kit, args.pc_work)]
    require(ARCHIVE.stat().st_size == 6858082 and sha(ARCHIVE) == EXPECTED, 'archive identity')
    output = args.output.absolute()
    require(output.resolve() == output, 'canonical output')
    require(all(output != p and not output.is_relative_to(p) and not p.is_relative_to(output) for p in (KIT,PC)), 'isolated output')
    require(not output.exists(), 'fresh output required')
    before = {'kit': inventory(KIT), 'pc': inventory(PC)}
    require(sha(KIT/'kit_manifest.json') == 'cf6e3578529d2237d4c732b3935284c2211c1c6c629cab807cd0a709bb72a8d6', 'externally pinned full kit')
    kit_manifest=json.loads((KIT/'kit_manifest.json').read_bytes())
    require(set(before['kit']) == set(kit_manifest['files']) | {'kit_manifest.json'}, 'full kit member set')
    require(all(before['kit'][k] == v for k,v in kit_manifest['files'].items()), 'all frozen kit members match')
    with tarfile.open(ARCHIVE, 'r:gz') as archive:
        members = archive.getmembers()
        require(len(members) <= 1000 and sum(m.size for m in members) <= 100_000_000, 'archive bounds')
        seen = set()
        records = []
        for m in members:
            p = PurePosixPath(m.name)
            require(m.name and not p.is_absolute() and '\\' not in m.name and ':' not in m.name, 'unsafe path')
            require(all(x not in ('', '.', '..') for x in m.name.split('/')), 'noncanonical path')
            require(p.parts[0] in ('energy_prepare_AadlGFiu', 'energy_prepare_m934k11g'), 'unexpected root')
            key = m.name.casefold()
            require(key not in seen, 'duplicate or case collision')
            seen.add(key)
            require(m.isfile() or m.isdir(), 'link or special member')
            require(0 <= m.size <= 32_000_000, 'member size')
            require(all(not x.endswith(('.', ' ')) and not any(c in x for c in '<>"|?*') for x in p.parts), 'Windows unsafe name')
            require(all(x.split('.')[0].upper() not in {'CON','PRN','AUX','NUL',*(f'COM{i}' for i in range(10)),*(f'LPT{i}' for i in range(10))} for x in p.parts), 'reserved name')
            records.append(dict(name=m.name, bytes=m.size, kind='file' if m.isfile() else 'directory'))
        # All members validated before creating output or extracting anything.
        output.mkdir()
        extracted = output/'board'
        extracted.mkdir()
        for m in members:
            dest = extracted.joinpath(*PurePosixPath(m.name).parts)
            require(dest.resolve().is_relative_to(extracted.resolve()), 'containment')
            if m.isdir():
                dest.mkdir(parents=True, exist_ok=True)
            else:
                dest.parent.mkdir(parents=True, exist_ok=True)
                with archive.extractfile(m) as source, dest.open('xb') as target:
                    shutil.copyfileobj(source, target)
                require(dest.stat().st_size == m.size, 'extracted size')
    work = extracted/'energy_prepare_AadlGFiu/work'
    require((work/'launcher_exit.txt').read_text().strip() == '0', 'successful launcher exit')
    require(sha(work/'plan.json') == '141d9f548de54066150f64da1575dbe7204857dd73cabd98a0935f5930c2a610', 'plan')
    require(sha(work/'settings.json') == '9c27ee1ab8607c1c5f224e89b0ae3d6de33f6912398c8d465c29d9fbdd860bdd', 'settings')
    for name in ('plan.json', 'settings.json', 'preflight.json', 'policy_source.json'):
        require((work/name).read_bytes() == (PC/name).read_bytes(), 'board/PC configuration mismatch '+name)
    board_before=inventory(extracted)
    command = [sys.executable, '-I', '-B', str(KIT/'energy/src/readback_candidate.py'),
        '--manifest-sha', '456e6e783a7d85ff2393cafe7f7a990bf7b2a69d5778babfb6381bbfebf9d4f6',
        '--settings-sha', sha(work/'settings.json'), '--board', str(work/'evidence'),
        '--pc', str(PC/'evidence'), '--settings', str(work/'settings.json'), '--output', str(output/'frozen_readback_01')]
    process = subprocess.run(command, capture_output=True)
    (output/'frozen.stdout.txt').write_bytes(process.stdout)
    (output/'frozen.stderr.txt').write_bytes(process.stderr)
    after = {'kit': inventory(KIT), 'pc': inventory(PC)}
    require(before == after and sha(ARCHIVE) == EXPECTED and inventory(extracted)==board_before, 'original input mutated')
    record = dict(scope='local author intake and frozen offline validator, not independent review or promotion',
        archive=str(ARCHIVE), archive_sha256=EXPECTED, members=records, extracted_files=inventory(extracted),
        input_inventories=before, originals_unchanged=True, frozen_command=command,
        frozen_actual_exit=process.returncode, board_access=False, promotion=False)
    (output/'intake.json').write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(dict(archive_identity=True, archive_members=len(records), files=len(record['extracted_files']),
        original_inputs_unchanged=True, frozen_actual_exit=process.returncode)))
    print(process.stdout.decode(errors='replace'))
    if process.stderr:
        print(process.stderr.decode(errors='replace'))


if __name__ == '__main__':
    main()
