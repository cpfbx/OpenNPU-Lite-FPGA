"""Read-only, whole-file diagnostics after validated ABBA receipts. No runtime IO."""
import csv
from decimal import Decimal,localcontext
import io

def analyze_window(raw, *, importer,guard,policy,mapping,mapping_basis,host_sha,expected_sha):
    parsed=importer.analyze_bytes(raw,expected_sha256=expected_sha,mapping=mapping,
        mapping_basis=mapping_basis,host_exe_sha256=host_sha,encoding='gb18030')
    parsed['importer_sha256']='3baf31a8f6d0e98f40ccc8365072182e6637e43b8ba7ee2d14978804755f8afc'
    # Inspect original lexical fields; NEVER rewrite header or pad/truncate Wh.
    fields=list(csv.reader(io.StringIO(raw.decode('gb18030')),strict=True))[1:]
    peak=max(importer.number(r[2]) for r in fields)
    endpoint_exponents=[importer.number(r[6]).as_tuple().exponent for r in (fields[0],fields[-1])]
    with localcontext() as ctx:
        ctx.prec=80
        quanta=[Decimal(10)**e for e in endpoint_exponents]
    checks=dict(grid_100ms=parsed['timestamp_step_ms']=='100',power_at_most_5W=peak<=Decimal('5'),
        endpoint_text_step_at_most_1e_minus6_Wh=all(q<=Decimal('0.000001') for q in quanta),
        saved_span_at_least_60s=Decimal(parsed['csv_time_span_seconds'])>=60,
        saved_span_below_1800s=Decimal(parsed['csv_time_span_seconds'])<1800)
    applicable=all(checks.values()); numeric=None; error=None
    if applicable:
        try: numeric=guard.inspect(parsed,policy=policy)
        except ValueError as failure: error=str(failure)
    return dict(import_result=parsed,basis_checks=checks,basis_applicable=applicable,
        original_power_peak_W=str(peak),wh_endpoint_lexical_quanta_Wh=[str(q) for q in quanta],
        lexical_precision_not_integrator_precision=True,
        stripped_trailing_zeros_may_cause_conservative_basis_rejection=True,
        numeric_consistency_evaluated=applicable,numeric_consistency_passed=None if not applicable else numeric is not None,
        guard_result=numeric,guard_error=error,diagnostic_passed=applicable and numeric is not None,
        scope='entire saved envelope; no synchronized task energy',joules_per_task_evaluated=False,
        meter_accuracy_verified=False,formal_energy_input_accepted=False,promotion=False)
