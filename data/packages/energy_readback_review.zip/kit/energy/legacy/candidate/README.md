# ABBA long-batch integration — offline review candidate

Human owner/sole board operator: bx. Offline implementation: Codex/root.
Source base: 35d4db623091dfc7a63459d07f04e4484dbbd999.
NOT an approved board release. No operator settings or launch wrapper supplied.
Only `check` is public; private entry is default-off and requires separate review
and bx approval. No SSH, install, system/voltage change, automatic retry or kill.

The frozen 54-member core (57ffe40b…197db3), nested 38-member short adapter,
3 MiB bank (42/43), owner, driver, oracle, thresholds, bootstrap, PowerShell/MSAA
and ACK wire shape are unchanged. Old smoke16 is untouched. This selects the
core's EXISTING abba1808 policy, not a new hardware mode or IsolatedPolicy.

ABBA: ARM 2t / cached FPGA / cached FPGA / ARM 2t. Each window: 4 warmup +
452 measured. Total 1824, measured 1808, warmup 16, PL requests 912. Two reused
historical inputs, NOT 1824 independent samples. Last PL job range 58305..58368.

## Explicit candidate configuration; no production schema adoption

New internal namespace `energy-abba-envelope-candidate-v1` rejects old smoke
settings. Required fields: schema, profile, session_id, ack_timeout_s,
start_timeout_s, stable_interval_s, pre_buffer_s, post_buffer_s, port,
activity_wait_s, completion_wait_s, consistency_policy. No actual defaults.

Activity wait covers the next capture request (including warmup or measured
batch); completion wait covers final persistence/readback. Separate GUI, ACK
and peer-startup waits remain. Timeout is failure, not permission to force free.

Policy requires decimal TEXT max_absolute_J/max_relative and a nonempty basis.
Full external settings SHA/hello/launch binds budgets and wait choices before
worker start; this does NOT authenticate operator approval or calibration.
Unchanged CORE capture-config SHA binds plan + ACK timeout ONLY, not extra
integration settings. Runtime does NOT parse/evaluate CSV budgets; receipts say
numeric_consistency_evaluated=false. Later offline processing must recompute the
entire original CSV with the pinned importer + unchanged csv_guard and committed
policy. No retrospective slicing, clear/reset, header repair or envelope/N claims.

## Memory and lifecycle

All outputs fully checked in memory; first 2 measured/window retained (8 MiB)
plus first failed/stopped payload (at most 1 MiB). Metadata grows with bounded
1824 rows (max 16384 bytes/row); total RSS is NOT constant. Outer calls JSON read
is bounded to 32 MiB rather than smoke's 300000 bytes. ARM RSS/CMA headroom is
NOT proven by mocks. Checkpoints follow end ACK; no per-call full SD payloads
during capture. Eight outputs are persisted after all captures close.

Real wait/group absence, original lock inode release, terminal/resource state,
four saved CSVs and every row must agree. Stopped entered request finishes and
is checked but not accepted (unchanged Option A); no next request. Unresolved
hardware stays isolated. Mocks do NOT prove real OS/device behavior.

## Read-only verification

Base CPython 3.10+, standard library only, not Windows venv PID proxy:

```
python -I -B src/integration_entry.py check --identity-sha <EXTERNAL_IDENTITY_SHA>
```

Review bundle run_checks.py runs integration/core/frozen adapter regressions.
Tests use bank bytes and mocks, no NumPy/GEMM/native/GUI/network/hardware. Local
child exits remain fixture-only group evidence. No new board run, stop injection,
accuracy, energy winner, J/task, independent/other-machine review or promotion.
