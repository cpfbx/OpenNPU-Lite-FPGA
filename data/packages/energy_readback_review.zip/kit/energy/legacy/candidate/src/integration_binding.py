"""Portable identity gate; runtime dependencies remain lazy and ARM-only."""
from pathlib import Path, PurePosixPath
import stat
import sys
from integration_common import CORE_SHA, decode, read, sha, hexstr

def verify(root, identity_sha):
    root = Path(root).absolute()
    if root.resolve() != root or root.is_symlink() or not hexstr(identity_sha,64): raise ValueError('canonical package/external identity')
    raw = read(root/'integration_identity.json',100000)
    if sha(raw) != identity_sha: raise ValueError('integration identity drift')
    doc = decode(raw)
    if (doc.get('schema') != 'energy-abba-integration-candidate-v1' or doc.get('core_identity_sha256') != CORE_SHA
        or doc.get('source_base') != '35d4db623091dfc7a63459d07f04e4484dbbd999'
        or doc.get('board_run_authorized') is not False or doc.get('promotion') is not False):
        raise ValueError('default-off integration identity')
    files = doc.get('files')
    if type(files) is not dict or not 54 < len(files) < 100: raise ValueError('bounded integration member set')
    found = set()
    for p in root.rglob('*'):
        if p.is_symlink() or not (stat.S_ISREG(p.lstat().st_mode) or stat.S_ISDIR(p.lstat().st_mode)):
            raise ValueError('plain package tree required')
        if p.is_file(): found.add(p.relative_to(root).as_posix())
    if found != set(files) | {'integration_identity.json'}: raise ValueError('integration member set drift')
    total = 0
    for name, spec in files.items():
        p = PurePosixPath(name)
        if (p.is_absolute() or p.as_posix() != name or '..' in p.parts or '\\' in name or ':' in name
            or type(spec) is not dict or set(spec) != {'bytes','sha256'} or type(spec['bytes']) is not int
            or not 0 <= spec['bytes'] <= 16000000): raise ValueError('canonical bounded member')
        raw = read(root/name,spec['bytes']); total += len(raw)
        if total > 32000000 or len(raw) != spec['bytes'] or sha(raw) != spec['sha256']: raise ValueError('integration bytes drift: '+name)
    if sha(read(root/'core/batch_identity.json',100000)) != CORE_SHA: raise ValueError('core identity drift')
    core_doc = decode(read(root/'core/batch_identity.json',100000))
    if {name[5:] for name in files if name.startswith('core/')} != set(core_doc['files'])|{'batch_identity.json'}:
        raise ValueError('core member set changed')
    for name, spec in core_doc['files'].items():
        if files.get('core/'+name) != spec: raise ValueError('core bytes changed')
    return doc

def configure_core(root):
    core = Path(root).resolve()/'core'
    sys.dont_write_bytecode = True
    for name in ('batch_binding','batch_protocol','batch_core','batch_policy','capture_bridge','batch_session','batch_observer'):
        module = sys.modules.get(name)
        if module is not None and Path(module.__file__).resolve() != core/'src'/(name+'.py'):
            raise RuntimeError('cross-candidate import: '+name)
    sys.path.insert(0,str(core/'src'))
    from batch_binding import configure, verify as check_core
    check_core(core,CORE_SHA); configure(core)
    return core
