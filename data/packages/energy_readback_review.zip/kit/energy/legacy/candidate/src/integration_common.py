"""Bounded, fail-closed integration data. No device imports or actions."""
import hashlib
import json
import math
import os
from pathlib import Path
import stat
import re
from decimal import Decimal

CORE_SHA = '57ffe40bedcacead2953e38131a1c64ea62a54b05db517621eea7ec287197db3'
LOCK = '/tmp/opennpu-kws-chain.lock'
LIMIT = 16384
BOARD_SERIAL = 'ftdi-1234-tulB'
PYNQ_IMAGE = 'pynq-z2-v3.1.1'
PROFILE = 'abba1808'
SETTINGS_SCHEMA = 'energy-abba-envelope-candidate-v1'
CALLS_BYTE_LIMIT = 32 * 1024 * 1024

def consistency_policy(value):
    """Validate an explicit diagnostic proposal, NOT operator approval/calibration.

    Same lexical/range limits as the unchanged frozen csv_guard; no defaults.
    This entry only binds the policy. Numeric CSV inspection remains offline.
    """
    if type(value) is not dict or set(value) != {'max_absolute_J','max_relative','basis'}:
        raise ValueError('explicit dual consistency budgets and basis required')
    basis = value['basis']
    if (type(basis) is not str or not basis.strip() or len(basis) > 512
        or any(ord(c) < 32 for c in basis)):
        raise ValueError('explicit single-line budget basis required')
    numbers = []
    for key in ('max_absolute_J','max_relative'):
        text = value[key]
        if (type(text) is not str or not 1 <= len(text) <= 80 or text != text.strip()
            or re.fullmatch(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?',text,re.ASCII) is None):
            raise ValueError('bounded ASCII decimal budget text required')
        number = Decimal(text)
        if not number.is_finite() or abs(number.adjusted()) > 20 or number.as_tuple().exponent < -20:
            raise ValueError('finite bounded decimal budget required')
        numbers.append(number)
    if numbers[0] <= 0 or not 0 < numbers[1] < 1:
        raise ValueError('positive absolute and 0<relative<1 required')
    return dict(value)

def declarations(board_serial, pynq_image):
    if board_serial != BOARD_SERIAL or pynq_image != PYNQ_IMAGE:
        raise ValueError('explicit original operator board/image declarations required')
    return dict(BOARD_SERIAL=board_serial,PYNQ_IMAGE=pynq_image)

def worker_environment(environment, board_serial, pynq_image):
    declared=declarations(board_serial,pynq_image)
    if any(environment.get(k)!=v for k,v in declared.items()):
        raise RuntimeError('worker environment differs from explicit operator declarations')
    return declared

def expected_capture_sha(settings):
    # Import only after the binding has verified/configured the unchanged core.
    # Use its actual pure-data plan, not a copied/approximate plan description.
    from batch_policy import BatchPolicy
    checked = config(settings)
    return sha(encode(dict(identity_sha256=CORE_SHA,
        plan=BatchPolicy(PROFILE,enabled=True).describe(),
        capture_ack_timeout_s=checked['ack_timeout_s'])))

def validate_gui_budget(settings, wait_s):
    checked=config(settings); finite(wait_s,.01,600)
    required=(5*wait_s+checked['start_timeout_s']+3*checked['stable_interval_s']+
              checked['pre_buffer_s']+checked['post_buffer_s'])
    if checked['ack_timeout_s'] <= required:
        raise ValueError('ACK budget must exceed declared five-helper/buffer waits plus transport margin')
    return required

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def encode(value):
    return (json.dumps(value, sort_keys=True, allow_nan=False) + '\n').encode('utf-8')

def decode(raw):
    def pairs(items):
        result = {}
        for k, v in items:
            if k in result: raise ValueError('duplicate JSON key')
            result[k] = v
        return result
    def bad(_): raise ValueError('nonfinite JSON')
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=bad)

def read(path, limit=LIMIT):
    path = Path(path)
    if path.is_symlink() or not stat.S_ISREG(path.lstat().st_mode):
        raise ValueError('regular nonsymlink file required')
    with path.open('rb') as stream: raw = stream.read(limit + 1)
    if len(raw) > limit: raise ValueError('file byte budget exceeded')
    return raw

def new_json(path, value):
    # Readers must only observe a complete JSON, never a partially written ACK.
    path = Path(path)
    temporary = path.with_name(path.name + '.publishing')
    raw = encode(value)
    with temporary.open('xb') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    os.link(temporary, path)  # exclusive publish; never replace a prior receipt
    temporary.unlink()      # only this function's newly-created temporary

def finite(value, low, high):
    if type(value) not in (int, float) or not math.isfinite(value) or not low <= value <= high:
        raise ValueError('explicit bounded numeric parameter required')
    return value

def hexstr(value, length):
    return type(value) is str and len(value) == length and all(c in '0123456789abcdef' for c in value)

def config(value):
    fields = {'schema', 'profile', 'session_id', 'ack_timeout_s', 'start_timeout_s',
              'stable_interval_s', 'pre_buffer_s', 'post_buffer_s', 'port',
              'activity_wait_s','completion_wait_s','consistency_policy'}
    if type(value) is not dict or set(value) != fields:
        raise ValueError('exact explicit integration config required')
    if value['schema'] != SETTINGS_SCHEMA or value['profile'] != PROFILE:
        raise ValueError('explicit ABBA candidate namespace/profile required; not smoke settings')
    if not hexstr(value['session_id'], 32): raise ValueError('fresh session id required')
    for key in ('ack_timeout_s', 'start_timeout_s'):
        finite(value[key], .01, 600)
    finite(value['stable_interval_s'], .01, 30)
    for key in ('pre_buffer_s', 'post_buffer_s'): finite(value[key], 0, 30)
    if value['ack_timeout_s'] <= value['start_timeout_s'] + 3 * value['stable_interval_s'] + value['pre_buffer_s'] + value['post_buffer_s']:
        raise ValueError('ACK budget must cover declared waits plus UI/transport margin')
    if type(value['port']) is not int or not 1024 <= value['port'] <= 65535:
        raise ValueError('explicit unprivileged loopback port required')
    for key in ('activity_wait_s','completion_wait_s'):
        finite(value[key], .01, 3600)
        if value[key] <= value['ack_timeout_s']:
            raise ValueError('explicit activity/completion wait must exceed capture ACK bound')
    return dict(value,consistency_policy=consistency_policy(value['consistency_policy']))

def check_request(request, session, window, kind, fixed_sha=None):
    if (type(request) is not dict or set(request) != {'session_id','window','kind','config_sha256','request_token'}
        or request['session_id'] != session or type(request['window']) is not int
        or request['window'] != window or request['kind'] != kind or not hexstr(request['config_sha256'],64)):
        raise ValueError('serial session-bound capture request required')
    body = {k:v for k,v in request.items() if k != 'request_token'}
    if sha(encode(body)) != request['request_token'] or (fixed_sha is not None and request['config_sha256'] != fixed_sha):
        raise ValueError('capture request token/config drift')
    return request['config_sha256']

def check_ack(ack, request, capture_id=None):
    if type(ack) is not dict: raise ValueError('ACK object required')
    for key in ('session_id','window','kind','config_sha256','request_token'):
        if type(ack.get(key)) is not type(request[key]) or ack[key] != request[key]:
            raise ValueError('ACK request binding mismatch')
    key = 'saving_started' if request['kind'] == 'begin' else 'saving_stopped'
    if ack.get(key) is not True or not hexstr(ack.get('capture_id'),32):
        raise ValueError('explicit observed saving ACK required')
    if capture_id is not None and ack['capture_id'] != capture_id:
        raise ValueError('capture identity drift')
    if ack.get('csv_units_interpreted') is not False or ack.get('synchronized_task_energy_verified') is not False:
        raise ValueError('capture-only scope required')
    if request['kind']=='end':
        if (type(ack.get('csv_bytes')) is not int or not 0 < ack['csv_bytes'] <= 16*1024*1024
            or not hexstr(ack.get('csv_sha256'),64) or ack.get('snapshot') != 'window_%d.csv'%request['window']):
            raise ValueError('bounded identified CSV snapshot required')
    return ack['capture_id']
