"""Future explicit GUI seam. Import/tests do NOT launch PowerShell or touch UI."""
import os
from pathlib import Path
import subprocess
from integration_common import decode, read, sha, hexstr, finite

_PENDING=[]  # Keep unknown-exit helpers reachable; never silently kill/retry them.

class PowerShellDriver:
    def __init__(self, host_folder, *, host_pid, exe_path, host_start_ticks,
                 powershell_exe, powershell_sha256, wait_s, enabled=False):
        if enabled is not True or os.name != 'nt': raise RuntimeError('explicit Windows UI activation required')
        if type(host_pid) is not int or host_pid <= 0 or type(host_start_ticks) is not str or not host_start_ticks.isdigit():
            raise ValueError('exact existing host PID/start required')
        self.folder = Path(host_folder).resolve()
        self.identity = [str(host_pid),str(Path(exe_path).resolve()),host_start_ticks]
        self.shell = Path(powershell_exe).resolve(strict=True)
        if (self.shell.name.lower() not in ('pwsh.exe','powershell.exe') or not hexstr(powershell_sha256,64)
            or sha(read(self.shell,64*1024*1024)) != powershell_sha256):
            raise ValueError('explicit existing PowerShell executable identity required')
        self.runtime = dict(path=str(self.shell),sha256=powershell_sha256,execution_policy_changed=False)
        self.policy_checked = False
        self.wait_s=finite(wait_s,.01,600)
        self.runtime['helper_wait_s']=self.wait_s
        self.pending=None; self.process_records=[]; self.evidence=None
        self.faulted=False

    def bind_evidence(self,path):
        path=Path(path).absolute()
        if self.evidence is not None or path.resolve()!=path: raise ValueError('one fresh canonical GUI evidence directory')
        path.mkdir(); self.evidence=path

    def invoke(self, arguments, kind):
        if self.pending is not None: raise RuntimeError('previous helper exit unknown; no further GUI/query process')
        if self.evidence is None: raise ValueError('bind GUI evidence before any helper launch')
        row=dict(kind=kind,pid=None,actual_exit=None,wait_expired=False,automatic_kill=False,
                 manual_followup_required=False,wait_budget_s=self.wait_s,
                 scope='helper subprocess, NOT existing UT70 host')
        index=len(self.process_records); self.process_records.append(row)
        out_path=self.evidence/('%03d.stdout.txt'%index); err_path=self.evidence/('%03d.stderr.txt'%index)
        row.update(stdout=out_path.name,stderr=err_path.name)
        with out_path.open('xb') as stdout,err_path.open('xb') as stderr:
            process=subprocess.Popen([str(self.shell),'-NoLogo','-NoProfile','-NonInteractive',*arguments],
                stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,close_fds=True,
                creationflags=subprocess.CREATE_NO_WINDOW,shell=False)
            row['pid']=process.pid
            try: row['actual_exit']=process.wait(timeout=self.wait_s)
            except subprocess.TimeoutExpired:
                # Popen.wait(timeout) does NOT kill. A delayed BM_CLICK might
                # still execute, so latch unknown and prohibit *all* further
                # helpers, including inspect/cleanup. Human follow-up required.
                row.update(wait_expired=True,manual_followup_required=True)
                self.pending=process; _PENDING.append(process)
                raise TimeoutError('helper wait expired; exit/click outcome unknown; no kill or retry')
            except BaseException:
                row['manual_followup_required']=True
                self.pending=process; _PENDING.append(process)
                raise
        if type(row['actual_exit']) is not int or row['actual_exit']!=0:
            raise RuntimeError('helper exited nonzero; no retry; click may be uncertain')
        raw=read(out_path,16384); read(err_path,65536)
        return decode(raw.decode('utf-8-sig'))

    def preflight(self):
        # Read-only policy query; never install, Set-ExecutionPolicy or Bypass.
        policy=self.invoke(['-Command','(Get-ExecutionPolicy).ToString() | ConvertTo-Json -Compress'],'policy_query')
        if policy not in ('RemoteSigned','Unrestricted'):
            raise RuntimeError('PowerShell policy not compatible; no policy change/bypass or GUI call')
        self.runtime['observed_policy']=policy; self.policy_checked=True

    def operation(self, operation):
        if operation not in ('inspect','start','stop'): raise ValueError('only save-checkbox operations')
        if getattr(self,'faulted',False): raise RuntimeError('helper failed; no automatic retry/query')
        try:
            if not self.policy_checked: self.preflight()
            if sha(read(self.shell,64*1024*1024)) != self.runtime['sha256']:
                raise RuntimeError('PowerShell executable changed; no GUI call')
            # No policy bypass, install, elevated launch or shell-string command.
            return self.invoke(['-File',str(self.folder/'host_operation.ps1'),'-Operation',operation,
                '-HostPid',self.identity[0],'-ExePath',self.identity[1],'-HostStartTicks',self.identity[2]],operation)
        except BaseException:
            self.faulted=True
            raise

    def inspect(self): return self.operation('inspect')
    def set_saving(self, enabled):
        if type(enabled) is not bool: raise ValueError('explicit save bool')
        return self.operation('start' if enabled else 'stop')
