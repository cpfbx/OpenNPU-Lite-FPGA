"""Cross-check core lifecycle against real outer OS observations; not an oracle."""
from integration_common import CORE_SHA, LOCK, PROFILE, encode, check_request, check_ack, hexstr

EXPECTED = {
    42:'aeac6bfc2e40ca48ef2e49623c55ca3c69506ba9d0e39939d514e3dac12c2842',
    43:'8e74ffe97ea4f44912cbd38dbc68201319b780eb425e6783f18a8070d4177201',
}
BACKENDS = ('openblas_2t','fpga_cached','fpga_cached','openblas_2t')

def evaluate(preflight, observation, lifecycle, completion, rows, request, exchanges, final_probe, *, session_id, transport_clean, expected_config_sha):
    checks = {}
    def test(key, value): checks[key] = value is True
    worker = preflight.get('worker', {})
    test('bootstrap', preflight.get('success') is True and worker.get('success') is True
         and worker.get('path') == LOCK and worker.get('uid') == 1000
         and worker.get('exclusive_probe') is True and worker.get('probe_descriptor_closed') is True
         and worker.get('session_lock_held') is False)
    test('actual_exit', type(observation.get('actual_child_exit_code')) is int and observation['actual_child_exit_code'] == 0)
    test('real_group_observation', observation.get('group_query_injected') is False and observation.get('process_group_absent') is True)
    test('clean_observer', observation.get('observer_clean') is True and observation.get('stop_requested') is False)
    test('completion', completion.get('operation_success') is True and completion.get('stop_signals') == []
         and completion.get('handler_restore_errors') == [])
    test('core_identity', lifecycle.get('package_sha256') == CORE_SHA and request.get('package_sha256') == CORE_SHA)
    test('expected_capture_config',hexstr(expected_config_sha,64) and request.get('config_sha256') == expected_config_sha)
    from batch_policy import BatchPolicy
    policy = BatchPolicy(PROFILE,enabled=True)
    # Compare canonical JSON, not Python == (True == 1), and bind BOTH records.
    wanted_plan = encode(policy.describe())
    test('abba_plan', encode(lifecycle.get('plan', {})) == wanted_plan
         and encode(request.get('plan', {})) == wanted_plan)
    counts = lifecycle.get('counts', {})
    test('counts', all(type(counts.get(k)) is int and counts[k] == v for k,v in
         dict(started=1824,completed=1824,exact_checked=1824,accepted=1824,measured_calls=1808,warmup_calls=16).items()))
    resources = lifecycle.get('resources', {})
    wanted = dict(held=False,safety_unresolved=False,lease_retained=False,runner_retained=False,root_buffers_retained=0)
    test('resources', all(type(resources.get(k)) is type(v) and resources[k] == v for k,v in wanted.items()))
    cleanup = lifecycle.get('cleanup_readback', {})
    terminal = cleanup.get('terminal', {})
    test('terminal', type(terminal.get('build_id')) is int and terminal['build_id'] == 0x2026D075
         and type(terminal.get('phase')) is int and terminal['phase'] == 1
         and type(terminal.get('error')) is int and terminal['error'] == 0)
    proof = cleanup.get('last_lock_proof', {})
    test('same_inode_worker', all(type(proof.get(k)) is int and proof[k] == worker.get(k) for k in ('device','inode'))
         and proof.get('path') == LOCK and proof.get('exclusive_flock') is True and proof.get('cloexec') is True
         and proof.get('pid') == observation.get('child_pid'))
    test('same_inode_released', all(type(final_probe.get(k)) is int and final_probe[k] == worker.get(k) for k in ('device','inode'))
         and final_probe.get('path') == LOCK and final_probe.get('exclusive_probe') is True
         and final_probe.get('probe_descriptor_closed') is True and final_probe.get('created') is False
         and final_probe.get('session_lock_held') is False)
    test('cleanup', lifecycle.get('operation_success') is True and lifecycle.get('cleanup_complete') is True)
    test('capture_closed', lifecycle.get('capture_close_confirmed') is True and lifecycle.get('capture_manual_followup_required') is False)
    cpus = lifecycle.get('cpu_windows', [])
    test('cpu_exits', type(cpus) is list and len(cpus) == 2 and all(
         type(c.get('actual_exit_code')) is int and c['actual_exit_code'] == 0 and c.get('process_group_absent') is True
         and c.get('group_query_injected') is False and c.get('stop_requested') is False
         and c.get('error_type') is None and type(c.get('checked_calls')) is int and c['checked_calls'] == policy.per_window for c in cpus))
    valid_rows = type(rows) is list and len(rows) == 1824
    if valid_rows:
        for position, row in enumerate(rows):
            w, index = divmod(position,policy.per_window)
            pair = 42 + index % 2
            required = dict(window=w,index=index,input_id=pair,
                            phase_index=index if index < policy.warmup else index-policy.warmup)
            valid_rows = valid_rows and all(type(row.get(k)) is int and row[k] == v for k,v in required.items())
            valid_rows = valid_rows and (row.get('backend') == BACKENDS[w] and row.get('phase') == ('warmup' if index < policy.warmup else 'measured')
                and row.get('exact') is True and row.get('accepted') is True
                and row.get('expected_sha256') == EXPECTED[pair] and row.get('output_sha256') == EXPECTED[pair])
    test('1824_exact_rows', valid_rows)
    valid_capture = type(exchanges) is list and len(exchanges) == 8
    try:
        ids = set(); current = None
        if valid_capture:
            for n, item in enumerate(exchanges):
                req, ack = item['request'], item['ack']
                check_request(req,session_id,n//2,'begin' if n%2 == 0 else 'end',expected_config_sha)
                cid = check_ack(ack,req,current if n%2 else None)
                if n%2 == 0:
                    if cid in ids: raise ValueError('reused capture')
                    ids.add(cid); current = cid
                else:
                    if (type(ack.get('csv_bytes')) is not int or ack['csv_bytes'] <= 0 or
                        type(ack.get('csv_sha256')) is not str or len(ack['csv_sha256']) != 64):
                        raise ValueError('no bound CSV snapshot')
    except (ValueError, KeyError, TypeError): valid_capture = False
    test('eight_bound_capture_exchanges',valid_capture)
    test('transport_clean',transport_clean is True)
    test('diagnostic_only', lifecycle.get('formal_energy_input_accepted') is False
         and lifecycle.get('synchronized_task_energy_verified') is False and lifecycle.get('promotion') is False)
    return dict(schema='energy-abba-outer-candidate-v1', checks=checks,
        operation_success=all(checks.values()), core_identity_sha256=CORE_SHA,
        session_id=session_id, formal_energy_input_accepted=False, promotion=False,
        scope='four saved PC envelopes; no synchronized service energy or J/task',
        provenance='cross-check of recorded evidence, not independent numerical replay')
