"""Read-only, missing-is-failure final probe. Never creates/repairs a lock."""
import os
import stat
from integration_common import LOCK

def probe(expected, *, enabled=False):
    if enabled is not True or os.name != 'posix': raise RuntimeError('explicit POSIX probe only')
    import fcntl
    return probe_with(expected, os, stat, fcntl)

def probe_with(expected, os_api, stat_api, flock_api):
    # Injectable *only* for offline tests. Production entry passes the actual OS.
    if type(expected) is not dict or any(type(expected.get(k)) is not int for k in ('device','inode')):
        raise ValueError('preflight device/inode required')
    def check(s):
        if (not stat_api.S_ISREG(s.st_mode) or s.st_uid != 1000 or s.st_nlink != 1 or s.st_mode & 0o022
            or (s.st_dev,s.st_ino) != (expected['device'],expected['inode'])):
            raise RuntimeError('canonical lock identity/owner/type/mode drift')
    before = os_api.lstat(LOCK); check(before)
    fd = os_api.open(LOCK, os_api.O_RDONLY | os_api.O_NOFOLLOW | os_api.O_NONBLOCK)
    try:
        check(os_api.fstat(fd))
        flock_api.flock(fd, flock_api.LOCK_EX | flock_api.LOCK_NB)
        check(os_api.lstat(LOCK))
    finally: os_api.close(fd)
    return dict(path=LOCK, device=before.st_dev, inode=before.st_ino, uid=1000,
                exclusive_probe=True, probe_descriptor_closed=True,
                session_lock_held=False, created=False, hardware_access=False)
