"""Own only four new Auto Save sessions. No CSV unit or energy interpretation."""
from pathlib import Path
import time
import uuid
from integration_common import config, read, sha, new_json, check_request, check_ack, expected_capture_sha

HOST_SHA = 'b5eb981043e8f0ad927b852817c93a9215f41031038fb8c54fbaed1a9f794532'

class PcCapture:
    def __init__(self, driver, csv_dir, output, settings, *, clock=time.monotonic, sleep=time.sleep):
        self.settings = config(settings)
        self.driver = driver; self.clock = clock; self.sleep = sleep
        self.csv_dir = Path(csv_dir).absolute(); self.output = Path(output).absolute()
        for path in (self.csv_dir, self.output.parent):
            if path.resolve() != path or not path.is_dir(): raise ValueError('canonical existing directory required')
        if self.output == self.csv_dir or self.csv_dir in self.output.parents or self.output in self.csv_dir.parents:
            raise ValueError('CSV and output trees must be separate')
        self.output.mkdir()
        self.active = None; self.index = 0; self.failed = False; self.uncertain = False
        self.fixed_sha = expected_capture_sha(self.settings); self.origin = None; self.events = []

    def state(self, wanted):
        state = self.driver.inspect()
        keys = ('host_pid','host_start_ticks','exe_sha256','serial','rate')
        if (type(state) is not dict or state.get('saving') is not wanted or state.get('connected') is not True
            or state.get('exe_sha256') != HOST_SHA or state.get('serial') != 'D0E18C66'
            or state.get('rate') != '10SPS' or type(state.get('host_pid')) is not int or state['host_pid'] <= 0
            or type(state.get('host_start_ticks')) is not str or not state['host_start_ticks'].isdigit()):
            raise RuntimeError('verified existing host/10SPS/save ownership required')
        identity = tuple(state[k] for k in keys)
        if self.origin is not None and identity != self.origin: raise RuntimeError('host identity changed')
        self.origin = identity
        return state

    def inventory(self):
        result = {}; total = 0
        for path in sorted(self.csv_dir.iterdir()):
            if path.suffix.lower() != '.csv': continue
            raw = read(path, 16 * 1024 * 1024); total += len(raw)
            if total > 64 * 1024 * 1024 or len(result) >= 256: raise ValueError('CSV inventory budget exceeded')
            result[path.name] = {'bytes':len(raw), 'sha256':sha(raw)}
        return result

    def click(self, wanted):
        self.state(not wanted)
        # From this point a failed UI operation may have taken effect. Never
        # retry a click with unknown outcome, even in error cleanup.
        self.uncertain = True
        report = self.driver.set_saving(wanted)
        if (type(report) is not dict or report.get('changed') is not True
            or report.get('before') is not (not wanted) or report.get('after') is not wanted):
            raise RuntimeError('single click outcome unconfirmed')
        self.state(wanted); self.uncertain = False

    def record(self, value):
        new_json(self.output / ('event_%02d.json' % len(self.events)), value)
        self.events.append(value)

    def begin(self, request):
        if self.failed or self.active is not None: raise RuntimeError('controller failed/active')
        self.fixed_sha = check_request(request, self.settings['session_id'], self.index, 'begin', self.fixed_sha)
        self.state(False)  # do not stop or take over a pre-existing recording
        before = self.inventory()
        self.sleep(self.settings['stable_interval_s'])
        if before != self.inventory(): raise RuntimeError('pre-existing CSV is changing')
        self.active = {'id':uuid.uuid4().hex, 'before':before, 'window':self.index}
        self.click(True)
        deadline = self.clock() + self.settings['start_timeout_s']
        previous = None
        while True:
            current = self.inventory()
            if any(current.get(k) != v for k,v in before.items()): raise RuntimeError('old CSV changed')
            fresh = set(current) - set(before)
            if len(fresh) > 1: raise RuntimeError('multiple fresh CSVs')
            if len(fresh) == 1:
                name = next(iter(fresh)); extent = current[name]['bytes']
                if previous is not None and previous[0] == name and extent > previous[1] > 0:
                    self.active['name'] = name; break
                previous = (name, extent)
            if self.clock() >= deadline: raise TimeoutError('no unique growing new CSV')
            self.sleep(min(.1, max(.001, deadline - self.clock())))
        self.sleep(self.settings['pre_buffer_s']); self.state(True)
        answer = dict(request, capture_id=self.active['id'], saving_started=True,
                      csv_units_interpreted=False, synchronized_task_energy_verified=False)
        self.record(answer); return answer

    def end(self, request):
        check_request(request, self.settings['session_id'], self.index, 'end', self.fixed_sha)
        if self.active is None or 'name' not in self.active: raise RuntimeError('no confirmed active CSV')
        self.sleep(self.settings['post_buffer_s']); self.click(False)
        inventories = []
        for _ in range(3):
            self.sleep(self.settings['stable_interval_s']); inventories.append(self.inventory())
        if inventories[0] != inventories[1] or inventories[1] != inventories[2]:
            raise RuntimeError('CSV did not become stable after stop')
        final = inventories[-1]; active = self.active; before = active['before']
        if set(final) != set(before) | {active['name']} or any(final.get(k) != v for k,v in before.items()):
            raise RuntimeError('CSV member set/old bytes drift')
        raw = read(self.csv_dir/active['name'], 16*1024*1024)
        if not raw or final[active['name']] != {'bytes':len(raw),'sha256':sha(raw)}:
            raise RuntimeError('snapshot differs from stable observation')
        snapshot = self.output / ('window_%d.csv' % self.index)
        with snapshot.open('xb') as stream: stream.write(raw)
        if self.inventory() != final: raise RuntimeError('CSV changed during snapshot')
        self.state(False)
        answer = dict(request, capture_id=active['id'], saving_stopped=True,
                      csv_name=active['name'], snapshot=snapshot.name,
                      csv_sha256=sha(raw), csv_bytes=len(raw),
                      csv_units_interpreted=False, synchronized_task_energy_verified=False)
        self.record(answer); self.active = None; self.index += 1
        return answer

    def handle(self, request):
        try:
            if self.failed: raise RuntimeError('no retry after controller failure')
            if request.get('kind') == 'begin': return self.begin(request)
            if request.get('kind') == 'end': return self.end(request)
            raise ValueError('unknown capture operation')
        except BaseException:
            self.failed = True
            raise

    def close_on_failure(self):
        """At most one known-owned stop, never repeat an uncertain click."""
        report = dict(saving_stop_confirmed=False, manual_followup_required=True)
        try:
            if self.uncertain: raise RuntimeError('previous UI click outcome unknown; no automatic retry')
            state = self.driver.inspect()
            if self.active is not None and state.get('saving') is True:
                self.click(False)
            self.state(False)
            report.update(saving_stop_confirmed=True, manual_followup_required=False)
        except BaseException as error: report['error_type'] = type(error).__name__
        self.record(dict(kind='failure_cleanup', **report))
        return report
