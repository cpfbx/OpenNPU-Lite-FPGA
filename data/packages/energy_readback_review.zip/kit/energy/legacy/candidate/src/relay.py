"""One bounded JSON connection. Loopback transport is NOT authentication."""
from pathlib import Path
import socket
import select
import time
from integration_common import LIMIT, encode, decode, read, new_json, check_request, check_ack, expected_capture_sha

class JsonPeer:
    def __init__(self, connection):
        self.connection = connection; self.pending = bytearray()
        self.connection.settimeout(.2)

    def check_idle(self):
        if self.pending: raise ValueError('unsolicited buffered frame while idle')
        readable,_,_=select.select([self.connection],[],[],0)
        if readable:
            # Do not consume a delayed frame and reinterpret it as a later ACK.
            block=self.connection.recv(1,socket.MSG_PEEK)
            if not block: raise EOFError('peer disconnected while worker active')
            raise ValueError('unsolicited peer bytes while awaiting worker request')

    def send(self, value):
        raw = encode(value)
        if len(raw) > LIMIT: raise ValueError('wire size budget')
        # sendall has a bounded socket timeout; no reconnect or resend.
        self.connection.sendall(raw)

    def receive(self, timeout, stopped):
        deadline = time.monotonic() + timeout
        while True:
            if stopped(): raise RuntimeError('cooperative stop while waiting for peer')
            if b'\n' in self.pending:
                raw, _, tail = self.pending.partition(b'\n'); self.pending = bytearray(tail)
                return decode(raw)
            if len(self.pending) >= LIMIT: raise ValueError('wire size budget')
            if time.monotonic() >= deadline: raise TimeoutError('peer deadline; no reconnect')
            try: block = self.connection.recv(min(4096,LIMIT-len(self.pending)))
            except socket.timeout: continue
            if not block: raise EOFError('peer disconnected')
            self.pending.extend(block)

def relay(directory, peer, settings, stopped, done, journal):
    """May run in a thread; never accesses hardware. Signals parent via error."""
    folder = Path(directory); exchanges = []; current = None; fixed_sha = expected_capture_sha(settings)
    for number in range(8):
        window, kind = number//2, 'begin' if number%2 == 0 else 'end'
        path = folder / ('window_%d_%s_request.json' % (window,kind))
        while not path.exists():
            if stopped(): raise RuntimeError('relay stopped')
            if done(): raise RuntimeError('worker exited before all capture exchanges')
            peer.check_idle()  # Detect EOF during warmup/active windows, not only at their end.
            time.sleep(.02)
        # Frozen CaptureBridge publishes with a direct fsynced write. A small
        # read may precede completion, so wait for a complete JSON, but never
        # consume a malformed final request as success.
        deadline = time.monotonic() + settings['ack_timeout_s']
        while True:
            try: request = decode(read(path)); break
            except (ValueError, UnicodeError):
                if stopped() or done() or time.monotonic() >= deadline: raise
                time.sleep(.02)
        fixed_sha = check_request(request,settings['session_id'],window,kind,fixed_sha)
        peer.send(request)
        answer = peer.receive(settings['ack_timeout_s'],stopped)
        if getattr(peer,'pending',None): raise ValueError('extra ACK frame before publication')
        current = check_ack(answer,request,current if number%2 else None)
        entry = dict(request=request,ack=answer)
        new_json(Path(journal)/('exchange_%d.json'%number),entry)
        new_json(folder/('window_%d_%s_ack.json'%(window,kind)),answer)
        exchanges.append(entry)
    return exchanges
