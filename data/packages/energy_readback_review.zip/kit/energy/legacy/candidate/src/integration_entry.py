"""Review candidate entry. Only check is public; private ABBA requires explicit opt-in.

No SSH launch. bx must separately approve transport/settings and operate the board.
"""
import argparse
import contextlib
import importlib.util
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import threading
import time
# Isolated Python deliberately omits the script directory from sys.path.
sys.dont_write_bytecode = True
sys.path.insert(0,str(Path(__file__).resolve().parent))
from integration_common import CORE_SHA, PROFILE, CALLS_BYTE_LIMIT, config, read, decode, encode, sha, new_json, declarations, finite, expected_capture_sha, validate_gui_budget, worker_environment
from integration_binding import verify, configure_core
from relay import JsonPeer, relay

@contextlib.contextmanager
def signals(stops):
    previous = {}; failures = []
    def latch(number, frame):
        if number not in stops: stops.append(number)
    try:
        for name in ('SIGINT','SIGTERM','SIGHUP'):
            if not hasattr(signal,name): continue
            number = getattr(signal,name); previous[number] = signal.getsignal(number)
            signal.signal(number,latch)
        yield failures
    finally:
        for number, old in previous.items():
            try: signal.signal(number,old)
            except BaseException as error: failures.append(dict(signal=number,error_type=type(error).__name__))

def fresh_output(root, output):
    output = Path(output).absolute()
    if output.resolve() != output or output == root or root in output.parents or output in root.parents:
        raise ValueError('fresh canonical output tree separate from package')
    output.mkdir(); return output

def settings_file(path, expected):
    raw = read(path)
    if sha(raw) != expected: raise ValueError('external settings SHA mismatch')
    return config(decode(raw))

def worker(root, identity, output, settings, expected_lock, *, board_serial=None, pynq_image=None, enabled=False):
    if enabled is not True: raise RuntimeError('worker default-off')
    settings = config(settings)
    worker_environment(os.environ,board_serial,pynq_image)
    verify(root,identity); core = configure_core(root)
    from batch_binding import arm_only
    arm_only()
    if os.geteuid() != 0: raise RuntimeError('original root worker required')
    from lock_probe import probe
    probe(expected_lock,enabled=True)  # read-only, same preflight inode before acquisition
    from capture_bridge import CaptureBridge
    from batch_session import run_internal
    bridge = CaptureBridge(output/'capture_bridge',settings['session_id'],lambda:False,
                           ack_timeout_s=settings['ack_timeout_s'],enabled=True)
    return run_internal(core,CORE_SHA,output/'worker',profile=PROFILE,capture=bridge,enabled=True)

def accept_peer(listener, wait_s, stopped, *, clock=time.monotonic):
    finite(wait_s,.01,3600)
    deadline=clock()+wait_s
    while True:
        if stopped(): raise RuntimeError('stop before PC peer')
        if clock() >= deadline: raise TimeoutError('PC startup wait expired; no worker launch')
        try: return listener.accept()
        except socket.timeout: continue

def board(root, identity, output, settings, settings_sha, *, board_serial=None, pynq_image=None, peer_wait_s=None, enabled=False):
    if enabled is not True: raise RuntimeError('board entry default-off')
    declared = declarations(board_serial,pynq_image)
    finite(peer_wait_s,.01,3600)  # startup budget, deliberately NOT the capture ACK bound
    verify(root,identity); core = configure_core(root)
    from batch_binding import arm_only
    arm_only()
    if os.geteuid() != 0: raise RuntimeError('original root Jupyter operator required')
    settings = config(settings)
    output = fresh_output(root,output)
    new_json(output/'launch.json',dict(identity_sha256=identity,core_identity_sha256=CORE_SHA,
        settings=settings,settings_sha256=settings_sha,operator='bx',
        operator_identity_declarations=declared,peer_startup_wait_s=peer_wait_s,
        operator_confirmed_this_launch=True,transport='manual SSH loopback forwarding candidate',
        board_run_authorized_by_package=False,promotion=False))
    spec = importlib.util.spec_from_file_location('integration_lock_bootstrap',root/'bootstrap/lock_bootstrap.py')
    bootstrap = importlib.util.module_from_spec(spec); spec.loader.exec_module(bootstrap)
    # Direct call from the outer process: missing-lock workload scan must know
    # this launcher PID, not mistake it for an unrelated Python workload.
    preflight = bootstrap.initialize(output/'lock_bootstrap.json')
    stop = []; relay_errors = []; exchanged = []; child = []; done = threading.Event()
    stop_sent=[]
    observer_record = {}; failures = []; primary = None; peer = None; thread = None
    final_probe = None
    from batch_observer import observe
    from lock_probe import probe
    from outer_receipt import evaluate
    def stopped(): return bool(stop or relay_errors)
    def popen(argv, **options):
        # No dependence on shell exports. Override the two declared values in
        # a COPY; never mutate the parent process/global shell environment.
        options['env']=dict(os.environ,**declared)
        value = subprocess.Popen(argv,**options); child.append(value); return value
    def request_stop():
        if not stop_sent and child and child[0].poll() is None:
            stop_sent.append(child[0].pid)
            child[0].send_signal(signal.SIGTERM)  # cooperative guardian only, never SIGKILL/group kill
    def relay_task():
        try: exchanged.extend(relay(output/'capture_bridge',peer,settings,stopped,done.is_set,output/'transport'))
        except BaseException as error:
            relay_errors.append(type(error).__name__)
            try: request_stop()  # Do not wait for the observer's next one-second poll.
            except BaseException as stop_error: relay_errors.append(type(stop_error).__name__)
    (output/'transport').mkdir()
    receipt = dict(operation_success=False,promotion=False,formal_energy_input_accepted=False)
    with signals(stop) as failures:
        try:
            with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as listener:
                listener.bind(('127.0.0.1',settings['port'])); listener.listen(1); listener.settimeout(.2)
                print('WAITING: loopback peer only; no worker/hardware started.',flush=True)
                connection,address=accept_peer(listener,peer_wait_s,stopped)
                with connection:
                    if address[0] != '127.0.0.1': raise RuntimeError('non-loopback peer')
                    peer = JsonPeer(connection)
                    hello = peer.receive(settings['ack_timeout_s'],stopped)
                    expected = dict(kind='hello',session_id=settings['session_id'],settings_sha256=settings_sha,identity_sha256=identity)
                    if hello != expected: raise ValueError('peer config/package/session mismatch')
                    peer.send(expected)
                    new_json(output/'worker_settings.json',settings)
                    new_json(output/'expected_lock.json',preflight['worker'])
                    command = [sys.executable,'-I','-B',str(root/'src/integration_entry.py'),'_worker',
                        '--identity-sha',identity,'--output',str(output),
                        '--settings',str(output/'worker_settings.json'),'--settings-sha',sha(encode(settings)),
                        '--expected-lock',str(output/'expected_lock.json'),
                        '--board-serial',board_serial,'--pynq-image',pynq_image,
                        '--expected-lock-sha',sha(encode(preflight['worker'])),'--enable-private-candidate']
                    thread = threading.Thread(target=relay_task,daemon=True); thread.start()
                    try:
                        observer_record = observe(command,output/'observation',stopped,request_stop,
                                                  enabled=True,popen_factory=popen)
                    finally:
                        done.set()
                        if thread is not None:
                            while thread.is_alive(): thread.join(.2)
                    final_probe = probe(preflight['worker'],enabled=True)
                    new_json(output/'lock_final_probe.json',final_probe)
                    def data(name, limit=16384): return decode(read(output/'worker'/name,limit))
                    lifecycle = data('lifecycle.json',100000)
                    rows = data('outputs/calls.json',CALLS_BYTE_LIMIT)
                    receipt = evaluate(preflight,observer_record,lifecycle,data('worker_completion.json'),rows,
                        data('request.json'),exchanged,final_probe,session_id=settings['session_id'],
                        expected_config_sha=expected_capture_sha(settings),
                        transport_clean=not stopped() and len(exchanged) == 8)
                    # Verify the eight retained representative outputs, without
                    # inventing independent replay of unsaved full-batch outputs.
                    from outer_receipt import EXPECTED
                    retained = True
                    for w in range(4):
                        for pair in (42,43):
                            raw = read(output/'worker/outputs'/('window_%d_input_%d.bin'%(w,pair)),1048576)
                            retained = retained and len(raw) == 1048576 and sha(raw) == EXPECTED[pair]
                    receipt['checks']['representative_outputs'] = retained
                    receipt['operation_success'] = all(receipt['checks'].values())
                    peer.send(dict(kind='captures_complete',session_id=settings['session_id'],worker_checks_passed=receipt['operation_success']))
        except BaseException as error:
            primary = error
            receipt.update(operation_success=False,error_type=type(error).__name__)
            # If observe raised, its finally has still waited; preserve real record.
            exit_path = output/'observation/actual_exit.json'
            if exit_path.exists(): observer_record = decode(read(exit_path))
        finally:
            done.set()
            # A failed/incomplete run may still have safely released hardware.
            # Preserve that independent observation; never turn it into success.
            if (final_probe is None and type(observer_record.get('actual_child_exit_code')) is int
                and observer_record.get('process_group_absent') is True):
                try:
                    final_probe = probe(preflight['worker'],enabled=True)
                    new_json(output/'lock_final_probe.json',final_probe)
                except BaseException as error:
                    receipt['final_probe_error_type'] = type(error).__name__
    receipt.update(identity_sha256=identity,settings_sha256=settings_sha,
        consistency_policy=settings['consistency_policy'],numeric_consistency_evaluated=False,
        stop_signals=stop,handler_restore_errors=failures,transport_errors=relay_errors,
        observed_os=observer_record,formal_energy_input_accepted=False,promotion=False)
    receipt['cooperative_stop_target_pids']=stop_sent
    receipt['final_lock_probe'] = final_probe
    if stop or failures or relay_errors: receipt['operation_success'] = False
    new_json(output/'outer_receipt.json',receipt)
    if primary is not None: raise primary
    if receipt['operation_success'] is not True: raise RuntimeError('ABBA candidate integration did not pass')
    return receipt

def pc(root, identity, output, settings, settings_sha, csv_dir, driver, *, enabled=False):
    if enabled is not True: raise RuntimeError('PC control default-off')
    settings = config(settings)
    verify(root,identity); configure_core(root)
    from pc_capture import PcCapture
    if hasattr(driver,'wait_s'): validate_gui_budget(settings,driver.wait_s)
    controller = PcCapture(driver,csv_dir,output,settings)
    if hasattr(driver,'bind_evidence'): driver.bind_evidence(controller.output/'gui_processes')
    stop = []; success = False; failure = None; cleanup = None; failures = []
    try:
        controller.state(False)  # host identity/policy/save ownership BEFORE any peer handshake
        # No direct remote board address, SSH launcher, credentials or reconnect.
        with signals(stop) as failures, socket.create_connection(('127.0.0.1',settings['port']),timeout=settings['ack_timeout_s']) as connection:
            peer = JsonPeer(connection)
            hello = dict(kind='hello',session_id=settings['session_id'],settings_sha256=settings_sha,identity_sha256=identity)
            peer.send(hello)
            if peer.receive(settings['ack_timeout_s'],lambda:bool(stop)) != hello: raise ValueError('board handshake mismatch')
            for _ in range(8):
                request = peer.receive(settings['activity_wait_s'],lambda:bool(stop))
                answer = controller.handle(request); peer.send(answer)
            result = peer.receive(settings['completion_wait_s'],lambda:bool(stop))
            if result != dict(kind='captures_complete',session_id=settings['session_id'],worker_checks_passed=True):
                raise RuntimeError('board completion not successful')
            controller.state(False); success = controller.index == 4 and controller.active is None
    except BaseException as error:
        failure = type(error).__name__; cleanup = controller.close_on_failure()
    finally:
        if stop or failures: success = False
        new_json(controller.output/'pc_receipt.json',dict(operation_success=success,error_type=failure,
            consistency_policy=settings['consistency_policy'],numeric_consistency_evaluated=False,
            settings_sha256=settings_sha,identity_sha256=identity,stop_signals=stop,
            handler_restore_errors=failures,
            failure_cleanup=cleanup,formal_energy_input_accepted=False,promotion=False,
            success_scope='PC capture only; final board outer receipt must be retrieved separately',
            powershell_runtime=getattr(driver,'runtime',None),
            gui_process_observations=getattr(driver,'process_records',[]),
            gui_helper_pending=getattr(driver,'pending',None) is not None,
            board_outer_receipt_verified=False,
            csv_units_interpreted=False,synchronized_task_energy_verified=False))
    if not success: raise RuntimeError('PC capture failed; see receipt and manual-follow-up status')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation',choices=['check','_worker','_board_abba_candidate','_pc_capture','_pc_inspect'])
    parser.add_argument('--identity-sha',required=True)
    for name in ('output','settings','expected-lock','csv-dir','exe-path','powershell-exe'):
        parser.add_argument('--'+name,type=Path)
    for name in ('settings-sha','expected-lock-sha','host-start-ticks','powershell-sha','board-serial','pynq-image'): parser.add_argument('--'+name)
    parser.add_argument('--peer-wait-s',type=float)
    parser.add_argument('--gui-wait-s',type=float)
    parser.add_argument('--host-pid',type=int)
    parser.add_argument('--enable-private-candidate',action='store_true')
    args = parser.parse_args(); root = Path(__file__).resolve().parent.parent
    verify(root,args.identity_sha)
    if args.operation == 'check':
        print('CHECK PASS: integration/core bytes only; no GUI, socket, library or board access.'); return
    if not args.enable_private_candidate: raise RuntimeError('private candidate disabled; review/confirmation required')
    settings = settings_file(args.settings,args.settings_sha)
    if args.operation == '_worker':
        lock_raw = read(args.expected_lock)
        if sha(lock_raw) != args.expected_lock_sha: raise ValueError('expected lock binding drift')
        worker(root,args.identity_sha,args.output,settings,decode(lock_raw),board_serial=args.board_serial,pynq_image=args.pynq_image,enabled=True)
    elif args.operation == '_board_abba_candidate':
        if input('bx: verify UTC, idle board, wiring, exact config and separate ABBA approval. Type YES: ') != 'YES':
            raise RuntimeError('operator did not confirm')
        board(root,args.identity_sha,args.output,settings,args.settings_sha,board_serial=args.board_serial,
              pynq_image=args.pynq_image,peer_wait_s=args.peer_wait_s,enabled=True)
    else:
        from ut70_driver import PowerShellDriver
        driver = PowerShellDriver(root/'host',host_pid=args.host_pid,exe_path=args.exe_path,
                                  host_start_ticks=args.host_start_ticks,powershell_exe=args.powershell_exe,
                                  powershell_sha256=args.powershell_sha,wait_s=args.gui_wait_s,enabled=True)
        if args.operation=='_pc_inspect':
            output=fresh_output(root,args.output)
            driver.bind_evidence(output/'gui_processes')
            try:
                state=driver.inspect()
                new_json(output/'gui_inspect.json',dict(state=state,gui_processes=driver.process_records,
                    scope='GUI read-only; no save click, socket, board or numeric energy validation'))
            finally:
                new_json(output/'gui_inspect_processes.json',dict(processes=driver.process_records,pending=driver.pending is not None))
            return
        pc(root,args.identity_sha,args.output,settings,args.settings_sha,args.csv_dir,driver,enabled=True)

if __name__ == '__main__':
    # -I drops the script directory. Only add this verified candidate's local
    # source directory, not cwd, sitecustomize or workspace paths.
    main()
