"""Incremental regression for external review. No real GUI/socket/board actions."""
from pathlib import Path
import os
import socket
import sys
import subprocess
import unittest
from unittest.mock import patch
from types import SimpleNamespace as NS
from integration_common import *
from test_integration import Fixture, settings, request, answer, valid_receipt_data, Clock
from pc_capture import PcCapture
from relay import relay
from relay import JsonPeer
from outer_receipt import evaluate

class IdentityAndConfig(Fixture):
    def test_missing_or_wrong_declarations(self):
        for serial,image in [(None,None),('',PYNQ_IMAGE),(BOARD_SERIAL,'wrong'),('wrong',PYNQ_IMAGE)]:
            with self.subTest(serial=serial), self.assertRaises(ValueError): declarations(serial,image)
        self.assertEqual(declarations(BOARD_SERIAL,PYNQ_IMAGE),dict(BOARD_SERIAL=BOARD_SERIAL,PYNQ_IMAGE=PYNQ_IMAGE))

    def test_worker_missing_environment_rejected_before_guard_or_probe(self):
        from integration_entry import worker
        with patch.dict(os.environ,{},clear=True),patch('integration_entry.verify',side_effect=AssertionError('must fail before package/device')):
            with self.assertRaises(RuntimeError): worker(self.base,'0'*64,self.base/'never',settings(),{},
                board_serial=BOARD_SERIAL,pynq_image=PYNQ_IMAGE,enabled=True)
        self.assertFalse((self.base/'never').exists())

    def test_worker_wrong_environment_rejected(self):
        from integration_entry import worker
        with patch.dict(os.environ,dict(BOARD_SERIAL='wrong',PYNQ_IMAGE=PYNQ_IMAGE),clear=True):
            with self.assertRaises(RuntimeError): worker(self.base,'0'*64,self.base/'never',settings(),{},
                board_serial=BOARD_SERIAL,pynq_image=PYNQ_IMAGE,enabled=True)

    def bad_request(self):
        req=request(0,'begin'); req['config_sha256']='d'*64
        req['request_token']=sha(encode({k:v for k,v in req.items() if k!='request_token'}))
        return req

    def test_pc_rejects_first_self_consistent_wrong_config_before_gui_click(self):
        pc=PcCapture(self.driver,self.csv,self.base/'pc',settings(),clock=self.clock,sleep=self.clock.sleep)
        with self.assertRaises(ValueError): pc.handle(self.bad_request())
        self.assertEqual(self.driver.clicks,[])

    def test_relay_rejects_wrong_config_before_sending(self):
        folder=self.base/'bridge'; folder.mkdir(); new_json(folder/'window_0_begin_request.json',self.bad_request())
        peer=NS(send=lambda value:(_ for _ in ()).throw(AssertionError('must not send')),receive=lambda *_:None)
        with self.assertRaises(ValueError): relay(folder,peer,settings(),lambda:False,lambda:False,self.base)

    def test_outer_rejects_all_self_consistent_but_wrong_config(self):
        data=valid_receipt_data(); data[5]['config_sha256']='d'*64
        for item in data[6]:
            req=item['request']; req['config_sha256']='d'*64
            req['request_token']=sha(encode({k:v for k,v in req.items() if k!='request_token'}))
            item['ack']=answer(req,item['ack']['capture_id'])
        result=evaluate(*data,session_id='a'*32,transport_clean=True,expected_config_sha=expected_capture_sha(settings()))
        self.assertFalse(result['operation_success']); self.assertFalse(result['checks']['expected_capture_config'])

    def test_expected_config_matches_frozen_plan_formula(self):
        from batch_policy import BatchPolicy
        wanted=sha(encode(dict(identity_sha256=CORE_SHA,plan=BatchPolicy('abba1808',enabled=True).describe(),
                              capture_ack_timeout_s=settings()['ack_timeout_s'])))
        self.assertEqual(expected_capture_sha(settings()),wanted)
        changed=settings(); changed['ack_timeout_s']=3
        self.assertNotEqual(expected_capture_sha(changed),wanted)

    def test_gui_wait_budget_explicit_and_not_silently_ack_timeout(self):
        self.assertGreater(validate_gui_budget(settings(),.05),0)
        with self.assertRaises(ValueError): validate_gui_budget(settings(),1)

class StartupBudget(unittest.TestCase):
    def test_peer_preflight_longer_than_ack_still_within_startup_budget(self):
        from integration_entry import accept_peer
        clock=Clock()
        def accept():
            clock.now+=1
            if clock.now<=3: raise socket.timeout()
            return ('SYNTHETIC CONNECTION',('127.0.0.1',123))
        result=accept_peer(NS(accept=accept),10,lambda:False,clock=clock)
        self.assertGreater(clock.now,settings()['ack_timeout_s']); self.assertEqual(result[0],'SYNTHETIC CONNECTION')
    def test_startup_timeout_no_worker(self):
        from integration_entry import accept_peer
        clock=Clock()
        def accept(): clock.now+=1; raise socket.timeout()
        with self.assertRaises(TimeoutError): accept_peer(NS(accept=accept),2,lambda:False,clock=clock)
    def test_stop_before_accept(self):
        from integration_entry import accept_peer
        with self.assertRaises(RuntimeError): accept_peer(NS(accept=lambda:self.fail('no accept')),2,lambda:True)
    def test_no_implicit_startup_budget(self):
        from integration_entry import accept_peer
        for value in (None,True,float('inf'),0,3601):
            with self.subTest(value=value),self.assertRaises(ValueError): accept_peer(NS(),value,lambda:False)

class IdleTransport(Fixture):
    def test_eof_detected_before_next_worker_request(self):
        connection=NS(settimeout=lambda _:None,recv=lambda *_:b'')
        peer=JsonPeer(connection)
        with patch('relay.select.select',return_value=([connection],[],[])):
            with self.assertRaises(EOFError): relay(self.base,peer,settings(),lambda:False,lambda:False,self.base)
    def test_unsolicited_bytes_refused(self):
        connection=NS(settimeout=lambda _:None,recv=lambda *_:b'x')
        with patch('relay.select.select',return_value=([connection],[],[])):
            with self.assertRaises(ValueError): JsonPeer(connection).check_idle()
    def test_buffered_extra_frame_refused(self):
        peer=JsonPeer(NS(settimeout=lambda _:None)); peer.pending.extend(b'{}\n')
        with self.assertRaises(ValueError): peer.check_idle()

class ActualLocalHelperWait(Fixture):
    def test_real_child_environment_without_shell_exports(self):
        source=Path(__file__).resolve().parent
        code=('import sys,os; sys.path.insert(0,sys.argv[1]); '
              'from integration_common import worker_environment; '
              'worker_environment(os.environ,sys.argv[2],sys.argv[3]); print("DECLARATIONS MATCH")')
        command=[sys.executable,'-I','-B','-c',code,str(source),BOARD_SERIAL,PYNQ_IMAGE]
        environment=dict(os.environ)
        environment.pop('BOARD_SERIAL',None); environment.pop('PYNQ_IMAGE',None)
        missing=subprocess.run(command,env=environment,capture_output=True)
        self.assertEqual(missing.returncode,1); self.assertNotIn(b'DECLARATIONS MATCH',missing.stdout)
        correct=subprocess.run(command,env=dict(environment,**declarations(BOARD_SERIAL,PYNQ_IMAGE)),capture_output=True)
        self.assertEqual(correct.returncode,0); self.assertEqual(correct.stdout.strip(),b'DECLARATIONS MATCH')
        wrong=subprocess.run(command,env=dict(environment,BOARD_SERIAL='wrong',PYNQ_IMAGE=PYNQ_IMAGE),capture_output=True)
        self.assertEqual(wrong.returncode,1)

    def test_bounded_frontend_no_kill_then_test_obtains_real_exit(self):
        from ut70_driver import PowerShellDriver, _PENDING
        value=PowerShellDriver.__new__(PowerShellDriver)
        value.shell=Path(sys.executable); value.wait_s=.001; value.pending=None; value.process_records=[]; value.evidence=None
        value.bind_evidence(self.base/'gui')
        actual_spawn=subprocess.Popen
        def fixture_spawn(argv,**opts):
            # This is a short Python fixture, never PowerShell/GUI. Preserve
            # real wait semantics while avoiding platform-specific argv.
            return actual_spawn([sys.executable,'-B','-c','import time; time.sleep(.15); print("null")'],**opts)
        with patch('ut70_driver.subprocess.Popen',side_effect=fixture_spawn),patch('ut70_driver.subprocess.CREATE_NO_WINDOW',0,create=True):
            with self.assertRaises(TimeoutError): value.invoke([],'SYNTHETIC wait')
        self.assertTrue(value.process_records[0]['wait_expired'])
        # Test-owned finite child only: explicitly reap without a kill/retry.
        self.assertEqual(value.pending.wait(timeout=5),0)
        self.assertIsNone(value.process_records[0]['actual_exit'])
        _PENDING.remove(value.pending)

if __name__=='__main__': unittest.main()
