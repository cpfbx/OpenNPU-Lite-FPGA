"""Synthetic whole outer launch seam; all socket/ARM/bootstrap/probe IO mocked."""
import importlib.util
import os
from pathlib import Path
import stat
import tempfile
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch
from integration_common import encode, decode, read, new_json, sha
from test_integration import settings, valid_receipt_data, FakeOs, FakeFlock

ROOT=Path(__file__).resolve().parent.parent

@unittest.skipUnless((ROOT/'core').is_dir(),'requires packaged core; no external fallback')
class OuterWiring(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.base=Path(self.temp.name).resolve()

    def perform(self, observer_failure=False,check_environment=False):
        import integration_entry as entry
        from batch_binding import load_bank
        package_sha=sha(read(ROOT/'integration_identity.json',100000))
        data=valid_receipt_data(); preflight, observation, lifecycle, completion, rows, req, exchanges, post=data
        bind=sha(encode(settings()))
        hello=dict(kind='hello',session_id='a'*32,settings_sha256=bind,identity_sha256=package_sha)
        class Connection:
            def __enter__(self): return self
            def __exit__(self,*_): pass
        class Listener(Connection):
            def bind(self,address):
                if address!=('127.0.0.1',settings()['port']): raise AssertionError('non-loopback')
            def listen(self,n): pass
            def settimeout(self,n): pass
            def accept(self): return Connection(),('127.0.0.1',1234)
        class Peer:
            def __init__(self,connection): self.sent=[]
            def receive(self,*_): return hello
            def send(self,value): self.sent.append(value)
        output=self.base/'outer'
        def fake_observe(command,folder,*args,**kwargs):
            # Explicitly no Popen here: synthetic evidence to exercise wiring,
            # not an OS lifecycle or independent board readback.
            if check_environment:
                self.assertIn('--board-serial',command); self.assertIn('--pynq-image',command)
                with patch.object(entry.subprocess,'Popen',return_value=NS(pid=789)) as popen,\
                     patch.dict(os.environ,dict(BOARD_SERIAL='wrong ambient serial',PYNQ_IMAGE='wrong ambient image')):
                    kwargs['popen_factory'](command)
                    environment=popen.call_args.kwargs['env']
                    self.assertEqual(environment['BOARD_SERIAL'],'ftdi-1234-tulB')
                    self.assertEqual(environment['PYNQ_IMAGE'],'pynq-z2-v3.1.1')
                    self.assertEqual(os.environ['BOARD_SERIAL'],'wrong ambient serial')
            folder.mkdir(); new_json(folder/'actual_exit.json',observation)
            if observer_failure: raise OSError('synthetic observer exception AFTER final OS record')
            target=output/'worker'; target.mkdir(); (target/'outputs').mkdir()
            for name,value in [('lifecycle.json',lifecycle),('worker_completion.json',completion),
                               ('outputs/calls.json',rows),('request.json',req)]: new_json(target/name,value)
            bank=load_bank(ROOT/'core')
            for w in range(4):
                for pair in bank:
                    (target/'outputs'/('window_%d_input_%d.bin'%(w,pair.input_id))).write_bytes(pair.expected)
            return observation
        fake_bootstrap=NS(initialize=lambda path:preflight)
        spec=NS(loader=NS(exec_module=lambda module:None))
        with patch('batch_binding.arm_only'),patch.object(entry.os,'geteuid',return_value=0,create=True),\
             patch.object(entry.socket,'socket',return_value=Listener()),patch.object(entry,'JsonPeer',Peer),\
             patch.object(entry,'relay',return_value=exchanges),\
             patch.object(entry.importlib.util,'spec_from_file_location',return_value=spec),\
             patch.object(entry.importlib.util,'module_from_spec',return_value=fake_bootstrap),\
             patch('batch_observer.observe',side_effect=fake_observe),patch('lock_probe.probe',return_value=post) as probe:
            if observer_failure:
                with self.assertRaises(OSError): entry.board(ROOT,package_sha,output,settings(),bind,
                    board_serial='ftdi-1234-tulB',pynq_image='pynq-z2-v3.1.1',peer_wait_s=1,enabled=True)
            else:
                result=entry.board(ROOT,package_sha,output,settings(),bind,
                    board_serial='ftdi-1234-tulB',pynq_image='pynq-z2-v3.1.1',peer_wait_s=1,enabled=True)
                self.assertTrue(result['operation_success'])
            self.assertEqual(probe.call_count,1)
        return decode(read(output/'outer_receipt.json',100000))

    def test_whole_outer_success_synthetic(self):
        self.assertTrue(self.perform()['operation_success'])
    def test_observer_failure_still_reports_final_lock_probe(self):
        result=self.perform(True)
        self.assertFalse(result['operation_success']); self.assertEqual(result['observed_os']['actual_child_exit_code'],0)
        self.assertTrue(result['final_lock_probe']['probe_descriptor_closed'])
    def test_explicit_popen_environment_overrides_wrong_ambient_without_mutating_it(self):
        self.assertTrue(self.perform(check_environment=True)['operation_success'])

@unittest.skipUnless((ROOT/'bootstrap').is_dir(),'requires packaged bootstrap')
class BootstrapWiring(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        spec=importlib.util.spec_from_file_location('test_bootstrap_local',ROOT/'bootstrap/lock_bootstrap.py')
        module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        namespace={'__name__':'not_main','APPROVED_LAUNCHER_PID':123}
        exec(module.WORKER,namespace)
        cls.bootstrap=staticmethod(namespace['bootstrap'])

    def test_existing_unchanged(self):
        api=FakeOs(); api.O_WRONLY=4; api.O_CREAT=8; api.O_EXCL=16
        result=self.bootstrap(api,stat,FakeFlock(),lambda:self.fail('must not scan existing lock'))
        self.assertFalse(result['created']); self.assertEqual(api.closed,[7])
    def test_busy_never_replaced(self):
        api=FakeOs(); flock=FakeFlock(); flock.busy=True
        with self.assertRaises(RuntimeError): self.bootstrap(api,stat,flock,lambda:None)
        self.assertEqual(api.closed,[7])
    def test_missing_requires_guard_then_exclusive_create(self):
        api=FakeOs(); api.O_WRONLY=4; api.O_CREAT=8; api.O_EXCL=16; api.exists=False; events=[]
        original=api.lstat
        def ls(path):
            if not api.exists: raise FileNotFoundError('synthetic missing')
            return original(path)
        def op(path,flags,mode=None):
            events.append(('open',flags,mode))
            if mode is not None: api.exists=True
            return 7
        api.lstat=ls; api.open=op; api.fsync=lambda fd:events.append(('fsync',fd))
        result=self.bootstrap(api,stat,FakeFlock(),lambda:events.append(('guard',)))
        self.assertTrue(result['created']); self.assertEqual(events[0],('guard',))
        self.assertEqual(events[1],('open',4|8|16|1,0o644)); self.assertEqual(api.closed,[7,7])
    def test_missing_with_workload_no_create(self):
        api=FakeOs(); calls=[]
        api.lstat=lambda path:(_ for _ in ()).throw(FileNotFoundError())
        api.open=lambda *args:calls.append(args)
        def guard(): raise RuntimeError('synthetic workload')
        with self.assertRaises(RuntimeError): self.bootstrap(api,stat,FakeFlock(),guard)
        self.assertEqual(calls,[])
    def test_create_race_no_retry(self):
        api=FakeOs(); api.O_WRONLY=4; api.O_CREAT=8; api.O_EXCL=16; calls=[]
        api.lstat=lambda path:(_ for _ in ()).throw(FileNotFoundError())
        def op(*args): calls.append(args); raise FileExistsError()
        api.open=op
        with self.assertRaises(RuntimeError): self.bootstrap(api,stat,FakeFlock(),lambda:None)
        self.assertEqual(len(calls),1)

if __name__=='__main__': unittest.main()
