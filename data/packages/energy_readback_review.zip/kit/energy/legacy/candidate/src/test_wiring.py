"""Packaged-core mock integration and actual local child wait; never board/UI."""
import os
import itertools
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch
from integration_binding import configure_core
from integration_common import CORE_SHA, decode, read
from test_integration import Clock, Driver, settings
from pc_capture import PcCapture
from relay import relay

ROOT=Path(__file__).resolve().parent.parent

@unittest.skipUnless((ROOT/'core').is_dir(),'packaged core required; no workspace fallback')
class Wiring(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.core=configure_core(ROOT)

    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.base=Path(self.temp.name).resolve(); (self.base/'csv').mkdir(); (self.base/'journal').mkdir()

    def execute(self, stop_after_first_pl=False):
        from batch_binding import load_bank
        from batch_policy import BatchPolicy
        from batch_session import execute
        from capture_bridge import CaptureBridge
        from batch_core import write_new
        bank=load_bank(self.core)  # original 3MiB bytes, no GEMM/NumPy
        stop=[]; done=threading.Event(); faults=[]; exchanges=[]; calls=[]
        driver=Driver(self.base/'csv'); clock=Clock(); clock.pump=driver.pump
        pc=PcCapture(driver,self.base/'csv',self.base/'pc',settings(),clock=clock,sleep=clock.sleep)
        bridge=CaptureBridge(self.base/'bridge','a'*32,lambda:bool(stop),ack_timeout_s=2,enabled=True)
        class Peer:
            def check_idle(self): pass  # explicit in-memory fixture; no network/EOF observation
            def send(self,request): self.next=pc.handle(request)
            def receive(self,*_): return self.next
        def exchange():
            try: exchanges.extend(relay(bridge.directory,Peer(),settings(),lambda:bool(stop),done.is_set,self.base/'journal'))
            except BaseException as error: faults.append(type(error).__name__)
        thread=threading.Thread(target=exchange); thread.start()
        clean=dict(held=False,safety_unresolved=False,lease_retained=False,runner_retained=False,root_buffers_retained=0)
        class Owner:
            supervision_status=clean; cleanup_readback={'source':'SYNTHETIC owner only'}; closed=False
            def pre_submit(self): return {'SYNTHETIC':True}
            def close(self): self.closed=True
        owner=Owner()
        def cpu(command,folder,owner,stopped,policy,before,accept,begin,end):
            for index in range(policy.per_window):
                if index==policy.warmup: begin()
                before(index); calls.append('cpu')
                accept(index,dict(begin_ns=1,end_ns=2,process_cpu_ns=1),bank[index%2].expected)
            end()
            return dict(actual_exit_code=0,process_group_absent=True,group_query_injected=True,
                        source='SYNTHETIC CPU lifecycle, not OS evidence')
        def pl(input_id):
            calls.append('pl')
            if stop_after_first_pl: stop.append('SYNTHETIC stop after returned request')
            return bank[input_id-42].expected,{'SYNTHETIC':True}
        evidence=self.base/'worker'; evidence.mkdir()
        try:
            # Windows process CPU clock may not advance for a no-work fake PL
            # return. Supply explicit synthetic positive ticks in this fixture;
            # do not weaken the frozen production timing validity check.
            with patch('batch_session.time.process_time_ns',side_effect=itertools.count(1).__next__):
                result=execute(self.core,CORE_SHA,evidence,BatchPolicy('abba1808',enabled=True),bank,owner,pl,bridge,lambda:bool(stop),cpu_window=cpu)
        finally:
            done.set(); thread.join(3)
            self.assertFalse(thread.is_alive())
            self.last=dict(owner=owner,calls=calls,pc=pc,driver=driver,faults=faults,exchanges=exchanges,evidence=evidence)
        return result

    def test_real_bridge_to_pc_controller_four_windows(self):
        result=self.execute(); self.assertTrue(result['operation_success'])
        self.assertEqual(result['counts']['accepted'],1824)
        self.assertEqual(self.last['calls'].count('pl'),912)
        self.assertEqual(self.last['pc'].index,4); self.assertTrue(self.last['owner'].closed)
        self.assertEqual(len(self.last['exchanges']),8); self.assertEqual(self.last['faults'],[])
        self.assertEqual(self.last['driver'].clicks,[True,False]*4)
        self.assertEqual(len(list((self.last['evidence']/'outputs').glob('*.bin'))),8)

    def test_stopped_return_checked_not_accepted_no_next(self):
        from batch_policy import BatchStop
        with self.assertRaises(BatchStop): self.execute(True)
        record=decode(read(self.last['evidence']/'lifecycle.json',100000))
        self.assertEqual((record['started'],record['exact_checked'],record['accepted']),(457,457,456))
        self.assertEqual(self.last['calls'],['cpu']*456+['pl'])
        self.assertTrue(self.last['owner'].closed); self.assertFalse(record['operation_success'])
        self.assertTrue((self.last['evidence']/'outputs/first_failed_or_stopped_output.bin').is_file())

    def test_actual_local_wait_fixture_explicitly_not_os_group_evidence(self):
        from batch_observer import observe
        record=observe([sys.executable,'-B','-c','raise SystemExit(0)'],self.base/'observer',lambda:False,
            lambda:self.fail('unexpected stop'),enabled=True,group_query=lambda pid:True)
        self.assertEqual(record['actual_child_exit_code'],0)
        self.assertTrue(record['group_query_injected'])  # cannot pass production outer receipt

    def test_actual_nonzero_local_wait(self):
        from batch_observer import observe
        record=observe([sys.executable,'-B','-c','raise SystemExit(7)'],self.base/'observer',lambda:False,
            lambda:None,enabled=True,group_query=lambda pid:True)
        self.assertEqual(record['actual_child_exit_code'],7)

    def test_default_off_before_output_or_socket(self):
        from integration_entry import board, pc, worker
        with self.assertRaises(RuntimeError): board(ROOT,'0'*64,self.base/'never',settings(),'0'*64)
        with self.assertRaises(RuntimeError): pc(ROOT,'0'*64,self.base/'never',settings(),'0'*64,self.base/'csv',None)
        with self.assertRaises(RuntimeError): worker(ROOT,'0'*64,self.base/'never',settings(),{})
        self.assertFalse((self.base/'never').exists())

    @unittest.skipIf(os.name=='posix','this rejection test targets the current Windows PC')
    def test_enabled_board_entry_still_refuses_pc_before_socket(self):
        from integration_entry import board
        identity=__import__('hashlib').sha256((ROOT/'integration_identity.json').read_bytes()).hexdigest()
        with patch('integration_entry.socket.socket',side_effect=AssertionError('must not connect')):
            with self.assertRaises(RuntimeError): board(ROOT,identity,self.base/'never',settings(),'0'*64,
                board_serial='ftdi-1234-tulB',pynq_image='pynq-z2-v3.1.1',peer_wait_s=1,enabled=True)
        self.assertFalse((self.base/'never').exists())

    def test_powershell_runtime_copy_bom_and_original_text(self):
        for name in ('native_controls.ps1','msaa_read.ps1'):
            runtime=(ROOT/'host'/name).read_bytes(); original=(ROOT/'host/original'/name).read_bytes()
            self.assertTrue(runtime.startswith(b'\xef\xbb\xbf'))
            text=original.decode('utf-8-sig')
            if name=='native_controls.ps1':
                start=text.index('function Get-Ut70Host {'); end=text.index('function Get-Ut70NamedControl',start)
                text=text[:start]+"function Get-Ut70Host { throw 'STOP: use only the verified host_operation entry' }\n\n"+text[end:]
                self.assertNotIn('25116',runtime.decode('utf-8-sig'))
            self.assertEqual(runtime.decode('utf-8-sig'),text)

    def test_pc_host_preflight_failure_before_socket(self):
        from integration_entry import pc
        identity=__import__('hashlib').sha256((ROOT/'integration_identity.json').read_bytes()).hexdigest()
        driver=Driver(self.base/'csv'); driver.identity['serial']='WRONG'
        with patch('integration_entry.socket.create_connection',side_effect=AssertionError('no peer before host preflight')):
            with self.assertRaises(RuntimeError): pc(ROOT,identity,self.base/'pc_fail',settings(),'0'*64,self.base/'csv',driver,enabled=True)
        self.assertEqual(driver.clicks,[])
        result=decode(read(self.base/'pc_fail/pc_receipt.json'))
        self.assertFalse(result['operation_success'])

    def test_signal_restore_does_not_skip_other_handlers(self):
        import integration_entry as entry
        stops=[]; restored=[]
        def change(number, handler):
            if handler=='old':
                restored.append(number)
                if len(restored)==1: raise OSError('synthetic restore failure')
        with patch.object(entry.signal,'getsignal',return_value='old'),patch.object(entry.signal,'signal',side_effect=change):
            with entry.signals(stops) as errors: pass
        self.assertGreaterEqual(len(restored),2); self.assertEqual(len(errors),1)

if __name__=='__main__': unittest.main()
