"""Long-plan regressions. SYNTHETIC settings, NOT approval/measurement."""
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from integration_common import *
from test_integration import settings, valid_receipt_data, answer, request
from outer_receipt import evaluate

class LongConfig(unittest.TestCase):
    def test_old_namespace_refused(self):
        value=settings(); value['schema']='energy-smoke-integration-v1'
        with self.assertRaises(ValueError): config(value)

    def test_budget_no_default(self):
        for bad in (None,{},False,dict(max_absolute_J='1',max_relative='.1')):
            with self.subTest(bad=bad):
                value=settings(); value['consistency_policy']=bad
                with self.assertRaises(ValueError): config(value)

    def test_budget_strings_only_finite_bounded(self):
        for bad in (True,0.1,'NaN','Inf',' 1','1_0','1e999','0.000000000000000000001','９','0','-1'):
            for key in ('max_absolute_J','max_relative'):
                with self.subTest(bad=bad,key=key):
                    value=settings(); value['consistency_policy'][key]=bad
                    with self.assertRaises(ValueError): config(value)

    def test_relative_at_one_refused(self):
        value=settings(); value['consistency_policy']['max_relative']='1'
        with self.assertRaises(ValueError): config(value)

    def test_policy_basis_required(self):
        for bad in ('','  ','a\nb','x'*513,False):
            value=settings(); value['consistency_policy']['basis']=bad
            with self.assertRaises(ValueError): config(value)

    def test_policy_snapshot_not_alias(self):
        original=settings(); checked=config(original)
        original['consistency_policy']['max_absolute_J']='9'
        self.assertEqual(checked['consistency_policy']['max_absolute_J'],'0.01')

    def test_activity_completion_explicit_bounds(self):
        for key in ('activity_wait_s','completion_wait_s'):
            for bad in (True,None,0,2,3601,float('inf'),float('nan')):
                value=settings(); value[key]=bad
                with self.subTest(key=key,bad=bad),self.assertRaises(ValueError): config(value)

    def test_full_settings_bind_policy_not_frozen_capture_sha(self):
        one=settings(); two=settings(); two['consistency_policy']['max_absolute_J']='0.02'
        self.assertNotEqual(sha(encode(config(one))),sha(encode(config(two))))
        self.assertEqual(expected_capture_sha(one),expected_capture_sha(two))

    def test_full_settings_bind_waits(self):
        one=settings(); two=settings(); two['activity_wait_s']=91
        self.assertNotEqual(sha(encode(config(one))),sha(encode(config(two))))

    def test_settings_file_hash_before_adoption(self):
        from integration_entry import settings_file
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'synthetic.json'; new_json(path,settings())
            with self.assertRaises(ValueError): settings_file(path,'0'*64)
            self.assertEqual(settings_file(path,sha(read(path))),settings())

class LongRows(unittest.TestCase):
    def run_value(self,data):
        return evaluate(*data,session_id='a'*32,transport_clean=True,expected_config_sha=expected_capture_sha(settings()))

    def test_plan_job_range_and_counts(self):
        from batch_policy import BatchPolicy
        policy=BatchPolicy(PROFILE,enabled=True)
        self.assertEqual((policy.per_window,policy.pl_calls),(456,912))
        first=policy.request(0); last=policy.request(911)
        self.assertEqual(first.first_job_id,1)
        self.assertEqual(last.first_job_id,58305)
        self.assertLess(last.first_job_id+63,65536)
        with self.assertRaises(ValueError): policy.request(912)

    def test_full_1824_rows_and_last_phase(self):
        data=valid_receipt_data()
        self.assertEqual(len(data[4]),1824)
        self.assertEqual(data[4][-1]['phase_index'],451)
        self.assertTrue(self.run_value(data)['operation_success'])

    def test_partial_row_1823_refused(self):
        data=valid_receipt_data(); data[4].pop()
        self.assertFalse(self.run_value(data)['operation_success'])

    def test_wrong_last_phase_refused(self):
        data=valid_receipt_data(); data[4][-1]['phase_index']=1
        self.assertFalse(self.run_value(data)['operation_success'])

    def test_smoke_or_inflated_counts_refused(self):
        for field,bad in [('accepted',16),('measured_calls',1824),('warmup_calls',8),('accepted',True)]:
            data=valid_receipt_data(); data[2]['counts'][field]=bad
            self.assertFalse(self.run_value(data)['operation_success'])

    def test_request_plan_drift_refused(self):
        data=valid_receipt_data(); data[5]['plan']['measured_per_window']=2
        self.assertFalse(self.run_value(data)['operation_success'])

    def test_boolean_plan_counter_refused(self):
        data=valid_receipt_data(); data[2]['plan']['board_run_authorized']=0
        self.assertFalse(self.run_value(data)['operation_success'])

    def test_cpu_old_smoke_count_refused(self):
        data=valid_receipt_data(); data[2]['cpu_windows'][1]['checked_calls']=4
        self.assertFalse(self.run_value(data)['operation_success'])

    def test_calls_read_budget_covers_frozen_max_metadata(self):
        self.assertGreater(CALLS_BYTE_LIMIT,1824*(16384+2)+2)
        raw=encode(valid_receipt_data()[4]); self.assertGreater(len(raw),300000)
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'calls.json'; path.write_bytes(raw)
            with self.assertRaises(ValueError): read(path,300000)
            self.assertEqual(len(decode(read(path,CALLS_BYTE_LIMIT))),1824)

class LongPcWaiting(unittest.TestCase):
    def test_explicit_waits_and_policy_receipt(self):
        import integration_entry as entry
        chosen=settings(); waits=[]
        hello=dict(kind='hello',session_id=chosen['session_id'],settings_sha256='e'*64,identity_sha256='f'*64)
        messages=[hello]+[request(w,k) for w in range(4) for k in ('begin','end')]+[
            dict(kind='captures_complete',session_id=chosen['session_id'],worker_checks_passed=True)]
        class Connection:
            def __enter__(self): return self
            def __exit__(self,*_): pass
        class Peer:
            def __init__(self,_): pass
            def send(self,_): pass
            def receive(self,timeout,stopped): waits.append(timeout); return messages.pop(0)
        class Controller:
            def __init__(self,driver,csv,output,config):
                self.output=output; output.mkdir(); self.index=0; self.active=None
            def state(self,value): pass
            def handle(self,value):
                if value['kind']=='end': self.index+=1
                return answer(value,str(value['window'])*32)
        with tempfile.TemporaryDirectory() as temp:
            output=Path(temp)/'pc'
            with patch.object(entry,'verify'),patch.object(entry,'configure_core'),\
                 patch('pc_capture.PcCapture',Controller),patch.object(entry,'JsonPeer',Peer),\
                 patch.object(entry.socket,'create_connection',return_value=Connection()):
                entry.pc(Path(temp),'f'*64,output,chosen,'e'*64,Path(temp),object(),enabled=True)
            receipt=decode(read(output/'pc_receipt.json'))
            self.assertEqual(waits,[2]+[90]*8+[30])
            self.assertEqual(receipt['consistency_policy'],chosen['consistency_policy'])
            self.assertIs(receipt['numeric_consistency_evaluated'],False)

if __name__=='__main__': unittest.main()
