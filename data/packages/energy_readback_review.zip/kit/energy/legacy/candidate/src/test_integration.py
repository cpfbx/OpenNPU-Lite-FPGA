"""Synthetic only. Never invokes PowerShell, SSH, socket listeners or native code."""
import copy
from pathlib import Path
import socket
import stat
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from integration_common import *
from pc_capture import PcCapture, HOST_SHA
from outer_receipt import evaluate, EXPECTED
from lock_probe import probe_with
from relay import JsonPeer, relay

def settings():
    return dict(schema=SETTINGS_SCHEMA,profile=PROFILE,session_id='a'*32,
        ack_timeout_s=2,start_timeout_s=.2,stable_interval_s=.01,pre_buffer_s=0,post_buffer_s=0,port=18765,
        activity_wait_s=90,completion_wait_s=30,
        consistency_policy=dict(max_absolute_J='0.01',max_relative='0.001',
            basis='SYNTHETIC UNIT TEST ONLY; NOT MEASUREMENT APPROVAL'))

def request(w, kind):
    value = dict(session_id='a'*32,window=w,kind=kind,config_sha256=expected_capture_sha(settings()))
    value['request_token'] = sha(encode(value)); return value

def answer(req, cid):
    value = dict(req,capture_id=cid,csv_bytes=5,csv_sha256='c'*64,snapshot='window_%d.csv'%req['window'],
                 csv_units_interpreted=False,synchronized_task_energy_verified=False)
    value['saving_started' if req['kind']=='begin' else 'saving_stopped'] = True
    return value

class Clock:
    def __init__(self): self.now = 0; self.pump = lambda:None
    def __call__(self): return self.now
    def sleep(self, duration): self.now += duration; self.pump()

class Driver:
    def __init__(self, folder):
        self.folder = folder; self.saving = False; self.clicks = []; self.number = 0
        self.fail_click = False; self.grow = True; self.mutate_old = False
        self.identity = dict(host_pid=123,host_start_ticks='111',exe_sha256=HOST_SHA,
                             serial='D0E18C66',rate='10SPS',connected=True)
    def inspect(self): return dict(self.identity,saving=self.saving)
    def set_saving(self, value):
        before = self.saving; self.saving = value; self.clicks.append(value)
        if value:
            self.number += 1; self.current = self.folder/('fresh_%d.CSV'%self.number)
            self.current.write_bytes(b'fixture,not-measurement\n')
        if self.fail_click: raise OSError('synthetic uncertain click')
        return dict(changed=True,before=before,after=value)
    def pump(self):
        if self.saving and self.grow:
            with self.current.open('ab') as stream: stream.write(b'0,1\n')
        if self.mutate_old:
            (self.folder/'old.csv').write_bytes(b'changed')

class Fixture(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name).resolve(); self.csv = self.base/'csv'; self.csv.mkdir()
        self.driver = Driver(self.csv); self.clock = Clock(); self.clock.pump = self.driver.pump
    def controller(self):
        return PcCapture(self.driver,self.csv,self.base/'output',settings(),clock=self.clock,sleep=self.clock.sleep)

class ConfigTests(Fixture):
    def test_abba_only(self): self.assertEqual(config(settings())['profile'],'abba1808')
    def test_smoke_refused(self):
        value = settings(); value['profile']='smoke8'
        with self.assertRaises(ValueError): config(value)
    def test_all_parameters_explicit(self):
        for key in settings():
            with self.subTest(key=key):
                value=settings(); del value[key]
                with self.assertRaises(ValueError): config(value)
    def test_nonfinite_bool_timeout(self):
        for bad in (True,False,float('nan'),float('inf'),-1,601):
            with self.subTest(bad=bad):
                value=settings(); value['ack_timeout_s']=bad
                with self.assertRaises(ValueError): config(value)
    def test_short_ack_budget(self):
        value=settings(); value['ack_timeout_s']=.21
        with self.assertRaises(ValueError): config(value)
    def test_boolean_port(self):
        value=settings(); value['port']=True
        with self.assertRaises(ValueError): config(value)
    def test_duplicate_json(self):
        with self.assertRaises(ValueError): decode(b'{"a":1,"a":2}')
    def test_nan_json(self):
        with self.assertRaises(ValueError): decode(b'{"a":NaN}')
    def test_no_clobber_json(self):
        path=self.base/'value.json'; new_json(path,dict(a=1))
        with self.assertRaises(FileExistsError): new_json(path,dict(a=2))
        self.assertEqual(decode(read(path)),dict(a=1))
    def test_big_file(self):
        path=self.base/'large'; path.write_bytes(b'x'*20)
        with self.assertRaises(ValueError): read(path,19)

class CaptureTests(Fixture):
    def test_four_windows_new_stable_snapshots(self):
        controller=self.controller()
        for w in range(4):
            start=controller.handle(request(w,'begin')); end=controller.handle(request(w,'end'))
            self.assertEqual(start['capture_id'],end['capture_id'])
            self.assertFalse(end['csv_units_interpreted'])
            self.assertEqual(end['csv_sha256'],sha((controller.output/end['snapshot']).read_bytes()))
        self.assertEqual(controller.index,4); self.assertEqual(self.driver.clicks,[True,False]*4)
    def test_existing_saving_not_touched(self):
        self.driver.saving=True; controller=self.controller()
        with self.assertRaises(RuntimeError): controller.handle(request(0,'begin'))
        self.assertTrue(controller.close_on_failure()['manual_followup_required'])
        self.assertEqual(self.driver.clicks,[])
    def test_host_hash_mismatch(self):
        self.driver.identity['exe_sha256']='0'*64; controller=self.controller()
        with self.assertRaises(RuntimeError): controller.handle(request(0,'begin'))
        self.assertEqual(self.driver.clicks,[])
    def test_host_pid_reuse(self):
        controller=self.controller(); controller.handle(request(0,'begin'))
        self.driver.identity['host_start_ticks']='112'
        with self.assertRaises(RuntimeError): controller.handle(request(0,'end'))
        self.assertEqual(self.driver.clicks,[True])
    def test_wrong_rate(self):
        self.driver.identity['rate']='100SPS'; controller=self.controller()
        with self.assertRaises(RuntimeError): controller.handle(request(0,'begin'))
    def test_uncertain_start_never_retried(self):
        controller=self.controller(); self.driver.fail_click=True
        with self.assertRaises(OSError): controller.handle(request(0,'begin'))
        self.assertTrue(controller.close_on_failure()['manual_followup_required'])
        self.assertEqual(self.driver.clicks,[True])
    def test_uncertain_stop_never_retried(self):
        controller=self.controller(); controller.handle(request(0,'begin')); self.driver.fail_click=True
        with self.assertRaises(OSError): controller.handle(request(0,'end'))
        self.assertTrue(controller.close_on_failure()['manual_followup_required'])
        self.assertEqual(self.driver.clicks,[True,False])
    def test_start_no_growth_deadline(self):
        controller=self.controller(); self.driver.grow=False
        with self.assertRaises(TimeoutError): controller.handle(request(0,'begin'))
        self.assertTrue(controller.close_on_failure()['saving_stop_confirmed'])
        self.assertEqual(self.driver.clicks,[True,False])
    def test_old_file_changed_before_start(self):
        (self.csv/'old.csv').write_bytes(b'old'); self.driver.mutate_old=True; controller=self.controller()
        with self.assertRaises(RuntimeError): controller.handle(request(0,'begin'))
        self.assertEqual(self.driver.clicks,[])
    def test_multiple_new_csvs(self):
        controller=self.controller(); original=self.driver.pump
        def two():
            original()
            if self.driver.saving: (self.csv/'extra.csv').write_bytes(b'new')
        self.clock.pump=two
        with self.assertRaises(RuntimeError): controller.handle(request(0,'begin'))
        controller.close_on_failure(); self.assertEqual(self.driver.clicks,[True,False])
    def test_unstable_after_stop(self):
        controller=self.controller(); controller.handle(request(0,'begin'))
        self.clock.pump=lambda:(self.csv/'other.csv').write_bytes(str(self.clock()).encode())
        with self.assertRaises(RuntimeError): controller.handle(request(0,'end'))
        controller.close_on_failure(); self.assertEqual(self.driver.clicks,[True,False])
    def test_wrong_session(self):
        controller=self.controller(); value=request(0,'begin'); value['session_id']='c'*32
        with self.assertRaises(ValueError): controller.handle(value)
        self.assertEqual(self.driver.clicks,[])
    def test_wrong_window(self):
        controller=self.controller()
        with self.assertRaises(ValueError): controller.handle(request(1,'begin'))
    def test_end_without_start(self):
        controller=self.controller()
        with self.assertRaises(RuntimeError): controller.handle(request(0,'end'))
    def test_no_restart_after_failure(self):
        controller=self.controller()
        with self.assertRaises(ValueError): controller.handle(request(1,'begin'))
        with self.assertRaises(RuntimeError): controller.handle(request(0,'begin'))
    def test_tampered_request_token(self):
        controller=self.controller(); value=request(0,'begin'); value['request_token']='f'*64
        with self.assertRaises(ValueError): controller.handle(value)
    def test_boolean_window(self):
        controller=self.controller(); value=request(0,'begin'); value['window']=False
        with self.assertRaises(ValueError): controller.handle(value)

def valid_receipt_data():
    from batch_policy import BatchPolicy
    policy=BatchPolicy(PROFILE,enabled=True)
    lock=dict(success=True,path=LOCK,uid=1000,device=123,inode=456,exclusive_probe=True,
              probe_descriptor_closed=True,session_lock_held=False)
    observation=dict(actual_child_exit_code=0,process_group_absent=True,group_query_injected=False,
                     observer_clean=True,stop_requested=False,child_pid=789)
    proof=dict(device=123,inode=456,path=LOCK,exclusive_flock=True,cloexec=True,pid=789)
    resources=dict(held=False,safety_unresolved=False,lease_retained=False,runner_retained=False,root_buffers_retained=0)
    lifecycle=dict(package_sha256=CORE_SHA,operation_success=True,cleanup_complete=True,
        plan=policy.describe(),
        counts=dict(started=1824,completed=1824,exact_checked=1824,accepted=1824,measured_calls=1808,warmup_calls=16),
        resources=resources,cleanup_readback=dict(last_lock_proof=proof,terminal=dict(build_id=0x2026D075,phase=1,error=0)),
        capture_close_confirmed=True,capture_manual_followup_required=False,
        cpu_windows=[dict(actual_exit_code=0,process_group_absent=True,group_query_injected=False,stop_requested=False,
                         error_type=None,checked_calls=456) for _ in range(2)],
        formal_energy_input_accepted=False,synchronized_task_energy_verified=False,promotion=False)
    rows=[]
    for w in range(4):
        for i in range(456):
            p=42+i%2
            rows.append(dict(window=w,index=i,input_id=p,phase_index=i if i<4 else i-4,
                backend=('openblas_2t','fpga_cached','fpga_cached','openblas_2t')[w],
                phase='warmup' if i<4 else 'measured',exact=True,accepted=True,
                expected_sha256=EXPECTED[p],output_sha256=EXPECTED[p]))
    exchanges=[]
    for w in range(4):
        for kind in ('begin','end'):
            req=request(w,kind); exchanges.append(dict(request=req,ack=answer(req,str(w)*32)))
    return [dict(success=True,worker=lock),observation,lifecycle,
            dict(operation_success=True,stop_signals=[],handler_restore_errors=[]),rows,
            dict(package_sha256=CORE_SHA,config_sha256=expected_capture_sha(settings()),plan=policy.describe()),exchanges,dict(lock,created=False)]

class ReceiptTests(unittest.TestCase):
    def run_value(self, values): return evaluate(*values,session_id='a'*32,transport_clean=True,expected_config_sha=expected_capture_sha(settings()))
    def test_success(self): self.assertTrue(self.run_value(valid_receipt_data())['operation_success'])
    def test_mutations_refused(self):
        mutations=[
            (0,('success',),False),(1,('actual_child_exit_code',),True),
            (1,('actual_child_exit_code',),1),(1,('group_query_injected',),True),
            (1,('process_group_absent',),False),(1,('stop_requested',),True),
            (2,('counts','accepted'),15),(2,('resources','root_buffers_retained'),True),
            (2,('cleanup_readback','terminal','error'),1),
            (2,('cleanup_readback','last_lock_proof','inode'),457),
            (2,('cleanup_readback','last_lock_proof','pid'),790),
            (2,('capture_manual_followup_required',),True),(2,('promotion',),True),
            (3,('handler_restore_errors',),[dict(signal=2)]),(5,('config_sha256',),'c'*64),
            (7,('inode',),999),(7,('created',),True),(7,('probe_descriptor_closed',),False)]
        for slot, path, bad in mutations:
            with self.subTest(path=path,bad=bad):
                data=valid_receipt_data(); obj=data[slot]
                for key in path[:-1]: obj=obj[key]
                obj[path[-1]]=bad
                self.assertFalse(self.run_value(data)['operation_success'])
    def test_corrupt_row(self):
        data=valid_receipt_data(); data[4][3]['output_sha256']='0'*64
        self.assertFalse(self.run_value(data)['operation_success'])
    def test_injected_cpu_exit(self):
        data=valid_receipt_data(); data[2]['cpu_windows'][0]['group_query_injected']=True
        self.assertFalse(self.run_value(data)['operation_success'])
    def test_ack_capture_id_drift(self):
        data=valid_receipt_data(); data[6][1]['ack']['capture_id']='c'*32
        self.assertFalse(self.run_value(data)['operation_success'])
    def test_duplicate_capture_ids(self):
        data=valid_receipt_data()
        for item in data[6]: item['ack']['capture_id']='0'*32
        self.assertFalse(self.run_value(data)['operation_success'])
    def test_transport_failure(self):
        self.assertFalse(evaluate(*valid_receipt_data(),session_id='a'*32,transport_clean=False,expected_config_sha=expected_capture_sha(settings()))['operation_success'])
    def test_invalid_csv_snapshot_refused(self):
        for key,bad in [('csv_bytes',True),('csv_bytes',0),('csv_bytes',17000000),('csv_sha256','z'*64),
                        ('snapshot','../window_0.csv'),('csv_units_interpreted',True)]:
            with self.subTest(key=key):
                data=valid_receipt_data(); data[6][1]['ack'][key]=bad
                self.assertFalse(self.run_value(data)['operation_success'])

class FakeOs:
    O_RDONLY=0; O_NOFOLLOW=1; O_NONBLOCK=2
    def __init__(self):
        self.value=SimpleNamespace(st_mode=stat.S_IFREG|0o644,st_uid=1000,st_nlink=1,st_dev=123,st_ino=456)
        self.closed=[]; self.flags=None
    def lstat(self,path):
        if path!=LOCK: raise AssertionError('wrong lock')
        return self.value
    def open(self,path,flags): self.flags=flags; return 7
    def fstat(self,fd): return self.value
    def close(self,fd): self.closed.append(fd)

class FakeFlock:
    LOCK_EX=1; LOCK_NB=2
    def __init__(self): self.busy=False
    def flock(self,fd,flags):
        if self.busy: raise BlockingIOError('busy')

class ProbeTests(unittest.TestCase):
    def test_same_inode_readonly(self):
        api=FakeOs(); result=probe_with(dict(device=123,inode=456),api,stat,FakeFlock())
        self.assertFalse(result['created']); self.assertEqual(api.flags,3); self.assertEqual(api.closed,[7])
    def test_busy_closed_not_repaired(self):
        api=FakeOs(); locks=FakeFlock(); locks.busy=True
        with self.assertRaises(BlockingIOError): probe_with(dict(device=123,inode=456),api,stat,locks)
        self.assertEqual(api.closed,[7])
    def test_bad_lock_properties(self):
        for field,bad in [('st_uid',0),('st_nlink',2),('st_mode',stat.S_IFLNK|0o644),
                          ('st_mode',stat.S_IFREG|0o666),('st_ino',457)]:
            with self.subTest(field=field):
                api=FakeOs(); setattr(api.value,field,bad)
                with self.assertRaises(RuntimeError): probe_with(dict(device=123,inode=456),api,stat,FakeFlock())
                self.assertEqual(api.closed,[])
    def test_inode_changed_after_open(self):
        api=FakeOs()
        def fstat_bad(fd):
            value=copy.copy(api.value); value.st_ino=999; return value
        api.fstat=fstat_bad
        with self.assertRaises(RuntimeError): probe_with(dict(device=123,inode=456),api,stat,FakeFlock())
        self.assertEqual(api.closed,[7])

class FakeConnection:
    def __init__(self, blocks): self.blocks=list(blocks); self.sent=[]
    def settimeout(self,value): pass
    def recv(self,count):
        block=self.blocks.pop(0)
        if isinstance(block,BaseException): raise block
        if len(block)>count:
            self.blocks.insert(0,block[count:]); return block[:count]
        return block
    def sendall(self,raw): self.sent.append(raw)

class PeerTests(Fixture):
    def test_fragmented_json(self):
        peer=JsonPeer(FakeConnection([b'{"a":',b'1}\n{"b":2}\n']))
        self.assertEqual(peer.receive(1,lambda:False),dict(a=1)); self.assertEqual(peer.receive(1,lambda:False),dict(b=2))
    def test_eof(self):
        with self.assertRaises(EOFError): JsonPeer(FakeConnection([b''])).receive(1,lambda:False)
    def test_stop(self):
        with self.assertRaises(RuntimeError): JsonPeer(FakeConnection([])).receive(1,lambda:True)
    def test_oversized_json(self):
        with self.assertRaises(ValueError): JsonPeer(FakeConnection([b'x'*(LIMIT+1)])).receive(1,lambda:False)
    def test_wire_duplicate_key(self):
        with self.assertRaises(ValueError): JsonPeer(FakeConnection([b'{"x":1,"x":2}\n'])).receive(1,lambda:False)
    def test_relay_eight_exchanges(self):
        directory=self.base/'bridge'; directory.mkdir(); journal=self.base/'journal'; journal.mkdir()
        blocks=[]
        for w in range(4):
            for kind in ('begin','end'):
                req=request(w,kind); new_json(directory/('window_%d_%s_request.json'%(w,kind)),req)
                blocks.append(encode(answer(req,str(w)*32)))
        connection=FakeConnection(blocks)
        result=relay(directory,JsonPeer(connection),settings(),lambda:False,lambda:False,journal)
        self.assertEqual(len(result),8); self.assertEqual(len(connection.sent),8)
        self.assertTrue((directory/'window_3_end_ack.json').is_file())
    def test_worker_exit_before_request(self):
        with self.assertRaises(RuntimeError): relay(self.base,JsonPeer(FakeConnection([])),settings(),lambda:False,lambda:True,self.base)
    def test_stale_ack_never_published(self):
        directory=self.base/'bridge'; directory.mkdir(); journal=self.base/'journal'; journal.mkdir()
        req=request(0,'begin'); new_json(directory/'window_0_begin_request.json',req)
        bad=answer(req,'0'*32); bad['session_id']='f'*32
        with self.assertRaises(ValueError): relay(directory,JsonPeer(FakeConnection([encode(bad)])),settings(),lambda:False,lambda:False,journal)
        self.assertFalse((directory/'window_0_begin_ack.json').exists())

class GuiPolicyTests(Fixture):
    def fake_shell(self):
        from ut70_driver import PowerShellDriver
        value=PowerShellDriver.__new__(PowerShellDriver)
        value.shell=self.base/'pwsh.exe'; value.shell.write_bytes(b'SYNTHETIC NEVER EXECUTED')
        value.runtime=dict(sha256=sha(value.shell.read_bytes())); value.policy_checked=False
        value.folder=self.base; value.identity=['123','SYNTHETIC_HOST.exe','111']
        value.wait_s=.05; value.pending=None; value.process_records=[]; value.evidence=None
        value.bind_evidence(self.base/'gui_processes')
        return value
    def test_restricted_refused_before_file_execution(self):
        shell=self.fake_shell(); calls=[]
        def popen(argv,**kwargs):
            calls.append(argv); kwargs['stdout'].write(b'"Restricted"')
            return SimpleNamespace(pid=123,wait=lambda timeout:0)
        with patch('ut70_driver.subprocess.Popen',side_effect=popen),patch('ut70_driver.subprocess.CREATE_NO_WINDOW',0,create=True):
            with self.assertRaises(RuntimeError): shell.inspect()
        self.assertEqual(len(calls),1); self.assertNotIn('-File',calls[0])
    def test_remote_signed_queries_then_one_operation(self):
        shell=self.fake_shell(); calls=[]
        def popen(argv,**kwargs):
            calls.append(argv)
            kwargs['stdout'].write(b'"RemoteSigned"' if '-Command' in argv else b'{"saving":false}')
            return SimpleNamespace(pid=123,wait=lambda timeout:0)
        with patch('ut70_driver.subprocess.Popen',side_effect=popen),patch('ut70_driver.subprocess.CREATE_NO_WINDOW',0,create=True):
            self.assertEqual(shell.inspect(),dict(saving=False))
        self.assertEqual(len(calls),2); self.assertIn('-File',calls[1])
        self.assertFalse(any('Bypass' in str(x) or 'Set-ExecutionPolicy' in str(x) for call in calls for x in call))
    def test_changed_shell_refused(self):
        shell=self.fake_shell(); shell.policy_checked=True; shell.shell.write_bytes(b'CHANGED')
        with patch('ut70_driver.subprocess.Popen',side_effect=AssertionError('no subprocess permitted')):
            with self.assertRaises(RuntimeError): shell.inspect()

    def test_nonzero_query_latches_without_repeating_preflight(self):
        shell=self.fake_shell()
        process=SimpleNamespace(pid=323,wait=lambda timeout:7)
        with patch('ut70_driver.subprocess.Popen',return_value=process) as spawn,patch('ut70_driver.subprocess.CREATE_NO_WINDOW',0,create=True):
            with self.assertRaises(RuntimeError): shell.inspect()
            with self.assertRaises(RuntimeError): shell.inspect()
        self.assertEqual(spawn.call_count,1)
        self.assertEqual(shell.process_records[0]['actual_exit'],7)

    def test_query_timeout_latches_without_kill_or_retry(self):
        shell=self.fake_shell(); calls=[]
        def wait(timeout): raise subprocess.TimeoutExpired('SYNTHETIC policy helper',timeout)
        process=SimpleNamespace(pid=321,wait=wait)
        with patch('ut70_driver.subprocess.Popen',return_value=process) as spawn,patch('ut70_driver.subprocess.CREATE_NO_WINDOW',0,create=True):
            with self.assertRaises(TimeoutError): shell.inspect()
            with self.assertRaises(RuntimeError): shell.inspect()
        self.assertEqual(spawn.call_count,1); self.assertIs(shell.pending,process)
        self.assertIsNone(shell.process_records[0]['actual_exit'])
        self.assertTrue(shell.process_records[0]['manual_followup_required'])
        self.assertFalse(shell.process_records[0]['automatic_kill'])

    def test_click_timeout_prevents_automatic_cleanup_helper(self):
        shell=self.fake_shell(); shell.policy_checked=True
        def wait(timeout): raise subprocess.TimeoutExpired('SYNTHETIC click helper',timeout)
        process=SimpleNamespace(pid=322,wait=wait)
        with patch('ut70_driver.subprocess.Popen',return_value=process) as spawn,patch('ut70_driver.subprocess.CREATE_NO_WINDOW',0,create=True):
            with self.assertRaises(TimeoutError): shell.set_saving(True)
            with self.assertRaises(RuntimeError): shell.set_saving(False)
            with self.assertRaises(RuntimeError): shell.inspect()
        self.assertEqual(spawn.call_count,1)

if __name__=='__main__': unittest.main()
