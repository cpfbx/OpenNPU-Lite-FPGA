Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName Accessibility
if (-not ('Ut70MsaaRead' -as [type])) {
    # This compiler-only suppression bridges the bundled COM interop reference's
    # System.Runtime 4.0 metadata to the current PowerShell runtime; no OS policy changes.
    Add-Type -CompilerOptions '/nowarn:1701' -ReferencedAssemblies ([Accessibility.IAccessible].Assembly.Location) -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using Accessibility;
public static class Ut70MsaaRead {
    [DllImport("oleacc.dll")]
    private static extern int AccessibleObjectFromWindow(IntPtr hwnd, uint obj, ref Guid iid, [MarshalAs(UnmanagedType.Interface)] out IAccessible acc);
    private static IAccessible Get(IntPtr h) {
        Guid iid = new Guid("618736E0-3C3D-11CF-810C-00AA00389B71");
        IAccessible a;
        int hr = AccessibleObjectFromWindow(h, 0xFFFFFFFC, ref iid, out a);
        Marshal.ThrowExceptionForHR(hr);
        if (a == null) throw new Exception("No accessible object");
        return a;
    }
    public static object[] Read(IntPtr h) {
        var a = Get(h);
        return new object[] {a.get_accName(0), a.get_accRole(0), a.get_accState(0), a.get_accValue(0), a.get_accDefaultAction(0)};
    }
}
'@
}
