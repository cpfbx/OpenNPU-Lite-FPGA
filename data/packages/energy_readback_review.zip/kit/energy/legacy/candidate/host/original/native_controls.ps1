Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'msaa_read.ps1')

if (-not ('Ut70CsvNative' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class Ut70CsvNative {
    public delegate bool EnumProc(IntPtr h, IntPtr p);
    [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr p, EnumProc c, IntPtr l);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint p);
    [DllImport("user32.dll")] public static extern bool IsChild(IntPtr p, IntPtr c);
    [DllImport("user32.dll")] public static extern bool IsWindowEnabled(IntPtr h);
    [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int n);
    [DllImport("user32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    public static extern IntPtr SendMessageTimeout(IntPtr h, uint m, IntPtr w, IntPtr l, uint flags, uint ms, out UIntPtr result);
    [DllImport("user32.dll", EntryPoint="SendMessageTimeoutW", CharSet=CharSet.Unicode, SetLastError=true)]
    public static extern IntPtr SendTextMessageTimeout(IntPtr h, uint m, IntPtr w, StringBuilder l, uint flags, uint ms, out UIntPtr result);
}
'@
}

function Get-Ut70Host {
    $p = Get-Process -Id 25116 -ErrorAction Stop
    $p.Refresh()
    $expected = 'C:\Users\BXstudywork\Downloads\ut70_host_20261017_b3599d5c\ATK_UT70_2.0.5.exe'
    if ($p.Path -ne $expected -or $p.MainWindowHandle -eq 0 -or -not $p.Responding) { throw 'STOP: expected host identity/window unavailable' }
    if ((Get-FileHash -LiteralPath $expected -Algorithm SHA256).Hash -ne 'B5EB981043E8F0AD927B852817C93A9215F41031038FB8C54FBAED1A9F794532') { throw 'STOP: executable identity changed' }
    return $p
}

function Get-Ut70NamedControl([string] $Name) {
    $p = Get-Ut70Host
    $found = [System.Collections.Generic.List[IntPtr]]::new()
    $callback = [Ut70CsvNative+EnumProc] {
        param([IntPtr]$h, [IntPtr]$unused)
        $b = [System.Text.StringBuilder]::new(512)
        [void][Ut70CsvNative]::GetWindowText($h, $b, $b.Capacity)
        if ($b.ToString() -ceq $Name) { $found.Add($h) }
        return $true
    }
    [void][Ut70CsvNative]::EnumChildWindows($p.MainWindowHandle, $callback, [IntPtr]::Zero)
    if ($found.Count -ne 1) { throw "STOP: control '$Name' is absent or ambiguous ($($found.Count))" }
    $h = $found[0]
    [uint32] $ownerPid = 0
    [void][Ut70CsvNative]::GetWindowThreadProcessId($h, [ref]$ownerPid)
    if ($ownerPid -ne $p.Id -or -not [Ut70CsvNative]::IsChild($p.MainWindowHandle, $h) -or -not [Ut70CsvNative]::IsWindowEnabled($h)) { throw 'STOP: control owner/parent/enabled check failed' }
    return $h
}

function Read-Ut70Message([IntPtr]$Handle, [uint32]$Message, [int]$Index = 0) {
    if ($Message -notin @(0x00F0, 0x0146, 0x0147)) { throw 'STOP: message is not an approved read' }
    [UIntPtr]$answer = [UIntPtr]::Zero
    $ok = [Ut70CsvNative]::SendMessageTimeout($Handle, $Message, [IntPtr]$Index, [IntPtr]::Zero, 2, 2000, [ref]$answer)
    if ($ok -eq [IntPtr]::Zero) { throw 'STOP: read timed out; no retry' }
    return $answer.ToUInt64()
}

function Get-Ut70SaveState {
    $h = Get-Ut70NamedControl '自动保存'
    $class = [System.Text.StringBuilder]::new(256)
    [void][Ut70CsvNative]::GetClassName($h, $class, $class.Capacity)
    $style = [Ut70CsvNative]::GetWindowLong($h, -16)
    $accessible = [Ut70MsaaRead]::Read($h)
    # This app uses BS_OWNERDRAW (11). BM_GETCHECK incorrectly returns 0 here.
    # Validate its MSAA check-button role (44) and checked bit instead.
    if ($class.ToString() -notlike 'WindowsForms10.BUTTON.*' -or ($style -band 15) -ne 11 -or $accessible[0] -cne '自动保存' -or [int]$accessible[1] -ne 44) { throw 'STOP: unexpected owner-drawn Auto Save control identity' }
    $state = [int]$accessible[2]
    if (($state -band 1) -ne 0 -or ($state -band 32) -ne 0) { throw 'STOP: checkbox unavailable or indeterminate' }
    return [pscustomobject]@{ Handle = $h; Checked = (($state -band 16) -ne 0); NativeButtonType = ($style -band 15); MsaaRole = [int]$accessible[1]; MsaaState = $state }
}

function Set-Ut70CsvSaving([bool]$Enabled) {
    # The ONLY write message in this helper targets this verified Auto Save checkbox.
    # It does not control protocol triggers, voltage, firmware, record groups or board software.
    $before = Get-Ut70SaveState
    if ($before.Checked -eq $Enabled) { return [pscustomobject]@{Changed=$false; Before=$before.Checked; After=$before.Checked} }
    [UIntPtr]$answer = [UIntPtr]::Zero
    $ok = [Ut70CsvNative]::SendMessageTimeout($before.Handle, 0x00F5, [IntPtr]::Zero, [IntPtr]::Zero, 2, 2000, [ref]$answer)
    if ($ok -eq [IntPtr]::Zero) { throw 'STOP: checkbox click outcome unknown; do not retry automatically' }
    $after = Get-Ut70SaveState
    if ($after.Checked -ne $Enabled) { throw 'STOP: checkbox did not reach requested state; no retry' }
    return [pscustomobject]@{Changed=$true; Before=$before.Checked; After=$after.Checked}
}

function Get-Ut70UploadOptions {
    $p = Get-Ut70Host
    $matches = [System.Collections.Generic.List[IntPtr]]::new()
    $callback = [Ut70CsvNative+EnumProc] {
        param([IntPtr]$candidate, [IntPtr]$unused)
        $class = [System.Text.StringBuilder]::new(256)
        [void][Ut70CsvNative]::GetClassName($candidate, $class, $class.Capacity)
        if ($class.ToString() -like 'WindowsForms10.COMBOBOX.*') {
            $accessible = [Ut70MsaaRead]::Read($candidate)
            if ([int]$accessible[1] -eq 46 -and $accessible[3] -ceq '10SPS') { $matches.Add($candidate) }
        }
        return $true
    }
    [void][Ut70CsvNative]::EnumChildWindows($p.MainWindowHandle, $callback, [IntPtr]::Zero)
    if ($matches.Count -ne 1) { throw 'STOP: expected sampling combo absent or ambiguous' }
    $h = $matches[0]
    $count = Read-Ut70Message $h 0x0146
    $selected = Read-Ut70Message $h 0x0147
    if ($count -lt 1 -or $count -gt 16 -or $selected -ge $count) { throw 'STOP: unexpected sampling combo structure' }
    $labels = @(for ($i=0; $i -lt $count; $i++) {
        [UIntPtr]$answer = [UIntPtr]::Zero
        $text = [System.Text.StringBuilder]::new(256)
        $ok = [Ut70CsvNative]::SendTextMessageTimeout($h, 0x0148, [IntPtr]$i, $text, 2, 2000, [ref]$answer)
        if ($ok -eq [IntPtr]::Zero -or $answer.ToUInt64() -ge 256) { throw 'STOP: sampling label read failed' }
        $text.ToString()
    })
    if ($labels[$selected] -cne '10SPS') { throw 'STOP: current rate is not 10SPS' }
    return [pscustomobject]@{SelectedIndex=$selected;Selected=$labels[$selected];Options=$labels;Changed=$false}
}
