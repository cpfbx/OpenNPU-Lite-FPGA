﻿param(
    [Parameter(Mandatory=$true)][ValidateSet('inspect','start','stop')][string]$Operation,
    [Parameter(Mandatory=$true)][int]$HostPid,
    [Parameter(Mandatory=$true)][string]$ExePath,
    [Parameter(Mandatory=$true)][string]$HostStartTicks
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
# Source helpers have BOM-only runtime derivatives (originals in original/).
# They define functions; no UI
# action occurs until the explicit operation below. Override the historical
# hard-coded process identity before any call to those functions.
. (Join-Path $PSScriptRoot 'native_controls.ps1')
function Get-Ut70Host {
    $hostProcess = Get-Process -Id $HostPid -ErrorAction Stop
    $hostProcess.Refresh()
    $resolvedExe = (Resolve-Path -LiteralPath $ExePath -ErrorAction Stop).ProviderPath
    if ($hostProcess.Path -ine $resolvedExe -or $hostProcess.MainWindowHandle -eq 0 -or -not $hostProcess.Responding -or
        $hostProcess.StartTime.ToUniversalTime().Ticks.ToString() -cne $HostStartTicks) {
        throw 'STOP: exact existing host process/window/start identity required'
    }
    if ((Get-FileHash -LiteralPath $resolvedExe -Algorithm SHA256).Hash -ne 'B5EB981043E8F0AD927B852817C93A9215F41031038FB8C54FBAED1A9F794532') {
        throw 'STOP: host executable bytes changed'
    }
    return $hostProcess
}
function Read-CurrentState {
    $hostProcess = Get-Ut70Host
    [void](Get-Ut70NamedControl '断开连接')
    [void](Get-Ut70NamedControl 'D0E18C66')
    $rate = Get-Ut70UploadOptions
    $saving = Get-Ut70SaveState
    return @{
        host_pid=$hostProcess.Id
        host_start_ticks=$HostStartTicks
        exe_sha256='b5eb981043e8f0ad927b852817c93a9215f41031038fb8c54fbaed1a9f794532'
        serial='D0E18C66'; rate=$rate.Selected; saving=$saving.Checked; connected=$true
    }
}
$beforeState = Read-CurrentState
if ($Operation -eq 'inspect') {
    $beforeState | ConvertTo-Json -Compress
} else {
    $wanted = $Operation -eq 'start'
    if ($beforeState.saving -eq $wanted) { throw 'STOP: no-op/ownership drift; no click' }
    $change = Set-Ut70CsvSaving $wanted
    $afterState = Read-CurrentState
    if ($change.Changed -ne $true -or $afterState.saving -ne $wanted) { throw 'STOP: uncertain click; no retry' }
    @{changed=$change.Changed;before=$change.Before;after=$change.After} | ConvertTo-Json -Compress
}
