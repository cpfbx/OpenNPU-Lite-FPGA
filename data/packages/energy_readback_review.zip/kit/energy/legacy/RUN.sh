#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
exec /usr/local/share/pynq-venv/bin/python3 -I -B launch_abba.py "$@"
