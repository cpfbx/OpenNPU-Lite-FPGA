"""Create NEW external binding from operator-supplied current metadata. No GUI/IPC."""
import argparse
import json
from pathlib import Path
import sys
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent))
from launch_abba import host_binding,digest,regular,HOST_SHA,POWERSHELL_SHA
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--pid',type=int,required=True); p.add_argument('--start-ticks',required=True)
    for name in ('exe-path','powershell-exe','csv-dir','output'): p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args(); root=Path(__file__).resolve().parent; out=a.output.absolute()
    csv=a.csv_dir.absolute()
    if (out.resolve()!=out or out.exists() or root in out.parents or csv in out.parents
        or not out.parent.is_dir() or csv.resolve()!=csv or not csv.is_dir()):
        raise ValueError('fresh external output outside immutable package and raw CSV directory')
    if digest(regular(a.exe_path,100000000))!=HOST_SHA: raise ValueError('UT70 executable bytes differ')
    if digest(regular(a.powershell_exe,100000000))!=POWERSHELL_SHA: raise ValueError('PowerShell bytes differ; do not install/migrate silently')
    value=host_binding(dict(host_pid=a.pid,host_start_ticks=a.start_ticks,exe_path=str(a.exe_path.absolute()),
        powershell_exe=str(a.powershell_exe.absolute()),csv_dir=str(csv),powershell_sha256=POWERSHELL_SHA,
        host_exe_sha256=HOST_SHA,serial='D0E18C66',rate='10SPS'))
    raw=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode()
    with out.open('xb') as stream: stream.write(raw)
    print(json.dumps(dict(binding_file=str(out),binding_sha256=digest(raw),
        current_process_identity_not_observed=True,saving_state_not_observed=True,activation_approved=False)))
if __name__=='__main__': main()
