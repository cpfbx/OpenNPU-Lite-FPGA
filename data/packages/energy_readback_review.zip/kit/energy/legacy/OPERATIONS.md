# ABBA 1808测量：受控操作单（离线候选，尚未批准实跑）

v2仅新增离线分组摘要与回归；运行器、600/600等待、1.01J AND 0.001逐窗一致性
预算、settings/contract/session与未激活v1逐字节一致。不同时启动v1/v2。
摘要保留全部四窗（含失败），分别列ARM2t与FPGA的能量、保存时长、积分均功率
的均值/范围；不做节能胜负、J/task或统计显著性裁决。缺窗不生成完整分组统计。

唯一板端操作者和最终批准者bx。当前只批准600/600等待与1.01J AND 0.001预算及
适用条件用于封装。包尚待独立增量审查；下面是该包审查通过并另获一次实跑批准后
的操作流程，不是现在应执行的指令。不会复用旧smoke16批准或旧host PID。

## 1. 纯离线check

核对本包外层ZIP SHA与launch_manifest SHA（见包外preparation_receipt.json），
在PC或ARM上只运行：

```
python -I -B launch_abba.py check --manifest-sha <EXTERNAL_MANIFEST_SHA>
```

板端既有环境也可使用`bash RUN.sh check --manifest-sha <EXTERNAL_MANIFEST_SHA>`。
check只验文件与纯配置，输出run_ready=false；不接GUI/socket、加载库或访问板卡。

## 2. 运行前必须由bx确认

- 审查通过的确切ZIP、manifest/settings/contract SHA和本次一次授权；新session。
- 当前UTC、板卡空闲、单一原USB供电/J9/UT70/HID接线及压降，USB麦克风未连接。
  查当前内存/存储/其他进程，不能凭历史PID738就推断当前空闲。
- 沿用包内missing-only规范锁准备；不得手工创建/删除锁、改允许名单、改权限、
  强杀未知进程、重启/更新内核、触发快充。异常先回传，不反复重跑。
- 当前UT70 host PID/start ticks/EXE绝对路径、原PowerShell路径/SHA及原执行策略，
  串号D0E18C66、10SPS、saving=false、实际CSV目录。程序重开可能自动开始保存，
  已有保存不接管，应先确认归属再由bx处理；本包不会改启动设置。

## 3. 新的外部host绑定（纯文件准备，不启动GUI）

先由bx提供当前进程元数据和实际路径，再运行：

```
python -I -B bind_host.py --pid <CURRENT_PID> --start-ticks <CURRENT_START_TICKS> --exe-path <CURRENT_EXE_PATH> --powershell-exe <EXISTING_PWSH_PATH> --csv-dir <CURRENT_CSV_DIRECTORY> --output <FRESH_FILE_OUTSIDE_PACKAGE_AND_CSV_DIR>
```

它只核对文件SHA并保存显式绑定，不证明当前PID仍活着/未复用或保存关闭。
实际PC入口仍会在连接前检查这些条件；runtime漂移即拒绝，不安装或绕过策略。
绑定文件和SHA需交bx核对；不写入不可变包，不含密码/token或原音频。

## 4. 批准后才可启动（以下均保留占位符）

SSH转发仅bx手动操作。使用当前明确确认的IP和用户名，不在脚本中缓存密码，
本机/板端均只用127.0.0.1:18772；不自动SSH、不自动重连。

先由bx在板端运行并等待loopback peer：

```
bash RUN.sh board --manifest-sha <EXTERNAL_MANIFEST_SHA> --confirm-scope ABBA1808-CHECKED-ENVELOPES-NO-FORMAL-ENERGY
```

确认本轮确切包/状态后输入ABBA1808，并完成冻结内层YES确认；它先准备原锁，
未收到匹配的PC hello不会启动硬件worker。然后bx在PC运行：

```
python -I -B launch_abba.py pc --manifest-sha <EXTERNAL_MANIFEST_SHA> --host-binding <EXTERNAL_BINDING_FILE> --host-binding-sha <EXTERNAL_BINDING_SHA> --confirm-scope ABBA1808-CHECKED-ENVELOPES-NO-FORMAL-ENERGY
```

两侧都打印新的EVIDENCE，路径末尾run；其父目录另含prepared_launch.json，
PC父目录还含原字节host_binding.json。取回时保留整个父目录，不只run。
顺序ARM2t/FPGA/FPGA/ARM2t，各4预热+452测量，1824总/1808测量/912PL。
每次全输出与历史42/43黄金核对，8份代表输出加首错最多1MiB，元数据有界增长。
不走旧320重复INT64黄金重算，不存452份完整输出，不改driver/oracle/门限。

规划仅参考smoke活动投影约9.37分钟，不含全部初始化/UI/落盘，不承诺完成时长。
各活动等待600、收尾600、ACK240、peer600、GUI30、start30、stable1、前后缓冲2。
这些都是确认等待，不是kill timeout；未知硬件/退出隔离保留，不强杀、不改时限重试。

## 5. 断线/停止/失败

不要重复启动。先保留原终端及证据，由bx回传进程/回执状态。
需要停止时按冻结完整请求边界合作停止：已进入请求完成后不启动下一请求；
该已返回输出可核对但不计accepted（Option A）。不要连续按Ctrl+C或kill -9。
任何不完整计数、未知helper或保存状态、退出/清理失败、CSV分裂/缺行/停止增长，
都不能写成通过；不补跑某一窗，不拼接/剪裁/清零CSV，不自动调宽预算。

## 6. 原件取回后离线汇总

bx按非测量时段安排两侧整个父目录归档/端点SHA对照；本工具不负责远程取件。
两侧原件安全解包在独立目录后，执行：

```
python -I -B readback_abba.py --manifest-sha <EXTERNAL_MANIFEST_SHA> --board-parent <RETRIEVED_BOARD_PARENT> --pc-parent <ORIGINAL_OR_RETRIEVED_PC_PARENT> --output <FRESH_OUTPUT_OUTSIDE_ALL_INPUT_TREES>
```

首先重算完整ABBA回执与8留存输出身份，拒绝旧16/部分计数，再核对8个PC事件/
板端ACK及4份原CSV SHA，最后以固定单位假设/完整文件运行冻结importer和csv_guard。
单位映射只支持已预先声明的mV/mA表头按V/A条件解释，不自动择优切换。
原表头、Wh累计值、时间戳及零点不改。CSV必须完整100ms步长、60<=跨度<1800s，
峰值<=5W，两个Wh端点原文精度不粗于1e-6Wh，才适用本预算依据。

注意：CSV可能自动省略尾零。工具不会自行补零来推定精度；若端点文本不足6位，
会保守标basis_applicable=false、预算未裁决，即便其他数值自洽。保留能量数值和
失败理由，不因此改阈值/重录。文本精度合格也不证明内部积分准确度。
结果仅为各完整保存包络的标称Wh端点差/功率积分与同源一致性；不除N当精确
J/task，不宣称计量准确度或节能胜负。单项失败全部保留，新目录报告，不回填旧烟测。
