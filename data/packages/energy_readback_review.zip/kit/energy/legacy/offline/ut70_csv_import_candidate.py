"""Offline UT70 host-CSV interpretation candidate, never measurement acceptance.

Read-only source; whole-file diagnostics; no device/board/clock access or energy-
tool schema emission. The historical strict CSV validator is deliberately unchanged.
"""
import argparse
import csv
from decimal import Decimal, localcontext
import hashlib
import io
import json
from pathlib import Path
import re
import stat

SCHEMA = 'ut70-host-csv-import-candidate-v1'
HOST_SHA = 'b5eb981043e8f0ad927b852817c93a9215f41031038fb8c54fbaed1a9f794532'
PROFILE = 'declared-5v-10sps-diagnostic'
HEADER_VA = ('电压(V)', '电流(A)', '功率(W)', 'D+(V)', 'D-(V)', '电阻(R)', '电量(Wh)', '时间(ms)', '')
HEADER_MILLI = ('电压(mV)', '电流(mA)') + HEADER_VA[2:]
MAX_BYTES = 4 * 1024 * 1024
MAX_ROWS = 30000
POWER_TOL_W = Decimal('0.00001')  # CSV-format consistency, NOT meter accuracy.


def sha_text(value):
    if type(value) is not str or re.fullmatch('[0-9a-f]{64}', value) is None:
        raise ValueError('explicit lowercase SHA256 required')
    return value


def number(value):
    if type(value) is not str or not 1 <= len(value) <= 80 or value != value.strip():
        raise ValueError('bounded numeric text required')
    if re.fullmatch(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?', value, re.ASCII) is None:
        raise ValueError('finite decimal syntax required')
    try:
        d = Decimal(value)
    except ArithmeticError as error:
        raise ValueError('invalid bounded decimal') from error
    if not d.is_finite() or abs(d.adjusted()) > 20 or d.as_tuple().exponent < -20:
        raise ValueError('bounded finite decimal required')
    return d


def analyze_bytes(raw, *, expected_sha256, mapping, mapping_basis, host_exe_sha256,
                  encoding='gb18030'):
    sha_text(expected_sha256)
    sha_text(host_exe_sha256)
    if type(mapping_basis) is not str or not mapping_basis.strip() or not 1 <= len(mapping_basis) <= 512 or any(ord(c) < 32 for c in mapping_basis):
        raise ValueError('explicit single-line mapping basis required')
    if mapping not in ('literal_header', 'declared_va_despite_milli_header'):
        raise ValueError('explicit supported mapping required')
    if encoding not in ('gb18030', 'utf-8-sig'):
        raise ValueError('explicit supported encoding required')
    if type(raw) is not bytes or not 0 < len(raw) <= MAX_BYTES or not raw.endswith(b'\n'):
        raise ValueError('bounded complete newline-terminated CSV required')
    digest = hashlib.sha256(raw).hexdigest()
    if digest != expected_sha256:
        raise ValueError('CSV SHA256 mismatch')
    # All arithmetic, including parsing-derived products, uses a local context.
    with localcontext() as ctx:
        ctx.prec = 80
        reader = csv.reader(io.StringIO(raw.decode(encoding)), strict=True)
        header = tuple(next(reader, ()))
        if header not in (HEADER_VA, HEADER_MILLI):
            raise ValueError('unknown CSV header/order/units')
        if mapping == 'declared_va_despite_milli_header':
            if header != HEADER_MILLI or host_exe_sha256 != HOST_SHA:
                raise ValueError('override requires exact observed milli header and declared known host SHA')
            scale = Decimal(1)
        else:
            scale = Decimal(1) if header == HEADER_VA else Decimal('0.001')
        rows = []
        for fields in reader:
            if len(rows) >= MAX_ROWS:
                raise ValueError('too many sample rows')
            if len(fields) != 9 or fields[-1] != '':
                raise ValueError('exact row width/trailing field required')
            r = tuple(number(x) for x in fields[:8])
            if any(x < 0 for x in r):
                raise ValueError('negative fields unsupported in this declared 5V diagnostic profile')
            if r[7] != r[7].to_integral_value():
                raise ValueError('integral millisecond timestamps required')
            rows.append(r)
        if len(rows) < 2:
            raise ValueError('at least two complete sample rows required')
        dt = [b[7]-a[7] for a,b in zip(rows,rows[1:])]
        if any(x != 100 for x in dt):
            raise ValueError('declared 10SPS profile requires consecutive 100ms timestamps')
        if any(b[6] < a[6] for a,b in zip(rows,rows[1:])):
            raise ValueError('host Wh decreased/reset; no correction allowed')
        v = [r[0]*scale for r in rows]
        amps = [r[1]*scale for r in rows]
        product_difference = max(abs(r[2]-voltage*current) for r,voltage,current in zip(rows,v,amps))
        if product_difference > POWER_TOL_W:
            raise ValueError('power product inconsistent under declared units')
        if not all(Decimal('4.5') <= x <= Decimal('5.5') for x in v):
            raise ValueError('voltage outside declared 5V diagnostic range; not a unit correction rule')
        raw_va_difference = max(abs(r[2]-r[0]*r[1]) for r in rows)
        literal_milli_difference = max(abs(r[2]-r[0]*r[1]/Decimal(1000000)) for r in rows)
        informative = not (raw_va_difference <= POWER_TOL_W and literal_milli_difference <= POWER_TOL_W)
        if mapping == 'declared_va_despite_milli_header' and not informative:
            raise ValueError('ambiguous low/zero-power unit hypotheses; override not interpreted')
        duration_ms = rows[-1][7]-rows[0][7]
        wh_delta = rows[-1][6]-rows[0][6]
        right_j = sum((b[2]*d/1000 for b,d in zip(rows[1:],dt)), Decimal(0))
        trap_j = sum(((a[2]+b[2])*d/2000 for a,b,d in zip(rows,rows[1:],dt)), Decimal(0))
        return {
            'schema': SCHEMA, 'scope': 'offline whole-file interpretation candidate only',
            'profile': PROFILE, 'source_sha256': digest, 'source_bytes': len(raw),
            'encoding_declared': encoding, 'raw_header': list(header),
            'raw_header_units': {'voltage': 'V' if header == HEADER_VA else 'mV',
                                 'current': 'A' if header == HEADER_VA else 'mA'},
            'declared_mapping': mapping, 'mapping_basis': mapping_basis,
            'host_exe_sha256_declared': host_exe_sha256,
            'host_executable_or_csv_origin_authenticated': False,
            'numeric_units_interpreted': {'voltage':'V','current':'A','power':'W','energy':'Wh','time':'ms'},
            'raw_vi_to_si_scale': str(scale),
            'mapping_status': 'explicit_candidate_override' if mapping != 'literal_header' else 'literal_header_interpretation',
            'power_product_consistent_under_declared_units': True,
            'power_product_pair_discriminating': informative,
            'unit_identity_independently_verified': False,
            'csv_power_consistency_tolerance_W': str(POWER_TOL_W),
            'max_power_product_difference_W': str(product_difference),
            'unscaled_va_power_difference_W': str(raw_va_difference),
            'literal_milli_power_difference_W': str(literal_milli_difference),
            'voltage_range_is_scenario_check_not_unit_proof': True,
            'rows': len(rows), 'first_timestamp_ms': str(rows[0][7]),
            'last_timestamp_ms': str(rows[-1][7]), 'csv_time_span_seconds': str(duration_ms/1000),
            'timestamp_step_ms': '100', 'window_selection': 'entire_file_only',
            'voltage_min_V': str(min(v)), 'voltage_max_V': str(max(v)),
            'sample_current_mean_A': str(sum(amps)/len(rows)),
            'sample_power_mean_W': str(sum(r[2] for r in rows)/len(rows)),
            'host_wh_start': str(rows[0][6]), 'host_wh_end': str(rows[-1][6]),
            'host_wh_endpoint_difference': str(wh_delta), 'host_wh_endpoint_difference_J': str(wh_delta*3600),
            'power_right_rectangle_J': str(right_j), 'power_trapezoid_J': str(trap_j),
            'host_wh_minus_trapezoid_J': str(wh_delta*3600-trap_j),
            'energy_consistency_is_not_independent_validation': True,
            'meter_accuracy_verified': False, 'pc_integrator_error_bound_known': False,
            'device_sample_time_or_packet_loss_certified': False,
            'pc_board_clock_alignment_verified': False, 'source_closed_by_host_verified': False,
            'task_count_or_idle_state_verified': False,
            'ready_for_matrix_energy_tool': False, 'formal_energy_input_accepted': False,
            'promotion': False,
        }


def read_source(path):
    if not stat.S_ISREG(path.lstat().st_mode):
        raise ValueError('regular nonsymlink CSV required')
    with path.open('rb') as stream:
        raw = stream.read(MAX_BYTES+1)
    if len(raw) > MAX_BYTES:
        raise ValueError('CSV exceeds candidate byte budget')
    return raw


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--source-sha256', required=True)
    p.add_argument('--host-exe-sha256', required=True)
    p.add_argument('--mapping', choices=('literal_header','declared_va_despite_milli_header'), required=True)
    p.add_argument('--mapping-basis', required=True)
    p.add_argument('--encoding', choices=('gb18030','utf-8-sig'), default='gb18030')
    a = p.parse_args(argv)
    source = a.input.resolve(strict=True)
    # Reject the original path being a symlink too; resolve() alone would hide it.
    if a.input.is_symlink():
        raise ValueError('input symlink not allowed')
    output = a.output.resolve()
    if a.output.is_symlink() or output.exists() or output == source or source.parent in output.parents:
        raise ValueError('new output outside the source directory tree required')
    raw = read_source(source)
    result = analyze_bytes(raw, expected_sha256=a.source_sha256, mapping=a.mapping,
                           mapping_basis=a.mapping_basis, host_exe_sha256=a.host_exe_sha256,
                           encoding=a.encoding)
    # Recheck content identity before writing; report always refers to the pinned snapshot.
    if hashlib.sha256(read_source(source)).hexdigest() != result['source_sha256']:
        raise ValueError('source changed during interpretation')
    result['importer_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    with output.open('x', encoding='utf-8') as stream:
        json.dump(result, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write('\n')
    print('CANDIDATE INTERPRETATION WRITTEN; no measurement acceptance, board access or promotion.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
