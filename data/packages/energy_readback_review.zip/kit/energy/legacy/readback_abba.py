"""Replay fixed ABBA receipt checks, then inspect four ORIGINAL entire CSVs."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent))
from launch_abba import verify,regular,decode,digest,host_binding,IDENTITY,HOST_SHA,IMPORTER_SHA
from envelope_analysis import analyze_window
from abba_summary import summarize

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path); module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module); return module

def context_check(value,*,side,manifest_sha,settings_sha,session):
    if (type(value) is not dict or value.get('schema')!='abba-prepared-launch-context-v1'
        or value.get('operation')!=side or value.get('manifest_sha256')!=manifest_sha
        or value.get('candidate_identity_sha256')!=IDENTITY or value.get('settings_sha256')!=settings_sha
        or value.get('session_id')!=session or value.get('operator')!='bx'
        or value.get('operator_confirmed_this_launch') is not True
        or value.get('activation_approved_by_package') is not False
        or value.get('formal_energy_input_accepted') is not False):
        raise ValueError('prepared launch context does not bind this NEW ABBA package/session')
    if side=='pc':
        host_binding(value.get('host_binding'))
        if not isinstance(value.get('host_binding_sha256'),str) or len(value['host_binding_sha256'])!=64:
            raise ValueError('PC external binding SHA missing')
    elif value.get('host_binding') is not None or value.get('host_binding_sha256') is not None:
        raise ValueError('board context cannot invent a PC host binding')

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest-sha',required=True)
    p.add_argument('--board-parent',type=Path,required=True)
    p.add_argument('--pc-parent',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args(argv); root=Path(__file__).resolve().parent
    candidate,settings,plan,_=verify(root,a.manifest_sha)
    sources={}
    def read(path,limit=16384):
        raw=regular(path,limit); sources[path]=digest(raw); return raw
    def doc(path,limit=16384): return decode(read(path,limit))
    inputs=[root,a.board_parent.absolute(),a.pc_parent.absolute()]; out=a.output.absolute()
    for item in inputs:
        if item.resolve()!=item or not item.is_dir(): raise ValueError('canonical evidence/package root required')
        if out==item or item in out.parents or out in item.parents: raise ValueError('fresh output outside source trees')
    if out.resolve()!=out or out.exists(): raise ValueError('fresh canonical output required')
    out.mkdir(); report=dict(operation_success=False,formal_energy_input_accepted=False,promotion=False,
        source_origin_authenticated=False,meter_accuracy_verified=False,joules_per_task_evaluated=False,
        settings_sha256=plan['settings_sha256'],manifest_sha256=a.manifest_sha,windows=[])
    error=None
    try:
        bc=doc(inputs[1]/'prepared_launch.json'); pc=doc(inputs[2]/'prepared_launch.json')
        for side,value in [('board',bc),('pc',pc)]:
            context_check(value,side=side,manifest_sha=a.manifest_sha,settings_sha=plan['settings_sha256'],session=settings['session_id'])
        binding_raw=read(inputs[2]/'host_binding.json')
        if digest(binding_raw)!=pc['host_binding_sha256'] or decode(binding_raw)!=pc['host_binding']:
            raise ValueError('retained external host binding bytes differ from launch context')
        board=inputs[1]/'run'; host=inputs[2]/'run'
        from integration_common import expected_capture_sha,CORE_SHA,CALLS_BYTE_LIMIT
        from outer_receipt import evaluate,EXPECTED
        outer=doc(board/'outer_receipt.json',100000); preflight=doc(board/'lock_bootstrap.json')
        observation=doc(board/'observation/actual_exit.json'); final=doc(board/'lock_final_probe.json')
        life=doc(board/'worker/lifecycle.json',100000); done=doc(board/'worker/worker_completion.json')
        rows=doc(board/'worker/outputs/calls.json',CALLS_BYTE_LIMIT); request=doc(board/'worker/request.json')
        exchanges=[doc(board/('transport/exchange_%d.json'%i)) for i in range(8)]
        replay=evaluate(preflight,observation,life,done,rows,request,exchanges,final,
            session_id=settings['session_id'],expected_config_sha=expected_capture_sha(settings),
            transport_clean=outer.get('transport_errors')==[] and outer.get('stop_signals')==[])
        retained=True
        for w in range(4):
            for pair in (42,43):
                raw=read(board/('worker/outputs/window_%d_input_%d.bin'%(w,pair)),1048576)
                retained=retained and len(raw)==1048576 and digest(raw)==EXPECTED[pair]
        replay['checks']['representative_outputs']=retained
        if (not all(replay['checks'].values()) or outer.get('checks')!=replay['checks']
            or outer.get('operation_success') is not True or outer.get('identity_sha256')!=IDENTITY
            or outer.get('settings_sha256')!=plan['settings_sha256']
            or outer.get('session_id')!=settings['session_id']
            or outer.get('consistency_policy')!=settings['consistency_policy']
            or outer.get('numeric_consistency_evaluated') is not False
            or outer.get('handler_restore_errors')!=[] or outer.get('formal_energy_input_accepted') is not False
            or outer.get('promotion') is not False):
            raise ValueError('board outer replay failed; no new-budget application to partial/old smoke')
        receipt=doc(host/'pc_receipt.json',100000)
        if (receipt.get('operation_success') is not True or receipt.get('settings_sha256')!=plan['settings_sha256']
            or receipt.get('identity_sha256')!=IDENTITY or receipt.get('stop_signals')!=[]
            or receipt.get('handler_restore_errors')!=[] or receipt.get('gui_helper_pending') is not False
            or receipt.get('consistency_policy')!=settings['consistency_policy']
            or receipt.get('numeric_consistency_evaluated') is not False
            or receipt.get('formal_energy_input_accepted') is not False
            or receipt.get('promotion') is not False): raise ValueError('PC receipt not complete')
        helpers=receipt.get('gui_process_observations'); runtime=receipt.get('powershell_runtime',{})
        binding=pc['host_binding']
        if (type(helpers) is not list or not helpers or any(type(x.get('actual_exit')) is not int
            or x['actual_exit']!=0 or x.get('wait_expired') is not False for x in helpers)
            or runtime.get('sha256')!=binding['powershell_sha256']
            or runtime.get('path')!=binding['powershell_exe']
            or runtime.get('execution_policy_changed') is not False): raise ValueError('helper/runtime receipt failed')
        for i,item in enumerate(exchanges):
            if doc(host/('event_%02d.json'%i))!=item['ack']: raise ValueError('PC/board ACK mismatch')
        importer=load('abba_pinned_importer',root/'offline/ut70_csv_import_candidate.py')
        guard=load('abba_frozen_csv_guard',candidate/'core/frozen/model/csv_guard.py')
        contract=doc(root/'measurement_contract.json')
        for w in range(4):
            ack=exchanges[2*w+1]['ack']; raw=read(host/('window_%d.csv'%w),importer.MAX_BYTES)
            if len(raw)!=ack['csv_bytes'] or digest(raw)!=ack['csv_sha256']: raise ValueError('CSV snapshot differs from bound end ACK')
            result=analyze_window(raw,importer=importer,guard=guard,policy=settings['consistency_policy'],
                mapping=contract['mapping'],mapping_basis=contract['mapping_basis'],host_sha=HOST_SHA,expected_sha=ack['csv_sha256'])
            result.update(window=w,backend=life['plan']['backends'][w]); report['windows'].append(result)
        report.update(operation_success=all(x['diagnostic_passed'] for x in report['windows']),
            board_receipt_checks=replay['checks'],completed_runtime_calls=1824,measured_runtime_calls=1808,
            retained_outputs_rechecked=8,unsaved_outputs_independently_replayed=False,
            sources_do_not_prove_physical_origin=True)
    except BaseException as failure:
        error=failure; report.update(operation_success=False,error_type=type(failure).__name__,error=str(failure))
    finally:
        try:
            report['abba_summary']=summarize(report['windows'])
        except Exception as summary_failure:
            report['abba_summary_error']=dict(type=type(summary_failure).__name__,message=str(summary_failure))
            report['operation_success']=False
        changed=[]
        for path,sha in sources.items():
            try:
                if digest(regular(path,33554432))!=sha: changed.append(str(path))
            except BaseException: changed.append(str(path))
        report['sources_unchanged']=not changed
        report['changed_or_unreadable_sources']=changed
        report['source_sha256']={str(path):sha for path,sha in sources.items()}
        if report['sources_unchanged'] is not True: report['operation_success']=False
        with (out/'readback.json').open('x',encoding='utf-8') as stream:
            json.dump(report,stream,ensure_ascii=False,allow_nan=False,indent=2); stream.write('\n')
    print(json.dumps(dict(operation_success=report['operation_success'],windows=len(report['windows']),
        output=str(out/'readback.json'),formal_energy_input_accepted=False)))
    return 0 if report['operation_success'] else 1
if __name__=='__main__': raise SystemExit(main())
