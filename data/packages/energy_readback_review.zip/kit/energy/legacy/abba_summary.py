"""Pure descriptive grouping of all four saved envelopes; never an energy verdict."""
from decimal import Decimal, localcontext
import re

BACKENDS = ('openblas_2t', 'fpga_cached', 'fpga_cached', 'openblas_2t')
FIELDS = ('saved_span_s', 'host_wh_endpoint_difference_J', 'power_trapezoid_J',
          'integral_mean_power_W')

def number(value):
    if type(value) is not str or len(value) > 128 or not re.fullmatch(r'[0-9]+(?:\.[0-9]+)?(?:[eE][+-]?[0-9]{1,3})?', value):
        raise ValueError('bounded nonnegative fixed-point decimal string required')
    result = Decimal(value)
    if result != 0 and not -80 <= result.adjusted() <= 80:
        raise ValueError('decimal magnitude out of descriptive bounds')
    return result

def summarize(windows):
    if type(windows) is not list or len(windows) > 4:
        raise ValueError('at most four window records required')
    with localcontext() as ctx:
        ctx.prec = 80
        records = {}
        for item in windows:
            w = item['window']
            if type(w) is not int or w not in range(4) or w in records or item['backend'] != BACKENDS[w]:
                raise ValueError('unique fixed ABBA window/backend required')
            for flag in ('basis_applicable', 'numeric_consistency_evaluated', 'diagnostic_passed'):
                if type(item[flag]) is not bool:
                    raise ValueError('exact boolean status required')
            if item['numeric_consistency_passed'] is not None and type(item['numeric_consistency_passed']) is not bool:
                raise ValueError('boolean or null numeric status required')
            if item['diagnostic_passed'] and not (item['basis_applicable'] and item['numeric_consistency_evaluated']
                                                  and item['numeric_consistency_passed'] is True):
                raise ValueError('contradictory diagnostic status')
            imported = item['import_result']
            sha = imported['source_sha256']
            if type(sha) is not str or re.fullmatch('[0-9a-f]{64}', sha) is None:
                raise ValueError('original source SHA required')
            rows = imported['rows']
            if type(rows) is not int or not 2 <= rows <= 30000:
                raise ValueError('bounded integer row count required')
            duration = number(imported['csv_time_span_seconds'])
            if duration <= 0:
                raise ValueError('positive saved span required')
            endpoint = number(imported['host_wh_endpoint_difference_J'])
            integral = number(imported['power_trapezoid_J'])
            records[w] = dict(window=w, backend=BACKENDS[w], source_sha256=sha, rows=rows,
                saved_span_s=format(duration, 'f'), host_wh_endpoint_difference_J=format(endpoint, 'f'),
                power_trapezoid_J=format(integral, 'f'), integral_mean_power_W=format(integral/duration, 'f'),
                **{k: item[k] for k in ('basis_applicable', 'numeric_consistency_evaluated',
                                       'numeric_consistency_passed', 'diagnostic_passed')})
        groups = {}
        for backend, ids in (('openblas_2t', [0, 3]), ('fpga_cached', [1, 2])):
            present = [i for i in ids if i in records]
            group = dict(expected_windows=ids, present_windows=present, complete=len(present) == 2,
                         all_present_diagnostics_passed=bool(present) and all(records[i]['diagnostic_passed'] for i in present),
                         statistics=None)
            # Do not silently turn an incomplete group into a two-window result.
            # Failed but readable windows remain in full descriptive statistics.
            if group['complete']:
                group['statistics'] = {}
                for field in FIELDS:
                    values = [number(records[i][field]) for i in ids]
                    group['statistics'][field] = dict(mean=format(sum(values)/2, 'f'),
                        minimum=format(min(values), 'f'), maximum=format(max(values), 'f'))
            groups[backend] = group
        return dict(schema='abba-saved-envelope-descriptive-summary-v1',
            scope='entire saved envelopes including buffers and control overhead',
            complete=len(records) == 4,
            all_diagnostics_passed=len(records) == 4 and all(r['diagnostic_passed'] for r in records.values()),
            missing_windows=[i for i in range(4) if i not in records],
            failed_windows=[i for i in sorted(records) if not records[i]['diagnostic_passed']],
            windows=[records[i] for i in sorted(records)], backends=groups,
            abba_blocks=1, independent_repetition_count_not_established=True,
            failed_windows_excluded=False, per_window_consistency_budget_not_backend_difference_threshold=True,
            group_mean_power_definition='arithmetic mean of window integral-energy/span; not sample mean or pooled integral',
            arithmetic='Decimal precision 80, descriptive not certified interval arithmetic',
            winner_evaluated=False, joules_per_task_evaluated=False, statistical_significance_evaluated=False,
            meter_accuracy_verified=False, formal_energy_input_accepted=False, promotion=False)
