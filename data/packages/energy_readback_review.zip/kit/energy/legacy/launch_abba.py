"""Prepared ABBA candidate. Check is read-only; NEW activation requires bx approval.

No SSH launcher, installation, retries, policy changes or implicit host reuse.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import platform
import stat
import sys
import tempfile

IDENTITY = 'bb98cbafd882a3be6f66ccfdfa6fed148ea4ddedd53c34e0c75e672840d1b068'
CONFIRM = 'ABBA1808-CHECKED-ENVELOPES-NO-FORMAL-ENERGY'
HOST_SHA = 'b5eb981043e8f0ad927b852817c93a9215f41031038fb8c54fbaed1a9f794532'
POWERSHELL_SHA = '60c9b29843624dd8af6b6a7b26147753be6aeef65098b9a503cc50850afe410f'
IMPORTER_SHA = '3baf31a8f6d0e98f40ccc8365072182e6637e43b8ba7ee2d14978804755f8afc'

def host_binding(value):
    fields={'host_pid','host_start_ticks','exe_path','powershell_exe','powershell_sha256',
            'host_exe_sha256','csv_dir','serial','rate'}
    if type(value) is not dict or set(value)!=fields: raise ValueError('fresh explicit host binding required')
    if (type(value['host_pid']) is not int or value['host_pid']<=0
        or type(value['host_start_ticks']) is not str or not value['host_start_ticks'].isascii()
        or not value['host_start_ticks'].isdigit() or not 1<=len(value['host_start_ticks'])<=24
        or value['host_exe_sha256']!=HOST_SHA or value['powershell_sha256']!=POWERSHELL_SHA
        or value['serial']!='D0E18C66' or value['rate']!='10SPS'):
        raise ValueError('exact known host/runtime/serial/rate required; no silent migration')
    for key in ('exe_path','powershell_exe','csv_dir'):
        text=value[key]
        if type(text) is not str or not 1<=len(text)<=512 or any(ord(c)<32 for c in text):
            raise ValueError('bounded explicit Windows path required')
        path=PureWindowsPath(text)
        if (not path.is_absolute() or len(path.drive)!=2 or path.drive[1]!=':'
            or not path.drive[0].isascii() or not path.drive[0].isalpha() or '..' in path.parts):
            raise ValueError('local absolute Windows paths only')
    return dict(value)

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def decode(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('duplicate JSON key')
            result[key] = value
        return result
    def bad(value):
        raise ValueError('nonfinite JSON')
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=bad)

def regular(path, limit):
    if path.is_symlink() or not stat.S_ISREG(path.lstat().st_mode):
        raise ValueError('regular nonsymlink file required')
    with path.open('rb') as stream:
        raw = stream.read(limit + 1)
    if len(raw) > limit:
        raise ValueError('file size bound exceeded')
    return raw

def verify(root, manifest_sha):
    root = Path(root).absolute()
    if root.resolve() != root or root.is_symlink():
        raise ValueError('canonical package directory required')
    if (type(manifest_sha) is not str or len(manifest_sha) != 64
            or any(c not in '0123456789abcdef' for c in manifest_sha)):
        raise ValueError('external manifest SHA required')
    raw = regular(root/'launch_manifest.json', 100000)
    if digest(raw) != manifest_sha:
        raise ValueError('launch manifest SHA mismatch')
    doc = decode(raw)
    if (set(doc) != {'schema', 'files', 'candidate_identity_sha256', 'activation_approved'}
            or doc['schema'] != 'prepared-abba-launch-candidate-v1'
            or doc['activation_approved'] is not False
            or doc['candidate_identity_sha256'] != IDENTITY):
        raise ValueError('prepared-only manifest required')
    files = doc['files']
    if type(files) is not dict or not 76 < len(files) < 120:
        raise ValueError('bounded manifest required')
    found = set()
    for path in root.rglob('*'):
        mode = path.lstat().st_mode
        if path.is_symlink() or not (stat.S_ISREG(mode) or stat.S_ISDIR(mode)):
            raise ValueError('plain package tree required')
        if path.is_file():
            found.add(path.relative_to(root).as_posix())
    if found != set(files) | {'launch_manifest.json'}:
        raise ValueError('launch member set drift')
    total = 0
    for name, spec in files.items():
        part = PurePosixPath(name)
        if (part.is_absolute() or part.as_posix() != name or '..' in part.parts
                or '\\' in name or ':' in name or type(spec) is not dict
                or set(spec) != {'bytes', 'sha256'} or type(spec['bytes']) is not int
                or not 0 <= spec['bytes'] <= 16000000):
            raise ValueError('invalid manifest member')
        member = regular(root/name, spec['bytes'])
        total += len(member)
        if total > 32000000 or len(member) != spec['bytes'] or digest(member) != spec['sha256']:
            raise ValueError('launch member bytes drift: ' + name)
    candidate = root/'candidate'
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(candidate/'src'))
    from integration_binding import verify as inner_verify, configure_core
    inner_verify(candidate, IDENTITY)
    configure_core(candidate)
    from integration_common import config, validate_gui_budget
    settings_raw = regular(root/'settings.json', 16384)
    settings = config(decode(settings_raw))
    plan = decode(regular(root/'launch_plan.json', 16384))
    expected_fields={'schema','candidate_identity_sha256','settings_sha256','activation_approved',
        'total_calls','measured_calls','warmup_calls','pl_calls','formal_energy_input_accepted',
        'board_python_prefix','board_serial','pynq_image','peer_wait_s','gui_wait_s',
        'contract_sha256','host_binding','parameters_approved_for_packaging'}
    if (type(plan) is not dict or set(plan)!=expected_fields
            or plan['schema']!='abba-launch-plan-candidate-v1'
            or plan['candidate_identity_sha256'] != IDENTITY
            or plan['settings_sha256'] != digest(settings_raw)
            or plan['activation_approved'] is not False
            or any(type(plan[k]) is not int or plan[k]!=v for k,v in
                dict(total_calls=1824,measured_calls=1808,warmup_calls=16,pl_calls=912).items())
            or plan['formal_energy_input_accepted'] is not False
            or plan['parameters_approved_for_packaging'] is not True
            or plan['host_binding']!='external_fresh_required'
            or plan['board_python_prefix']!='/usr/local/share/pynq-venv'
            or plan['board_serial']!='ftdi-1234-tulB' or plan['pynq_image']!='pynq-z2-v3.1.1'
            or type(plan['peer_wait_s']) is not int or plan['peer_wait_s']!=600
            or type(plan['gui_wait_s']) is not int or plan['gui_wait_s']!=30):
        raise ValueError('fixed ABBA scope/config drift')
    contract_raw=regular(root/'measurement_contract.json',16384)
    if digest(contract_raw)!=plan['contract_sha256']: raise ValueError('contract drift')
    contract=decode(contract_raw)
    if (contract.get('schema')!='abba-envelope-contract-candidate-v1'
        or contract.get('activation_approved') is not False
        or contract.get('parameters_approved_for_packaging') is not True
        or contract.get('consistency_policy')!=settings['consistency_policy']):
        raise ValueError('explicit candidate measurement contract required')
    selected=dict(activity_wait_s=600,completion_wait_s=600,ack_timeout_s=240,start_timeout_s=30,
        stable_interval_s=1,pre_buffer_s=2,post_buffer_s=2)
    if any(type(settings[k]) is not int or settings[k]!=v for k,v in selected.items()):
        raise ValueError('approved preparation parameters drift')
    if (settings['consistency_policy']['max_absolute_J']!='1.01'
        or settings['consistency_policy']['max_relative']!='0.001'):
        raise ValueError('approved dual budget drift')
    if digest(regular(root/'offline/ut70_csv_import_candidate.py',100000))!=IMPORTER_SHA:
        raise ValueError('pinned importer drift')
    required = validate_gui_budget(settings, plan['gui_wait_s'])
    return candidate, settings, plan, required

def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['check', 'board', 'pc'])
    parser.add_argument('--manifest-sha', required=True)
    parser.add_argument('--confirm-scope')
    parser.add_argument('--host-binding',type=Path)
    parser.add_argument('--host-binding-sha')
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parent
    candidate, settings, plan, required = verify(root, args.manifest_sha)
    if args.operation == 'check':
        print(json.dumps(dict(check_pass=True, check_scope='offline_package_only',
            run_ready=False, board_preflight_ok=None, host_preflight_ok=None,
            runtime_checks_not_performed=['board_idle_and_bootstrap', 'current_host_and_saving_state',
                'current_powershell_bytes_and_policy', 'manual_transport','exact_package_activation_approval'],
            candidate_identity_sha256=IDENTITY,
            settings_sha256=plan['settings_sha256'], minimum_ack_allowance_s=required,
            ack_timeout_s=settings['ack_timeout_s'], board_access=False, gui_access=False,
            socket_access=False, activation_approved=False)))
        return 0
    if args.confirm_scope != CONFIRM:
        raise ValueError('bx must approve exact package/parameters before activation')
    if args.operation == 'board':
        if (platform.system() != 'Linux' or platform.machine() != 'armv7l'
                or os.geteuid() != 0 or Path(sys.prefix).as_posix() != plan['board_python_prefix']):
            raise RuntimeError('existing root ARMv7 PYNQ environment required; no fallback/install')
    elif os.name != 'nt':
        raise RuntimeError('PC capture requires existing Windows host')
    host=None; host_raw=None
    if args.operation=='pc':
        if args.host_binding is None or args.host_binding_sha is None:
            raise ValueError('fresh external host binding and SHA required; no cached PID')
        host_raw=regular(args.host_binding,16384)
        if digest(host_raw)!=args.host_binding_sha: raise ValueError('external host binding SHA drift')
        host=host_binding(decode(host_raw))
    if input('bx: exact ABBA package/contract approved, UTC/idle/wiring verified? Type ABBA1808: ') != 'ABBA1808':
        raise RuntimeError('operator confirmation absent; no activation')
    # Fresh evidence is outside the immutable bundle. No deletion/reuse.
    parent = Path(tempfile.mkdtemp(prefix='bx_energy_'+args.operation+'_', dir=root.parent))
    output = parent/'run'
    from datetime import datetime, timezone
    context=dict(schema='abba-prepared-launch-context-v1',operation=args.operation,
        manifest_sha256=args.manifest_sha,settings_sha256=plan['settings_sha256'],
        candidate_identity_sha256=IDENTITY,session_id=settings['session_id'],
        operator='bx',operator_confirmed_this_launch=True,activation_approved_by_package=False,
        parameters_approved_for_packaging=True,formal_energy_input_accepted=False,
        created_utc=datetime.now(timezone.utc).isoformat(),
        host_binding_sha256=None if host_raw is None else digest(host_raw),host_binding=host)
    with (parent/'prepared_launch.json').open('x',encoding='utf-8') as stream:
        json.dump(context,stream,sort_keys=True,indent=2); stream.write('\n')
    if host_raw is not None:
        with (parent/'host_binding.json').open('xb') as stream: stream.write(host_raw)
    print('EVIDENCE: ' + str(output), flush=True)
    command = [str(candidate/'src/integration_entry.py'),
        '_board_abba_candidate' if args.operation == 'board' else '_pc_capture',
        '--identity-sha', IDENTITY, '--output', str(output),
        '--settings', str(root/'settings.json'), '--settings-sha', plan['settings_sha256'],
        '--enable-private-candidate']
    if args.operation == 'board':
        command += ['--board-serial', plan['board_serial'], '--pynq-image', plan['pynq_image'],
                    '--peer-wait-s', str(plan['peer_wait_s'])]
    else:
        command += ['--csv-dir', host['csv_dir'], '--gui-wait-s', str(plan['gui_wait_s']),
            '--host-pid', str(host['host_pid']), '--host-start-ticks', host['host_start_ticks'],
            '--exe-path', host['exe_path'], '--powershell-exe', host['powershell_exe'],
            '--powershell-sha', host['powershell_sha256']]
    # In-process handoff: do NOT leave a Python wrapper parent that the unchanged
    # missing-lock workload scanner would classify as a separate workload.
    import integration_entry
    sys.argv = command
    integration_entry.main()
    print('Completed entry; inspect both original PC and board receipts.', flush=True)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
