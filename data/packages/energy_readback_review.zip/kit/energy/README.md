# 新候选能量运行接线：离线审阅候选

负责人bx，唯一实板操作者bx。此目录不是已批准板测包，无RUN.sh；不得调用内部entry启动采集。`legacy/`中旧RUN.sh只作冻结来源证据，绝不能用其启动本新候选。

`component/`保留已审candidate_03的全部68文件，`legacy/`保留原prepared_abba_02全部88文件。`src/`新增会话组合/候选回执/采后核验，派生entry只调整绑定和资源位置、增加新路径检查，旧CPU协议/实际wait/保存逻辑不改。

新worker选择flat runner和ContiguousBatchCall；原batch_session.execute的计时、黄金核对、CPU观察、保存握手和清理原样复用。每次PL记录强制候选标记与全局序号，采后拒绝历史旧路径。旧CSV保存包络、Wh差值、双预算检查原规则不改。

未核定新settings/预算/host绑定和可批准启动范围，未独立审查、未上板或测能量。只可离线执行身份check和离线测试。不把内部的私有运行函数当用户批准。
