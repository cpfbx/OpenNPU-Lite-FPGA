"""Bounded payload retention and serial exact accounting, no device imports."""
import hashlib
import json
from pathlib import Path
from batch_policy import BACKENDS, BatchStop, validate_policy, exact_int

CALL_BYTES = 1048576

def sha(raw): return hashlib.sha256(raw).hexdigest()
def encode(value): return (json.dumps(value,sort_keys=True,allow_nan=False)+'\n').encode('utf-8')
def write_new(path, value):
    import os
    with Path(path).open('xb') as stream:
        stream.write(encode(value)); stream.flush(); os.fsync(stream.fileno())

class Ledger:
    """At most four first-two representative pairs + ONE returned failure.

    Raw retained bytes <=9MiB, independent of measured N. Metadata grows with
    plan length, but is explicitly bounded by 1824 rows * 16KiB. A stopped
    return may be checked but is NOT counted accepted (historical Option A).
    """
    def __init__(self, policy, bank):
        validate_policy(policy)
        if (type(bank) is not tuple or len(bank)!=2 or
                [p.input_id for p in bank]!=[42,43] or
                any(type(p.expected) is not bytes or len(p.expected)!=CALL_BYTES for p in bank)):
            raise ValueError('two pinned full-size expected outputs required')
        self.policy, self.bank = policy, bank
        self.rows=[]; self.payloads={}; self.failure=None; self.failure_format=None
        self.window=-1; self.next=0; self.pending=None; self.faulted=False; self.window_closed=True
        self.started=self.completed=self.exact_checked=self.accepted=0

    def begin(self, window, backend):
        exact_int(window,0,3)
        if self.faulted or not self.window_closed or self.pending is not None or window!=self.window+1 or backend!=BACKENDS[window]:
            raise ValueError('serial ABBA window order required')
        if self.window>=0 and self.next!=self.policy.per_window:
            raise ValueError('previous window incomplete')
        self.window=window; self.next=0; self.window_closed=False

    def expected(self, index):
        exact_int(index,0,self.policy.per_window-1)
        return self.bank[index%2]

    def start(self, index, *, stop_requested):
        exact_int(index,0,self.policy.per_window-1)
        if stop_requested is not False: raise BatchStop('stop before complete request')
        if self.faulted or self.window_closed or self.window<0 or index!=self.next or self.pending is not None:
            raise ValueError('one outstanding sequential request only')
        self.pending=index; self.started+=1

    def complete(self, index, raw, *, begin_ns, end_ns, process_cpu_ns, metrics, stop_requested):
        if self.pending!=index or type(index) is not int:
            raise ValueError('result without matching started request')
        self.pending=None; self.completed+=1
        try:
            exact_int(begin_ns); exact_int(end_ns); exact_int(process_cpu_ns,1)
            if end_ns<=begin_ns or type(raw) is not bytes or len(raw)!=CALL_BYTES or type(metrics) is not dict:
                raise ValueError('exact output extent/plain metrics/positive timing required')
            pair=self.expected(index)
            phase='warmup' if index<self.policy.warmup else 'measured'
            phase_index=index if phase=='warmup' else index-self.policy.warmup
            row=dict(window=self.window,backend=BACKENDS[self.window],index=index,
                     phase=phase,phase_index=phase_index,input_id=pair.input_id,
                     begin_ns=begin_ns,end_ns=end_ns,process_cpu_ns=process_cpu_ns,
                     output_sha256=sha(raw),expected_sha256=sha(pair.expected),
                     exact=(raw==pair.expected),metrics=metrics,accepted=False)
            if len(encode(row))>16384: raise ValueError('per-call metadata budget exceeded')
            self.rows.append(row)
            if not row['exact']: raise ValueError('full INT32 output differs from pinned golden')
            self.exact_checked+=1
            if stop_requested is not False: raise BatchStop('current request returned exact; stop means not accepted')
            row['accepted']=True; self.accepted+=1; self.next+=1
            if phase=='measured' and phase_index<2:
                self.payloads['window_%d_input_%d.bin'%(self.window,pair.input_id)]=raw
            return row
        except BaseException:
            self.faulted=True
            if type(raw) is bytes and len(raw)<=CALL_BYTES and self.failure is None:
                self.failure=raw
                self.failure_format='returned logical-call bytes; acceptance failed (extent/layout not certified)'
            raise

    def end(self, os_receipt):
        if self.faulted or self.window_closed or self.pending is not None or self.next!=self.policy.per_window:
            raise ValueError('cannot close incomplete window')
        if BACKENDS[self.window]=='openblas_2t':
            if (type(os_receipt) is not dict or type(os_receipt.get('actual_exit_code')) is not int or
                os_receipt['actual_exit_code']!=0 or os_receipt.get('process_group_absent') is not True):
                raise ValueError('real parent wait and absent process group required')
        elif os_receipt is not None:
            raise ValueError('FPGA cannot invent CPU OS receipts')
        self.window_closed=True

    def finish(self, cleanup):
        if (self.window!=3 or not self.window_closed or self.faulted or self.pending is not None or
            self.accepted!=4*self.policy.per_window or self.next!=self.policy.per_window):
            raise ValueError('all four complete windows required')
        wanted=dict(held=False,safety_unresolved=False,lease_retained=False,runner_retained=False,root_buffers_retained=0)
        if type(cleanup) is not dict or any(type(cleanup.get(k)) is not type(v) or cleanup[k]!=v for k,v in wanted.items()):
            raise ValueError('actual clean resource readback required')
        return dict(started=self.started,completed=self.completed,exact_checked=self.exact_checked,
                    accepted=self.accepted,measured_calls=4*self.policy.measured,
                    warmup_calls=4*self.policy.warmup,payload_retained_bytes=self.retained_bytes,
                    started_scope='guardian complete-request entry, not proof of native/DMA start',
                    scope=self.policy.describe()['scope'],formal_energy_input_accepted=False,promotion=False)

    @property
    def retained_bytes(self):
        return sum(len(v) for v in self.payloads.values())+(0 if self.failure is None else len(self.failure))

    def persist(self, directory):
        """Called AFTER measured batch/close, not per completed request."""
        directory=Path(directory); directory.mkdir()
        for name,raw in self.payloads.items():
            with (directory/name).open('xb') as stream: stream.write(raw)
        if self.failure is not None:
            with (directory/'first_failed_or_stopped_output.bin').open('xb') as stream: stream.write(self.failure)
            write_new(directory/'first_failed_or_stopped_output_info.json',dict(
                bytes=len(self.failure),sha256=sha(self.failure),format=self.failure_format,
                numerical_accepted=False))
        write_new(directory/'calls.json',self.rows)
