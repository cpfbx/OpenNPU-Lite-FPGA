"""Private CPU worker: fixed-size pipe output, no per-call output files."""
import os
import signal
import sys
import time
from pathlib import Path
from batch_policy import BatchPolicy, BatchStop
from batch_core import CALL_BYTES, encode, write_new
from batch_protocol import unique_json

def loop(policy, inputs, compute, guardian_guard, stopped, source, sink):
    """Dependency-injected PC fixture covers protocol, NOT native ARM compute."""
    def guard():
        if stopped() is not False: raise BatchStop('CPU stop before next complete request')
        guardian_guard()
    def send(row, payload=None):
        sink.write(encode(row))
        if payload is not None: sink.write(payload)
        sink.flush()
    def receive(kind,index):
        raw=source.readline(8193)
        if len(raw)>8192 or not raw.endswith(b'\n'): raise BatchStop('guardian pipe closed/incomplete')
        row=unique_json(raw)
        if row==dict(kind='stop'): raise BatchStop('guardian STOP')
        if row!=dict(kind=kind,index=index) or type(row.get('index')) is not int:
            raise ValueError('guardian grant/ack drift')
    for index in range(policy.per_window):
        guard()
        send(dict(kind='ready',index=index,input_id=42+index%2,pid=os.getpid()))
        receive('go',index); guard()
        begin=time.perf_counter_ns(); cpu=time.process_time_ns()
        output=compute(*inputs[index%2])
        cpu=time.process_time_ns()-cpu; end=time.perf_counter_ns()
        payload=output if type(output) is bytes else output.tobytes(order='C')
        if type(payload) is not bytes or len(payload)!=CALL_BYTES: raise ValueError('current output bytes drift')
        send(dict(kind='result',index=index,input_id=42+index%2,pid=os.getpid(),
                  payload_bytes=CALL_BYTES,begin_ns=begin,end_ns=end,process_cpu_ns=cpu),payload)
        receive('ack',index)
        del output,payload
    guard(); send(dict(kind='done',calls=policy.per_window,pid=os.getpid()))
    return 0

def run(root, identity_sha, config_path, config_sha):
    from batch_binding import verify, configure, bounded, sha, arm_only, load_bank, import_base
    arm_only(); verify(root,identity_sha); configure(root)
    raw=bounded(config_path,30000)
    if sha(raw)!=config_sha: raise ValueError('CPU configuration identity drift')
    c=unique_json(raw)
    if set(c)!={'package_sha256','ticket','window','profile','stop_flag'} or c['package_sha256']!=identity_sha:
        raise ValueError('exact private CPU configuration required')
    if type(c['window']) is not int or c['window'] not in (0,3): raise ValueError('CPU window must be A')
    policy=BatchPolicy(c['profile'],enabled=True)
    stop=Path(c['stop_flag']).absolute(); config=Path(config_path).absolute()
    if (stop.resolve()!=stop or config.resolve()!=config or stop.exists() or
            stop.parent.parent!=config.parent or stop.name!='stop.flag' or root==stop or root in stop.parents):
        raise ValueError('canonical external fresh CPU stop path required')
    from os_evidence import verify_guardian_ticket
    requested=[]
    for name in ('SIGINT','SIGTERM','SIGHUP'):
        signal.signal(getattr(signal,name),lambda n,f: requested.append(n))
    def stopped(): return bool(requested) or os.path.lexists(stop)
    verify_guardian_ticket(c['ticket'])
    if os.getsid(0)!=os.getpid() or os.getpgrp()!=os.getpid(): raise RuntimeError('dedicated child session/group required')
    bank=load_bank(root)
    import numpy as np
    blas=import_base(root,'blas_candidate','cpu/blas_candidate.py')
    from batch_binding import LIB_SHA, BANK_SHA
    native=blas.BlasCandidate(root/'frozen/cpu/libmatrix_blas_arm.so',LIB_SHA,threads=2,target='arm',enabled=True)
    write_new(config.parent/'cpu_identity.json',dict(pid=os.getpid(),pgid=os.getpgrp(),
        identity=native.identity,numpy_version=np.__version__,affinity=sorted(os.sched_getaffinity(0)),
        bank_sha256=BANK_SHA,source='native CPU child before warmup/capture',
        physical_identity_authenticated=False,promotion=False))
    inputs=[]
    for pair in bank:
        values=[np.frombuffer(x,dtype=np.int8).reshape(512,512).copy() for x in (pair.a,pair.b)]
        for a in values: a.setflags(write=False)
        inputs.append(tuple(values))
    def compute(a,b):
        out=native(a,b)
        if type(out) is not np.ndarray or out.dtype!=np.int32 or out.shape!=(512,512):
            raise ValueError('CPU dtype/shape drift')
        return out
    return loop(policy,inputs,compute,lambda: verify_guardian_ticket(c['ticket']),stopped,sys.stdin.buffer,sys.stdout.buffer)

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--identity-sha',required=True); p.add_argument('--config',type=Path,required=True)
    p.add_argument('--config-sha',required=True); a=p.parse_args()
    raise SystemExit(run(Path(__file__).resolve().parent.parent,a.identity_sha,a.config,a.config_sha))
