"""Standard-library fake-register/process tests. No ARM/UT70/FPGA access."""
import io
import json
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch

from batch_policy import BatchPolicy, BatchStop, validate_policy, BACKENDS
from batch_core import Ledger, CALL_BYTES, encode
import batch_protocol as protocol
import batch_session as session
import batch_owner
import batch_observer
from capture_bridge import CaptureBridge

BANK=tuple(NS(input_id=42+i,expected=(bytes(CALL_BYTES) if i==0 else b'\1'*CALL_BYTES)) for i in range(2))
CLEAN=dict(held=False,safety_unresolved=False,lease_retained=False,runner_retained=False,root_buffers_retained=0)
OS_RECEIPT=dict(actual_exit_code=0,process_group_absent=True,pid=123)

class Owner:
    def __init__(self): self.guards=0; self.held=False; self.closed=False; self.cleanup_readback=None
    def pre_submit(self):
        self.guards+=1
        if self.held: raise RuntimeError('SYNTHETIC unhealthy owner')
        return dict(scope='SYNTHETIC ONLY, not OS lock proof')
    def _hold(self,error): self.held=True
    @property
    def supervision_status(self): return dict(CLEAN,held=self.held)
    def close(self):
        if self.held: raise RuntimeError('SYNTHETIC quarantine')
        self.closed=True; self.cleanup_readback=dict(scope='SYNTHETIC cleanup')

class Capture:
    def __init__(self): self.active=None; self.begins=[]; self.ends=[]
    def begin(self,window,config_sha256):
        if self.active is not None: raise ValueError('fake capture already active')
        self.active=(window,config_sha256); self.begins.append(window)
        return dict(window=window,config_sha256=config_sha256,capture_id='SYNTHETIC-%d'%window,saving_started=True)
    def end(self,window):
        self.ends.append(window); w,config=self.active; self.active=None
        return dict(window=window,config_sha256=config,capture_id='SYNTHETIC-%d'%window,saving_stopped=True)

def result(ledger,index,**kw):
    options=dict(begin_ns=1,end_ns=2,process_cpu_ns=1,metrics={},stop_requested=False); options.update(kw)
    return ledger.complete(index,BANK[index%2].expected,**options)

class PolicyTests(unittest.TestCase):
    def test_default_off(self):
        with self.assertRaises(ValueError): BatchPolicy('smoke8')
    def test_profile(self):
        for value in (None,True,'320','short','abba1809'):
            with self.subTest(value=value),self.assertRaises(ValueError): BatchPolicy(value,enabled=True)
    def test_no_old_type_cast(self):
        with self.assertRaises(ValueError): validate_policy(NS(enabled=True,profile='abba1808'))
    def test_long_counts(self):
        p=BatchPolicy('abba1808',enabled=True)
        self.assertEqual((p.measured,p.warmup,p.pl_calls),(452,4,912))
        self.assertEqual((p.describe()['measured_calls'],p.describe()['total_calls']),(1808,1824))
    def test_small_counts(self):
        p=BatchPolicy('smoke8',enabled=True); self.assertEqual((p.measured,p.warmup,p.pl_calls),(2,2,8))
    def test_sequence_ids(self):
        p=BatchPolicy('abba1808',enabled=True)
        self.assertEqual(p.request(911).first_job_id,58305)
        self.assertEqual(p.request(911).input_id,43)
    def test_bad_pl_index(self):
        p=BatchPolicy('smoke8',enabled=True)
        for i in (True,-1,8,1.0):
            with self.subTest(i=i),self.assertRaises(ValueError): p.request(i)
    def test_frozen(self):
        p=BatchPolicy('smoke8',enabled=True)
        with self.assertRaises(AttributeError): p.profile='abba1808'

class LedgerTests(unittest.TestCase):
    def setUp(self): self.p=BatchPolicy('smoke8',enabled=True); self.l=Ledger(self.p,BANK)
    def start(self): self.l.begin(0,BACKENDS[0]); self.l.start(0,stop_requested=False)
    def test_no_bank(self):
        with self.assertRaises(ValueError): Ledger(self.p,())
    def test_window_order(self):
        with self.assertRaises(ValueError): self.l.begin(1,BACKENDS[1])
    def test_backend_order(self):
        with self.assertRaises(ValueError): self.l.begin(0,'fpga_cached')
    def test_boolean_window(self):
        with self.assertRaises(ValueError): self.l.begin(False,BACKENDS[0])
    def test_no_double_start(self):
        self.start()
        with self.assertRaises(ValueError): self.l.start(0,stop_requested=False)
    def test_stop_before(self):
        self.l.begin(0,BACKENDS[0])
        with self.assertRaises(BatchStop): self.l.start(0,stop_requested=True)
        self.assertEqual(self.l.started,0)
    def test_return_without_start(self):
        with self.assertRaises(ValueError): result(self.l,0)
    def test_exact(self):
        self.start(); row=result(self.l,0)
        self.assertTrue(row['exact']); self.assertEqual(self.l.accepted,1)
    def test_stop_after(self):
        self.start()
        with self.assertRaises(BatchStop): result(self.l,0,stop_requested=True)
        self.assertEqual((self.l.started,self.l.completed,self.l.exact_checked,self.l.accepted),(1,1,1,0))
        self.assertEqual(self.l.retained_bytes,CALL_BYTES)
    def test_wrong_output(self):
        self.start()
        with self.assertRaises(ValueError): self.l.complete(0,b'\2'*CALL_BYTES,begin_ns=1,end_ns=2,process_cpu_ns=1,metrics={},stop_requested=False)
        self.assertEqual(self.l.accepted,0); self.assertIsNotNone(self.l.failure)
    def test_boolean_timing(self):
        self.start()
        with self.assertRaises(ValueError): result(self.l,0,begin_ns=True)
    def test_negative_timing(self):
        self.start()
        with self.assertRaises(ValueError): result(self.l,0,process_cpu_ns=-1)
    def test_backwards(self):
        self.start()
        with self.assertRaises(ValueError): result(self.l,0,end_ns=0)
    def test_nan_metrics(self):
        self.start()
        with self.assertRaises(ValueError): result(self.l,0,metrics=dict(x=float('nan')))
    def test_metadata_budget(self):
        self.start()
        with self.assertRaises(ValueError): result(self.l,0,metrics=dict(x='z'*20000))
    def test_incomplete_end(self):
        self.start()
        with self.assertRaises(ValueError): self.l.end(OS_RECEIPT)
    def test_cannot_skip_os_end(self):
        self.l.begin(0,BACKENDS[0])
        for i in range(self.p.per_window): self.l.start(i,stop_requested=False); result(self.l,i)
        with self.assertRaises(ValueError): self.l.begin(1,BACKENDS[1])
    def test_exit_bool_rejected(self):
        self.l.begin(0,BACKENDS[0])
        for i in range(self.p.per_window): self.l.start(i,stop_requested=False); result(self.l,i)
        with self.assertRaises(ValueError): self.l.end(dict(actual_exit_code=False,process_group_absent=True))
    def test_live_group_rejected(self):
        self.l.begin(0,BACKENDS[0])
        for i in range(self.p.per_window): self.l.start(i,stop_requested=False); result(self.l,i)
        with self.assertRaises(ValueError): self.l.end(dict(actual_exit_code=0,process_group_absent=False))
    def test_not_finished(self):
        with self.assertRaises(ValueError): self.l.finish(CLEAN)
    def test_long_1824_raw_bound(self):
        p=BatchPolicy('abba1808',enabled=True); ledger=Ledger(p,BANK)
        for w,b in enumerate(BACKENDS):
            ledger.begin(w,b)
            for i in range(p.per_window): ledger.start(i,stop_requested=False); result(ledger,i)
            ledger.end(OS_RECEIPT if b=='openblas_2t' else None)
        r=ledger.finish(CLEAN)
        self.assertEqual((r['accepted'],r['measured_calls'],len(ledger.rows)),(1824,1808,1824))
        self.assertEqual(r['payload_retained_bytes'],8*CALL_BYTES)
        self.assertFalse(r['formal_energy_input_accepted'])
        with self.assertRaises(ValueError): ledger.finish(dict(CLEAN,held=True))

class ReaderTests(unittest.TestCase):
    def parse(self,raw):
        import queue
        q=queue.Queue(2); errors=[]; protocol.reader(io.BytesIO(raw),q,errors); return q,errors
    def test_payload(self):
        q,e=self.parse(encode(dict(kind='result',payload_bytes=CALL_BYTES))+bytes(CALL_BYTES))
        self.assertFalse(e); self.assertEqual(len(q.get()[1]),CALL_BYTES); self.assertIsNone(q.get())
    def test_truncated(self):
        _,e=self.parse(encode(dict(kind='result',payload_bytes=CALL_BYTES))+b'x'); self.assertTrue(e)
    def test_boolean_extent(self):
        _,e=self.parse(encode(dict(kind='result',payload_bytes=True))); self.assertTrue(e)
    def test_large_extent(self):
        _,e=self.parse(encode(dict(kind='result',payload_bytes=2*CALL_BYTES))); self.assertTrue(e)
    def test_duplicate(self):
        _,e=self.parse(b'{"kind":"ready","kind":"done"}\n'); self.assertTrue(e)
    def test_long_line(self):
        _,e=self.parse(b'x'*8193+b'\n'); self.assertTrue(e)
    def test_nonfinite(self):
        _,e=self.parse(b'{"x":NaN}\n'); self.assertTrue(e)

class ProtocolTests(unittest.TestCase):
    def run_window(self,tmp,mode='normal',owner=None,stop=None,accept=None,before=None):
        p=BatchPolicy('smoke8',enabled=True); owner=owner or Owner()
        argv=[sys.executable,'-B',str(Path(__file__).with_name('pc_batch_fixture.py')),mode]
        return protocol.run_cpu_window(argv,Path(tmp)/'cpu',owner,stop or (lambda:False),p,
            before or (lambda i:None),accept or (lambda i,row,raw: self.assertEqual(raw,BANK[i%2].expected)),
            lambda:None,lambda:None,group_query=lambda pid:True)
    def test_real_pc_wait(self):
        with tempfile.TemporaryDirectory() as tmp:
            r=self.run_window(tmp); self.assertEqual((r['actual_exit_code'],r['checked_calls']),(0,4)); self.assertFalse(protocol._RUNNING)
            self.assertFalse(list(Path(tmp).rglob('*.bin')))
    def test_wrong_rejected(self):
        with tempfile.TemporaryDirectory() as tmp,self.assertRaises(AssertionError): self.run_window(tmp,'wrong')
        self.assertFalse(protocol._RUNNING)
    def test_child_crash(self):
        with tempfile.TemporaryDirectory() as tmp,self.assertRaises(RuntimeError): self.run_window(tmp,'crash')
        self.assertFalse(protocol._RUNNING)
    def test_stop_after_current(self):
        stopped=[False]; calls=[]
        def accept(i,row,raw): calls.append(i); stopped[0]=True
        with tempfile.TemporaryDirectory() as tmp,self.assertRaises(BatchStop): self.run_window(tmp,stop=lambda:stopped[0],accept=accept)
        self.assertEqual(calls,[0]); self.assertFalse(protocol._RUNNING)
    def test_parent_guard_before_go(self):
        owner=Owner()
        def before(i): raise ValueError('SYNTHETIC lock drift before grant')
        with tempfile.TemporaryDirectory() as tmp,self.assertRaises(ValueError): self.run_window(tmp,owner=owner,before=before)
        self.assertFalse(protocol._RUNNING)
    def test_live_group_retains_owner(self):
        owner=Owner(); p=BatchPolicy('smoke8',enabled=True)
        command=[sys.executable,'-B',str(Path(__file__).with_name('pc_batch_fixture.py'))]
        with tempfile.TemporaryDirectory() as tmp:
            try:
                with self.assertRaises(RuntimeError):
                    protocol.run_cpu_window(command,Path(tmp)/'cpu',owner,lambda:False,p,lambda i:None,
                        lambda i,r,p:None,lambda:None,lambda:None,group_query=lambda pid:False)
                self.assertTrue(owner.held); self.assertEqual(len(protocol._RUNNING),1)
                self.assertIsNotNone(protocol._RUNNING[0].returncode)
            finally:
                # Explicit FALSE group fixture: actual child was waited. Clear
                # only test-held references; never a production force release.
                for child in protocol._RUNNING:
                    child.stdout.close()
                protocol._RUNNING[:]=[]

class OwnerSafetyTests(unittest.TestCase):
    def setup_owner(self,stopped=None,runner=None):
        # Reuse explicit old fake register/buffer objects, not a real ndarray or DMA.
        import test_short_adapter as old
        p=BatchPolicy('smoke8',enabled=True)
        owner=batch_owner.BatchOwner(p,stopped or (lambda:False),enabled=True)
        with patch.dict(sys.modules,{'numpy':old.NP}),patch.object(batch_owner,'ObservedLease',old.Lease):
            owner.start(runner or old.Runner,'SYNTHETIC.bit',lambda:None,old.Recovery)
        return owner,old
    def test_new_policy_accepted(self):
        owner,old=self.setup_owner()
        with patch.dict(sys.modules,{'numpy':old.NP}): owner.pre_submit(); owner.close()
        self.assertFalse(owner.supervision_status['lease_retained'])
    def test_old_type_rejected(self):
        from short_policy import ShortPolicy
        with self.assertRaises(ValueError): batch_owner.BatchOwner(ShortPolicy(enabled=True),lambda:False,enabled=True)
    def test_stop_before_request(self):
        flag=[False]; owner,old=self.setup_owner(lambda:flag[0]); flag[0]=True
        with patch.dict(sys.modules,{'numpy':old.NP}),self.assertRaises(BatchStop): owner.execute_chain(old.jobs(),**old.options())
        self.assertEqual(owner._runner.calls,0); owner.close()
    def test_stop_inside_request_completes(self):
        import test_short_adapter as old
        flag=[False]
        class Runner(old.Runner):
            def run_chain(self,*a,**kw):
                flag[0]=True; return super().run_chain(*a,**kw)
        owner,_=self.setup_owner(lambda:flag[0],Runner)
        with patch.dict(sys.modules,{'numpy':old.NP}):
            owner.execute_chain(old.jobs(),**old.options())
            self.assertFalse(owner._unsafe); self.assertEqual(owner._runner.calls,1)
            with self.assertRaises(BatchStop): owner.execute_chain(old.jobs(),**old.options(1))
        owner.close()
    def test_identity_drift_quarantines(self):
        owner,old=self.setup_owner(); owner._runner.mmio.values[0x60]=0
        with patch.dict(sys.modules,{'numpy':old.NP}),self.assertRaises(RuntimeError): owner.execute_chain(old.jobs(),**old.options())
        self.assertTrue(owner.supervision_status['held'])
        with self.assertRaises(RuntimeError): owner.close()
    def test_buffer_drift_rejected(self):
        owner,old=self.setup_owner(); owner._buffers[0].nbytes=1
        with patch.dict(sys.modules,{'numpy':old.NP}),self.assertRaises(RuntimeError): owner.pre_submit()
        owner._buffers[0].nbytes=4198400; owner.close()

class ObserverTests(unittest.TestCase):
    def test_default_off(self):
        with self.assertRaises(ValueError): batch_observer.observe([],None,lambda:False,lambda:None)
    def test_actual_pc_exit(self):
        for code in (0,3):
            with self.subTest(code=code),tempfile.TemporaryDirectory() as tmp:
                r=batch_observer.observe([sys.executable,'-B','-c','raise SystemExit(%d)'%code],Path(tmp)/'os',
                    lambda:False,lambda:None,enabled=True,group_query=lambda pid:True)
                self.assertEqual(r['actual_child_exit_code'],code); self.assertTrue(r['observer_clean'])
    def test_stop_before_launch(self):
        with self.assertRaises(RuntimeError): batch_observer.observe(['SYNTHETIC-never-launch'],None,lambda:True,lambda:None,enabled=True)
    def test_unknown_group_no_success(self):
        with tempfile.TemporaryDirectory() as tmp,self.assertRaises(RuntimeError):
            batch_observer.observe([sys.executable,'-B','-c','pass'],Path(tmp)/'os',lambda:False,lambda:None,
                                   enabled=True,group_query=lambda pid:False)
    def test_stop_reader_failure_still_observes_wait(self):
        reads=[0]
        def broken():
            reads[0]+=1
            if reads[0]>1: raise OSError('SYNTHETIC stop reader failed')
            return False
        with tempfile.TemporaryDirectory() as tmp:
            directory=Path(tmp)/'os'
            with self.assertRaises(OSError):
                batch_observer.observe([sys.executable,'-B','-c','pass'],directory,broken,lambda:None,
                                       enabled=True,group_query=lambda pid:True)
            row=json.loads((directory/'actual_exit.json').read_bytes())
            self.assertEqual(row['actual_child_exit_code'],0); self.assertFalse(row['observer_clean'])

class CaptureBridgeTests(unittest.TestCase):
    def make(self,tmp,stopped):
        return CaptureBridge(Path(tmp).resolve()/'capture','a'*32,stopped,ack_timeout_s=.01,enabled=True)
    def test_default_off(self):
        with self.assertRaises(ValueError): CaptureBridge(None,'a'*32,lambda:False,ack_timeout_s=1)
    def test_old_directory_rejected(self):
        with tempfile.TemporaryDirectory() as tmp,self.assertRaises(ValueError):
            CaptureBridge(tmp,'a'*32,lambda:False,ack_timeout_s=1,enabled=True)
    def test_stop_while_begin_wait(self):
        with tempfile.TemporaryDirectory() as tmp:
            bridge=CaptureBridge(Path(tmp).resolve()/'capture','a'*32,lambda:True,ack_timeout_s=1,enabled=True)
            with self.assertRaises(BatchStop): bridge.begin(0,'0'*64)
    def test_stale_token(self):
        with tempfile.TemporaryDirectory() as tmp:
            bridge=CaptureBridge(Path(tmp).resolve()/'capture','a'*32,lambda:False,ack_timeout_s=1,enabled=True)
            (bridge.directory/'window_0_begin_ack.json').write_bytes(encode(dict(session_id='b'*32,request_token='x',kind='begin')))
            with self.assertRaises(ValueError): bridge.begin(0,'0'*64)
    def test_no_repeated_window(self):
        with tempfile.TemporaryDirectory() as tmp:
            bridge=CaptureBridge(Path(tmp).resolve()/'capture','a'*32,lambda:False,ack_timeout_s=1,enabled=True)
            with self.assertRaises(ValueError): bridge.begin(1,'0'*64)
    def test_timeout_must_be_explicit(self):
        with self.assertRaises(TypeError): CaptureBridge(None,'a'*32,lambda:False,enabled=True)
    def test_bad_timeout(self):
        for value in (True,0,-1,float('inf'),float('nan'),601):
            with self.subTest(value=value),self.assertRaises(ValueError):
                CaptureBridge(None,'a'*32,lambda:False,ack_timeout_s=value,enabled=True)
    def test_stop_while_end_wait(self):
        calls=[0]
        def stopped(): calls[0]+=1; return calls[0]>=2
        with tempfile.TemporaryDirectory() as tmp:
            bridge=self.make(tmp,stopped); bridge.active=(0,'0'*64)
            with patch('capture_bridge.time.sleep'),self.assertRaises(BatchStop): bridge.end(0)
            self.assertTrue(bridge.failed); self.assertIsNone(bridge.active)
            self.assertTrue((bridge.directory/'window_0_end_request.json').exists())
    def test_begin_stop_then_end_does_not_wait(self):
        with tempfile.TemporaryDirectory() as tmp:
            bridge=self.make(tmp,lambda:True)
            with self.assertRaises(BatchStop): bridge.begin(0,'0'*64)
            with patch('capture_bridge.time.sleep') as sleep,self.assertRaises(BatchStop): bridge.end(0)
            sleep.assert_not_called()
    def test_end_missing_ack_bounded_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            bridge=self.make(tmp,lambda:False); bridge.active=(0,'0'*64)
            with self.assertRaises(TimeoutError): bridge.end(0)
            self.assertTrue(bridge.failed)
    def test_failed_bridge_cannot_start_next(self):
        with tempfile.TemporaryDirectory() as tmp:
            bridge=self.make(tmp,lambda:True)
            with self.assertRaises(BatchStop): bridge.begin(0,'0'*64)
            bridge.active=None
            with self.assertRaises(ValueError): bridge.begin(0,'0'*64)

class SessionTests(unittest.TestCase):
    def run_fake(self,root,owner=None,capture=None,stop=None,cpu=None,call=None):
        owner=owner or Owner(); capture=capture or Capture(); p=BatchPolicy('smoke8',enabled=True)
        def fake_cpu(command,obs,owner,stopped,p,before,accept,begin,end):
            for i in range(p.per_window):
                if i==p.warmup: begin()
                owner.pre_submit(); before(i)
                accept(i,dict(begin_ns=1,end_ns=2,process_cpu_ns=1),BANK[i%2].expected)
            end(); return dict(OS_RECEIPT,scope='SYNTHETIC ONLY')
        # Explicit deterministic synthetic clock: a no-op fake call can consume
        # zero Windows CPU ticks. Do not weaken real positive timing checks.
        import itertools
        ticks=itertools.count(1)
        with patch.object(session.time,'process_time_ns',side_effect=lambda:next(ticks)):
            return session.execute(Path(root),'0'*64,Path(root),p,BANK,owner,
                call or (lambda input_id:(BANK[input_id-42].expected,{})),capture,stop or (lambda:False),
                cpu_window=cpu or fake_cpu)
    def test_four_window_normal(self):
        with tempfile.TemporaryDirectory() as tmp:
            c=Capture(); owner=Owner(); r=self.run_fake(tmp,owner=owner,capture=c)
            self.assertEqual((r['accepted'],len(r['activity_windows'])),(16,4))
            self.assertEqual((c.begins,c.ends),([0,1,2,3],[0,1,2,3])); self.assertTrue(owner.closed)
            self.assertEqual(len(list((Path(tmp)/'outputs').glob('*.bin'))),8)
    def test_stop_before_any(self):
        with tempfile.TemporaryDirectory() as tmp:
            c=Capture(); owner=Owner()
            with self.assertRaises(BatchStop): self.run_fake(tmp,owner=owner,capture=c,stop=lambda:True)
            self.assertTrue(owner.closed); self.assertEqual(c.begins,[])
    def test_capture_begin_fails_cleanup(self):
        c=Capture()
        def bad(w,config_sha256): c.active=(w,config_sha256); raise ValueError('SYNTHETIC capture start fail')
        c.begin=bad
        with tempfile.TemporaryDirectory() as tmp:
            owner=Owner()
            with self.assertRaises(ValueError): self.run_fake(tmp,owner=owner,capture=c)
            self.assertTrue(owner.closed); self.assertEqual(c.ends,[0])
    def test_capture_close_fails_once(self):
        c=Capture(); ends=[]
        def bad(w): ends.append(w); raise ValueError('SYNTHETIC stop ACK fail')
        c.end=bad
        with tempfile.TemporaryDirectory() as tmp,self.assertRaises(ValueError): self.run_fake(tmp,capture=c)
        self.assertEqual(ends,[0])
    def test_persistence_preserves_primary(self):
        with tempfile.TemporaryDirectory() as tmp:
            original=session.write_new
            def broken(path,value):
                if path.name=='lifecycle.json': raise OSError('SYNTHETIC disk fail')
                return original(path,value)
            with patch.object(session,'write_new',broken),self.assertRaises(BatchStop): self.run_fake(tmp,stop=lambda:True)
    def test_real_runtime_off(self):
        with self.assertRaises(ValueError): session.run_internal(None,None,None,profile='smoke8',capture=None)
    def test_real_runtime_pc_rejected(self):
        from batch_binding import arm_only
        with patch('platform.machine',return_value='x86_64'),self.assertRaises(RuntimeError): arm_only()
    def test_cross_candidate_import_rejected(self):
        from batch_binding import configure
        with tempfile.TemporaryDirectory() as tmp,self.assertRaises(RuntimeError): configure(Path(tmp))
    def test_signal_restore_failure_preserves_body(self):
        original=NS(scope='SYNTHETIC signal handler'); seen=[]; record={}
        def signal_set(n,handler):
            seen.append((n,handler))
            if handler is original: raise OSError('SYNTHETIC restore fail')
        with patch.object(session.signal,'SIGHUP',101,create=True),patch.object(session.signal,'getsignal',return_value=original),patch.object(session.signal,'signal',side_effect=signal_set):
            with self.assertRaisesRegex(ValueError,'SYNTHETIC body'):
                with session.stopping(record): raise ValueError('SYNTHETIC body')
        self.assertEqual(len(record['handler_restore_errors']),3)
        self.assertEqual(len(seen),6)
    def test_window_checkpoint_failure_stops(self):
        with tempfile.TemporaryDirectory() as tmp:
            original=session.write_new; c=Capture(); owner=Owner()
            def broken(path,value):
                if path.name=='window_receipt.json': raise OSError('SYNTHETIC checkpoint fail')
                return original(path,value)
            with patch.object(session,'write_new',broken),self.assertRaises(OSError): self.run_fake(tmp,capture=c,owner=owner)
            self.assertEqual(c.begins,[0]); self.assertTrue(owner.closed)
    def test_failure_close_ack_rejected_preserves_primary(self):
        capture=Capture(); owner=Owner(); old_end=capture.end
        def bad_end(window):
            row=old_end(window); row['saving_stopped']=False; return row
        capture.end=bad_end
        def bad_cpu(command,obs,owner,stopped,p,before,accept,begin,end):
            begin(); raise ValueError('SYNTHETIC primary CPU failure')
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaisesRegex(ValueError,'primary CPU failure'):
                self.run_fake(tmp,owner=owner,capture=capture,cpu=bad_cpu)
            row=json.loads((Path(tmp)/'lifecycle.json').read_bytes())
            self.assertFalse(row['capture_close_confirmed'])
            self.assertTrue(row['capture_manual_followup_required']); self.assertTrue(owner.closed)

class PrivateWiringTests(unittest.TestCase):
    def run_private_mock(self,tmp,inject_stop=False):
        import batch_binding as binding
        import batch_call
        import itertools
        root=Path(tmp).resolve()/'package'; root.mkdir()
        out=Path(tmp).resolve()/'evidence'
        capture=CaptureBridge(Path(tmp).resolve()/'bridge','a'*32,lambda:False,ack_timeout_s=1,enabled=True)
        def exchange(obj,kind,w,c):
            return dict(window=w,config_sha256=c,capture_id='SYNTHETIC-%d'%w,
                        **{('saving_started' if kind=='begin' else 'saving_stopped'):True})
        class Array:
            def reshape(self,*a): return self
            def copy(self): return self
            def setflags(self,**kw): pass
        np=NS(int8='SYNTHETIC',frombuffer=lambda *a,**kw:Array())
        bank=tuple(NS(input_id=p.input_id,a=b'a',b=b'b',expected=p.expected) for p in BANK)
        owner=Owner(); owner.start=lambda *a,**kw:None
        deps=NS(runner_type=None,lease_factory=None,recovery_factory=None,
                supervise=lambda owner,operation,publish,enabled:operation())
        handlers={}; count=[0]
        def set_handler(n,h): handlers[n]=h
        def call(*operands):
            value=BANK[count[0]%2].expected; count[0]+=1
            if inject_stop and count[0]==1: handlers[session.signal.SIGINT](session.signal.SIGINT,None)
            return value,{}
        def cpu(command,obs,owner,stopped,p,before,accept,begin,end):
            for i in range(p.per_window):
                if i==p.warmup: begin()
                before(i); accept(i,dict(begin_ns=1,end_ns=2,process_cpu_ns=1),BANK[i%2].expected)
            end(); return OS_RECEIPT
        ticks=itertools.count(1)
        with patch.object(binding,'arm_only'),patch.object(binding,'verify'),patch.object(binding,'configure'),\
             patch.object(binding,'load_bank',return_value=bank),patch.object(binding,'load_dependencies',return_value=deps),\
             patch.object(batch_owner,'BatchOwner',return_value=owner),patch.object(batch_call,'BatchCall',return_value=call),\
             patch.dict(sys.modules,{'numpy':np}),patch.dict(os.environ,{'BOARD_SERIAL':'ftdi-1234-tulB','PYNQ_IMAGE':'pynq-z2-v3.1.1'}),\
             patch.object(CaptureBridge,'exchange',exchange),patch.object(session,'run_cpu_window',cpu),\
             patch.object(session.signal,'SIGHUP',101,create=True),patch.object(session.signal,'getsignal',return_value=lambda n,f:None),\
             patch.object(session.signal,'signal',side_effect=set_handler),patch.object(session.time,'process_time_ns',side_effect=lambda:next(ticks)):
            try:
                result=session.run_internal(root,'0'*64,out,profile='smoke8',capture=capture,enabled=True)
                return result,owner
            finally: self.assertTrue(owner.closed)
    def test_complete_private_wiring_is_mock_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            r,_=self.run_private_mock(tmp); self.assertEqual(r['accepted'],16)
    def test_same_live_signal_latch(self):
        with tempfile.TemporaryDirectory() as tmp,self.assertRaises(BatchStop): self.run_private_mock(tmp,True)

if __name__=='__main__': unittest.main(verbosity=2)
