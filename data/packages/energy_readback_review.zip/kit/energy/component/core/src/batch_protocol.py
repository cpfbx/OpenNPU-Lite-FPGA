"""One live output over bounded pipes; real wait, never a kill/retry timeout."""
import os
from pathlib import Path
import queue
import subprocess
import threading
import time
import json
from batch_core import CALL_BYTES, encode, write_new
from batch_policy import BatchStop, validate_policy

_RUNNING=[]

def unique_json(raw):
    def pairs(items):
        result={}
        for k,v in items:
            if k in result: raise ValueError('duplicate protocol key')
            result[k]=v
        return result
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite JSON')))

def read_exact(stream, count):
    result=bytearray(); left=count
    while left:
        raw=stream.read(min(left,65536))
        if not raw: raise ValueError('truncated current CPU output')
        result.extend(raw); left-=len(raw)
    return bytes(result)

def reader(stream, messages, errors):
    try:
        while True:
            raw=stream.readline(8193)
            if not raw:
                messages.put_nowait(None); return
            if len(raw)>8192 or not raw.endswith(b'\n'): raise ValueError('bounded protocol line required')
            row=unique_json(raw)
            if type(row) is not dict: raise ValueError('plain protocol object required')
            payload=None
            if row.get('kind')=='result':
                if type(row.get('payload_bytes')) is not int or row['payload_bytes']!=CALL_BYTES:
                    raise ValueError('exact current output extent required before allocation')
                payload=read_exact(stream,CALL_BYTES)
            messages.put_nowait((row,payload))
    except BaseException as error:
        errors.append(type(error).__name__)
        stream.close()  # Broken trusted protocol; never leave a blocked producer pipe.

def run_cpu_window(command, directory, owner, stopped, policy, before_call, accept,
                   begin_measured, end_measured, *, popen_factory=subprocess.Popen,
                   group_query=None):
    """Callbacks are internal trusted code. PC tests must label mock group query.

    Measured interval includes handshake, full exact checks and output hashes;
    pure BLAS wall/CPU durations come from child timestamps, kept separately.
    A real Linux binding uses the frozen read-only process-group query.
    """
    validate_policy(policy)
    injected_query=group_query is not None
    if group_query is None:
        from os_evidence import process_group_absent
        group_query=process_group_absent
    if type(command) is not list or not command or any(type(x) is not str or '\0' in x for x in command):
        raise ValueError('fixed private argv required')
    directory=Path(directory); directory.mkdir()
    owner.pre_submit()
    if stopped() is not False: raise BatchStop('stop before CPU launch')
    messages,errors=queue.Queue(maxsize=2),[]
    stderr=(directory/'child.stderr.txt').open('xb')
    options=dict(stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,close_fds=True,shell=False)
    if os.name=='nt': options['creationflags']=subprocess.CREATE_NO_WINDOW
    else: options['start_new_session']=True
    child=thread=None; waited=absent=None; primary=None; received=0; saw_done=False
    record=dict(actual_exit_code=None,process_group_absent=None,checked_calls=0,
                source='parent Popen.wait + OS process group query',automatic_kill=False,
                group_query_injected=injected_query,
                formal_energy_input_accepted=False,promotion=False)

    def cancel():
        flag=directory/'stop.flag'
        try:
            with flag.open('xb') as stream: stream.write(b'STOP\n')
        except FileExistsError:
            pass  # Child treats ANY existing entry as stop, never overwrite it.

    def send(row):
        child.stdin.write(encode(row)); child.stdin.flush()

    def receive():
        while True:
            if stopped() is not False: cancel()
            if errors: raise RuntimeError('CPU pipe reader failed: '+errors[0])
            try: value=messages.get(timeout=.1)
            except queue.Empty: continue
            if value is None: raise RuntimeError('CPU pipe EOF before completion')
            return value

    try:
        child=popen_factory(command,**options); _RUNNING.append(child)
        record['pid']=child.pid
        write_new(directory/'child_started.json',dict(pid=child.pid,actual_exit_code=None))
        thread=threading.Thread(target=reader,args=(child.stdout,messages,errors),daemon=True); thread.start()
        for index in range(policy.per_window):
            row,payload=receive()
            wanted=dict(kind='ready',index=index,input_id=42+index%2,pid=child.pid)
            if row!=wanted or payload is not None or any(type(row.get(k)) is not int for k in ('index','input_id','pid')):
                raise ValueError('CPU READY identity/order drift')
            if index==policy.warmup: begin_measured()
            owner.pre_submit()
            if stopped() is not False: raise BatchStop('stop before CPU GO')
            before_call(index)
            send(dict(kind='go',index=index))
            row,payload=receive()
            if (row.get('kind')!='result' or any(type(row.get(k)) is not int for k in ('index','input_id','pid')) or
                    row['index']!=index or row['pid']!=child.pid or row['input_id']!=42+index%2):
                raise ValueError('CPU RESULT identity/order drift')
            accept(index,row,payload)
            received+=1
            if index==policy.per_window-1: end_measured()
            if stopped() is not False: raise BatchStop('stop after complete CPU request')
            send(dict(kind='ack',index=index))
        done,payload=receive()
        if (done!=dict(kind='done',calls=policy.per_window,pid=child.pid) or payload is not None or
                type(done.get('calls')) is not int or type(done.get('pid')) is not int):
            raise ValueError('CPU DONE/count drift')
        saw_done=True
    except BaseException as error:
        primary=error
        if child is not None:
            try: cancel(); send(dict(kind='stop'))
            except BaseException: pass
    finally:
        if child is not None:
            try:
                try: child.stdin.close()
                except OSError as error:
                    # A crashed producer may break stdin. Still obtain real wait
                    # and group absence; a pipe-close error is NOT permission to
                    # skip the OS child lifecycle or claim it is still running.
                    if primary is None: primary=error
                intervals=0
                while True:
                    try:
                        waited=child.wait(timeout=1.); break
                    except subprocess.TimeoutExpired:
                        intervals+=1
                        if stopped() is not False: cancel()
                        if intervals%30==0:
                            write_new(directory/('observation_%06d.json'%intervals),dict(pid=child.pid,actual_exit_code=None,killed=False))
                if type(waited) is not int: raise ValueError('real wait integer exit required')
                absent=group_query(child.pid)
                if absent is not True: raise RuntimeError('CPU group present/unknown; quarantine owner')
                if thread is not None:
                    thread.join(timeout=1.)
                    if thread.is_alive() or errors: raise RuntimeError('CPU reader unresolved')
                    rest=[]
                    while not messages.empty(): rest.append(messages.get_nowait())
                    if primary is None and (not saw_done or rest!=[None]):
                        raise ValueError('extra protocol frame or missing EOF')
            except BaseException as error:
                owner._hold(error)
                if primary is None: primary=error
            finally:
                record.update(actual_exit_code=waited,process_group_absent=absent,checked_calls=received,
                              stop_requested=stopped() is not False,error_type=None if primary is None else type(primary).__name__)
                if waited is not None and absent is True:
                    _RUNNING.remove(child)
                    if child.stdout is not None: child.stdout.close()
                try: write_new(directory/'actual_exit.json',record)
                except BaseException as error:
                    if primary is None: primary=error
        stderr.close()
    if primary is not None: raise primary
    if record['stop_requested']: raise BatchStop('stop before next window')
    if waited!=0 or received!=policy.per_window: raise RuntimeError('CPU exit/count failed')
    return record
