"""Private actual-exit observer. No board launcher/SSH/automatic signal killing."""
import os
from pathlib import Path
import subprocess
import time
from batch_core import write_new

def observe(command, directory, stopped, request_stop, *, enabled=False,
            popen_factory=subprocess.Popen, group_query=None):
    if enabled is not True: raise ValueError('private observer default-off')
    if type(command) is not list or not command or any(type(x) is not str or '\0' in x for x in command):
        raise ValueError('trusted fixed argv required')
    if stopped() is not False: raise RuntimeError('stop before child launch')
    injected_query=group_query is not None
    if group_query is None:
        from os_evidence import process_group_absent
        group_query=process_group_absent
    directory=Path(directory); directory.mkdir()
    record=dict(actual_child_exit_code=None,process_group_absent=None,observer_clean=False,
                group_query_injected=injected_query,
                automatic_kill=False,board_run_authorized=False,promotion=False)
    primary=None; child=None; stop_sent=False; stop_seen=False
    with (directory/'child.stdout.txt').open('xb') as stdout,(directory/'child.stderr.txt').open('xb') as stderr:
        options=dict(stdout=stdout,stderr=stderr,stdin=subprocess.DEVNULL,close_fds=True,shell=False)
        if os.name=='nt': options['creationflags']=subprocess.CREATE_NO_WINDOW
        else: options['start_new_session']=True
        try:
            child=popen_factory(command,**options)
            record['child_pid']=child.pid
            try: write_new(directory/'child_started.json',dict(pid=child.pid,actual_exit_code=None))
            except BaseException as error:
                primary=error
                try: request_stop(); stop_sent=True
                except BaseException: pass
            intervals=0
            while True:
                try: stop_seen=stop_seen or stopped() is not False
                except BaseException as error:
                    if primary is None: primary=error
                    stop_seen=True
                if stop_seen and not stop_sent:
                    # Trusted launcher will bind a cooperative atomic stop
                    # request; never turn this observation into SIGKILL.
                    try: request_stop(); stop_sent=True
                    except BaseException as error:
                        if primary is None: primary=error
                try:
                    record['actual_child_exit_code']=child.wait(timeout=1.); break
                except subprocess.TimeoutExpired:
                    intervals+=1
                    if intervals%30==0:
                        try: write_new(directory/('observation_%06d.json'%intervals),dict(pid=child.pid,actual_exit_code=None,killed=False))
                        except BaseException as error:
                            if primary is None: primary=error
            if type(record['actual_child_exit_code']) is not int: raise ValueError('OS wait integer required')
            record['process_group_absent']=group_query(child.pid)
            if record['process_group_absent'] is not True: raise RuntimeError('worker group still present/unknown')
            record['observer_clean']=primary is None and not stop_sent and not stop_seen
        except BaseException as error:
            if primary is None: primary=error
        finally:
            # No callback/receipt/observer failure may skip a real wait on a
            # child already started. Retain observation; never kill on timeout.
            if child is not None and record['actual_child_exit_code'] is None:
                while True:
                    try:
                        record['actual_child_exit_code']=child.wait(timeout=1.); break
                    except subprocess.TimeoutExpired: continue
                try: record['process_group_absent']=group_query(child.pid)
                except BaseException as error:
                    if primary is None: primary=error
            record['error_type']=None if primary is None else type(primary).__name__
            record['stop_requested']=stop_sent or stop_seen
            try: write_new(directory/'actual_exit.json',record)
            except BaseException as error:
                if primary is None: primary=error
    if primary is not None: raise primary
    return record
