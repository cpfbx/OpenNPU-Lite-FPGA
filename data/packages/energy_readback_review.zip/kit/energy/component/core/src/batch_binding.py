"""Identity checks are portable/read-only. Runtime is private and default-off."""
import hashlib
import importlib
import json
import platform
import stat
import sys
from pathlib import Path, PurePosixPath
from batch_protocol import unique_json

FROZEN_SHA='ced4ef12f521db1946690870364bd5b916a32304d02c2f6d9b150076772e48e3'
LIB_SHA='a1ee68685946287785a55e07fb60089441252676fc78ee1756a28c3f5de29c3b'
BANK_SHA='de295140ef9e059ca1a1959c1961a866e306fe1d83c598362657e90db33c3f77'
IDENTITY='batch_identity.json'

def sha(raw): return hashlib.sha256(raw).hexdigest()
def bounded(path, size):
    path=Path(path)
    if path.is_symlink() or not stat.S_ISREG(path.lstat().st_mode): raise ValueError('regular nonsymlink input required')
    with path.open('rb') as stream: raw=stream.read(size+1)
    if len(raw)>size: raise ValueError('input byte budget exceeded')
    return raw

def verify(root, expected_sha):
    root=Path(root).absolute()
    if root.resolve()!=root or root.is_symlink(): raise ValueError('canonical package root required')
    raw=bounded(root/IDENTITY,100000)
    if type(expected_sha) is not str or sha(raw)!=expected_sha: raise ValueError('external batch identity required')
    doc=unique_json(raw)
    if (doc.get('schema')!='checked-service-batch-candidate-v1' or doc.get('frozen_identity_sha256')!=FROZEN_SHA or
        doc.get('board_run_authorized') is not False or doc.get('promotion') is not False or type(doc.get('files')) is not dict):
        raise ValueError('default-off candidate identity required')
    names=set()
    for path in root.rglob('*'):
        mode=path.lstat().st_mode
        if path.is_symlink() or not (stat.S_ISDIR(mode) or stat.S_ISREG(mode)):
            raise ValueError('plain package tree required')
        if path.is_file(): names.add(path.relative_to(root).as_posix())
    if names!=set(doc['files'])|{IDENTITY} or not 38<len(names)<=80:
        raise ValueError('exact bounded package member set required')
    must={'src/'+name+'.py' for name in ('batch_policy','batch_core','batch_owner','batch_call',
          'batch_binding','batch_protocol','batch_cpu_worker','batch_session','batch_observer','capture_bridge')}
    if not must<=names or doc.get('source_base')!='35d4db623091dfc7a63459d07f04e4484dbbd999':
        raise ValueError('required new batch sources and base identity missing')
    total=0
    for name,spec in doc['files'].items():
        p=PurePosixPath(name)
        if (p.is_absolute() or p.as_posix()!=name or '..' in p.parts or '\\' in name or ':' in name or
            type(spec) is not dict or set(spec)!={'bytes','sha256'} or type(spec['bytes']) is not int or
            not 0<=spec['bytes']<=16000000): raise ValueError('canonical bounded member required')
        total+=spec['bytes']
        if total>32000000: raise ValueError('package total byte budget exceeded')
        raw=bounded(root/name,spec['bytes'])
        if len(raw)!=spec['bytes'] or sha(raw)!=spec['sha256']: raise ValueError('package member drift: '+name)
    # Frozen verifier is itself bound by this manifest and original outer hash.
    frozen=root/'frozen'; raw=bounded(frozen/'short_adapter_identity.json',100000)
    if sha(raw)!=FROZEN_SHA: raise ValueError('original nested identity drift')
    old=unique_json(raw)
    for name,spec in old['files'].items():
        if doc['files'].get('frozen/'+name)!=spec: raise ValueError('frozen original member modified')
    return doc

def configure(root):
    root=Path(root).resolve(); sys.dont_write_bytecode=True
    # Byte verification must not be followed by silently reusing imports from
    # the editable workspace or another candidate. A real binding is fresh.
    own=('batch_policy','batch_core','batch_owner','batch_call','batch_protocol',
         'batch_cpu_worker','batch_session','batch_observer','capture_bridge','batch_binding')
    for name in own:
        if name in sys.modules and Path(sys.modules[name].__file__).resolve()!=root/'src'/(name+'.py'):
            raise RuntimeError('cross-candidate batch import: '+name)
    for name,relative in (('os_evidence','adapter/os_evidence.py'),('control','model/control.py'),
                          ('fixtures','model/fixtures.py'),('blas_candidate','cpu/blas_candidate.py')):
        if name in sys.modules and Path(sys.modules[name].__file__).resolve()!=root/'frozen'/relative:
            raise RuntimeError('cross-candidate frozen import: '+name)
    wanted=[root/'src']+[root/'frozen'/x for x in ('adapter','model','cpu','baseline/scripts','baseline/python')]
    sys.path[:0]=[str(x) for x in wanted]

def import_base(root, name, relative):
    target=Path(root)/'frozen'/relative
    if name in sys.modules and Path(sys.modules[name].__file__).resolve()!=target:
        raise RuntimeError('fresh worker required: '+name)
    module=importlib.import_module(name)
    if Path(module.__file__).resolve()!=target: raise RuntimeError('cross-tree import: '+name)
    return module

def load_bank(root):
    fixtures=import_base(root,'fixtures','model/fixtures.py')
    return fixtures.load_bank(Path(root)/'frozen/bank',BANK_SHA)

def arm_only():
    if (platform.system()!='Linux' or platform.machine()!='armv7l' or sys.byteorder!='little' or
        platform.release()!='6.6.10-xilinx-v2024.1-g3c0eca68c652'):
        raise RuntimeError('private original ARMv7 runtime only; no PC fallback')

def load_dependencies(root):
    modules={name:import_base(root,name,'baseline/python/'+name+'.py') for name in
             ('pynq_gemm','kws_threeway_entry_support_draft','kws_device_recovery_candidate','kws_device_supervision_candidate')}
    from types import SimpleNamespace
    return SimpleNamespace(runner_type=modules['pynq_gemm'].PynqGemm,
        lease_factory=modules['kws_threeway_entry_support_draft'].existing_shared_lock_draft,
        recovery_factory=modules['kws_device_recovery_candidate']._Recovery,
        supervise=modules['kws_device_supervision_candidate']._supervise)

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('operation',choices=['check'])
    p.add_argument('--identity-sha',required=True); a=p.parse_args()
    verify(Path(__file__).resolve().parent.parent,a.identity_sha)
    print('CHECK PASS: exact batch source/frozen assets; no native/device load, no board launch.')
