"""Passive per-window handshake only. Does NOT operate UT70 or interpret CSV."""
from pathlib import Path
import time
import math
from batch_core import write_new, encode, sha
from batch_policy import BatchStop
from batch_protocol import unique_json

class CaptureBridge:
    """Trusted external PC controller must return matching session/token/SHA.

    File arrival does not authenticate a human, instrument, saving state, or CSV
    timing. No automatic defaults to the historical late controller. The future
    launcher must bind this bridge and its chosen PC controller to one identity.
    """
    def __init__(self,directory,session_id,stopped,*,ack_timeout_s,enabled=False):
        if (enabled is not True or type(session_id) is not str or len(session_id)!=32 or
                any(c not in '0123456789abcdef' for c in session_id) or not callable(stopped)):
            raise ValueError('explicit new capture session required')
        if (type(ack_timeout_s) not in (int,float) or not math.isfinite(ack_timeout_s)
                or not 0 < ack_timeout_s <= 600):
            raise ValueError('explicit finite acknowledgement wait bound required; no runtime default')
        self.directory=Path(directory).absolute()
        if self.directory.resolve()!=self.directory or self.directory.exists():
            raise ValueError('fresh canonical external capture bridge directory required')
        self.directory.mkdir(); self.session=session_id; self.stopped=stopped; self.active=None; self.index=0
        self.ack_timeout_s=ack_timeout_s; self.failed=False

    def exchange(self,kind,window,config_sha):
        name='window_%d_%s'%(window,kind)
        req=dict(session_id=self.session,kind=kind,window=window,config_sha256=config_sha)
        token=sha(encode(req)); req['request_token']=token
        write_new(self.directory/(name+'_request.json'),req)
        path=self.directory/(name+'_ack.json')
        deadline=time.monotonic()+self.ack_timeout_s
        while True:
            # This aborts only a PC acknowledgement wait, not an entered matrix
            # request. It never implies that meter saving has actually stopped.
            if self.stopped() is not False:
                self.failed=True
                raise BatchStop('stop while waiting capture '+kind+'; confirmation unknown')
            if path.exists(): break
            left=deadline-time.monotonic()
            if left<=0:
                self.failed=True
                raise TimeoutError('capture '+kind+' acknowledgement missing; manual PC follow-up required')
            time.sleep(min(.1,left))
        from batch_binding import bounded
        value=unique_json(bounded(path,16384))
        if (type(value) is not dict or value.get('session_id')!=self.session or
                value.get('request_token')!=token or value.get('kind')!=kind):
            raise ValueError('stale/unbound capture acknowledgement')
        return value

    def begin(self,window,config_sha256):
        if self.failed or self.active is not None or type(window) is not int or window!=self.index or not 0<=window<4:
            raise ValueError('serial per-backend capture required')
        self.active=(window,config_sha256)
        try: return self.exchange('begin',window,config_sha256)
        except BaseException:
            self.failed=True
            raise

    def end(self,window):
        if self.active is None or type(window) is not int or self.active[0]!=window:
            raise ValueError('matching active capture required')
        _,config=self.active; self.active=None; self.index+=1
        try: return self.exchange('end',window,config)
        except BaseException:
            self.failed=True
            raise
