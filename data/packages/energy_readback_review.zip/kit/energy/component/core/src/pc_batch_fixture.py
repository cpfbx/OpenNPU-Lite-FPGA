"""EXPLICIT fake CPU protocol process; no native library, matrix, meter or board."""
import hashlib
import sys
from batch_cpu_worker import loop
from batch_policy import BatchPolicy
from batch_core import CALL_BYTES

def main():
    mode=sys.argv[1] if len(sys.argv)>1 else 'normal'
    calls=[0]
    def compute(*operands):
        raw=bytes(CALL_BYTES) if calls[0]%2==0 else b'\1'*CALL_BYTES
        hashlib.sha256(raw).digest()  # Finite synthetic CPU work, not GEMM.
        calls[0]+=1
        if mode=='wrong' and calls[0]==1: raw=b'\2'*CALL_BYTES
        if mode=='crash' and calls[0]==1: raise RuntimeError('SYNTHETIC child failure')
        return raw
    def guard(): pass  # EXPLICIT fixture, never OS guardian evidence.
    return loop(BatchPolicy('smoke8',enabled=True),[(None,None)]*2,compute,guard,
                lambda:False,sys.stdin.buffer,sys.stdout.buffer)

if __name__=='__main__': raise SystemExit(main())
