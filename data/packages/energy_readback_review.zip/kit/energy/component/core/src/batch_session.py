"""Private real wiring, no board RUN. Capture callbacks must be reviewed separately."""
import contextlib
import os
from pathlib import Path
import signal
import sys
import time
from batch_core import Ledger, write_new, encode, sha
from batch_policy import BACKENDS, BatchPolicy, BatchStop
from batch_protocol import run_cpu_window

@contextlib.contextmanager
def stopping(record):
    previous={}; stops=[]; errors=[]
    def stop(n,frame):
        if n not in stops: stops.append(n)
        old=previous[n]
        if callable(old): old(n,frame)
    try:
        for name in ('SIGINT','SIGTERM','SIGHUP'):
            n=getattr(signal,name); old=signal.getsignal(n)
            signal.signal(n,stop); previous[n]=old
        yield stops
    finally:
        for n,old in previous.items():
            try: signal.signal(n,old)
            except BaseException as error: errors.append(dict(signal=n,error_type=type(error).__name__))
        record['stop_signals']=stops
        record['handler_restore_errors']=errors

def capture_ack(value, *, window, config_sha, key, capture_id=None):
    if (type(value) is not dict or value.get(key) is not True or
        type(value.get('window')) is not int or value['window']!=window or
        value.get('config_sha256')!=config_sha or type(value.get('capture_id')) is not str or not value['capture_id']):
        raise RuntimeError('explicit matched per-window capture acknowledgement required')
    if capture_id is not None and value['capture_id']!=capture_id:
        raise RuntimeError('capture close identity drift')
    return value['capture_id']

def execute(root, identity_sha, evidence, policy, bank, owner, call, capture, stopped,
            *, cpu_window=None):
    """Trusted dependency seam for standard-library fixtures; not an authority boundary."""
    cpu_window=run_cpu_window if cpu_window is None else cpu_window
    ledger=Ledger(policy,bank); record=dict(operation_success=False,cleanup_complete=False,
        package_sha256=identity_sha,plan=policy.describe(),cpu_windows=[],activity_windows=[],
        formal_energy_input_accepted=False,synchronized_task_energy_verified=False,
        board_observed_meter_state=False,promotion=False)
    primary=None; active=None; used_ids=set()
    record['capture_close_confirmed']=None
    ack_timeout_s=getattr(capture,'ack_timeout_s',None)
    config_sha=sha(encode(dict(identity_sha256=identity_sha,plan=policy.describe(),capture_ack_timeout_s=ack_timeout_s)))
    write_new(evidence/'request.json',dict(config_sha256=config_sha,plan=policy.describe(),
        package_sha256=identity_sha,capture_ack_timeout_s=ack_timeout_s,
        output_retention='first two measured/window + first failed/stopped',
        capture_scope='per_backend_saved_envelope; NOT synchronized activity energy'))
    def start_capture(window):
        nonlocal active
        if stopped() is not False: raise BatchStop('stop before capture')
        active=dict(window=window,id=None)  # begin may acquire then fail; cleanup still attempts end once.
        record['capture_manual_followup_required']=True
        ack=capture.begin(window,config_sha256=config_sha)
        write_new(evidence/('capture_%d_started.json'%window),ack)
        cid=capture_ack(ack,window=window,config_sha=config_sha,key='saving_started')
        if cid in used_ids: raise ValueError('each backend requires distinct saving session')
        used_ids.add(cid); active['id']=cid
        record['capture_close_confirmed']=False
        record['activity_windows'].append(dict(window=window,backend=BACKENDS[window],
                   begin_ns=time.perf_counter_ns(),end_ns=None,clock='board perf_counter_ns',
                   csv_time_mapping_verified=False))
    def end_activity():
        record['activity_windows'][-1]['end_ns']=time.perf_counter_ns()
    def close_capture():
        nonlocal active
        current=active; active=None  # no second automatic attempt if end fails
        ack=capture.end(current['window'])
        write_new(evidence/('capture_%d_stopped.json'%current['window']),ack)
        capture_ack(ack,window=current['window'],config_sha=config_sha,key='saving_stopped',capture_id=current['id'])
        record['capture_close_confirmed']=True
        record['capture_manual_followup_required']=False
    try:
        for window,backend in enumerate(BACKENDS):
            if stopped() is not False: raise BatchStop('stop before next backend')
            owner.pre_submit(); ledger.begin(window,backend)
            folder=evidence/('window_%d'%window); folder.mkdir()
            if backend=='openblas_2t':
                ticket=owner.pre_submit(); observation=folder/'cpu_observation'
                config=dict(package_sha256=identity_sha,ticket=ticket,window=window,
                            profile=policy.profile,stop_flag=str(observation/'stop.flag'))
                config_path=folder/'cpu_config.json'; write_new(config_path,config)
                command=[sys.executable,'-B',str(root/'src/batch_cpu_worker.py'),'--identity-sha',identity_sha,
                         '--config',str(config_path),'--config-sha',sha(config_path.read_bytes())]
                def accept(index,row,raw):
                    return ledger.complete(index,raw,begin_ns=row.get('begin_ns'),end_ns=row.get('end_ns'),
                        process_cpu_ns=row.get('process_cpu_ns'),metrics={},stop_requested=stopped())
                receipt=cpu_window(command,observation,owner,stopped,policy,
                        lambda index: ledger.start(index,stop_requested=stopped()),accept,
                        lambda: start_capture(window),end_activity)
                record['cpu_windows'].append(receipt)
            else:
                receipt=None
                for index in range(policy.per_window):
                    if index==policy.warmup: start_capture(window)
                    owner.pre_submit(); ledger.start(index,stop_requested=stopped())
                    pair=bank[index%2]
                    begin=time.perf_counter_ns(); cpu=time.process_time_ns()
                    output,metrics=call(pair.input_id)
                    cpu=time.process_time_ns()-cpu; end=time.perf_counter_ns()
                    raw=output if type(output) is bytes else output.tobytes(order='C')
                    ledger.complete(index,raw,begin_ns=begin,end_ns=end,process_cpu_ns=cpu,
                                    metrics=metrics,stop_requested=stopped())
                    del output,raw
                end_activity()
            if stopped() is not False: raise BatchStop('stop before window acceptance')
            close_capture(); ledger.end(receipt)
            # Small checkpoint only AFTER the saving envelope is acknowledged
            # closed. No full-size per-call SD writes in the active batch.
            write_new(folder/'window_receipt.json',dict(window=window,backend=backend,
                counts=dict(started=ledger.started,completed=ledger.completed,accepted=ledger.accepted),
                calls=[r for r in ledger.rows if r['window']==window],
                activity=record['activity_windows'][-1],cpu_exit=receipt,
                source='after-window checkpoint, not synchronized energy'))
    except BaseException as error:
        primary=error
        payload=getattr(error,'matrix_returned_payload',None)
        if type(payload) is bytes and len(payload)<=1048576 and ledger.failure is None:
            ledger.failure=payload
            ledger.failure_format='frozen run_chain tile-order payload; logical unpack not verified'
    finally:
        if active is not None:
            current=active; active=None
            try:
                ack=capture.end(current['window'])
                write_new(evidence/'failure_capture_close.json',ack)
                capture_ack(ack,window=current['window'],config_sha=config_sha,key='saving_stopped',capture_id=current['id'])
                if current['id'] is None:
                    raise RuntimeError('capture start identity was not confirmed; close binding unknown')
                record['capture_close_confirmed']=True
                record['capture_manual_followup_required']=False
            except BaseException as error:
                record['capture_close_confirmed']=False
                record['capture_manual_followup_required']=True
                record['capture_close_error_type']=type(error).__name__
                if primary is None: primary=error
        try:
            owner.close(); record['cleanup_complete']=True; record['cleanup_readback']=owner.cleanup_readback
        except BaseException as error:
            record['cleanup_error_type']=type(error).__name__
            if primary is None: primary=error
        record['resources']=owner.supervision_status
        if primary is None:
            try:
                record['counts']=ledger.finish(record['resources']); record['operation_success']=True
            except BaseException as error: primary=error
        record.update(started=ledger.started,completed=ledger.completed,exact_checked=ledger.exact_checked,
                      accepted=ledger.accepted,payload_retained_bytes=ledger.retained_bytes)
        try: ledger.persist(evidence/'outputs')
        except BaseException as error:
            record['output_persistence_error_type']=type(error).__name__
            if primary is None: primary=error
        if primary is not None:
            record.update(operation_success=False,error_type=type(primary).__name__,error_message=str(primary))
        try: write_new(evidence/'lifecycle.json',record)
        except BaseException as error:
            if primary is None: primary=error
    if primary is not None: raise primary
    return record

def run_internal(root, expected_sha, evidence, *, profile, capture, enabled=False):
    if enabled is not True: raise ValueError('private batch runtime default-off')
    from batch_binding import arm_only, verify, configure, load_bank, load_dependencies
    arm_only(); root=Path(root).absolute(); verify(root,expected_sha); configure(root)
    evidence=Path(evidence).absolute()
    if evidence.resolve()!=evidence or evidence.exists() or evidence==root or root in evidence.parents:
        raise ValueError('fresh canonical evidence outside package required')
    from capture_bridge import CaptureBridge
    if (type(capture) is not CaptureBridge or root==capture.directory or root in capture.directory.parents or
        os.environ.get('BOARD_SERIAL')!='ftdi-1234-tulB' or os.environ.get('PYNQ_IMAGE')!='pynq-z2-v3.1.1'):
        raise ValueError('explicit trusted capture and original operator identity declarations required')
    policy=BatchPolicy(profile,enabled=True); bank=load_bank(root); deps=load_dependencies(root)
    import numpy as np
    prepared={}
    for pair in bank:
        values=[np.frombuffer(raw,np.int8).reshape(512,512).copy() for raw in (pair.a,pair.b)]
        for value in values: value.setflags(write=False)
        prepared[pair.input_id]=tuple(values)
    from batch_owner import BatchOwner
    from batch_call import BatchCall
    outer_record={}; requested=[]
    owner=BatchOwner(policy,lambda:bool(requested),enabled=True)
    capture.stopped=lambda:bool(requested)  # Same live latch even while waiting for PC begin ACK.
    evidence.mkdir(); runtime=evidence/'runtime'; runtime.mkdir()
    def operation():
        nonlocal requested
        previous=Path.cwd()
        result=None; primary=None
        try:
            with stopping(outer_record) as pending:
                requested=pending
                try:
                    os.chdir(runtime)
                    owner.start(deps.runner_type,root/'frozen/baseline/hardware/opennpu_gemm_accelerator.bit',
                                deps.lease_factory,deps.recovery_factory)
                    raw_call=BatchCall(owner,policy,enabled=True)
                    result=execute(root,expected_sha,evidence,policy,bank,owner,
                                   lambda input_id:raw_call(*prepared[input_id]),capture,lambda:bool(pending))
                except BaseException as error:
                    primary=error
                    # execute owns its cleanup; start failures need the same safe-close attempt.
                    if not (evidence/'lifecycle.json').exists():
                        try: owner.close()
                        except BaseException as cleanup_error:
                            outer_record['start_cleanup_error_type']=type(cleanup_error).__name__
        finally:
            os.chdir(previous)
            outer_record.update(operation_success=primary is None and not outer_record.get('handler_restore_errors') and not requested,
                                source='worker lifecycle, NOT actual worker process exit',promotion=False)
            try: write_new(evidence/'worker_completion.json',outer_record)
            except BaseException as error:
                if primary is None: primary=error
        if primary is not None: raise primary
        if not outer_record['operation_success']: raise RuntimeError('stop/signal restoration unresolved; no success')
        return result
    result=deps.supervise(owner,operation,lambda attention:write_new(evidence/'attention.json',attention),enabled=True)
    verify(root,expected_sha)
    return result

if __name__=='__main__':
    raise SystemExit('PRIVATE candidate only; no public board RUN, independent review pending.')
