# Checked service-batch candidate - OFFLINE REVIEW ONLY

Owner/operator: bx. Implementation: Codex/root. Original base: 35d4db6.
This is not a board-run release, a measured energy result, or an independent
review pass. Never launch legacy RUN.sh or replace the frozen default.

`frozen/` is the exact 38-member candidate_08 (ced4ef12...) including D075
BIT/HWH, audited 3MiB bank and private OpenBLAS 0.3.28 ARM library. Original
MIT and OpenBLAS license notices remain there; new batch derivatives use the
project MIT terms. No native library is loaded by check/tests.

`src/` contains an explicit new policy, owner/call derivatives, full-output
ledger, bounded CPU pipe, real-wait observation, private real wiring and a
passive per-window capture handshake. `pc_batch_fixture.py` is a FAKE process,
not ARM computation. Do not count fixture calls as board results.

## Portable offline commands

Windows: use a non-proxy Python interpreter. A venv python.exe may be a PID
proxy; the portable review runner detects this BEFORE tests (exit2), without
weakening real parent/child PID checks. Use its --python option for a base
interpreter when needed. No dependency installation is required.

From the candidate directory, using the externally supplied identity SHA:

    python -B src/batch_binding.py check --identity-sha <batch_identity_SHA256>

Tests require only the Python standard library. Set PYTHONPATH to the candidate
subdirectories below (use your shell's path separator; do not install packages):

    src
    frozen/adapter
    frozen/model
    frozen/cpu
    frozen/baseline/python
    frozen/baseline/scripts

Then run:

    python -B -m unittest discover -s src -p "test_batch_candidate.py" -v

Re-run the identity check afterwards. Always use -B to keep the sealed package
free of __pycache__. Linux runtime checks and parent-owned canonical-lock
observations are NOT validated merely by running the Windows fixture tests.

## Explicit workloads and boundaries

- smoke8: 2 measured + 2 warmup requests per ABBA window; 8 measured, 16 total,
  8 PL calls. This does NOT authorize bx to run it yet.
- abba1808: 452 measured + 4 warmup per window; 1808 measured, 1824 total,
  912 PL calls. Inputs 42/43 repeat, not 1808 independent test matrices.
- Same two-input bank exact comparison for EVERY output. Representative raw
  payload retention is first two measured results per window (8MiB), plus at
  most one failed/stopped returned output (1MiB). Current pipe/output buffers
  and Python/NumPy/CMA overhead are additional, NOT included in that 9MiB bound.
- Metadata grows with fixed plan size (max 1824 rows, each <=16KiB). It is not
  an O(1) whole-process-memory claim. Board peak RSS/CMA remains unmeasured.
- No full output written per request. Small window checkpoints are written
  after capture close, and representative outputs after all windows/cleanup.
  Unexpected crashes/power loss may lose non-checkpointed in-memory evidence;
  stopped/failed normal paths attempt to persist it. No zero-SD-write claim.
- Active service timing includes verification/hash/handshake; child/FPGA pure
  request wall/CPU remain separate. Saved envelope includes capture margins
  and may include CPU shutdown. It is NOT synchronized activity energy.
- Stop: complete entered request, no next grant; a stopped returned result may
  be checked but is not accepted. All stopped/incomplete batches fail closure.
- Real wait/group absence and owner/DMA/lock cleanup are required. Unknown
  hardware/process state is retained/quarantined, never killed or force-freed.

## Deliberately unfinished before board release

Independent review; final trusted PC capture controller integration and
launch/stop binding; outer final receipt cross-check of same-inode lock release
and worker artifacts; bx approval of exact package/small-run workload; current
physical wiring; CSV consistency budgets; instrument/time/ADC mapping error
basis. The observer is a private reusable component, not a completed public
launcher. No formal activity-window crop or J/task acceptance entry exists.

CaptureBridge requires an explicit finite ack_timeout_s, with no runtime
default. Both begin/end waits honor the live stop latch. A stop or missing ACK
fails the session, marks saving-close unconfirmed and requires manual PC
follow-up, while the separate hardware owner still attempts verified cleanup.
This is NOT a compute kill deadline or proof that UT70 has stopped saving.

The existing canonical /tmp/opennpu-kws-chain.lock is REQUIRED before a future
board launch. This candidate never creates/deletes/replaces it. A final bx-run
package must bind the already reviewed bootstrap (missing-only, no clobber,
no symlink bypass) and test it before release. No such board RUN is authorized
by this README; do not manually bypass the existing-lock check.

The passive bridge does not operate the UT70, read CSV units, authenticate the
operator or equate receipt-file arrival with physical sample timing. The old
late controller is NOT automatically promoted. No SSH/Jupyter/UT70 commands
are included in this review entry.
