"""Explicit NEW short schedule, never an instance of an old 483/320 policy."""
from dataclasses import dataclass


class ShortStop(RuntimeError):
    """Stop observed before a new unsafe submission; cleanup may still run."""


@dataclass(frozen=True)
class ShortRequest:
    index: int
    shape: tuple
    jobs: int
    first_job_id: int
    input_id: int


@dataclass(frozen=True)
class ShortPolicy:
    enabled: bool = False

    def __post_init__(self):
        if self.enabled is not True:
            raise ValueError('short policy default-off')

    def request(self, index):
        if type(index) is not int or not 0 <= index < 8:
            raise ValueError('eight short PL calls only; no wrap/retry')
        return ShortRequest(index, (512, 512, 512), 64, 1 + 64 * index, 42 + index % 2)


def validate_policy(value):
    if type(value) is not ShortPolicy or value.enabled is not True:
        raise ValueError('exact new short policy required')
