"""Guardian-controlled four-call CPU window with REAL wait evidence.

One READY/GO/RESULT/ACK exchange per BLAS invocation. Parent checks live owner
and canonical lock before every GO; child checks the same guardian lock ticket
and stop flag immediately before calling BLAS. No timeout-kill or retry.
"""
import json
import os
from pathlib import Path
import queue
import subprocess
import threading
import time

from os_evidence import process_group_absent
from short_policy import ShortStop

_RUNNING = []


def encode(value):
    return (json.dumps(value, sort_keys=True, allow_nan=False) + '\n').encode('utf-8')


def unique_json(raw):
    def pairs(items):
        result = {}
        for k, v in items:
            if k in result:
                raise ValueError('duplicate protocol JSON key')
            result[k] = v
        return result
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite protocol JSON')))


def write_new(path, value):
    with Path(path).open('xb') as stream:
        stream.write(encode(value)); stream.flush(); os.fsync(stream.fileno())


def _reader(stream, messages, errors):
    try:
        while True:
            raw = stream.readline(8193)
            if not raw:
                messages.put_nowait(None)
                return
            if len(raw) > 8192 or not raw.endswith(b'\n'):
                raise ValueError('bounded complete protocol line required')
            messages.put_nowait(unique_json(raw))
    except BaseException as error:
        errors.append(type(error).__name__)


def run_cpu_window(command, directory, owner, stop_requested, accept_result,
                   *, popen_factory=subprocess.Popen, group_query=process_group_absent):
    """Trusted internal binding supplies fixed command and actual owner.

    Windows tests use an explicit non-hardware group-query fixture; real Linux
    binding MUST use the default os.killpg presence query. No plugin CLI.
    """
    directory = Path(directory)
    directory.mkdir()
    if type(command) is not list or not command or any(type(x) is not str or '\0' in x for x in command):
        raise ValueError('fixed trusted current-runtime child argv required')
    owner.pre_submit()
    if stop_requested() is not False:
        raise ShortStop('stop pending before CPU process launch')
    messages, reader_errors = queue.Queue(maxsize=8), []
    options = dict(stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                   stderr=(directory / 'child.stderr.txt').open('xb'),
                   close_fds=True, shell=False)
    if os.name == 'nt':
        options['creationflags'] = subprocess.CREATE_NO_WINDOW
    else:
        options['start_new_session'] = True
    process = None
    reader = None
    waited = None
    absent = None
    primary = None
    checked = 0
    stderr = options['stderr']
    record = dict(scope='private CPU window OS/protocol observation', actual_exit_code=None,
                  process_group_absent=None, checked_calls=0, physical_identity_authenticated=False,
                  automatic_retry=False, automatic_kill=False, promotion=False)

    def cancel():
        flag = directory / 'stop.flag'
        if not flag.exists():
            with flag.open('xb') as f:
                f.write(b'STOP\n'); f.flush(); os.fsync(f.fileno())

    def send(value):
        process.stdin.write(encode(value)); process.stdin.flush()

    def receive():
        while True:
            if stop_requested() is not False:
                cancel()
            if reader_errors:
                raise RuntimeError('CPU protocol reader failed: ' + reader_errors[0])
            try:
                message = messages.get(timeout=.1)
            except queue.Empty:
                continue  # observation only, not an execution/kill deadline
            if message is None:
                raise RuntimeError('CPU stdout ended before full protocol')
            if type(message) is not dict:
                raise ValueError('CPU plain protocol object required')
            return message

    try:
        process = popen_factory(command, **options)
        _RUNNING.append(process)
        record['pid'] = process.pid
        write_new(directory / 'child_started.json', dict(pid=process.pid, actual_exit_code=None))
        reader = threading.Thread(target=_reader, args=(process.stdout, messages, reader_errors), daemon=True)
        reader.start()
        for index in range(4):
            message = receive()
            wanted = dict(kind='ready', index=index, input_id=42 + index % 2, pid=process.pid)
            if message != wanted or any(type(message[k]) is not int for k in ('index', 'input_id', 'pid')):
                raise ValueError('CPU READY identity/order drift')
            owner.pre_submit()  # Real guardian MMIO, buffer and OS lease audit.
            if stop_requested() is not False:
                cancel(); send(dict(kind='stop')); raise ShortStop('stop before CPU GO')
            send(dict(kind='go', index=index))
            result = receive()
            if (result.get('kind') != 'result' or type(result.get('index')) is not int
                    or result['index'] != index or result.get('pid') != process.pid):
                raise ValueError('CPU RESULT identity/order drift')
            accept_result(index, result)  # Persisted raw output + exact golden check.
            checked += 1
            if stop_requested() is not False:
                cancel(); send(dict(kind='stop')); raise ShortStop('stop after completed CPU call')
            send(dict(kind='ack', index=index))
        done = receive()
        if done != dict(kind='done', calls=4, pid=process.pid) or type(done.get('calls')) is not int:
            raise ValueError('CPU DONE/count drift')
    except BaseException as error:
        primary = error
        if process is not None:
            try:
                cancel(); send(dict(kind='stop'))
            except BaseException:
                pass  # Wait still owns completion; never infer a safe exit.
    finally:
        if process is not None:
            try:
                if process.stdin is not None:
                    process.stdin.close()
                intervals = 0
                while True:
                    try:
                        waited = process.wait(timeout=1.)
                        break
                    except subprocess.TimeoutExpired:
                        intervals += 1
                        if stop_requested() is not False:
                            cancel()
                        if intervals % 30 == 0:
                            write_new(directory / ('observation_%06d.json' % intervals),
                                      dict(pid=process.pid, actual_exit_code=None, killed=False))
                if type(waited) is not int:
                    raise ValueError('parent wait did not return exact integer')
                absent = group_query(process.pid)
                if absent is not True:
                    raise RuntimeError('CPU group still present/unknown; retain owner lease')
                if reader is not None:
                    reader.join(timeout=1.)
                    if reader.is_alive() or reader_errors:
                        raise RuntimeError('CPU pipe reader lifecycle unresolved')
            except BaseException as error:
                owner._hold(error)
                if primary is None:
                    primary = error
            finally:
                if waited is not None:
                    record.update(actual_exit_code=waited, process_group_absent=absent)
                    if absent is True:
                        _RUNNING.remove(process)
                        process.stdout.close()
                record.update(checked_calls=checked,
                              stop_requested=stop_requested() is not False,
                              error_type=None if primary is None else type(primary).__name__)
                try:
                    write_new(directory / 'actual_exit.json', record)
                except BaseException as error:
                    if primary is None:
                        primary = error
        stderr.close()
    if primary is not None:
        raise primary
    if record['stop_requested']:
        raise ShortStop('stop pending after CPU wait; no successful window')
    if waited != 0 or checked != 4:
        raise RuntimeError('CPU actual exit/count failed; no next backend')
    return record
