"""Read bounded, pinned 320 originals; export two audited fixed operand pairs.

No NumPy, matrix computation, PYNQ, WSL, native libraries or network access.
This reuses a historical full replay, it does not perform a new INT64 oracle.
"""
import argparse
import ast
import json
from pathlib import Path
import stat
import struct

from control import CALL_BYTES, INPUT_BYTES, Pair, digest, encode, sha_text, validate_bank

READBACK_SHA = '8f3c3dfec65491bba7dd521149392069b4449cf1cb2cc5ec9120fc388dc2a08c'
INVENTORY_SHA = '1f759034abe8a6eb67459dadabe30b9e417b6f5e5fbe7a95822cbdbec7dadd3f'
RELEASE_SHA = '140235264d869f889c2ccbeb3fa0b0a2d1408a607affd3f5ddb8e7b6fcaa7840'
EXPERIMENT = 'session/worker/experiment/'


def unique_json(raw):
    def pairs(items):
        result = {}
        for k, v in items:
            if k in result:
                raise ValueError('duplicate JSON key')
            result[k] = v
        return result
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite JSON')))


def read_regular(path, limit):
    path = Path(path)
    if path.is_symlink() or not stat.S_ISREG(path.lstat().st_mode):
        raise ValueError('regular nonsymlink input required')
    with path.open('rb') as f:
        raw = f.read(limit + 1)
    if len(raw) > limit:
        raise ValueError('file byte budget exceeded')
    return raw


def npy_payload(raw, descr):
    if type(raw) is not bytes or raw[:8] != b'\x93NUMPY\x01\x00' or len(raw) < 10:
        raise ValueError('fixed NPY v1 little-endian input required')
    size = struct.unpack_from('<H', raw, 8)[0]
    if not 0 < size <= 4096 or len(raw) < 10 + size:
        raise ValueError('bounded NPY header required')
    header_raw = raw[10:10 + size]
    if not header_raw.endswith(b'\n'):
        raise ValueError('complete NPY header required')
    header = ast.literal_eval(header_raw.decode('ascii').strip())
    if (type(header) is not dict or set(header) != {'descr', 'fortran_order', 'shape'}
            or header['descr'] != descr or header['fortran_order'] is not False
            or type(header['shape']) is not tuple or header['shape'] != (512, 512)
            or any(type(x) is not int for x in header['shape'])):
        raise ValueError('fixed NPY shape/dtype/layout required')
    payload = raw[10 + size:]
    if descr not in ('|i1', '<i4') or len(payload) != (INPUT_BYTES if descr == '|i1' else CALL_BYTES):
        raise ValueError('exact NPY payload length required')
    return payload


def prepare(source_dir, output):
    source_dir, output = Path(source_dir).absolute(), Path(output).absolute()
    if source_dir.resolve() != source_dir or output.resolve() != output or output.exists():
        raise ValueError('canonical source and fresh output required')
    if output == source_dir or source_dir in output.parents:
        raise ValueError('output must be outside historical source tree')
    readback = read_regular(source_dir / 'independent_readback.json', 100000)
    index_raw = read_regular(source_dir / 'original_inventory_before.json', 1000000)
    if digest(readback) != READBACK_SHA or digest(index_raw) != INVENTORY_SHA:
        raise ValueError('historical replay/inventory identity drift')
    index = unique_json(index_raw)
    originals = source_dir / 'originals/matrix_isolated_evidence_nyi5y50v'
    checked = {}

    def get(name, limit=CALL_BYTES + 4096):
        path = originals / name
        if originals.resolve() not in path.resolve().parents:
            raise ValueError('historical path escaped root')
        raw = read_regular(path, limit)
        if name not in index or digest(raw) != index[name]:
            raise ValueError('historical member drift: ' + name)
        checked[name] = digest(raw)
        return raw

    # Bind the replay itself to the same original tree.
    if get('readback.json', 100000) != readback:
        raise ValueError('independent/original readback mismatch')
    bank = []
    for input_id, call_index in ((42, 2), (43, 3)):
        prefix = EXPERIMENT + 'inputs/input_%02d_' % input_id
        a = npy_payload(get(prefix + 'a.npy'), '|i1')
        b = npy_payload(get(prefix + 'b.npy'), '|i1')
        expected = None
        for step in (4, 5, 6, 7):
            middle = 'fpga/' if step == 6 else 'observation/worker/'
            prefix = EXPERIMENT + 'step_%02d/' % step
            request = unique_json(get(prefix + 'request.json', 10000))
            wanted_backend = {4: 'numpy_fp32', 5: 'openblas_1t', 6: 'fpga_cached', 7: 'openblas_2t'}[step]
            group = request['inputs'][call_index]
            if (request['shape_mnk'] != [512, 512, 512] or request['backend'] != wanted_backend
                    or group['input_id'] != input_id or group['seed'] != 20262019 + input_id - 42):
                raise ValueError('historical request/seed drift')
            call = unique_json(get(prefix + middle + 'call_%02d.json' % call_index, 20000))
            name = prefix + middle + 'output_%02d.npy' % call_index
            raw = get(name)
            if (call['group'] != group or call['output'] !=
                    dict(file='output_%02d.npy' % call_index, sha256=digest(raw))):
                raise ValueError('historical call/output binding drift')
            payload = npy_payload(raw, '<i4')
            if expected is not None and payload != expected:
                raise ValueError('historical four-backend outputs disagree')
            expected = payload
        if any(abs(value[0]) > 8388608 for value in struct.iter_unpack('<i', expected)):
            raise ValueError('INT8 K512 output bound exceeded')
        bank.append(Pair(input_id, a, b, expected))
    bank = tuple(bank)
    validate_bank(bank)
    output.mkdir()
    members = {}
    for pair in bank:
        for label, raw in (('a', pair.a), ('b', pair.b), ('expected', pair.expected)):
            name = 'input_%d_%s.bin' % (pair.input_id, label)
            with (output / name).open('xb') as f:
                f.write(raw)
            members[name] = dict(bytes=len(raw), sha256=digest(raw))
    manifest = dict(schema='matrix-short-envelope-audited-bank-v1',
                    historical_independent_readback_sha256=READBACK_SHA,
                    historical_original_inventory_sha256=INVENTORY_SHA,
                    historical_release_sha256=RELEASE_SHA, checked_originals=checked,
                    shape_mnk=[512, 512, 512], input_ids=[42, 43], input_seeds=[20262019, 20262020],
                    members=members, payload_bytes=3 * 1024 * 1024,
                    new_int64_oracle_executed=False, four_historical_backends_equal=True,
                    physical_identity_authenticated=False, board_access=False, promotion=False)
    for name, prior in checked.items():
        if digest(read_regular(originals / name, CALL_BYTES + 4096)) != prior:
            raise ValueError('historical source changed during extraction')
    if digest(read_regular(source_dir / 'independent_readback.json', 100000)) != READBACK_SHA:
        raise ValueError('historical replay changed during extraction')
    if digest(read_regular(source_dir / 'original_inventory_before.json', 1000000)) != INVENTORY_SHA:
        raise ValueError('historical inventory changed during extraction')
    with (output / 'bank.json').open('xb') as f:
        f.write(encode(manifest))
    return dict(bank=str(output), bank_manifest_sha256=digest(encode(manifest)),
                selected_originals=len(checked), source_bytes_unchanged=True, **manifest)


def load_bank(directory, expected_manifest_sha):
    directory = Path(directory)
    raw = read_regular(directory / 'bank.json', 100000)
    if digest(raw) != sha_text(expected_manifest_sha):
        raise ValueError('bank manifest identity drift')
    manifest = unique_json(raw)
    names = {'input_%d_%s.bin' % (i, s) for i in (42, 43) for s in ('a', 'b', 'expected')}
    if (set(x.name for x in directory.iterdir()) != names | {'bank.json'}
            or manifest.get('schema') != 'matrix-short-envelope-audited-bank-v1'
            or manifest.get('historical_independent_readback_sha256') != READBACK_SHA
            or manifest.get('historical_original_inventory_sha256') != INVENTORY_SHA
            or manifest.get('historical_release_sha256') != RELEASE_SHA
            or manifest.get('input_ids') != [42, 43] or manifest.get('shape_mnk') != [512, 512, 512]
            or set(manifest.get('members', {})) != names):
        raise ValueError('fixed bank scope/member set required')
    def get(input_id, label, size):
        name = 'input_%d_%s.bin' % (input_id, label)
        data = read_regular(directory / name, size)
        if manifest['members'][name] != dict(bytes=len(data), sha256=digest(data)):
            raise ValueError('bank member byte identity drift')
        return data
    bank = tuple(Pair(i, get(i, 'a', INPUT_BYTES), get(i, 'b', INPUT_BYTES),
                      get(i, 'expected', CALL_BYTES)) for i in (42, 43))
    validate_bank(bank)
    return bank


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = prepare(args.source_dir, args.output)
    print(json.dumps({k: result[k] for k in ('bank_manifest_sha256', 'selected_originals',
                      'source_bytes_unchanged', 'new_int64_oracle_executed', 'board_access')}))
