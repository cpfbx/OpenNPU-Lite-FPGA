"""New offline envelope consistency guard; no default threshold or schema bridge."""
from decimal import Decimal, localcontext
from control import sha_text


def decimal_text(value):
    if type(value) is not str or not 1 <= len(value) <= 80 or value != value.strip():
        raise ValueError('bounded decimal string required')
    import re
    if re.fullmatch(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?', value, re.ASCII) is None:
        raise ValueError('finite ASCII decimal required')
    d = Decimal(value)
    if not d.is_finite() or abs(d.adjusted()) > 20 or d.as_tuple().exponent < -20:
        raise ValueError('bounded finite decimal required')
    return d


def inspect(candidate, *, policy):
    """Caller must regenerate candidate from raw CSV using pinned importer.

    This function checks internal arithmetic of a supplied object, not CSV
    origin, prior approval, prior policy commitment, calibration or synchronization.
    No favorable source selection when Wh and P disagree.
    """
    if type(policy) is not dict or set(policy) != {'max_absolute_J', 'max_relative', 'basis'}:
        raise ValueError('explicit absolute AND relative consistency budgets required')
    if (type(policy['basis']) is not str or not policy['basis'].strip()
            or len(policy['basis']) > 512 or any(ord(c) < 32 for c in policy['basis'])):
        raise ValueError('explicit single-line diagnostic budget basis required')
    if type(candidate) is not dict or candidate.get('schema') != 'ut70-host-csv-import-candidate-v1':
        raise ValueError('pinned importer candidate required')
    if (candidate.get('window_selection') != 'entire_file_only'
            or candidate.get('power_product_consistent_under_declared_units') is not True
            or candidate.get('numeric_units_interpreted') !=
                dict(voltage='V', current='A', power='W', energy='Wh', time='ms')
            or candidate.get('formal_energy_input_accepted') is not False
            or candidate.get('ready_for_matrix_energy_tool') is not False
            or candidate.get('promotion') is not False):
        raise ValueError('whole-file units/candidate scope missing')
    sha_text(candidate.get('source_sha256'))
    if candidate.get('importer_sha256') != '3baf31a8f6d0e98f40ccc8365072182e6637e43b8ba7ee2d14978804755f8afc':
        raise ValueError('reviewed importer identity required')
    with localcontext() as ctx:
        ctx.prec = 80
        max_abs, max_rel = map(decimal_text, (policy['max_absolute_J'], policy['max_relative']))
        if max_abs <= 0 or not 0 < max_rel < 1:
            raise ValueError('positive absolute and 0<relative<1 budgets required')
        start, end, delta, energy, trap, stated = map(decimal_text, (
            candidate.get('host_wh_start'), candidate.get('host_wh_end'),
            candidate.get('host_wh_endpoint_difference'), candidate.get('host_wh_endpoint_difference_J'),
            candidate.get('power_trapezoid_J'), candidate.get('host_wh_minus_trapezoid_J')))
        duration = decimal_text(candidate.get('csv_time_span_seconds'))
        if (start < 0 or end < start or delta != end - start or energy != delta * 3600
                or trap < 0 or duration <= 0 or stated != energy - trap):
            raise ValueError('endpoint/integral arithmetic inconsistent')
        difference = abs(stated)
        denominator = max(abs(energy), abs(trap))
        # Multiplication avoids rounding near the relative boundary. Zero/zero
        # has no relative informative content; report None, not a divide by zero.
        abs_ok = difference <= max_abs
        rel_ok = difference <= max_rel * denominator
        if not (abs_ok and rel_ok):
            raise ValueError('Wh/P energy discrepancy exceeds supplied diagnostic budgets')
        return dict(scope='whole saved envelope diagnostic only',
                    source_sha256=candidate['source_sha256'],
                    envelope_energy_from_host_Wh_J=str(energy),
                    same_source_power_trapezoid_J=str(trap),
                    absolute_difference_J=str(difference),
                    relative_difference=None if denominator == 0 else str(difference / denominator),
                    numeric_consistency_passed=True, policy=dict(policy),
                    policy_prior_commitment_or_approval_verified=False,
                    raw_csv_recomputed_by_this_function=False,
                    synchronized_task_energy_verified=False, meter_accuracy_verified=False,
                    joules_per_task_evaluated=False, formal_energy_input_accepted=False,
                    promotion=False)
