"""Private ARM-only CPU worker. No public board RUN or FPGA imports."""
import argparse
import os
from pathlib import Path
import platform
import signal
import sys
import time


def run(root, expected_sha, config_path, config_sha):
    from binding_short import verify, paths, bounded, sha, unique_json, LIB_SHA, BANK_SHA, bound_import
    if platform.system() != 'Linux' or platform.machine() != 'armv7l' or sys.byteorder != 'little':
        raise RuntimeError('private worker requires original Linux ARMv7 little-endian runtime')
    if platform.release() != '6.6.10-xilinx-v2024.1-g3c0eca68c652':
        raise RuntimeError('private worker kernel identity drift')
    verify(root, expected_sha); paths(root)
    raw = bounded(config_path, 20000)
    if sha(raw) != config_sha:
        raise ValueError('guardian-written CPU config identity mismatch')
    c = unique_json(raw)
    if (set(c) != {'package_sha256', 'ticket', 'window', 'output', 'stop_flag'}
            or c['package_sha256'] != expected_sha or type(c['window']) is not int or c['window'] not in (0, 3)):
        raise ValueError('fixed private CPU window config required')
    config_path = config_path.absolute()
    out, stop_flag = Path(c['output']).absolute(), Path(c['stop_flag']).absolute()
    if (config_path.resolve() != config_path or out.resolve() != out or out.exists()
            or stop_flag.resolve() != stop_flag or out.parent != stop_flag.parent
            or root == out or root in out.parents or config_path.parent != out.parent.parent):
        raise ValueError('fresh external private CPU output/stop paths required')
    from os_evidence import verify_guardian_ticket
    from cpu_protocol import unique_json, encode, write_new
    from short_policy import ShortStop
    stopped = []
    for name in ('SIGINT', 'SIGTERM', 'SIGHUP'):
        signal.signal(getattr(signal, name), lambda n, f: stopped.append(n) if n not in stopped else None)

    def guard():
        if stopped or os.path.lexists(stop_flag):
            raise ShortStop('CPU stop pending before BLAS')
        verify_guardian_ticket(c['ticket'])

    def send(value):
        sys.stdout.buffer.write(encode(value)); sys.stdout.buffer.flush()

    def receive(kind, index):
        raw = sys.stdin.buffer.readline(8193)
        if len(raw) > 8192 or not raw.endswith(b'\n'):
            raise ShortStop('CPU parent pipe ended/incomplete; no further BLAS')
        value = unique_json(raw)
        if value == dict(kind='stop'):
            raise ShortStop('CPU guardian requested stop')
        if value != dict(kind=kind, index=index) or type(value.get('index')) is not int:
            raise ValueError('CPU guardian grant/ack sequence drift')

    guard()
    if os.getsid(0) != os.getpid() or os.getpgrp() != os.getpid():
        raise RuntimeError('private CPU must be a new dedicated session/process group')
    bank_module = bound_import(root, 'fixtures', 'model/fixtures.py')
    bank = bank_module.load_bank(root / 'bank', BANK_SHA)
    import numpy as np
    blas_module = bound_import(root, 'blas_candidate', 'cpu/blas_candidate.py')
    candidate = blas_module.BlasCandidate(root / 'cpu/libmatrix_blas_arm.so', LIB_SHA,
                                          threads=2, target='arm', enabled=True)
    inputs = []
    for pair in bank:
        arrays = [np.frombuffer(raw, dtype=np.int8).copy().reshape(512, 512).copy() for raw in (pair.a, pair.b)]
        for value in arrays:
            value.setflags(write=False)
        inputs.append(tuple(arrays))
    out.mkdir()
    write_new(out / 'identity.json', dict(pid=os.getpid(), pgid=os.getpgrp(), candidate=candidate.identity,
              numpy=np.__version__, affinity=sorted(os.sched_getaffinity(0)),
              library_sha256=LIB_SHA, bank_sha256=BANK_SHA, inherited_lock_descriptor=False))
    for index in range(4):
        guard()
        send(dict(kind='ready', index=index, input_id=42 + index % 2, pid=os.getpid()))
        receive('go', index)
        guard()  # Last child-side parent-lock/stop check before native BLAS.
        begin = time.perf_counter_ns(); cpu = time.process_time_ns()
        output = candidate(*inputs[index % 2])
        cpu = time.process_time_ns() - cpu; end = time.perf_counter_ns()
        if type(output) is not np.ndarray or output.dtype != np.int32 or output.shape != (512, 512):
            raise ValueError('CPU output dtype/shape drift')
        payload = output.tobytes(order='C')
        with (out / ('output_%02d.bin' % index)).open('xb') as f:
            f.write(payload); f.flush(); os.fsync(f.fileno())
        row = dict(kind='result', index=index, input_id=42 + index % 2, pid=os.getpid(),
                   begin_ns=begin, end_ns=end, process_cpu_ns=cpu, sha256=sha(payload))
        write_new(out / ('call_%02d.json' % index), row)
        send(row)
        receive('ack', index)
    guard()
    send(dict(kind='done', calls=4, pid=os.getpid()))
    return 0


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package-sha', required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--config-sha', required=True)
    args = parser.parse_args()
    raise SystemExit(run(Path(__file__).resolve().parent.parent, args.package_sha, args.config, args.config_sha))
