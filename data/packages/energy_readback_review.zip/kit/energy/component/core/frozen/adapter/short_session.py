"""Unreleased real short-plan internal wiring. No public board launch command.

A future bx-approved launcher must bind this function, capture controller and
outer actual-exit observer to one sealed identity. Merely calling Python is not
permission to run a board. No automatic upload, SSH, recording or meter control.
"""
import contextlib
from datetime import datetime, timezone
import os
from pathlib import Path
import platform
import signal
import sys
import time

from short_policy import ShortPolicy, ShortStop
from short_owner import ShortOwner
from short_call import ShortCall
from cpu_protocol import run_cpu_window, write_new, encode


def validate_experiment(value):
    """External prior approval reference is REQUIRED, never authenticated here."""
    if type(value) is not dict or set(value) != {'policy', 'approval_reference'}:
        raise ValueError('explicit pre-capture policy and bx approval reference required')
    if (type(value['approval_reference']) is not str or not value['approval_reference'].strip()
            or len(value['approval_reference']) > 512
            or any(ord(c) < 32 for c in value['approval_reference'])):
        raise ValueError('single-line prior user approval reference required')
    p = value['policy']
    if type(p) is not dict or set(p) != {'max_absolute_J', 'max_relative', 'basis'}:
        raise ValueError('explicit absolute/relative budgets and basis required')
    if type(p['basis']) is not str or not p['basis'].strip() or len(p['basis']) > 512 or any(ord(c) < 32 for c in p['basis']):
        raise ValueError('single-line diagnostic policy basis required')
    # This module is also imported on PC before model paths are set; use the
    # same bounded decimal domain locally, with no automatic threshold defaults.
    import re
    from decimal import Decimal
    numbers = []
    for key in ('max_absolute_J', 'max_relative'):
        text = p[key]
        if (type(text) is not str or not 1 <= len(text) <= 80
                or re.fullmatch(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?', text, re.ASCII) is None):
            raise ValueError('bounded finite ASCII budget string required')
        number = Decimal(text)
        if not number.is_finite() or abs(number.adjusted()) > 20 or number.as_tuple().exponent < -20:
            raise ValueError('bounded diagnostic policy number required')
        numbers.append(number)
    if not numbers[0] > 0 or not 0 < numbers[1] < 1:
        raise ValueError('positive absolute and 0<relative<1 budgets required')
    return dict(policy=dict(p), approval_reference=value['approval_reference'])


def persist_terminal(evidence, events, record, primary):
    """Attempt BOTH final records; IO failure must not erase the primary error."""
    failures = []
    for name, value in (('events.json', events), ('lifecycle.json', record)):
        try:
            write_new(evidence / name, value)
        except BaseException as error:
            failures.append(dict(file=name, error_type=type(error).__name__))
            record['operation_success'] = False
            record['terminal_persistence_errors'] = list(failures)
            if primary is None:
                primary = error
                record.setdefault('error_type', type(error).__name__)
                record.setdefault('error_message', str(error))
            else:
                note = getattr(primary, 'add_note', None)
                if callable(note):
                    try:
                        note('Terminal persistence failed: %s (%s)' % (name, type(error).__name__))
                    except BaseException:
                        pass
    if failures:
        try:
            primary.terminal_persistence_errors = failures
        except BaseException:
            pass
    return primary


CAPTURE_START = {'per_window': ('capture_started.json', 'saving_started'),
                 'single_envelope': ('envelope_started.json', 'coverage_armed')}
CAPTURE_STOP = {'per_window': ('capture_stopped.json', 'saving_stopped'),
                'single_envelope': ('envelope_closed.json', 'coverage_closed')}


def begin_capture(capture, scope, policy_sha256, folder, window):
    """Write and validate ONE capture acknowledgement; no device access."""
    name, key = CAPTURE_START[scope]
    ack = capture.begin(window, policy_sha256=policy_sha256)
    write_new(Path(folder) / name, ack)
    if (type(ack) is not dict or ack.get(key) is not True
            or type(ack.get('capture_id')) is not str or not ack['capture_id']
            or ack.get('policy_sha256') != policy_sha256
            or (scope == 'single_envelope' and ack.get('scope') != 'single_envelope')):
        raise RuntimeError('capture start not acknowledged; no matrix calls')
    return ack['capture_id']


def end_capture(capture, scope, capture_id, policy_sha256, folder, window):
    """Write and validate ONE capture close acknowledgement; no device access."""
    name, key = CAPTURE_STOP[scope]
    ack = capture.end(window)
    write_new(Path(folder) / name, ack)
    if (type(ack) is not dict or ack.get(key) is not True
            or ack.get('capture_id') != capture_id
            or ack.get('policy_sha256') != policy_sha256):
        raise RuntimeError('capture stop not acknowledged')
    return ack


@contextlib.contextmanager
def stop_latch():
    previous, stops = {}, []
    def stop(number, frame):
        if number not in stops:
            stops.append(number)
        old = previous[number]
        if callable(old):
            old(number, frame)  # Preserve unchanged outer supervisor recorder.
    try:
        for name in ('SIGINT', 'SIGTERM', 'SIGHUP'):
            n = getattr(signal, name)
            previous[n] = signal.getsignal(n)
            signal.signal(n, stop)
        yield stops
    finally:
        for number, handler in previous.items():
            signal.signal(number, handler)


def run_internal(root, expected_sha, evidence, *, capture, experiment=None,
                 capture_scope='per_window', enabled=False):
    if enabled is not True:
        raise ValueError('unreleased real adapter default-off; not board authorization')
    if capture_scope not in ('per_window', 'single_envelope'):
        raise ValueError('explicit per_window or single_envelope capture scope required')
    if platform.system() != 'Linux' or platform.machine() != 'armv7l' or sys.byteorder != 'little':
        raise RuntimeError('original Linux ARMv7 little-endian runtime required')
    if platform.release() != '6.6.10-xilinx-v2024.1-g3c0eca68c652':
        raise RuntimeError('original kernel identity required')
    from binding_short import verify, load_device_dependencies, bounded, sha, BANK_SHA, bound_import
    root = Path(root).absolute()
    verify(root, expected_sha)
    experiment = validate_experiment(experiment)  # Before acquisition or any capture.
    policy_sha256 = sha(encode(experiment))
    evidence = Path(evidence).absolute()
    if evidence.resolve() != evidence or evidence.exists() or evidence == root or root in evidence.parents:
        raise ValueError('canonical fresh evidence outside immutable candidate required')
    if (capture is None or not callable(getattr(capture, 'begin', None))
            or not callable(getattr(capture, 'end', None))):
        raise ValueError('separately reviewed trusted PC capture controller required; no simulated default')
    if (os.environ.get('BOARD_SERIAL') != 'ftdi-1234-tulB'
            or os.environ.get('PYNQ_IMAGE') != 'pynq-z2-v3.1.1'):
        raise ValueError('explicit operator board/image declarations required')
    deps = load_device_dependencies(root, expected_sha)
    model_module = bound_import(root, 'control', 'model/control.py')
    fixtures = bound_import(root, 'fixtures', 'model/fixtures.py')
    bank = fixtures.load_bank(root / 'bank', BANK_SHA)
    import numpy as np
    prepared = []
    for pair in bank:
        a, b = [np.frombuffer(raw, np.int8).reshape(512, 512).copy() for raw in (pair.a, pair.b)]
        a.setflags(write=False); b.setflags(write=False)
        prepared.append((a, b))
    evidence.mkdir()
    runtime = evidence / 'runtime'; runtime.mkdir()
    model = model_module.SerialModel(bank, enabled=True)
    policy = ShortPolicy(enabled=True)
    stop_requests = []
    owner = ShortOwner(policy, lambda: bool(stop_requests), enabled=True)
    record = dict(scope='unreleased real short functionality/saved-envelope diagnostic',
                  package_sha256=expected_sha, actual_child_exit_code=None,
                  checked_calls=0, operation_success=False, cleanup_complete=False,
                  capture_controls_independently_verified=False,
                  capture_scope=capture_scope,
                  policy_sha256=policy_sha256, approval_reference_authenticated=False,
                  synchronized_task_energy_verified=False, formal_energy_input_accepted=False,
                  physical_identity_authenticated=False, promotion=False)
    write_new(evidence / 'request.json', dict(contract=model_module.contract(),
              package_sha256=expected_sha, bank_sha256=BANK_SHA,
              experiment=experiment, policy_sha256=policy_sha256,
              declared_identity=dict(BOARD_SERIAL=os.environ['BOARD_SERIAL'], PYNQ_IMAGE=os.environ['PYNQ_IMAGE']),
              source_of_actual_exit='future OUTER observer, never this worker record'))

    def operation():
        primary = None
        active_capture = None
        try:
            with stop_latch() as requested:
                # Same list is used at resource initialization and every submit.
                # Keep lambda closure live rather than copying a boolean snapshot.
                owner.stop_requested = lambda: bool(requested)
                os.chdir(runtime)  # Driver runtime artifacts never touch immutable package.
                owner.start(deps.runner_type, root / 'baseline/hardware/opennpu_gemm_accelerator.bit',
                            deps.lease_factory, deps.recovery_factory)
                call = ShortCall(owner, policy, enabled=True)
                envelope_id = None
                if capture_scope == 'single_envelope':
                    # One operator save session covers all four ABBA windows.
                    # Mark the failure path before begin: if begin acquires then
                    # fails validation, the finally still attempts the close once.
                    active_capture = 3
                    envelope_id = begin_capture(capture, capture_scope, policy_sha256,
                                                evidence, 0)
                for window, backend in enumerate(model_module.BACKENDS):
                    if requested:
                        raise ShortStop('stop before next capture/backend')
                    folder = evidence / ('window_%d' % window); folder.mkdir()
                    if capture_scope == 'per_window':
                        active_capture = window
                        capture_id = begin_capture(capture, capture_scope, policy_sha256,
                                                   folder, window)
                        model_capture_id = capture_id
                    else:
                        capture_id = envelope_id
                        # The offline model rejects a repeated capture_id, so each
                        # window gets a derived id while the envelope id is kept.
                        model_capture_id = '%s:w%d' % (capture_id, window)
                        write_new(folder / 'capture_armed.json',
                                  dict(capture_id=capture_id, model_capture_id=model_capture_id,
                                       policy_sha256=policy_sha256, window=window,
                                       scope='single_envelope', coverage_active=True,
                                       meter_control='operator; not board-driven',
                                       board_observed_meter_state=False))
                    owner.pre_submit()
                    model.begin(backend=backend, capture_id=model_capture_id,
                                owner_lease_held=True, lock_path=model_module.LOCK,
                                stop_requested=bool(requested))
                    if backend == 'openblas_2t':
                        ticket = owner.pre_submit()
                        observation = folder / 'cpu_observation'
                        config = dict(package_sha256=expected_sha, ticket=ticket, window=window,
                                      output=str(observation / 'worker'), stop_flag=str(observation / 'stop.flag'))
                        config_file = folder / 'cpu_config.json'
                        write_new(config_file, config)
                        command = [sys.executable, '-B', str(root / 'adapter/cpu_worker.py'),
                                   '--package-sha', expected_sha, '--config', str(config_file),
                                   '--config-sha', sha(config_file.read_bytes())]

                        def accept(index, row):
                            raw = bounded(observation / 'worker' / ('output_%02d.bin' % index), 1048576)
                            if (len(raw) != 1048576 or sha(raw) != row.get('sha256')
                                    or type(row.get('process_cpu_ns')) is not int or row['process_cpu_ns'] <= 0):
                                raise ValueError('CPU raw result identity/timing drift')
                            write_new(folder / ('received_%02d.json' % index), row)
                            model.accept(raw, input_id=row.get('input_id'), backend=backend,
                                         begin_ns=row.get('begin_ns'), end_ns=row.get('end_ns'),
                                         stop_requested=bool(requested))

                        cpu = run_cpu_window(command, observation, owner, lambda: bool(requested), accept)
                    else:
                        cpu = None
                        for index in range(4):
                            owner.pre_submit()  # Data lookup below is NOT permission.
                            pair = model.expected_pair()
                            if requested:
                                raise ShortStop('stop before complete FPGA request')
                            begin = time.perf_counter_ns(); cpu_begin = time.process_time_ns()
                            output, metrics = call(*prepared[index % 2])
                            end = time.perf_counter_ns(); process_cpu = time.process_time_ns() - cpu_begin
                            raw = output.tobytes(order='C')
                            with (folder / ('output_%02d.bin' % index)).open('xb') as f:
                                f.write(raw); f.flush(); os.fsync(f.fileno())
                            write_new(folder / ('call_%02d.json' % index), dict(input_id=pair.input_id,
                                      begin_ns=begin, end_ns=end, process_cpu_ns=process_cpu, metrics=metrics,
                                      output_sha256=sha(raw)))
                            model.accept(raw, input_id=pair.input_id, backend=backend,
                                         begin_ns=begin, end_ns=end, stop_requested=bool(requested))
                    if capture_scope == 'per_window':
                        # No automatic second end attempt if acknowledgement fails.
                        active_capture = None
                        end_capture(capture, capture_scope, capture_id, policy_sha256,
                                    folder, window)
                        active_capture = None
                    owner.pre_submit()
                    end_kwargs = dict(
                        completed_calls=4,
                        actual_exit_code=None if cpu is None else cpu['actual_exit_code'],
                        process_group_absent=None if cpu is None else cpu['process_group_absent'],
                        cpu_pid=None if cpu is None else cpu['pid'],
                        owner_lease_held=True, stop_requested=bool(requested))
                    # The frozen offline model only guards that capture coverage
                    # was accounted for before accepting a window. It records no
                    # per-window stop claim; the real meter stop is the PC receipt.
                    end_kwargs['capture_stopped'] = True
                    model.end(**end_kwargs)
                if capture_scope == 'single_envelope':
                    # Clear first: a close ack failure must not trigger a second
                    # capture.end() from the finally block.
                    active_capture = None
                    end_capture(capture, capture_scope, envelope_id, policy_sha256,
                                evidence, 3)
                # Terminal marker written ONLY after all windows and capture close.
                # The outer observer counts events itself; this marker is not
                # self-authenticating and never replaces the real child exit.
                write_new(evidence / 'run_complete.json',
                          dict(schema='short-run-complete-v1',
                               package_sha256=expected_sha, capture_scope=capture_scope,
                               capture_id=(envelope_id if capture_scope == 'single_envelope'
                                           else None),
                               checked_calls=model.checked_calls, calls=16,
                               stop_requested=bool(requested),
                               completed_at_utc=datetime.now(timezone.utc).isoformat(
                                   timespec='microseconds')))
        except BaseException as error:
            primary = error
            model.request_stop()
            record.update(error_type=type(error).__name__, error_message=str(error))
            payload = getattr(error, 'matrix_returned_payload', None)
            if type(payload) is bytes:
                try:
                    with (evidence / 'failed_payload.bin').open('xb') as f:
                        f.write(payload)
                except BaseException as save_error:
                    record['failed_payload_save_error_type'] = type(save_error).__name__
        finally:
            if active_capture is not None:
                try:
                    write_new(evidence / 'failure_capture_stop.json', capture.end(active_capture))
                except BaseException as error:
                    record['capture_stop_error_type'] = type(error).__name__
                    if primary is None:
                        primary = error
            try:
                owner.close()
                record['cleanup_complete'] = True
                record['cleanup_readback'] = owner.cleanup_readback
            except BaseException as error:
                record['cleanup_error_type'] = type(error).__name__
                if primary is None:
                    primary = error
            record.update(checked_calls=model.checked_calls, resources=owner.supervision_status)
            if primary is None:
                state = owner.supervision_status
                try:
                    record['model_result'] = model.finish(cleanup={k: state[k] for k in
                        ('held', 'safety_unresolved', 'lease_retained', 'runner_retained', 'root_buffers_retained')})
                    record['operation_success'] = True
                except BaseException as error:
                    primary = error
                    record.update(error_type=type(error).__name__, error_message=str(error))
            primary = persist_terminal(evidence, model.events, record, primary)
        if primary is not None:
            raise primary
        return record

    previous = Path.cwd()
    try:
        result = deps.supervise(owner, operation, lambda attention: write_new(evidence / 'attention.json', attention),
                                enabled=True)
    finally:
        # Quarantine in the unchanged supervisor never returns to this finally.
        os.chdir(previous)
    write_new(evidence / 'supervision_complete.json', dict(returned_without_pending_stop=True,
              actual_child_exit_code=None, source='not an outer process exit receipt', promotion=False))
    verify(root, expected_sha)  # Immutable package/driver/library bytes still exact.
    return result


if __name__ == '__main__':
    print('UNRELEASED internal adapter only. No board RUN; bx approval and independent review required.')
    raise SystemExit(2)
