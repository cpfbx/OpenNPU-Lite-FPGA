UNRELEASED SHORT-DIAGNOSTIC CANDIDATE. BOARD RUN REQUIRES bx EXPLICIT APPROVAL.
Scope: 512^3 INT8, four ABBA windows, 8 calls per backend, 16 calls total.
Capture: ONE continuous operator save envelope; the board only carries the token.
Stop boundary: finish the admitted run_chain/BLAS request, then start no next request.
Check: python -B adapter/binding_short.py check --identity-sha <externally supplied SHA>
Board entry (only after approval): python -B run_short_diagnostic.py --help
PC tests: python -B -m unittest discover -s adapter -p test_*.py -v
