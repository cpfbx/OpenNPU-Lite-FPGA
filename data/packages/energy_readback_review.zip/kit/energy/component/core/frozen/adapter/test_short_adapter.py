"""Standard-library, explicit fake-register and PC-process tests; NOT board proof."""
import errno
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch

import os_evidence as evidence
import short_owner as owners
from short_policy import ShortPolicy, ShortStop, validate_policy
from cpu_protocol import run_cpu_window, _RUNNING
from short_session import validate_experiment, persist_terminal


class Buffer:
    dtype = 'uint8'
    ndim = 1
    flags = NS(c_contiguous=True, writeable=True)
    def __init__(self, size, address):
        self.nbytes, self.physical_address = size, address
        self.freed = False
    def freebuffer(self):
        self.freed = True


NP = NS(ndarray=Buffer, dtype=lambda x: x, uint8='uint8', shares_memory=lambda a, b: a is b)


class MMIO:
    def __init__(self, values):
        self.values = values
    def read(self, offset):
        return self.values[offset]


class Runner:
    def __init__(self, bit):
        self.pynq_version = '3.1.1'
        self._pynq = NS(Clocks=NS(fclk0_mhz=100.))
        self.build_id, self.capabilities = 0x2026D075, 0x00080EFE
        self.mmio = MMIO({0x60: self.build_id, 0x64: self.capabilities, 0x12c: 1, 8: 0, 4: 1})
        registers = MMIO({0: 1, 4: 2, 0x30: 1, 0x34: 2})
        def channel(offset):
            return NS(_mmio=registers, _offset=offset, _align=8, _dre=False,
                      _max_size=0x7FFFFF, _first_transfer=True, _active_buffer=None)
        self.dma = NS(sendchannel=channel(0), recvchannel=channel(0x30))
        self.buffers, self.calls = [], 0
    def _allocate(self, *, shape, dtype):
        buf = Buffer(shape[0], 0x1000 if not self.buffers else 0x800000)
        self.buffers.append(buf)
        return buf
    def run_chain(self, jobs, *buffers, **options):
        self.calls += 1
        self.mmio.values.update({0x12c: 2, 4: 4})
        return b'fake-driver-CPU-bytes', [], {}


class Recovery:
    def __init__(self, runner, **kw):
        self.last_diagnostics = None
    def recover_and_confirm(self, runner):
        runner.mmio.values.update({0x12c: 1, 4: 1})
        self.last_diagnostics = dict(confirmed=True, scope='FAKE REGISTERS ONLY')
        return True


class Lease:
    def __init__(self, factory):
        self.entered, self.released, self.audits = False, False, 0
    def __enter__(self):
        self.entered = True
        return self
    def audit(self):
        self.audits += 1
        if self.released:
            raise RuntimeError('fake lease already released')
        return dict(scope='SYNTHETIC LEASE; NOT OS LOCK PROOF')
    def __exit__(self, *exc):
        self.released = True


def jobs():
    return [NS(matrix_m=512, matrix_n=512, matrix_k=512) for _ in range(64)]


def options(index=0):
    return dict(first_job_id=1 + index * 64, timeout_s=60., mode_override=11,
                launch_order='dma-first', profile_host=True)


class PolicyTests(unittest.TestCase):
    def test_default_off(self):
        with self.assertRaises(ValueError): ShortPolicy()
    def test_eight_explicit_requests(self):
        p = ShortPolicy(enabled=True)
        self.assertEqual([p.request(i).first_job_id for i in range(8)], list(range(1, 513, 64)))
        self.assertEqual([p.request(i).input_id for i in range(8)], [42, 43] * 4)
    def test_exhausted_or_wrong_index(self):
        p = ShortPolicy(enabled=True)
        for value in (True, -1, 8, 1.0):
            with self.subTest(value=value), self.assertRaises(ValueError): p.request(value)
    def test_no_legacy_policy_cast(self):
        with self.assertRaises(ValueError): validate_policy(NS(enabled=True))


class ExperimentTests(unittest.TestCase):
    def example(self):
        return dict(policy=dict(max_absolute_J='0.1', max_relative='0.01', basis='SYNTHETIC ONLY'),
                    approval_reference='SYNTHETIC TEST, not real user approval')
    def test_explicit_only(self):
        e = self.example()
        self.assertEqual(validate_experiment(e), e)
    def test_no_default_budget(self):
        with self.assertRaises(ValueError): validate_experiment(None)
    def test_no_approval_reference(self):
        e = self.example(); e.pop('approval_reference')
        with self.assertRaises(ValueError): validate_experiment(e)
    def test_empty_basis(self):
        e = self.example(); e['policy']['basis'] = ''
        with self.assertRaises(ValueError): validate_experiment(e)
    def test_numeric_budget_refused(self):
        e = self.example(); e['policy']['max_absolute_J'] = 0.1
        with self.assertRaises(ValueError): validate_experiment(e)
    def test_nonfinite_budget_refused(self):
        for value in ('NaN', 'Inf', '1e100000', '0', '-1', ' 0.1'):
            e = self.example(); e['policy']['max_absolute_J'] = value
            with self.subTest(value=value), self.assertRaises(ValueError): validate_experiment(e)
    def test_relative_bounds_refused(self):
        for value in ('0', '-1', '1', '2', True):
            e = self.example(); e['policy']['max_relative'] = value
            with self.subTest(value=value), self.assertRaises(ValueError): validate_experiment(e)
    def test_approval_cannot_add_override_flag(self):
        e = self.example(); e['approved'] = True
        with self.assertRaises(ValueError): validate_experiment(e)
    def test_input_policy_not_aliased(self):
        e = self.example(); result = validate_experiment(e)
        e['policy']['max_relative'] = '0.9'
        self.assertEqual(result['policy']['max_relative'], '0.01')


class TerminalPersistenceTests(unittest.TestCase):
    def check_case(self, primary, failed_names):
        attempted, record = [], dict(operation_success=True)
        def write(path, value):
            attempted.append(path.name)
            if path.name in failed_names:
                raise OSError('SECONDARY_' + path.name)
        with patch('short_session.write_new', side_effect=write):
            returned = persist_terminal(Path('SYNTHETIC'), [], record, primary)
        self.assertEqual(attempted, ['events.json', 'lifecycle.json'])
        self.assertFalse(record['operation_success'])
        return returned
    def test_primary_plus_events_failure_preserves_primary(self):
        original = ValueError('ORIGINAL_ACQUISITION_FAILURE')
        self.assertIs(self.check_case(original, {'events.json'}), original)
    def test_primary_plus_lifecycle_failure_preserves_primary(self):
        original = ValueError('ORIGINAL_ACQUISITION_FAILURE')
        self.assertIs(self.check_case(original, {'lifecycle.json'}), original)
    def test_both_secondary_failures_preserve_primary(self):
        original = ValueError('ORIGINAL_ACQUISITION_FAILURE')
        self.assertIs(self.check_case(original, {'events.json', 'lifecycle.json'}), original)
        self.assertEqual(len(original.terminal_persistence_errors), 2)
    def test_no_primary_write_failure_still_fails(self):
        self.assertIsInstance(self.check_case(None, {'events.json'}), OSError)


class OwnerTests(unittest.TestCase):
    def setUp(self):
        self.np_patch = patch.dict(sys.modules, {'numpy': NP})
        self.lease_patch = patch.object(owners, 'ObservedLease', Lease)
        self.np_patch.start(); self.lease_patch.start()
        self.stopped = False
        self.owner = owners.ShortOwner(ShortPolicy(enabled=True), lambda: self.stopped, enabled=True)
        self.owner.start(Runner, Path('FAKE.bit'), lambda: None, Recovery)
    def tearDown(self):
        self.np_patch.stop(); self.lease_patch.stop()
    def test_eight_new_short_calls_and_real_method_cleanup(self):
        runner = self.owner._runner
        for index in range(8):
            self.owner.execute_chain(jobs(), **options(index))
        self.owner.close()
        self.assertEqual(runner.calls, 8)
        self.assertTrue(all(b.freed for b in runner.buffers))
        self.assertFalse(self.owner.supervision_status['lease_retained'])
        self.assertEqual(self.owner.cleanup_readback['terminal']['phase'], 1)
    def test_stop_before_dma_never_calls_driver(self):
        runner = self.owner._runner
        self.stopped = True
        with self.assertRaises(ShortStop): self.owner.execute_chain(jobs(), **options())
        self.assertEqual(runner.calls, 0)
        self.assertFalse(self.owner.supervision_status['held'])
        self.owner.close()
    def test_stop_at_last_submit_guard(self):
        runner = self.owner._runner
        checks = []
        def pending():
            checks.append(1)
            return len(checks) >= 2
        self.owner.stop_requested = pending
        with self.assertRaises(ShortStop): self.owner.execute_chain(jobs(), **options())
        self.assertEqual(runner.calls, 0)
        self.assertFalse(self.owner.supervision_status['held'])
        self.owner.close()
    def test_bad_job_sequence_quarantines(self):
        with self.assertRaises(ValueError): self.owner.execute_chain(jobs(), **options(1))
        self.assertTrue(self.owner.supervision_status['held'])
        with self.assertRaises(RuntimeError): self.owner.close()
    def test_no_ninth_submit(self):
        for i in range(8): self.owner.execute_chain(jobs(), **options(i))
        with self.assertRaises(ValueError): self.owner.execute_chain(jobs(), **options(8))
        self.assertEqual(self.owner._runner.calls, 8)
    def test_dma_error_no_submit(self):
        self.owner._runner.dma.sendchannel._mmio.values[4] = 0x10
        with self.assertRaises(RuntimeError): self.owner.execute_chain(jobs(), **options())
        self.assertEqual(self.owner._runner.calls, 0)
        self.assertTrue(self.owner.supervision_status['held'])
    def test_identity_error_no_submit(self):
        self.owner._runner.mmio.values[0x60] = 0
        with self.assertRaises(RuntimeError): self.owner.execute_chain(jobs(), **options())
        self.assertEqual(self.owner._runner.calls, 0)
    def test_lock_observation_failure_no_submit(self):
        self.owner._lease.audit = lambda: (_ for _ in ()).throw(RuntimeError('synthetic lock loss'))
        with self.assertRaises(RuntimeError): self.owner.execute_chain(jobs(), **options())
        self.assertEqual(self.owner._runner.calls, 0)
        self.assertTrue(self.owner.supervision_status['held'])
    def test_original_driver_failure_retains_buffers(self):
        self.owner._runner.run_chain = lambda *a, **kw: (_ for _ in ()).throw(RuntimeError('driver failed'))
        with self.assertRaises(RuntimeError): self.owner.execute_chain(jobs(), **options())
        self.assertTrue(self.owner.supervision_status['safety_unresolved'])
        self.assertEqual(self.owner.supervision_status['root_buffers_retained'], 2)
    def test_returned_failure_payload_retained(self):
        def bad(*a, **kw):
            self.owner._runner.mmio.values[0x12c] = 99
            return b'RETAIN_THIS', [], {}
        self.owner._runner.run_chain = bad
        with self.assertRaises(RuntimeError) as caught:
            self.owner.execute_chain(jobs(), **options())
        self.assertEqual(caught.exception.matrix_returned_payload, b'RETAIN_THIS')
    def test_bool_options_not_int(self):
        o = options(); o['first_job_id'] = True
        with self.assertRaises(ValueError): self.owner.execute_chain(jobs(), **o)
    def test_no_profile_off(self):
        o = options(); o['profile_host'] = False
        with self.assertRaises(ValueError): self.owner.execute_chain(jobs(), **o)
    def test_alias_roots_refused(self):
        self.owner._buffers[1].physical_address = self.owner._buffers[0].physical_address
        with self.assertRaises(RuntimeError): self.owner.execute_chain(jobs(), **options())
    def test_free_failure_retains_lease_and_buffer(self):
        self.owner._buffers[-1].freebuffer = lambda: (_ for _ in ()).throw(RuntimeError('free failed'))
        with self.assertRaises(RuntimeError): self.owner.close()
        self.assertTrue(self.owner.supervision_status['held'])
        self.assertTrue(self.owner.supervision_status['lease_retained'])
        self.assertEqual(self.owner.supervision_status['root_buffers_retained'], 2)
    def test_cleanup_recovery_not_exact_true(self):
        self.owner._recovery.recover_and_confirm = lambda r: 1
        with self.assertRaises(RuntimeError): self.owner.close()
        self.assertTrue(self.owner.supervision_status['held'])
    def test_constructor_default_off(self):
        with self.assertRaises(ValueError): owners.ShortOwner(ShortPolicy(enabled=True), lambda: False)


class KernelParserTests(unittest.TestCase):
    def setUp(self):
        self.os_patch = patch.multiple(os, major=lambda d: 0, minor=lambda d: 20, create=True)
        self.os_patch.start()
        self.raw = 'pos:\t0\nflags:\t02404000\nino:\t456\nlock:\t1: FLOCK ADVISORY WRITE 123 00:14:456 0 EOF\n'
    def tearDown(self): self.os_patch.stop()
    def parse(self, text): return evidence.parse_fdinfo(text, pid=123, device=20, inode=456)
    def test_exact_synthetic_kernel_record(self): self.assertTrue(self.parse(self.raw)['exclusive_flock'])
    def test_no_flock_line(self):
        with self.assertRaises(ValueError): self.parse(self.raw.split('lock:')[0])
    def test_shared_lock_refused(self):
        with self.assertRaises(ValueError): self.parse(self.raw.replace('WRITE', 'READ'))
    def test_wrong_guardian_pid(self):
        with self.assertRaises(ValueError): self.parse(self.raw.replace('WRITE 123', 'WRITE 124'))
    def test_wrong_inode(self):
        with self.assertRaises(ValueError): self.parse(self.raw.replace('00:14:456', '00:14:457'))
    def test_no_cloexec(self):
        with self.assertRaises(ValueError): self.parse(self.raw.replace('02404000', '00404000'))
    def test_duplicate_lock_refused(self):
        with self.assertRaises(ValueError): self.parse(self.raw + self.raw.split('lock:')[1].join(['lock:', '']))
    def test_process_start_comm_with_parens(self):
        fields = ['S'] + ['0'] * 18 + ['9876'] + ['0'] * 10
        self.assertEqual(evidence.process_start('123 (a tricky) name) ' + ' '.join(fields)), 9876)
    def test_process_start_bad(self):
        with self.assertRaises(ValueError): evidence.process_start('bad')
    def test_group_presence_not_absent(self):
        with patch.object(os, 'killpg', return_value=None, create=True):
            self.assertFalse(evidence.process_group_absent(123))
    def test_group_esrch_absent(self):
        with patch.object(os, 'killpg', side_effect=ProcessLookupError(), create=True):
            self.assertTrue(evidence.process_group_absent(123))
    def test_group_eperm_unknown(self):
        with patch.object(os, 'killpg', side_effect=PermissionError(), create=True):
            with self.assertRaises(PermissionError): evidence.process_group_absent(123)


class FakeGuardian:
    def __init__(self): self.checks, self.held = 0, False
    def pre_submit(self): self.checks += 1
    def _hold(self, error): self.held = True


class ProtocolTests(unittest.TestCase):
    def run_scenario(self, scenario, *, accept=None, group=lambda pid: True, stop=lambda: False):
        owner = FakeGuardian()
        with tempfile.TemporaryDirectory(prefix='short_protocol_pc_') as directory:
            root = Path(directory).resolve() / 'new'
            command = [sys.executable, '-B', str(Path(__file__).parent / 'pc_protocol_fixture.py'), scenario]
            try:
                result = run_cpu_window(command, root, owner, stop, accept or (lambda i, r: None), group_query=group)
            except BaseException:
                self.last = json.loads((root / 'actual_exit.json').read_bytes()) if (root / 'actual_exit.json').exists() else None
                self.owner = owner
                raise
            self.last, self.owner = result, owner
            return result
    def tearDown(self):
        # Only our known non-forking desktop stubs: SUT already waited for exit.
        # No kill/terminate, no real board or unresolved live process is touched.
        for p in list(_RUNNING):
            if p.poll() is not None:
                p.stdout.close()
                _RUNNING.remove(p)
    def test_real_pc_wait_and_four_handshakes(self):
        r = self.run_scenario('normal')
        self.assertEqual(r['actual_exit_code'], 0)
        self.assertEqual(r['checked_calls'], 4)
        self.assertEqual(self.owner.checks, 5)
        self.assertFalse(self.owner.held)
    def test_real_pc_exit7_rejected(self):
        with self.assertRaises(RuntimeError): self.run_scenario('exit7')
        self.assertEqual(self.last['actual_exit_code'], 7)
        self.assertEqual(self.last['checked_calls'], 4)
    def test_ready_order_drift_refused(self):
        with self.assertRaises(ValueError): self.run_scenario('bad_ready')
        self.assertEqual(self.last['actual_exit_code'], 1)
        self.assertEqual(self.last['checked_calls'], 0)
    def test_result_rejection_stops_child(self):
        def reject(i, row): raise ValueError('wrong golden')
        with self.assertRaises(ValueError): self.run_scenario('normal', accept=reject)
        self.assertEqual(self.last['actual_exit_code'], 1)
        self.assertEqual(self.last['checked_calls'], 0)
    def test_stop_after_first_result_no_second_go(self):
        seen = []
        with self.assertRaises(ShortStop):
            self.run_scenario('normal', accept=lambda i, r: seen.append(i), stop=lambda: bool(seen))
        self.assertEqual(seen, [0])
        self.assertEqual(self.last['actual_exit_code'], 1)
        self.assertEqual(self.last['checked_calls'], 1)
    def test_unknown_group_retains_owner(self):
        with self.assertRaises(RuntimeError): self.run_scenario('normal', group=lambda pid: None)
        self.assertTrue(self.owner.held)
        self.assertEqual(self.last['actual_exit_code'], 0)
        self.assertIsNone(self.last['process_group_absent'])


if __name__ == '__main__': unittest.main(verbosity=2)
