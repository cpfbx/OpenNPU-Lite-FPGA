"""Sealed candidate byte checks and lazy dependency binding; CLI CHECK ONLY."""
import argparse
import hashlib
import importlib
import json
from pathlib import Path, PurePosixPath
import stat
import sys
from types import SimpleNamespace

IDENTITY = 'short_adapter_identity.json'
BASE = '35d4db623091dfc7a63459d07f04e4484dbbd999'
BIT_SHA = '47ae0a3640ef6d31db467118fd1822c04d465cd31171275fc04824824a20451c'
HWH_SHA = 'd727688adc43d526b853e158648023f230fab081dd84e2c8e86437c60d747294'
LIB_SHA = 'a1ee68685946287785a55e07fb60089441252676fc78ee1756a28c3f5de29c3b'
BANK_SHA = 'de295140ef9e059ca1a1959c1961a866e306fe1d83c598362657e90db33c3f77'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def unique_json(raw):
    def pairs(items):
        result = {}
        for k, v in items:
            if k in result:
                raise ValueError('duplicate JSON key')
            result[k] = v
        return result
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite JSON')))


def bounded(path, budget):
    if not stat.S_ISREG(path.lstat().st_mode) or path.is_symlink():
        raise ValueError('regular nonsymlink package/config member required')
    with path.open('rb') as f:
        raw = f.read(budget + 1)
    if len(raw) > budget:
        raise ValueError('package/config byte budget exceeded')
    return raw


def verify(root, expected_sha):
    root = Path(root).absolute()
    if root.resolve() != root or root.is_symlink() or type(expected_sha) is not str or len(expected_sha) != 64:
        raise ValueError('canonical sealed root/external identity SHA required')
    raw = bounded(root / IDENTITY, 1000000)
    if sha(raw) != expected_sha:
        raise ValueError('short candidate identity mismatch')
    identity = unique_json(raw)
    if (identity.get('schema') != 'matrix-real-short-adapter-unreleased-v1'
            or identity.get('source_base') != BASE or identity.get('board_run_authorized') is not False
            or identity.get('promotion') is not False or identity.get('total_calls') != 16
            or type(identity.get('total_calls')) is not int or type(identity.get('files')) is not dict):
        raise ValueError('unreleased short scope required')
    files = identity['files']
    must = {'adapter/binding_short.py', 'adapter/cpu_worker.py', 'adapter/short_owner.py',
            'adapter/short_call.py', 'adapter/short_session.py', 'adapter/os_evidence.py',
            'adapter/cpu_protocol.py', 'adapter/short_policy.py', 'model/control.py', 'model/fixtures.py',
            'model/csv_guard.py', 'bank/bank.json', 'cpu/blas_candidate.py', 'cpu/libmatrix_blas_arm.so',
            'baseline/python/pynq_gemm.py', 'baseline/python/kws_threeway_entry_support_draft.py',
            'baseline/python/pynq_dma_loopback.py', 'baseline/python/chain_protocol.py',
            'baseline/python/tiled_gemm.py', 'baseline/python/d007_mode11_contract.py',
            'baseline/scripts/matrix_panel_builder_candidate.py',
            'baseline/python/kws_device_recovery_candidate.py',
            'baseline/python/kws_device_supervision_candidate.py',
            'baseline/hardware/opennpu_gemm_accelerator.bit',
            'baseline/hardware/opennpu_gemm_accelerator.hwh'}
    must |= {'bank/input_%d_%s.bin' % (i, suffix) for i in (42, 43) for suffix in ('a', 'b', 'expected')}
    if not must <= set(files) or not 20 <= len(files) <= 100:
        raise ValueError('required bounded source/assets missing')
    actual = set()
    for p in root.rglob('*'):
        mode = p.lstat().st_mode
        if p.is_symlink() or not (stat.S_ISREG(mode) or stat.S_ISDIR(mode)):
            raise ValueError('plain sealed package tree required')
        if p.is_file():
            actual.add(p.relative_to(root).as_posix())
    if actual != set(files) | {IDENTITY}:
        raise ValueError('exact candidate member set required')
    total = 0
    for name, record in files.items():
        parts = PurePosixPath(name)
        if parts.is_absolute() or '..' in parts.parts or '\\' in name or ':' in name:
            raise ValueError('canonical package member path required')
        if (type(record) is not dict or set(record) != {'bytes', 'sha256'}
                or type(record['bytes']) is not int or not 0 <= record['bytes'] <= 16 * 1024 * 1024):
            raise ValueError('bounded exact member identity required')
        total += record['bytes']
        if total > 32 * 1024 * 1024:
            raise ValueError('candidate total byte budget exceeded')
        raw = bounded(root / name, record['bytes'])
        if len(raw) != record['bytes'] or sha(raw) != record['sha256']:
            raise ValueError('candidate member drift: ' + name)
    for name, digest in (('baseline/hardware/opennpu_gemm_accelerator.bit', BIT_SHA),
                         ('baseline/hardware/opennpu_gemm_accelerator.hwh', HWH_SHA),
                         ('cpu/libmatrix_blas_arm.so', LIB_SHA), ('bank/bank.json', BANK_SHA)):
        if files[name]['sha256'] != digest:
            raise ValueError('frozen asset identity mismatch')
    return identity


def paths(root):
    """Only after verify; fresh trusted worker, no system installations."""
    root = Path(root).resolve()
    sys.dont_write_bytecode = True
    wanted = [root / x for x in ('adapter', 'model', 'cpu', 'baseline/scripts', 'baseline/python')]
    sys.path[:0] = [str(x) for x in wanted]


def bound_import(root, name, relative):
    expected = Path(root) / relative
    if name in sys.modules and Path(sys.modules[name].__file__).resolve() != expected:
        raise RuntimeError('fresh worker required; cross-tree import: ' + name)
    module = importlib.import_module(name)
    if Path(module.__file__).resolve() != expected:
        raise RuntimeError('bound module source location drift: ' + name)
    return module


def load_device_dependencies(root, expected_sha):
    verify(root, expected_sha); paths(root)
    modules = {name: bound_import(root, name, 'baseline/python/' + name + '.py') for name in
               ('pynq_gemm', 'kws_threeway_entry_support_draft', 'kws_device_recovery_candidate',
                'kws_device_supervision_candidate')}
    return SimpleNamespace(runner_type=modules['pynq_gemm'].PynqGemm,
        lease_factory=modules['kws_threeway_entry_support_draft'].existing_shared_lock_draft,
        recovery_factory=modules['kws_device_recovery_candidate']._Recovery,
        supervise=modules['kws_device_supervision_candidate']._supervise)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('operation', choices=('check',))
    p.add_argument('--identity-sha', required=True)
    a = p.parse_args()
    verify(Path(__file__).resolve().parent.parent, a.identity_sha)
    print('CHECK ONLY: candidate source/assets exact; no library/device load or board run.')
