"""Explicit desktop CPU protocol stub, no matrix/NumPy/hardware operations."""
import json
import os
import platform
import sys


def emit(value):
    print(json.dumps(value), flush=True)


if __name__ == '__main__':
    if platform.machine().lower() not in ('amd64', 'x86_64'):
        raise SystemExit('desktop fixture only; never ARM')
    scenario = sys.argv[1]
    for i in range(4):
        emit(dict(kind='ready', index=i if scenario != 'bad_ready' else 9,
                  input_id=42 + i % 2, pid=os.getpid()))
        grant = json.loads(sys.stdin.readline())
        if grant.get('kind') == 'stop':
            raise SystemExit(1)
        emit(dict(kind='result', index=i, pid=os.getpid()))
        ack = json.loads(sys.stdin.readline())
        if ack.get('kind') == 'stop':
            raise SystemExit(1)
    emit(dict(kind='done', calls=4, pid=os.getpid()))
    raise SystemExit(7 if scenario == 'exit7' else 0)
