"""Offline serial control MODEL. No hardware imports, process launch or board CLI.

Receipts here are model inputs, not OS/lock attestation. The future real adapter
must derive them from sealed supervisor/owner and parent wait evidence.
"""
from dataclasses import dataclass
import hashlib
import json

CALL_BYTES = 512 * 512 * 4
INPUT_BYTES = 512 * 512
LOCK = '/tmp/opennpu-kws-chain.lock'
BACKENDS = ('openblas_2t', 'fpga_cached', 'fpga_cached', 'openblas_2t')
INPUT_IDS = (42, 43, 42, 43)


def contract():
    return dict(schema='matrix-short-envelope-offline-candidate-v1',
                shape_mnk=[512, 512, 512], order=list(BACKENDS),
                inputs_per_window=list(INPUT_IDS), calls=16, calls_per_backend=8,
                warmups=0, distinct_inputs=2, input_seeds=[20262019, 20262020],
                mode=11, layout='k_major', clock_hz=100000000,
                canonical_lock=LOCK, input_reuse_diagnostic=True,
                numerical_check='every output equals pinned previously audited INT32',
                scope='offline model only; no hardware binding or measurement acceptance',
                board_run_authorized=False, performance_gate_evaluated=False,
                formal_energy_input_accepted=False, promotion=False)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def sha_text(value):
    if type(value) is not str or len(value) != 64 or set(value) - set('0123456789abcdef'):
        raise ValueError('lowercase SHA256 required')
    return value


def positive_int(value):
    if type(value) is not int or value <= 0:
        raise ValueError('positive integer required')
    return value


@dataclass(frozen=True)
class Pair:
    input_id: int
    a: bytes
    b: bytes
    expected: bytes

    def validate(self):
        if type(self) is not Pair or type(self.input_id) is not int or self.input_id not in (42, 43):
            raise ValueError('exact fixed pair required')
        for raw, length in ((self.a, INPUT_BYTES), (self.b, INPUT_BYTES), (self.expected, CALL_BYTES)):
            if type(raw) is not bytes or len(raw) != length:
                raise ValueError('exact immutable little-endian payload required')


def validate_bank(bank):
    if type(bank) is not tuple or len(bank) != 2:
        raise ValueError('exact two-pair immutable bank required')
    for pair, wanted in zip(bank, (42, 43)):
        pair.validate()
        if pair.input_id != wanted:
            raise ValueError('fixed bank order required')
    if bank[0].a == bank[1].a and bank[0].b == bank[1].b:
        raise ValueError('two distinct operand pairs required')


class SerialModel:
    """Fail-closed offline transition checker; never owns real resources."""
    def __init__(self, bank, *, enabled=False):
        if enabled is not True:
            raise ValueError('offline model default-off')
        validate_bank(bank)
        self.bank = bank
        self.window = 0
        self.in_window = 0
        self.checked_calls = 0
        self.started_calls = 0
        self.active = False
        self.faulted = False
        self.finished = False
        self._start_ns = None
        self._last_end_ns = 0
        self._capture_id = None
        self._cpu_pids = set()
        self.events = []

    def _fail(self, message):
        self.faulted = True
        raise ValueError(message)

    def _available(self):
        if self.faulted or self.finished:
            self._fail('model faulted/finished; no retry or continuation')

    def begin(self, *, backend, capture_id, owner_lease_held, lock_path, stop_requested=False):
        self._available()
        if (self.active or self.window >= 4 or backend != BACKENDS[self.window]
                or owner_lease_held is not True or lock_path != LOCK
                or stop_requested is not False or type(capture_id) is not str
                or not capture_id or len(capture_id) > 128
                or any(ord(x) < 32 for x in capture_id)
                or any(e.get('capture_id') == capture_id for e in self.events)):
            self._fail('capture/order/lease/stop precondition refused')
        self._capture_id = capture_id
        self.active = True
        self.in_window = 0
        self._start_ns = None
        self.events.append(dict(event='model_window_begin', window=self.window,
                                backend=backend, capture_id=capture_id,
                                capture_start_authentication=False))

    def expected_pair(self):
        if not self.active or self.in_window >= 4:
            self._fail('no active scheduled call')
        return self.bank[self.in_window % 2]

    def accept(self, output, *, input_id, backend, begin_ns, end_ns, stop_requested=False):
        self._available()
        if not self.active or self.in_window >= 4 or stop_requested is not False:
            self._fail('inactive/exhausted/stopped call')
        pair = self.expected_pair()
        self.started_calls += 1
        # Keep the returned bytes on the exception so an adapter can preserve
        # a failed output without accepting it. Model retains no successful arrays.
        try:
            if (type(input_id) is not int or input_id != pair.input_id
                    or backend != BACKENDS[self.window]):
                raise ValueError('call identity drift')
            positive_int(begin_ns); positive_int(end_ns)
            if end_ns <= begin_ns or begin_ns < self._last_end_ns:
                raise ValueError('monotonic call sequence drift')
            if type(output) is not bytes or len(output) != CALL_BYTES or output != pair.expected:
                raise ValueError('output differs from pinned INT32 golden')
        except BaseException as error:
            self.faulted = True
            if type(output) is bytes and len(output) <= CALL_BYTES:
                error.returned_payload = output
            raise
        if self._start_ns is None:
            self._start_ns = begin_ns
        self._last_end_ns = end_ns
        self.in_window += 1
        self.checked_calls += 1
        self.events.append(dict(event='model_call_exact', window=self.window,
                                index=self.in_window - 1, input_id=input_id,
                                begin_ns=begin_ns, end_ns=end_ns,
                                output_sha256=digest(output), exact_int32_values=512 * 512))

    def end(self, *, completed_calls, actual_exit_code, process_group_absent,
            cpu_pid, owner_lease_held, capture_stopped, stop_requested=False):
        self._available()
        if (not self.active or type(completed_calls) is not int or completed_calls != 4
                or self.in_window != 4 or owner_lease_held is not True
                or capture_stopped is not True or stop_requested is not False):
            self._fail('window not complete/lease lost/capture open/stop pending')
        if BACKENDS[self.window] == 'openblas_2t':
            if (type(actual_exit_code) is not int or actual_exit_code != 0
                    or process_group_absent is not True
                    or type(cpu_pid) is not int or cpu_pid <= 1 or cpu_pid in self._cpu_pids):
                self._fail('fresh CPU exit/group boundary not satisfied')
            self._cpu_pids.add(cpu_pid)
        elif actual_exit_code is not None or process_group_absent is not None or cpu_pid is not None:
            self._fail('FPGA window cannot borrow CPU process evidence')
        self.events.append(dict(event='model_window_end', window=self.window,
                                completed_calls=completed_calls, cpu_pid=cpu_pid,
                                begin_ns=self._start_ns, end_ns=self._last_end_ns,
                                actual_process_or_lock_attestation=False))
        self.active = False
        self.window += 1

    def request_stop(self):
        self.faulted = True
        self.events.append(dict(event='model_stop_latched', no_next_call=True))

    def finish(self, *, cleanup):
        self._available()
        wanted = dict(held=False, safety_unresolved=False, lease_retained=False,
                      runner_retained=False, root_buffers_retained=0)
        # Equality alone would accept False == 0 and 0 == False.
        if (self.active or self.window != 4 or self.checked_calls != 16
                or type(cleanup) is not dict or set(cleanup) != set(wanted)
                or any(type(cleanup[k]) is not type(v) or cleanup[k] != v for k, v in wanted.items())):
            self._fail('model completion/cleanup not satisfied')
        self.finished = True
        return dict(scope='offline control model with supplied receipts only',
                    checked_calls=self.checked_calls, checked_int32_values=self.checked_calls * 512 * 512,
                    model_complete=True, real_cleanup_verified=False, board_access=False,
                    performance_gate_evaluated=False, formal_energy_input_accepted=False, promotion=False)


def encode(value):
    return (json.dumps(value, sort_keys=True, allow_nan=False, indent=2) + '\n').encode('utf-8')
