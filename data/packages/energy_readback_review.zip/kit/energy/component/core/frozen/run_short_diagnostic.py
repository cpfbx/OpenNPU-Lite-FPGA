#!/usr/bin/env python3
"""UNRELEASED board entry: one-seat 512^3 ABBA short diagnostic (16 calls).

The operator (bx) starts ONE UT70 save session on the PC, carries its capture
token here, runs this entry, and stops the save session afterwards. This entry
never drives the meter: it only proves the run carried the token and closes its
coverage request after the fourth window. No board authorization is implied.

Usage is documented in the review package, never executed automatically.
"""
import argparse
import json
import os
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'adapter'))


class DiagnosticError(RuntimeError):
    """Refused before the sealed adapter is entered."""


def unique_json(raw, limit=200000):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise DiagnosticError('duplicate JSON key')
            result[key] = value
        return result
    if len(raw) > limit:
        raise DiagnosticError('input byte budget exceeded')
    return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(
                          DiagnosticError('non-finite JSON')))


def write_new(path, value):
    raw = (json.dumps(value, sort_keys=True, allow_nan=False, indent=2) + '\n').encode('utf-8')
    with Path(path).open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


class TokenCapture:
    """Board-side coverage proxy for ONE continuous operator save envelope.

    begin() and end() are coverage acknowledgements, not meter observations: the
    meter is started/stopped by the operator on the PC, and the PC controller
    records the real bytes. This proxy deliberately reports saving_started and
    saving_stopped as null instead of pretending the board saw the meter.
    """

    def __init__(self, token):
        if (type(token) is not dict or set(token) != {'session_id', 'policy_sha256'}
                or type(token['session_id']) is not str
                or re.fullmatch(r'[0-9a-f]{32}', token['session_id']) is None
                or type(token['policy_sha256']) is not str
                or re.fullmatch(r'[0-9a-f]{64}', token['policy_sha256']) is None):
            raise DiagnosticError('explicit PC capture token required')
        self.token = dict(token)
        self.armed = False
        self.closed = False

    def begin(self, window, *, policy_sha256):
        if self.armed or self.closed:
            raise DiagnosticError('single envelope already opened/closed')
        if window != 0:
            raise DiagnosticError('single envelope opens at window 0 only')
        if policy_sha256 != self.token['policy_sha256']:
            raise DiagnosticError('capture token policy differs from the sealed experiment')
        self.armed = True
        return dict(coverage_armed=True, saving_started=None,
                    capture_id=self.token['session_id'],
                    policy_sha256=policy_sha256, scope='single_envelope',
                    window=0, meter_control='operator; not board-driven',
                    board_observed_meter_state=False)

    def end(self, window):
        if not self.armed or self.closed:
            raise DiagnosticError('no open coverage request to close')
        if window != 3:
            raise DiagnosticError('single envelope closes at window 3 only')
        self.armed = False
        self.closed = True
        return dict(coverage_closed=True, saving_stopped=None,
                    capture_id=self.token['session_id'],
                    policy_sha256=self.token['policy_sha256'], scope='single_envelope',
                    window=3, meter_control='operator; not board-driven',
                    board_observed_meter_state=False)


def run(args):
    from binding_short import verify, paths, bounded, sha
    verify(ROOT, args.package_sha)
    paths(ROOT)
    from short_session import encode, run_internal, validate_experiment
    experiment = validate_experiment(unique_json(bounded(args.experiment, 20000)))
    token = unique_json(bounded(args.capture_token, 2000))
    policy_sha256 = sha(encode(experiment))
    if token.get('policy_sha256') != policy_sha256:
        raise DiagnosticError('capture token policy SHA differs from the experiment')
    token_out = Path(args.worker_token_out).absolute()
    if (token_out.resolve() != token_out or not token_out.parent.is_dir()
            or token_out.exists()):
        raise DiagnosticError('fresh canonical worker-token file in an existing directory required')
    write_new(token_out, dict(session_id=token['session_id'], policy_sha256=policy_sha256,
                              package_sha256=args.package_sha, pid=os.getpid()))
    os.environ['BOARD_SERIAL'] = args.board_serial
    os.environ['PYNQ_IMAGE'] = args.pynq_image
    record = run_internal(ROOT, args.package_sha, Path(args.evidence), capture=TokenCapture(token),
                          experiment=experiment, capture_scope='single_envelope', enabled=True)
    print(json.dumps(dict(session_id=token['session_id'], checked_calls=record.get('checked_calls'),
                          cleanup_complete=record.get('cleanup_complete'),
                          capture_scope=record.get('capture_scope'),
                          operation_success=record.get('operation_success'),
                          board_run_authorized=False, promotion=False)))
    return 0


def build_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package-sha', required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--worker-token-out', type=Path, required=True)
    parser.add_argument('--experiment', type=Path, required=True)
    parser.add_argument('--capture-token', type=Path, required=True)
    parser.add_argument('--board-serial', required=True)
    parser.add_argument('--pynq-image', required=True)
    return parser


if __name__ == '__main__':
    # argparse owns --help (0) and usage errors (2); never mask them as 1.
    arguments = build_parser().parse_args()
    try:
        code = run(arguments)
    except Exception as error:
        print('SHORT DIAGNOSTIC REFUSED/FAILED: %s: %s' % (type(error).__name__, error),
              file=sys.stderr)
        code = 1
    raise SystemExit(code)
