"""Sealed offline binding; no board RUN or hardware constructor."""
import importlib
from pathlib import Path
import sys
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent


def check(manifest_sha):
    from verify_kit import verify
    return verify(ROOT, manifest_sha)


def load_components(manifest_sha, *, enabled=False):
    if enabled is not True:
        raise ValueError('new long-batch component binding default-off')
    if any(n == 'pynq' or n.startswith('pynq.') for n in sys.modules):
        raise ValueError('offline cold process required')
    check(manifest_sha)
    paths = [ROOT/'core/src', ROOT/'core/frozen/adapter', ROOT/'core/frozen/model',
             ROOT/'core/frozen/cpu', ROOT/'core/frozen/baseline/python',
             ROOT/'core/frozen/baseline/scripts', ROOT/'extension']
    expected = {p.stem:p for folder in paths for p in folder.glob('*.py')}
    expected['offline_binding'] = ROOT/'offline_binding.py'
    for name, path in expected.items():
        if name in sys.modules and Path(getattr(sys.modules[name], '__file__', '')).resolve() != path.resolve():
            raise ValueError('cross-candidate module collision: ' + name)
    for folder in reversed(paths):
        if str(folder) not in sys.path:
            sys.path.insert(0, str(folder))
    binding = importlib.import_module('batch_binding')
    registry = importlib.import_module('batch_path_selection')
    policy = importlib.import_module('batch_policy')
    # Bind the validated panel module while still cold. Loading it lazily after
    # a future runner constructor imports PYNQ would violate its own cold gate.
    importlib.import_module('panel_contiguous_candidate')
    return SimpleNamespace(selector=registry, policy=policy, bank=binding.load_bank(ROOT/'core'))
