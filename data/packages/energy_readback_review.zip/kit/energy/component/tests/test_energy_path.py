"""Real Python packing/owner/call over synthetic MMIO, DMA and lease only."""
import argparse
import ast
from dataclasses import replace, FrozenInstanceError
import hashlib
import inspect
import json
from pathlib import Path
import sys
import tempfile
import textwrap
import unittest
from unittest.mock import patch

parser=argparse.ArgumentParser(add_help=False)
parser.add_argument('--manifest-sha',required=True)
options,remaining=parser.parse_known_args()
sys.argv=[sys.argv[0],*remaining]
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
import offline_binding
BOUND=offline_binding.load_components(options.manifest_sha,enabled=True)
import numpy as np
import batch_owner
import batch_session
from batch_call import BatchCall
from batch_core import Ledger
from batch_policy import BatchPolicy, BatchStop
from batch_path_selection import select,bind_call,verify_path_rows
from contiguous_batch_call import ContiguousBatchCall
import panel_contiguous_candidate as panel
from matrix_panel_builder_candidate import build_panel_layout_cached_transactions as old_builder
from tiled_gemm import TileConfig,Layout
from chain_protocol import pack_chain
from flat_driver_candidate import FlatPackPynqGemm
import pynq_gemm
sys.path.insert(0,str(ROOT/'tests'))
import offline_fixture as fixture


class Harness:
    def __init__(self,profile='smoke8'):
        self.policy=BatchPolicy(profile,True)
        self.selection=select(self.policy,'flat_contiguous',enabled=True)
        self.stop=False
        pair=BOUND.bank[0]
        a,b=self.arrays(pair)
        jobs=list(old_builder(a,b,TileConfig(layout=Layout.K_MAJOR),enabled=True).transactions)
        payload=fixture.tiled_output(jobs,np.frombuffer(pair.expected,'<i4').reshape(512,512))
        old,tx,rx,self.events=fixture.fixture(jobs,payload)
        self.runner=self.selection.runner_type.__new__(self.selection.runner_type)
        self.runner.__dict__.update(old.__dict__)
        self.owner=fixture.owner_fixture(self.runner,tx,rx,self.events,lambda:self.stop)
        self.owner.policy=self.policy
        self.call=bind_call(self.owner,self.policy,self.selection,enabled=True)
        self.jobs=jobs

    @staticmethod
    def arrays(pair):
        return [np.frombuffer(raw,np.int8).reshape(512,512).copy() for raw in (pair.a,pair.b)]

    def invoke(self,input_id=42):
        pair=BOUND.bank[input_id-42]
        self.runner.mmio.payload=fixture.tiled_output(self.jobs,np.frombuffer(pair.expected,'<i4').reshape(512,512))
        return self.call(*self.arrays(pair))

    def discard(self):
        if self.owner._closed:
            return
        if not self.owner._held and not self.owner._unsafe and not self.owner._lease.fault:
            self.owner.close()
        if self.owner in batch_owner._RETAINED:
            batch_owner._RETAINED.remove(self.owner)  # synthetic resources only


class BindingTests(unittest.TestCase):
    def test_binding_default_off(self):
        with self.assertRaises(ValueError):offline_binding.load_components(options.manifest_sha)
    def test_wrong_identity(self):
        with self.assertRaises(ValueError):offline_binding.check('0'*64)
    def test_cold_binding_rejects_pynq(self):
        from types import ModuleType
        with patch.dict(sys.modules,{'pynq':ModuleType('pynq')}),self.assertRaisesRegex(ValueError,'cold'):
            offline_binding.load_components(options.manifest_sha,enabled=True)
    def test_selector_default_off(self):
        with self.assertRaises(ValueError):select(BatchPolicy('smoke8',True),'flat_contiguous')
    def test_selector_truthy_rejected(self):
        with self.assertRaises(ValueError):select(BatchPolicy('smoke8',True),'flat_contiguous',enabled=1)
    def test_implicit_old_or_unknown_rejected(self):
        for x in (None,True,'old','flat','auto','fpga_cached'):
            with self.subTest(x=x),self.assertRaises(ValueError):select(BatchPolicy('smoke8',True),x,enabled=True)
    def test_wrong_policy_type(self):
        from types import SimpleNamespace
        with self.assertRaises(ValueError):select(SimpleNamespace(profile='abba1808',enabled=True),'flat_contiguous',enabled=True)
    def test_selection_immutable(self):
        s=select(BatchPolicy('smoke8',True),'flat_contiguous',enabled=True)
        with self.assertRaises(FrozenInstanceError):s.host_path='old'
    def test_guard_inherited(self):
        self.assertIs(ContiguousBatchCall.__call__,BatchCall.__call__)
        self.assertIs(ContiguousBatchCall.__init__,BatchCall.__init__)
    def test_dma_submit_inherited(self):
        s=select(BatchPolicy('abba1808',True),'flat_contiguous',enabled=True)
        self.assertIs(s.runner_type._submit_chain,pynq_gemm.PynqGemm._submit_chain)
    def test_call_ast_only_builder_and_marker(self):
        old=ast.parse(textwrap.dedent(inspect.getsource(BatchCall._call)))
        new=ast.parse(textwrap.dedent(inspect.getsource(ContiguousBatchCall._call)))
        class Normalize(ast.NodeTransformer):
            def visit_ImportFrom(self,node):
                if node.module=='panel_contiguous_candidate':node.module='matrix_panel_builder_candidate'
                return node
            def visit_Assign(self,node):
                if (len(node.targets)==1 and isinstance(node.targets[0],ast.Subscript)
                    and ast.unparse(node.targets[0])=="metrics['host_path_candidate']"):
                    if not isinstance(node.value,ast.Constant) or node.value.value!='flat_contiguous':raise AssertionError('wrong marker')
                    return None
                return node
        self.assertEqual(ast.dump(old),ast.dump(Normalize().visit(new)))
    def test_full_plan_still_1824(self):
        p=BatchPolicy('abba1808',True)
        self.assertEqual((p.measured,p.warmup,p.per_window,p.pl_calls),(452,4,456,912))
    def test_frozen_core_unmodified(self):
        lineage=json.loads((ROOT/'lineage.json').read_bytes())
        for name,spec in lineage['original_core_files'].items():
            raw=(ROOT/name).read_bytes()
            self.assertEqual((len(raw),hashlib.sha256(raw).hexdigest()),(spec['bytes'],spec['sha256']))


class Calls(unittest.TestCase):
    def harness(self,profile='smoke8'):
        h=Harness(profile);self.addCleanup(h.discard);return h
    def test_both_banks_wire_equal(self):
        for pair in BOUND.bank:
            a,b=Harness.arrays(pair)
            old=old_builder(a,b,TileConfig(layout=Layout.K_MAJOR),enabled=True)
            new=panel.build_panel_layout_cached_transactions(a,b,TileConfig(layout=Layout.K_MAJOR),enabled=True)
            self.assertEqual(old,new)
            self.assertEqual(pack_chain(list(old.transactions),57537),pack_chain(list(new.transactions),57537))
    def test_six_real_calls_exact_and_one_dma_per_channel(self):
        h=self.harness()
        for i in range(6):
            output,metrics=h.invoke(42+i%2)
            self.assertEqual(output.astype('<i4').tobytes(),BOUND.bank[i%2].expected)
            self.assertEqual(metrics['batch_pl_index'],i)
            self.assertEqual(metrics['host_path_candidate'],'flat_contiguous')
        self.assertEqual((h.call._index,h.owner._index),(6,6))
        self.assertEqual(len([x for x in h.events if x[:2]==('transfer','send')]),6)
        self.assertEqual(len([x for x in h.events if x[:2]==('transfer','recv')]),6)
    def test_last_long_request_911_not_72_policy(self):
        h=self.harness('abba1808');h.call._index=h.owner._index=911
        out,m=h.invoke(43)
        self.assertEqual(out.astype('<i4').tobytes(),BOUND.bank[1].expected)
        self.assertEqual(m['first_job_id'],58305)
        self.assertEqual((h.call._index,h.owner._index),(912,912))
        with self.assertRaises(ValueError):h.invoke(42)
    def test_wrong_runner_composition(self):
        h=self.harness()
        bad=replace(h.selection,runner_type=pynq_gemm.PynqGemm)
        with self.assertRaises(ValueError):bind_call(h.owner,h.policy,bad,enabled=True)
    def test_nonclass_runner_rejected(self):
        h=self.harness()
        with self.assertRaises(ValueError):bind_call(h.owner,h.policy,replace(h.selection,runner_type=None),enabled=True)
    def test_panel_bound_before_future_hardware_import(self):
        from types import ModuleType
        self.assertIs(sys.modules['panel_contiguous_candidate'],panel)
        h=self.harness()
        with patch.dict(sys.modules,{'pynq':ModuleType('pynq')}):
            output,_=h.invoke()
        self.assertEqual(output.astype('<i4').tobytes(),BOUND.bank[0].expected)
    def test_marker_cannot_substitute_call_type(self):
        h=self.harness()
        bad=replace(h.selection,call_type=BatchCall)
        with self.assertRaises(ValueError):bind_call(h.owner,h.policy,bad,enabled=True)
    def test_policy_object_mismatch(self):
        h=self.harness()
        with self.assertRaises(ValueError):bind_call(h.owner,BatchPolicy('smoke8',True),h.selection,enabled=True)
    def test_stop_before_construction(self):
        h=self.harness();h.stop=True
        with patch.object(panel,'build_panel_layout_cached_transactions') as build:
            with self.assertRaises(BatchStop):h.invoke()
            build.assert_not_called()
        self.assertFalse(any(x[0]=='transfer' for x in h.events))
    def test_stop_during_build_no_dma(self):
        h=self.harness();real=panel.build_panel_layout_cached_transactions
        def stopped(*args,**kwargs):
            result=real(*args,**kwargs);h.stop=True;return result
        with patch.object(panel,'build_panel_layout_cached_transactions',side_effect=stopped):
            with self.assertRaises(BatchStop):h.invoke()
        self.assertFalse(any(x[0]=='transfer' for x in h.events))
    def test_lost_lease_no_dma(self):
        h=self.harness();h.owner._lease.fault=True
        with self.assertRaises(RuntimeError):h.invoke()
        self.assertFalse(any(x[0]=='transfer' for x in h.events))
    def corrupt(self,change,pattern):
        h=self.harness();real=h.owner.execute_chain
        def changed(*args,**kwargs):return change(real(*args,**kwargs))
        with patch.object(h.owner,'execute_chain',side_effect=changed):
            with self.assertRaisesRegex(ValueError,pattern) as caught:h.invoke()
        self.assertEqual(len(caught.exception.matrix_returned_payload),1048576)
        self.assertTrue(h.call._failed)
        with self.assertRaisesRegex(RuntimeError,'no retry'):h.invoke()
    def test_record_reconstruction_failure(self):
        def bad(x):
            payload,records,metrics=x;records=list(records)
            records[0]=replace(records[0],header_bytes=b'\0'*64)
            return payload,records,metrics
        self.corrupt(bad,'records differ')
    def test_work_counter_failure(self):
        def bad(x):x[2]['effective_macs']+=1;return x
        self.corrupt(bad,'counter mismatch')
    def test_bool_counter_failure(self):
        def bad(x):x[2]['jobs']=True;return x
        self.corrupt(bad,'counter mismatch')
    def test_conservation_failure(self):
        def bad(x):x[2]['pl_total_cycles']+=1;return x
        self.corrupt(bad,'conservation')
    def test_nan_inner_time(self):
        def bad(x):x[2]['seconds']=float('nan');return x
        self.corrupt(bad,'positive inner')
    def test_first_wrong_output_retained(self):
        h=self.harness();pair=BOUND.bank[0]
        h.runner.mmio.payload=bytes([h.runner.mmio.payload[0]^1])+h.runner.mmio.payload[1:]
        output,m=h.call(*Harness.arrays(pair))
        l=Ledger(h.policy,BOUND.bank);l.begin(0,'openblas_2t');l.start(0,stop_requested=False)
        with self.assertRaises(ValueError):l.complete(0,output.astype('<i4').tobytes(),begin_ns=1,end_ns=2,process_cpu_ns=1,metrics=m,stop_requested=False)
        self.assertEqual(l.failure,output.astype('<i4').tobytes());self.assertEqual(l.accepted,0)
    def test_current_completes_stop_not_accepted(self):
        h=self.harness();real=h.runner.run_chain
        def stopped(*args,**kwargs):
            result=real(*args,**kwargs);h.stop=True;return result
        with patch.object(h.runner,'run_chain',side_effect=stopped):out,m=h.invoke()
        l=Ledger(h.policy,BOUND.bank);l.begin(0,'openblas_2t');l.start(0,stop_requested=False)
        with self.assertRaises(BatchStop):l.complete(0,out.astype('<i4').tobytes(),begin_ns=1,end_ns=2,process_cpu_ns=1,metrics=m,stop_requested=True)
        self.assertEqual((l.completed,l.exact_checked,l.accepted),(1,1,0))
        with self.assertRaises(BatchStop):h.invoke(43)
    def test_cleanup_idempotent_after_close(self):
        h=self.harness();h.owner.close();h.discard()
        self.assertTrue(h.owner._closed)
    def test_zero_cpu_increment_not_relaxed(self):
        from batch_policy import exact_int
        with self.assertRaises(ValueError):exact_int(0,1)
    def test_full_smoke_scheduler_new_call(self):
        h=self.harness()
        class Capture:
            ack_timeout_s=240
            def __init__(self):self.active=None;self.windows=[]
            def begin(self,w,config_sha256):
                self.active=(w,config_sha256);self.windows.append(w)
                return dict(window=w,config_sha256=config_sha256,capture_id='FAKE-'+str(w),saving_started=True)
            def end(self,w):
                old,sha=self.active;self.active=None
                return dict(window=w,config_sha256=sha,capture_id='FAKE-'+str(old),saving_stopped=True)
        def cpu(command,folder,owner,stopped,p,start,accept,begin,end):
            for i in range(p.per_window):
                if i==p.warmup:begin()
                start(i);accept(i,dict(begin_ns=1,end_ns=2,process_cpu_ns=1),BOUND.bank[i%2].expected)
            end()
            return dict(actual_exit_code=0,process_group_absent=True,source='SYNTHETIC ONLY: no CPU subprocess launched')
        with tempfile.TemporaryDirectory(prefix='candidate_energy_smoke_') as d:
            path=Path(d)
            clock=iter(range(0,1000000,1000))
            # Deterministic SYNTHETIC clock for this scheduler fixture only;
            # do not relax original positive CPU timing or claim performance.
            with patch.object(batch_session.time,'process_time_ns',side_effect=lambda:next(clock)):
                result=batch_session.execute(ROOT/'core','0'*64,path,h.policy,BOUND.bank,h.owner,
                    h.invoke,Capture(),lambda:h.stop,cpu_window=cpu)
            rows=json.loads((path/'outputs/calls.json').read_bytes())
            self.assertTrue(result['operation_success'])
            self.assertEqual(result['accepted'],16)
            self.assertTrue(verify_path_rows(rows,h.policy)['host_path_binding_verified'])
            self.assertEqual(len(list((path/'outputs').glob('window_*.bin'))),8)
            self.assertTrue(h.owner._closed)


class PathRows(unittest.TestCase):
    def rows(self,profile='abba1808'):
        p=BatchPolicy(profile,True);rows=[];pl=0
        for w in range(4):
            for i in range(p.per_window):
                metrics={} if w in (0,3) else dict(host_path_candidate='flat_contiguous',batch_pl_index=pl)
                if w in (1,2):pl+=1
                rows.append(dict(window=w,index=i,input_id=42+i%2,
                    backend='openblas_2t' if w in (0,3) else 'fpga_cached',metrics=metrics))
        return rows,p
    def test_1824_metadata_full(self):
        rows,p=self.rows();proof=verify_path_rows(rows,p)
        self.assertEqual(proof['pl_rows'],912)
        self.assertFalse(proof['numeric_checked_by_this_function'])
    def test_no_missing_rows(self):
        rows,p=self.rows()
        with self.assertRaises(ValueError):verify_path_rows(rows[:-1],p)
    def test_old_rows_not_promoted_by_name(self):
        rows,p=self.rows();rows[p.per_window]['metrics'].pop('host_path_candidate')
        with self.assertRaises(ValueError):verify_path_rows(rows,p)
    def test_wrong_path_marker(self):
        rows,p=self.rows();rows[p.per_window]['metrics']['host_path_candidate']='flat'
        with self.assertRaises(ValueError):verify_path_rows(rows,p)
    def test_bad_pl_sequence(self):
        rows,p=self.rows();rows[p.per_window]['metrics']['batch_pl_index']=True
        with self.assertRaises(ValueError):verify_path_rows(rows,p)
    def test_cpu_cannot_claim_fpga_metrics(self):
        rows,p=self.rows();rows[0]['metrics']={'host_path_candidate':'flat_contiguous'}
        with self.assertRaises(ValueError):verify_path_rows(rows,p)
    def test_new_label_not_silently_replacing_transport(self):
        rows,p=self.rows();rows[p.per_window]['backend']='fpga_flat_contiguous'
        with self.assertRaises(ValueError):verify_path_rows(rows,p)
    def test_bad_input_sequence(self):
        rows,p=self.rows();rows[1]['input_id']=42
        with self.assertRaises(ValueError):verify_path_rows(rows,p)


if __name__=='__main__':unittest.main(verbosity=2)
