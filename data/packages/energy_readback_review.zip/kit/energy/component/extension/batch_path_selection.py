"""Explicit composed components; no runner construction, CLI or board permit."""
from dataclasses import dataclass
from batch_policy import validate_policy
from contiguous_batch_call import ContiguousBatchCall
from flat_driver_candidate import flat_runner_type, FlatPackPynqGemm


@dataclass(frozen=True)
class Selection:
    host_path: str
    transport_backend: str
    effective_backend: str
    call_type: type
    runner_type: type


def select(policy, host_path, *, enabled=False):
    if enabled is not True:
        raise ValueError('new energy host selector default-off')
    validate_policy(policy)
    if type(host_path) is not str or host_path != 'flat_contiguous':
        raise ValueError('exact explicit flat_contiguous path required; no fallback')
    return Selection(host_path, 'fpga_cached', 'fpga_flat_contiguous',
                     ContiguousBatchCall, flat_runner_type(enabled=True))


def bind_call(owner, policy, selection, *, enabled=False):
    if enabled is not True or type(selection) is not Selection:
        raise ValueError('explicit selected long-batch binding required')
    from batch_owner import BatchOwner
    import pynq_gemm
    validate_policy(policy)
    if (type(owner) is not BatchOwner or owner.policy is not policy
            or selection.host_path != 'flat_contiguous'
            or selection.transport_backend != 'fpga_cached'
            or selection.effective_backend != 'fpga_flat_contiguous'
            or selection.call_type is not ContiguousBatchCall
            or not isinstance(selection.runner_type, type)
            or not issubclass(selection.runner_type, FlatPackPynqGemm)
            or selection.runner_type.run_chain is not FlatPackPynqGemm.run_chain
            or selection.runner_type._submit_chain is not pynq_gemm.PynqGemm._submit_chain
            or type(owner._runner) is not selection.runner_type
            or getattr(owner._runner, '_flat_pack_enabled', None) is not True):
        raise ValueError('owner/policy/call/runner composition mismatch')
    owner.pre_submit()
    return selection.call_type(owner, policy, enabled=True)


def verify_path_rows(rows, policy):
    """Only metadata path accounting, not output/numeric/OS/energy acceptance."""
    validate_policy(policy)
    if type(rows) is not list or len(rows) != 4*policy.per_window:
        raise ValueError('all fixed-plan rows required')
    pl_index = 0
    for absolute, row in enumerate(rows):
        window, index = divmod(absolute, policy.per_window)
        expected_backend = ('openblas_2t', 'fpga_cached', 'fpga_cached', 'openblas_2t')[window]
        if (type(row) is not dict or type(row.get('window')) is not int or row['window'] != window
                or type(row.get('index')) is not int or row['index'] != index
                or type(row.get('input_id')) is not int or row['input_id'] != 42+index%2
                or row.get('backend') != expected_backend or type(row.get('metrics')) is not dict):
            raise ValueError('row plan or transport backend mismatch')
        metrics = row['metrics']
        if window in (1, 2):
            if (metrics.get('host_path_candidate') != 'flat_contiguous'
                    or type(metrics.get('batch_pl_index')) is not int
                    or metrics['batch_pl_index'] != pl_index):
                raise ValueError('new candidate marker or PL sequence missing')
            pl_index += 1
        elif metrics:
            raise ValueError('CPU must not claim FPGA path metrics')
    return dict(host_path_binding_verified=True, pl_rows=pl_index,
                transport_backend='fpga_cached', effective_backend='fpga_flat_contiguous',
                scope='metadata path binding only', numeric_checked_by_this_function=False,
                energy_evaluated=False, board_access=False, promotion=False)
