"""Pinned builder imports in the copied long-batch tree; no hardware access."""
import hashlib
import importlib
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
EXPECTED = {
    'tiled_gemm': ('core/frozen/baseline/python/tiled_gemm.py', 'd2355e421f7befeb5852e3c80cffbfd19f838ec4922711fee8ebedc98b3f2482'),
    'chain_protocol': ('core/frozen/baseline/python/chain_protocol.py', '60236cd1251014ffcafc30257acef6b50a181b08443b715315d78312450630bf'),
    'matrix_panel_builder_candidate': ('core/frozen/baseline/scripts/matrix_panel_builder_candidate.py', '8d7b8353bcc208f407dfe7b2f67b84abaae22b3b6a79ae669fac3eb8ac681363'),
}


def load():
    if any(n == 'pynq' or n.startswith('pynq.') for n in sys.modules):
        raise ValueError('offline cold process required')
    for name, (relative, digest) in EXPECTED.items():
        path = ROOT/relative
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError('frozen builder source drift: ' + name)
        current = sys.modules.get(name)
        if current is not None and Path(getattr(current, '__file__', '')).resolve() != path.resolve():
            raise ValueError('builder module collision: ' + name)
        if str(path.parent) not in sys.path:
            sys.path.insert(0, str(path.parent))
    return tuple(importlib.import_module(n) for n in EXPECTED)
