# 最终候选能量：长批次调用层离线接线

2026-10-23，内部候选。没有RUN、激活settings、UT70操作或ARM实跑入口。本包不批准上板，不能因PC夹具通过就直接运行旧能量脚本。

`core/`是原长批次54文件的原字节副本。新ContiguousBatchCall继承原BatchCall入口防护，仅改_call的连续面板builder导入和host_path_candidate标记；原BatchPolicy仍支持smoke8/abba1808，原BatchOwner及DMA/CPU/停止/资源释放主体不改。flat runner/pack及连续面板helper为已审原字节，原Compare策略未接入。

`offline_binding.py`只读绑定本树，拒绝跨候选模块/PYNQ已加载；`batch_path_selection.py`显式绑定新Call及flat runner，不能用旧Call配新标签。历史transport_backend保留fpga_cached，**有效后端是fpga_flat_contiguous**，新外层必须同时绑定包身份/选择与每条记录marker，不能仅靠旧backend字段汇总新结果。

外部清单SHA见包外candidate_identity.json/审阅交付说明，不在包内自算替代锚。普通电脑Python3.10+；新调用测试需要已有NumPy，不安装依赖。

```text
python -I -B verify_kit.py --manifest-sha <EXTERNAL_MANIFEST_SHA>
python -I -B tests/test_energy_path.py --manifest-sha <EXTERNAL_MANIFEST_SHA>
```

测试中MMIO/DMA/锁/恢复为明确模拟，固定银行预填输出不执行RTL。完整smoke调度测试CPU窗口也模拟，不能当真实进程组/wait证明。1824元数据检查不是1824次矩阵执行；原77core回归中已有真实本地进程协议测试，仍非ARM/BLAS实测。

contract_candidate.md是待批准范围建议，不是最终参数批准。下一步仍需连接真实batch会话外层/PC保存与新身份、保留退出/原锁观察、复算器拒绝旧路径、新封装和独立审查，最后由bx批准精确包操作。默认、硬件、oracle和旧包不变。所有焦耳和ARM性能本轮均未测。
