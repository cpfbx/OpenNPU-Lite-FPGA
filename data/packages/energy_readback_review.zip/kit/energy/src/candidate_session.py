"""Private new-path session; frozen execute/CPU wait/capture/cleanup unchanged."""
import os
from pathlib import Path
import sys

COMPONENT_SHA = '23de58493983c2f0871c88fbdf2fdec3fb5667edff19b3b9a6b7b44ab1ce1215'
CORE_SHA = '57ffe40bedcacead2953e38131a1c64ea62a54b05db517621eea7ec287197db3'


def context(profile):
    return dict(component_manifest_sha256=COMPONENT_SHA, core_identity_sha256=CORE_SHA,
                host_path='flat_contiguous', transport_backend='fpga_cached',
                effective_backend='fpga_flat_contiguous', profile=profile,
                scope='explicit selected runtime path; not energy or promotion', promotion=False)


def run_internal(component, expected_sha, evidence, *, profile, capture, enabled=False):
    if enabled is not True:
        raise ValueError('private candidate session default-off')
    component = Path(component).absolute()
    if expected_sha != COMPONENT_SHA:
        raise ValueError('exact reviewed component required')
    import offline_binding
    if Path(offline_binding.__file__).resolve() != component/'offline_binding.py':
        raise ValueError('cross-component session binding')
    # Preserve the reviewed cold preloading gate BEFORE hardware imports/start.
    selected = offline_binding.load_components(expected_sha, enabled=True)
    from batch_binding import arm_only, verify, configure, load_dependencies
    arm_only()
    root = component/'core'
    verify(root, CORE_SHA)
    configure(root)
    evidence = Path(evidence).absolute()
    assembly = component.parent
    if (evidence.resolve() != evidence or evidence.exists() or evidence == assembly
            or assembly in evidence.parents or evidence in assembly.parents):
        raise ValueError('fresh canonical evidence outside component required')
    from capture_bridge import CaptureBridge
    if (type(capture) is not CaptureBridge or assembly == capture.directory
            or assembly in capture.directory.parents or capture.directory in assembly.parents
            or os.environ.get('BOARD_SERIAL') != 'ftdi-1234-tulB'
            or os.environ.get('PYNQ_IMAGE') != 'pynq-z2-v3.1.1'):
        raise ValueError('original capture bridge and explicit board declarations required')
    policy = selected.policy.BatchPolicy(profile, enabled=True)
    selection = selected.selector.select(policy, 'flat_contiguous', enabled=True)
    bank = selected.bank
    deps = load_dependencies(root)
    import numpy as np
    prepared = {}
    for pair in bank:
        values = [np.frombuffer(raw, np.int8).reshape(512, 512).copy() for raw in (pair.a, pair.b)]
        for value in values:
            value.setflags(write=False)
        prepared[pair.input_id] = tuple(values)
    from batch_owner import BatchOwner
    from batch_session import execute, stopping
    from batch_core import write_new
    outer_record = {}
    requested = []
    owner = BatchOwner(policy, lambda: bool(requested), enabled=True)
    capture.stopped = lambda: bool(requested)
    evidence.mkdir()
    runtime = evidence/'runtime'
    runtime.mkdir()
    write_new(evidence/'candidate_path.json', context(profile))

    def operation():
        nonlocal requested
        previous = Path.cwd()
        result = None
        primary = None
        try:
            with stopping(outer_record) as pending:
                requested = pending
                try:
                    os.chdir(runtime)
                    owner.start(selection.runner_type,
                                root/'frozen/baseline/hardware/opennpu_gemm_accelerator.bit',
                                deps.lease_factory, deps.recovery_factory)
                    raw_call = selected.selector.bind_call(owner, policy, selection, enabled=True)
                    result = execute(root, CORE_SHA, evidence, policy, bank, owner,
                                     lambda input_id: raw_call(*prepared[input_id]), capture,
                                     lambda: bool(pending))
                except BaseException as error:
                    primary = error
                    # Same ownership split as frozen run_internal: execute owns
                    # normal/error cleanup; failures before execute need close.
                    if not (evidence/'lifecycle.json').exists():
                        try:
                            owner.close()
                        except BaseException as cleanup_error:
                            outer_record['start_cleanup_error_type'] = type(cleanup_error).__name__
        finally:
            os.chdir(previous)
            outer_record.update(operation_success=primary is None
                                and not outer_record.get('handler_restore_errors') and not requested,
                                source='worker lifecycle, NOT actual worker process exit', promotion=False)
            try:
                write_new(evidence/'worker_completion.json', outer_record)
            except BaseException as error:
                if primary is None:
                    primary = error
        if primary is not None:
            raise primary
        if not outer_record['operation_success']:
            raise RuntimeError('stop/signal restoration unresolved; no success')
        return result

    result = deps.supervise(owner, operation,
                            lambda attention: write_new(evidence/'attention.json', attention), enabled=True)
    offline_binding.check(expected_sha)
    return result


if __name__ == '__main__':
    raise SystemExit('PRIVATE session only; no public board RUN or approval.')
