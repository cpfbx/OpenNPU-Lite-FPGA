"""Private offline audit of new candidate records and FOUR whole original CSVs."""
import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT/'src'))
sys.path.insert(1, str(ROOT/'legacy/candidate/src'))
from runtime_binding import verify, configure_core, module
from integration_common import read, decode, sha, encode, config, expected_capture_sha, CALLS_BYTE_LIMIT, new_json


def audit(root, identity, board, pc, settings_path, settings_sha, output):
    root, board, pc, output = [Path(p).absolute() for p in (root, board, pc, output)]
    verify(root, identity)
    configure_core(root)
    for p in (root, board, pc):
        if p.resolve() != p or not p.is_dir():
            raise ValueError('canonical input trees required')
        if output == p or p in output.parents or output in p.parents:
            raise ValueError('output must be outside all input trees')
    if output.resolve() != output or output.exists():
        raise ValueError('fresh canonical output required')
    output.mkdir()
    sources = {}
    def raw(path, limit=16384):
        path = Path(path).absolute()
        if path.resolve() != path:
            raise ValueError('aliased source path')
        value = read(path, limit)
        if path in sources and sources[path] != sha(value):
            raise ValueError('source changed during audit')
        sources[path] = sha(value)
        return value
    def doc(path, limit=16384):
        return decode(raw(path, limit))
    report = dict(operation_success=False, windows=[], promotion=False, board_access=False,
                  formal_energy_input_accepted=False, meter_accuracy_verified=False,
                  joules_per_task_evaluated=False, source_origin_authenticated=False,
                  manifest_sha256=identity, settings_sha256=settings_sha)
    try:
        settings_raw = raw(settings_path)
        if sha(settings_raw) != settings_sha:
            raise ValueError('external settings pin mismatch')
        settings = config(decode(settings_raw))
        launch = doc(board/'launch.json', 100000)
        if (launch.get('identity_sha256') != identity or launch.get('settings_sha256') != settings_sha
                or encode(launch.get('settings')) != encode(settings) or launch.get('operator') != 'bx'
                or launch.get('operator_confirmed_this_launch') is not True
                or launch.get('board_run_authorized_by_package') is not False or launch.get('promotion') is not False):
            raise ValueError('new launch/package/settings context missing')
        from candidate_receipt import evaluate, EXPECTED
        outer = doc(board/'outer_receipt.json', 100000)
        life = doc(board/'worker/lifecycle.json', 100000)
        rows = doc(board/'worker/outputs/calls.json', CALLS_BYTE_LIMIT)
        exchanges = [doc(board/('transport/exchange_%d.json' % n)) for n in range(8)]
        replay = evaluate(doc(board/'lock_bootstrap.json'), doc(board/'observation/actual_exit.json'),
                          life, doc(board/'worker/worker_completion.json'), rows,
                          doc(board/'worker/request.json'), exchanges, doc(board/'lock_final_probe.json'),
                          session_id=settings['session_id'],
                          expected_config_sha=expected_capture_sha(settings),
                          path_context=doc(board/'worker/candidate_path.json'),
                          transport_clean=outer.get('transport_errors') == [] and outer.get('stop_signals') == [])
        retained = True
        for w in range(4):
            for pair in (42, 43):
                value = raw(board/('worker/outputs/window_%d_input_%d.bin' % (w, pair)), 1048576)
                retained = retained and len(value) == 1048576 and sha(value) == EXPECTED[pair]
        replay['checks']['representative_outputs'] = retained
        if (not all(replay['checks'].values()) or outer.get('checks') != replay['checks']
                or outer.get('operation_success') is not True or outer.get('identity_sha256') != identity
                or outer.get('settings_sha256') != settings_sha or outer.get('session_id') != settings['session_id']
                or outer.get('handler_restore_errors') != [] or outer.get('consistency_policy') != settings['consistency_policy']
                or outer.get('numeric_consistency_evaluated') is not False
                or outer.get('formal_energy_input_accepted') is not False or outer.get('promotion') is not False
                or any(encode(outer.get(k)) != encode(replay[k]) for k in (
                    'component_manifest_sha256', 'core_identity_sha256', 'host_path', 'transport_backend',
                    'effective_backend', 'candidate_runtime', 'path_binding_error_type', 'energy_evaluated'))):
            raise ValueError('new candidate board receipt replay rejected')
        receipt = doc(pc/'pc_receipt.json', 100000)
        if (receipt.get('operation_success') is not True or receipt.get('identity_sha256') != identity
                or receipt.get('settings_sha256') != settings_sha or receipt.get('stop_signals') != []
                or receipt.get('handler_restore_errors') != [] or receipt.get('gui_helper_pending') is not False
                or receipt.get('consistency_policy') != settings['consistency_policy']
                or receipt.get('numeric_consistency_evaluated') is not False
                or receipt.get('formal_energy_input_accepted') is not False or receipt.get('promotion') is not False):
            raise ValueError('new candidate PC receipt rejected')
        # Preserve the original host/runtime and helper-observation contract.
        helpers = receipt.get('gui_process_observations')
        host_runtime = receipt.get('powershell_runtime', {})
        binding_raw = raw(pc/'host_binding.json')
        launch_pc = doc(pc/'host_context.json')
        host = decode(binding_raw)
        definitions = module('_legacy_host_definitions', root/'legacy/launch_abba.py')
        definitions.host_binding(host)
        if (launch_pc.get('identity_sha256') != identity or launch_pc.get('settings_sha256') != settings_sha
                or launch_pc.get('host_binding_sha256') != sha(binding_raw)
                or launch_pc.get('operator_confirmed_this_launch') is not True):
            raise ValueError('new PC host context missing')
        if (type(helpers) is not list or not helpers
                or any(type(x.get('actual_exit')) is not int or x['actual_exit'] != 0
                       or x.get('wait_expired') is not False for x in helpers)
                or host_runtime.get('path') != host['powershell_exe']
                or host_runtime.get('sha256') != host['powershell_sha256']
                or host_runtime.get('execution_policy_changed') is not False):
            raise ValueError('helper/runtime evidence incomplete')
        for n, item in enumerate(exchanges):
            if encode(doc(pc/('event_%02d.json' % n))) != encode(item['ack']):
                raise ValueError('PC/board ACK mismatch')
        importer = module('_unchanged_csv_importer', root/'legacy/offline/ut70_csv_import_candidate.py')
        guard = module('_unchanged_csv_guard', root/'component/core/frozen/model/csv_guard.py')
        analysis = module('_unchanged_envelope_analysis', root/'legacy/envelope_analysis.py')
        summary = module('_unchanged_abba_summary', root/'legacy/abba_summary.py')
        contract = doc(root/'legacy/measurement_contract.json')
        for w in range(4):
            ack = exchanges[2*w+1]['ack']
            value = raw(pc/('window_%d.csv' % w), importer.MAX_BYTES)
            if len(value) != ack['csv_bytes'] or sha(value) != ack['csv_sha256']:
                raise ValueError('CSV differs from original end ACK')
            result = analysis.analyze_window(value, importer=importer, guard=guard,
                policy=settings['consistency_policy'], mapping=contract['mapping'],
                mapping_basis=contract['mapping_basis'], host_sha=definitions.HOST_SHA,
                expected_sha=ack['csv_sha256'])
            result.update(window=w, backend=('openblas_2t', 'fpga_flat_contiguous',
                                             'fpga_flat_contiguous', 'openblas_2t')[w])
            report['windows'].append(result)
        report.update(operation_success=all(w['diagnostic_passed'] for w in report['windows']),
                      board_receipt_checks=replay['checks'], completed_runtime_calls=1824,
                      retained_outputs_rechecked=8, unsaved_outputs_independently_replayed=False)
        # The unchanged summary only accepts historical scheduler role strings.
        # Preserve its arithmetic; separately bind the effective backend above.
        grouped = [dict(w, backend=life['plan']['backends'][i]) for i, w in enumerate(report['windows'])]
        report['abba_summary'] = summary.summarize(grouped)
        report['effective_fpga_backend'] = 'fpga_flat_contiguous'
    except Exception as error:
        report.update(operation_success=False, error_type=type(error).__name__, error=str(error))
    finally:
        changed = []
        for path, pin in sources.items():
            try:
                if path.resolve() != path or sha(read(path, CALLS_BYTE_LIMIT)) != pin:
                    changed.append(str(path))
            except (OSError, ValueError):
                changed.append(str(path))
        report['sources_unchanged'] = not changed
        report['changed_or_unreadable_sources'] = changed
        report['source_sha256'] = {str(p): h for p, h in sources.items()}
        if changed:
            report['operation_success'] = False
        try:
            verify(root, identity)
            report['package_unchanged'] = True
        except (ValueError, OSError, KeyError, TypeError):
            report['package_unchanged'] = False
            report['operation_success'] = False
        new_json(output/'readback.json', report)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    for key in ('manifest-sha', 'settings-sha'):
        parser.add_argument('--'+key, required=True)
    for key in ('board', 'pc', 'settings', 'output'):
        parser.add_argument('--'+key, type=Path, required=True)
    args = parser.parse_args()
    result = audit(ROOT, args.manifest_sha, args.board, args.pc, args.settings, args.settings_sha, args.output)
    print(encode(dict(operation_success=result['operation_success'], board_access=False, promotion=False)).decode(), end='')
    raise SystemExit(0 if result['operation_success'] else 1)
