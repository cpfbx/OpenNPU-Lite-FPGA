"""Add exact new-path gates to the frozen lifecycle/OS/capture checker."""
from pathlib import Path
from runtime_binding import module, COMPONENT_SHA, CORE_SHA
from integration_common import encode

ROOT = Path(__file__).resolve().parent.parent
LEGACY = module('_unchanged_outer_receipt', ROOT/'legacy/candidate/src/outer_receipt.py')
EXPECTED = LEGACY.EXPECTED


def path_check(rows, path_context):
    from batch_policy import BatchPolicy
    from path_rows import verify_path_rows
    from candidate_session import context
    if encode(path_context) != encode(context('abba1808')):
        raise ValueError('exact new component/path context required')
    policy = BatchPolicy('abba1808', enabled=True)
    return verify_path_rows(rows, policy)


def evaluate(*args, path_context=None, **kwargs):
    result = LEGACY.evaluate(*args, **kwargs)
    error = None
    try:
        path = path_check(args[4], path_context)
        checked = path['pl_rows'] == 912
    except (ValueError, TypeError, KeyError) as failure:
        checked = False
        error = type(failure).__name__
    result['checks']['flat_contiguous_path'] = checked is True
    result['operation_success'] = all(result['checks'].values())
    result.update(component_manifest_sha256=COMPONENT_SHA,
                  host_path='flat_contiguous', transport_backend='fpga_cached',
                  effective_backend='fpga_flat_contiguous', path_binding_error_type=error,
                  candidate_runtime=True, energy_evaluated=False)
    return result
