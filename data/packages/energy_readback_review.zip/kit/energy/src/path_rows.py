"""Exact reviewed pure-data row function; no driver imports."""
from batch_policy import validate_policy

def verify_path_rows(rows, policy):
    """Only metadata path accounting, not output/numeric/OS/energy acceptance."""
    validate_policy(policy)
    if type(rows) is not list or len(rows) != 4*policy.per_window:
        raise ValueError('all fixed-plan rows required')
    pl_index = 0
    for absolute, row in enumerate(rows):
        window, index = divmod(absolute, policy.per_window)
        expected_backend = ('openblas_2t', 'fpga_cached', 'fpga_cached', 'openblas_2t')[window]
        if (type(row) is not dict or type(row.get('window')) is not int or row['window'] != window
                or type(row.get('index')) is not int or row['index'] != index
                or type(row.get('input_id')) is not int or row['input_id'] != 42+index%2
                or row.get('backend') != expected_backend or type(row.get('metrics')) is not dict):
            raise ValueError('row plan or transport backend mismatch')
        metrics = row['metrics']
        if window in (1, 2):
            if (metrics.get('host_path_candidate') != 'flat_contiguous'
                    or type(metrics.get('batch_pl_index')) is not int
                    or metrics['batch_pl_index'] != pl_index):
                raise ValueError('new candidate marker or PL sequence missing')
            pl_index += 1
        elif metrics:
            raise ValueError('CPU must not claim FPGA path metrics')
    return dict(host_path_binding_verified=True, pl_rows=pl_index,
                transport_backend='fpga_cached', effective_backend='fpga_flat_contiguous',
                scope='metadata path binding only', numeric_checked_by_this_function=False,
                energy_evaluated=False, board_access=False, promotion=False)
