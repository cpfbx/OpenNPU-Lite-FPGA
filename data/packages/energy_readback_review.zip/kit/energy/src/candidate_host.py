"""Retain fresh driver bindings; no GUI call, inference or board action."""
from runtime_binding import module
from integration_common import new_json, encode, sha


def retain_host(root, output, driver, csv_dir, identity, settings_sha, *, operator_confirmed=False):
    if operator_confirmed is not True:
        raise ValueError('fresh operator declaration required')
    definitions = module('_candidate_host_definitions', root/'legacy/launch_abba.py')
    pid, exe, ticks = driver.identity
    binding = definitions.host_binding(dict(host_pid=int(pid), exe_path=exe, host_start_ticks=ticks,
        powershell_exe=driver.runtime['path'], powershell_sha256=driver.runtime['sha256'],
        host_exe_sha256=definitions.HOST_SHA, csv_dir=str(csv_dir), serial='D0E18C66', rate='10SPS'))
    new_json(output/'host_binding.json', binding)
    new_json(output/'host_context.json', dict(identity_sha256=identity, settings_sha256=settings_sha,
        host_binding_sha256=sha(encode(binding)), operator='bx', operator_confirmed_this_launch=True,
        scope='declared driver identity; actual GUI identity is checked by frozen PcCapture', promotion=False))
    return binding
