"""Externally pinned runtime assembly; no hardware constructor or activation."""
import importlib.util
from pathlib import Path
import sys

COMPONENT_SHA = '23de58493983c2f0871c88fbdf2fdec3fb5667edff19b3b9a6b7b44ab1ce1215'
LEGACY_SHA = '52f6f73b793e5d331942b68af9d1f4636ad4648b3d3d1b6d7997e4083ba5056d'
CORE_SHA = '57ffe40bedcacead2953e38131a1c64ea62a54b05db517621eea7ec287197db3'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def verify(root, identity):
    root = Path(root).absolute()
    # This generic verifier is part of the externally pinned assembly too.
    verifier = module('_runtime_inventory', root/'verify_kit.py')
    result = verifier.verify(root, identity)
    verifier.verify(root/'component', COMPONENT_SHA)
    # Verify the legacy exact file set without importing its old runtime binding.
    from integration_common import decode, read, sha
    raw = read(root/'legacy/launch_manifest.json', 100000)
    if sha(raw) != LEGACY_SHA:
        raise ValueError('legacy source manifest changed')
    manifest = decode(raw)
    for name, item in manifest['files'].items():
        raw = read(root/'legacy'/name, item['bytes'])
        if len(raw) != item['bytes'] or sha(raw) != item['sha256']:
            raise ValueError('legacy source bytes changed')
    return result


def configure_core(root):
    root = Path(root).resolve()
    component = root/'component'
    core = component/'core'
    # Reject already imported foreign modules, including optional old bindings.
    expected = {p.stem: p for p in (core/'src').glob('*.py')}
    expected.update({p.stem: p for p in (root/'legacy/candidate/src').glob('*.py')})
    expected['offline_binding'] = component/'offline_binding.py'
    expected.update({p.stem: p for p in (root/'src').glob('*.py')})
    for name, path in expected.items():
        if name in sys.modules and Path(getattr(sys.modules[name], '__file__', '')).resolve() != path:
            raise RuntimeError('cross-runtime module: ' + name)
    paths = [root/'src', root/'legacy/candidate/src', component, core/'src']
    for path in reversed(paths):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))
    from batch_binding import verify as check_core, configure
    check_core(core, CORE_SHA)
    configure(core)
    return core
