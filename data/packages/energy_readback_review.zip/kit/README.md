# 两线薄启动封装候选（仅供审阅，尚未批准实跑）

负责人及唯一实板操作者bx。本包原样保留kws/466文件与energy/167文件；launch.py/kit_support.py是新外层，不修改模型、门限、BatchPolicy、计时、黄金核对、保存协议或清理主体。旧目录中的README/RUN只作来源，不用于启动新候选。不能执行energy/legacy/RUN.sh。

本包包含公共WAV、模型及厂商生成物等受各自许可限制的资产，不可直接整体公开。没有私人实录语音/凭据；host_binding不内置，实际PID/路径/CSV目录需现场提供。

## 操作顺序（独审与bx确切批准后才适用）

1. 双端核对外层ZIP和kit_manifest SHA，新目录解包，运行 `python3 -I -B launch.py check --manifest-sha <本包manifest>`。check只核字节，不代表run_ready，也不测试依赖。
2. 由bx在板上运行 `preflight --output <包外全新json> --manifest-sha ...`，输入PROBEONLY：只核ARM/内核/root、当前boot、既有规范锁lstat和现有NumPy身份；不FLOCK/不创建锁/不测试模型/不接Overlay。缺锁立即停止，另交bx确认已审LOCKONLY工具，不能自行创建。不得将旧boot/inode抄入新请求。
3. KWS：`prepare --kind kws --mode public_wav --preflight <文件> --preflight-sha <SHA> --output <包外全新目录> --manifest-sha ...`，也允许事前显式选fixed_features。固定420窗，不录音、不训练、不softmax/门控。prepare仅生成request/plan，不启动测试。用现有ARM NumPy，任何特征/logits不精确均失败留存，无预存特征回退。PC时长不能折算板时，无已保证的ARM完成时间。
4. 能量：先由bx审定显式policy；energy_policy_proposal.json只是与旧设置相同的未批准建议，不能当计量精度或审批记录。`prepare --kind energy --policy <文件> --policy-sha <SHA> --preflight <板端文件> --preflight-sha <SHA> --output <包外新目录> --manifest-sha ...`，生成新session_id的settings/plan。传给PC的是这次同一settings.json、plan.json、preflight.json及policy_source.json，而不是PC另生成新session。PC和板端分别放包外独立工作目录；不要复制已有attempt/evidence。
5. 两种prepare均输出payload SHA和plan SHA。bx核对配置、UTC/空闲/单一供电/接线/依赖，再分别批准确切ZIP、plan和范围。包本身始终activation_approved=false。能量ABBA为4×(4预热+452正式)=1824调用，仍按同N服务批次整文件保存包络诊断，不除N冒充精确J/task；既定双预算只是Wh与P积分的一致性报警。
6. 获上述明确批准后，用 `run --work <目录> --plan-sha <SHA> --role board --confirm-scope <确切scope> --enable-reviewed-launcher --manifest-sha ...`。KWS scope是CPU420-FIXED-REFERENCE-NO-PL-NO-DEPLOYMENT，能量scope是ENERGY1808-NEW-FLAT-CONTIGUOUS-ENVELOPES。新外层再询问CPU420或ENERGY1808，随后冻结入口仍保留自己的CPU420或YES/NEW-ENERGY确认。确认前后核对同boot/同锁/依赖；同plan目录创建attempt后不再允许运行，不自动重试。
7. 能量PC使用同一plan与 `--role pc --host-binding <本次文件> --host-sha <SHA>`；先核原Windows上位机和PowerShell实际字节，原控制器再核现有PID/启动ticks、10SPS/连接/未保存等状态。关闭自动保存，禁止清零/重新开始/切快充。手动SSH只做loopback转发 `ssh -N -L 18772:127.0.0.1:18772 xilinx@192.168.2.99`，传输与板启动均由bx操作。绝不自动SSH、不额外在板上启动Python包装父进程。
8. Ctrl+C沿用冻结合作停止，当前完整请求/窗口结束后不启动下一个；没有自动kill、超时成功、删除锁或恢复重试。若未知fd/硬件安全状态隔离，保留活进程和原件，联系bx，不自动结束。attempt即使未开始硬件也保留；重试须新目录并由bx另行决定。

board运行要求当前ARM读数和原镜像内核；energy还要求原 `/usr/local/share/pynq-venv` Python。启动层不安装/切环境/调权限/加载模块。只读probe导入现有NumPy是依赖检查，不是假定无任何原生扩展，也不证明全板空闲；空闲与实物身份仍由bx确认。

## 结果回收与边界

工作目录内request/settings、plan、preflight、attempt、entry_return、evidence完整保留。entry_return仅记录同进程函数返回，**不是**独立OS退出观察；由用户shell另外记录实际launcher退出码。真正子进程wait/组消失、锁/资源证据仍在原外层回执。KWS用kws/src/readback.py，能量用energy/src/readback_candidate.py按各自原参数回读，输出必须放包和输入树外；不执行旧legacy回读冒充新路径。

本包暂无ARM、能量新数据或部署接受。全部运行入口目前只供离线反例审查；请先完成新封装审查，再由bx批准实跑。
