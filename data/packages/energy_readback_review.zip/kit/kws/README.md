# 新DS-CNN ARM CPU参考：受控离线候选

负责人bx，只有bx能操作开发板。本目录尚未独审/批准板测，无RUN.sh；仅允许离线check/测试。内部parent/_worker不是已发布启动入口。

`component/`完整保留已审33文件整数组件；`frontend/`保留固定参考Hann/mel与原FFT512/FFT80/DCT算术，`public_wav/`是401条公开源、data/cohort.json是同420固定窗的顺序/偏移/PCM哈希。没有个人实录音频。

两种显式模式：fixed_features只核板端整数logits；public_wav从真实WAV重新前处理再核特征/logits，绝不在失败时回退到已保存特征。两者均只作CPU数值参考，不加载PYNQ/Overlay/DMA、TFLite/TF，不给动作、不校准门限、不宣称新识别率或部署通过。

私有外层沿用原/tmp/opennpu-kws-chain.lock与原ObservedLease/实际wait观察器；缺失/忙/身份漂移失败即停，不创建锁、不改权限。当前窗口合作停止后不接受为成功、不启动下一窗；退出/进程组/同inode释放须分别核对。未知FD释放进入保留锁的进程隔离，不自动重试、kill或超时抢锁。

原21常量及整数算术不改，WAV短窗归一化顺序与已复验参考参数路径相同。INT8特征/logits要求全精确；不宣称float MFCC位级相同。重复420固定窗不增加独立样本，旧三层模型实板证据不能与新模型PC/ARM参考混算。

数组/FFT派生来源与MPL2、Speech Commands公开源许可保留；模型来源另遵原component溯源。仅内部研究审阅，不代表公开资产白名单已批准。
