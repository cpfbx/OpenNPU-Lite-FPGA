# FFT来源核查与重放边界

官方TF2.14.1源码：
- https://raw.githubusercontent.com/tensorflow/tensorflow/v2.14.1/tensorflow/core/kernels/fft_ops.cc
  CPU DoRealForwardFFT使用Eigen Tensor fft，先全FFT再切正频率；CPU RFFT内核注册。
- https://raw.githubusercontent.com/tensorflow/tensorflow/v2.14.1/third_party/eigen3/workspace.bzl
  Eigen commit 0b51f763cbbd0ed08168f88972724329f0375498，归档SHA
  70a3b0e357fc037740002f5097a15dba1ea0dde28d37f5d9c86f76a06626f4fc。
- https://gitlab.com/libeigen/eigen/-/raw/0b51f763cbbd0ed08168f88972724329f0375498/unsupported/Eigen/CXX11/src/Tensor/TensorFFT.h
  上游固定提交核查非二次幂分支/Bluestein和幂二次FFT；未假称网页展示字节与wheel二进制逐一认证。

现有wheel TensorFFT.h：
.offline-results/WP4-tf-reference-20261015_01/site-packages/tensorflow/include/unsupported/Eigen/CXX11/src/Tensor/TensorFFT.h
SHA d352382b28211235c36795efa512f4cefd40c2319add9a2b57bb7e1df8828ba8。
源码路径：evalToBuf非二次幂分支、findGoodComposite、processDataLineBluestein、
butterfly_8/butterfly_1D_merge以及固定twiddle LUT。

DCT使用RFFT80，是非2次幂；对应Bluestein内部长度为最小满足m>=159的2次幂，即256。
音频STFT使用FFT512，是另一条幂二次路径，不能以80点结果覆盖其验证。
对应参考DCT旋转/归一化仍来自前轮已固定代码，模型source cast不动。

eigen80_replay.py是已有本地TensorFFT.h的有限Python数值翻译，保留出处及MPL2标记；
此目录为私有研究记录，未复制或分发整套Eigen库，也未将其根许可改成项目MIT。
如未来正式发布派生源码，必须连同适用MPL2完整文本/来源说明完成白名单核定；
本轮没有许可合法性意见或发布授权。
它只用于比较1..64行固定80点，非通用FFT库、生产移植或性能候选。
NumPycomplex64乘法可能与编译器std::complex浮点指令不同，重放结果必须实测，不能假定逐位等价。
