"""Public WAV-to-feature diagnostic with fixed TF-generated parameters; no TF import."""
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import os
import sys
import time
import wave

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parent.parent
FIRST=HERE.parent/'KWS-frontend-followup-20261022_01'
SECOND=HERE.parent/'KWS-fft-kernel-20261022_01'
SITE=HERE.parent/'WP4-tf-reference-20261015_01/site-packages'


def sha(raw):return hashlib.sha256(raw).hexdigest()


def require(value,message):
    if not value:raise ValueError(message)


def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m


def main():
    out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
    for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
    sys.path.insert(0,str(SITE))
    import numpy as np
    require(np.__version__=='1.26.4' and sys.version_info[:2]==(3,10),'fixed diagnostic runtime')
    require(Path(np.__file__).resolve().is_relative_to(SITE.resolve()),'existing isolated NumPy')
    params=json.loads((HERE/'parameter_export_01/manifest.json').read_bytes())
    config={'sample_rate':16000,'frame_length':480,'frame_step':320,'fft_length':512,
            'num_mel_bins':40,'num_spectrogram_bins':257,'lower_hertz':20,'upper_hertz':4000,'periodic_hann':True}
    require(params['configuration']==config and params['no_audio_model_or_label_dependency'] is True,'fixed parameter configuration')
    origin_raw=(HERE/'five_probe_01/result.json').read_bytes()
    require(sha(origin_raw)=='17bc78e52becead1a76e71500e01986c6fc4f9c6970dd1de5f244d1353238c0e','fixed parameter external anchor')
    origin=json.loads(origin_raw)
    def parameter(name,shape):
        raw=(HERE/'parameter_export_01'/name).read_bytes();entry=origin['files'][name]
        require(len(raw)==entry['bytes'] and sha(raw)==entry['sha256'] and params['files'][name]==entry,'parameter identity')
        value=np.frombuffer(raw,dtype='<f4').reshape(shape);require(np.isfinite(value).all(),'finite parameter');return value
    tf_hann=parameter('tf_hann.f32',(480,));tf_weights=parameter('tf_mel_weights.f32',(257,40))
    baseline_source=PROJECT/'.board-work/FPGA-20-zip-test-20261013/delivery/pretrained_kws_candidate/frontend_probe.py'
    require(sha(baseline_source.read_bytes())=='02007caa18bad8e552299eca35456c38bbde179270d9f470d6e33bd0d19c4d39','baseline source identity')
    baseline=load(baseline_source,'pinned_numpy_baseline');np_weights=baseline.mel_matrix()
    np_hann=np.float32(.5)-np.float32(.5)*np.cos(np.arange(480,dtype=np.float32)*np.float32(2*np.pi/480))
    f=load(HERE/'fft512_probe.py','fft512_probe');e=f.source();d=load(FIRST/'dct_probe.py','dct_probe')
    lut=e.tables(SITE/'tensorflow/include/unsupported/Eigen/CXX11/src/Tensor/TensorFFT.h')
    source_rows=(FIRST/'reference_02/raw.json').read_bytes()
    old_summary_raw=(FIRST/'reference_02/summary.json').read_bytes()
    require(sha(old_summary_raw)=='4e78b389cdf8729ed7c89364d5097c38e02af95800fba2a32e8f598faf4d2bea','old study summary')
    old_summary=json.loads(old_summary_raw);require(sha(source_rows)==old_summary['raw_sha256'],'record identity')
    old_rows=json.loads(source_rows)
    ref_raw=(FIRST/'reference_02/reference.i8').read_bytes()
    require(sha(ref_raw)=='9fd7517250011f7b9e1d8e70e96085041f2136aa5e13f1392ff204bf6e7e4480','full reference features')
    reference=np.frombuffer(ref_raw,dtype=np.int8).reshape(420,49,10)
    mfcc_raw=(FIRST/'reference_02/reference_mfcc.f32').read_bytes()
    require(sha(mfcc_raw)==old_summary['files']['reference_mfcc.f32']['sha256'],'reference MFCC identity')
    mfcc_reference=np.frombuffer(mfcc_raw,dtype='<f4').reshape(420,49,10)
    selection_raw=(PROJECT/'.offline-results/WP4-voice-gate-20261015_01/experiment_02/selection.json').read_bytes()
    require(sha(selection_raw)=='dbcb0f442d1df4ab960c5b6930c8bbdf4c6e288758f1a810e5cd4175bf774db3','selection')
    selections={r['source_id']:r for r in json.loads(selection_raw)['cohorts']['evaluation']}
    historical_raw=(SITE.parent/'frontend_check_01/raw.jsonl').read_bytes()
    require(sha(historical_raw)=='468659fead5798f2a5878b449a9e8ed1c86746260416df0da99b4ac802144d2b','historical raw')
    historical=[json.loads(line) for line in historical_raw.splitlines()]
    require(len(old_rows)==len(historical)==len(selections)==420,'cohort length')
    require([r['source_id'] for r in old_rows]==[r['source_id'] for r in historical],'cohort order')
    variants=('numpy_hann_numpy_weights','numpy_hann_reference_weights','reference_hann_reference_weights')
    outputs={name:[] for name in variants};counts=Counter();windows=Counter();float_counts=Counter();float_max=Counter()
    winning_mfcc=[];rows=[];started=time.monotonic()
    for index,row in enumerate(old_rows):
        item=selections[row['source_id']];dataset=(PROJECT/'data/speech_commands_v0.02').resolve();path=(dataset/item['path']).resolve()
        require(path.is_relative_to(dataset) and sha(path.read_bytes())==item['source_sha256'],'public source WAV')
        with wave.open(str(path),'rb') as stream:
            require((stream.getnchannels(),stream.getsampwidth(),stream.getframerate())==(1,2,16000),'WAV domain')
            stream.setpos(item['offset']);pcm=np.frombuffer(stream.readframes(16000),dtype='<i2').copy()
        require(0<len(pcm)<=16000 and int(pcm.max())>0,'normalization domain unchanged')
        require(sha(np.pad(pcm,(0,16000-len(pcm))).astype('<i2').tobytes())==row['pcm_sha256'],'PCM identity')
        audio=np.pad(pcm.astype(np.float32)/np.float32(pcm.max()),(0,16000-len(pcm)))
        frames=np.stack([audio[i*320:i*320+480] for i in range(49)])
        sn=f.rfft512(frames*np_hann,lut,e);st=f.rfft512(frames*tf_hann,lut,e)
        mn=np.hypot(sn.real,sn.imag);mt=np.hypot(st.real,st.imag)
        inputs={'numpy_hann_numpy_weights':(mn,np_weights),'numpy_hann_reference_weights':(mn,tf_weights),
                'reference_hann_reference_weights':(mt,tf_weights)}
        results={}
        for name,(magnitude,weights) in inputs.items():
            logmel=np.log(magnitude@weights+np.float32(1e-6))
            features=d.rotate_rfft(e.rfft80(logmel,lut));q=d.source_cast(features)
            diff=np.argwhere(q!=reference[index]).tolist();counts[name]+=len(diff);windows[name]+=bool(diff)
            floats=int(np.count_nonzero(features!=mfcc_reference[index]));delta=float(np.max(np.abs(features.astype(np.float64)-mfcc_reference[index])))
            float_counts[name]+=floats;float_max[name]=max(float_max[name],delta);outputs[name].append(q)
            results[name]={'count':len(diff),'positions':diff,'sha256':sha(q.tobytes()),
                           'float_nonexact':floats,'float_max_abs':delta}
            if name=='reference_hann_reference_weights':winning_mfcc.append(features)
        rows.append({'source_id':row['source_id'],'source_sha256':item['source_sha256'],'pcm_sha256':row['pcm_sha256'],
                     'historical_official_feature_sha256':historical[index]['official_feature_sha256'],
                     'original_samples':len(pcm),'variants':results})
        if (index+1)%60==0:print('WAV_COHORT',index+1,'/420',flush=True)
    require('tensorflow' not in sys.modules,'unexpected TF import')
    files={}
    for name,values in outputs.items():
        data=np.stack(values).tobytes();filename=name+'.i8'
        with (out/filename).open('xb') as stream:stream.write(data)
        files[filename]={'bytes':len(data),'sha256':sha(data)}
    data=np.stack(winning_mfcc).astype('<f4').tobytes()
    with (out/'reference_parameter_mfcc.f32').open('xb') as stream:stream.write(data)
    files['reference_parameter_mfcc.f32']={'bytes':len(data),'sha256':sha(data)}
    with (out/'raw.json').open('x') as stream:json.dump(rows,stream,indent=2)
    result={'scope':'public fixed 420 WAV-to-feature diagnostic; TF-generated fixed operator parameters',
            'counts':dict(counts),'mismatched_windows':dict(windows),'float_nonexact':dict(float_counts),
            'float_max_abs':dict(float_max),'files':files,'raw_sha256':sha((out/'raw.json').read_bytes()),
            'parameter_manifest_sha256':sha((HERE/'parameter_export_01/manifest.json').read_bytes()),
            'script_sha256':sha(Path(__file__).read_bytes()),'fft512_source_sha256':sha((HERE/'fft512_probe.py').read_bytes()),
            'fixed_dct_source_sha256':sha((SECOND/'eigen80_replay.py').read_bytes()),
            'runtime':{'python':sys.version,'numpy':np.__version__,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},
            'pc_elapsed_seconds':time.monotonic()-started,'tensorflow_imported':False,'board_access':False,
            'inference_run':False,'frontend_fix_accepted':False,'deployable':False,'promotion':False}
    with (out/'result.json').open('x') as stream:json.dump(result,stream,indent=2)
    print(json.dumps(result),flush=True)


if __name__=='__main__':main()
