import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
import numpy as np

ROOT=Path(__file__).resolve().parent/'candidate_01'
spec=importlib.util.spec_from_file_location('qualified_integer',ROOT/'portable_integer.py')
q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)


class PortableTests(unittest.TestCase):
    def test_default_off(self):
        with self.assertRaises(ValueError):q.IntegerReference(ROOT/'model')
    def test_truthy_enable_refused(self):
        with self.assertRaises(ValueError):q.IntegerReference(ROOT/'model',enabled=1)
    def test_constants_read_only(self):
        m=q.IntegerReference(ROOT/'model',enabled=True)
        self.assertTrue(all(not a.flags.writeable for a in m.constants.values()))
    def test_wrong_input_shape(self):
        m=q.IntegerReference(ROOT/'model',enabled=True)
        with self.assertRaises(ValueError):m.infer(np.zeros((1,49,70,1),np.int8))
    def test_wrong_input_dtype(self):
        m=q.IntegerReference(ROOT/'model',enabled=True)
        with self.assertRaises(ValueError):m.infer(np.zeros((1,49,10,1),np.float32))
    def test_model_bytes_tamper(self):
        with tempfile.TemporaryDirectory(prefix='portable_model_') as d:
            folder=Path(d)/'model';shutil.copytree(ROOT/'model',folder)
            p=folder/'kws_ref_model.tflite';raw=p.read_bytes();p.write_bytes(bytes([raw[0]^1])+raw[1:])
            with self.assertRaisesRegex(ValueError,'model byte drift'):q.IntegerReference(folder,enabled=True)
    def test_constant_bytes_tamper(self):
        with tempfile.TemporaryDirectory(prefix='portable_constant_') as d:
            folder=Path(d)/'model';shutil.copytree(ROOT/'model',folder)
            p=next(folder.glob('constant_*.bin'));raw=p.read_bytes();p.write_bytes(bytes([raw[0]^1])+raw[1:])
            with self.assertRaisesRegex(ValueError,'constant identity'):q.IntegerReference(folder,enabled=True)
    def test_parent_constant_path_rejected(self):
        with tempfile.TemporaryDirectory(prefix='portable_path_') as d:
            folder=Path(d)/'model';shutil.copytree(ROOT/'model',folder)
            p=folder/'descriptor.json';doc=json.loads(p.read_bytes())
            next(iter(doc['constants'].values()))['file']='../outside.bin';p.write_text(json.dumps(doc),encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'basename'):q.IntegerReference(folder,enabled=True)
    def test_negative_or_nonfinite_scale(self):
        for x in (-1,float('nan'),float('inf')):
            with self.subTest(x=x),self.assertRaises(ValueError):q.quant_multiplier(x)
    def test_i32_overflow(self):
        with self.assertRaises(OverflowError):q.checked_i32(np.array([2**31],dtype=np.int64))
    def test_no_native_or_schema_modules_loaded(self):
        self.assertFalse(any(n in sys.modules for n in ('tensorflow','tflite_runtime','tflite','flatbuffers','pynq')))
    def test_first_fixed_input_logits(self):
        m=q.IntegerReference(ROOT/'model',enabled=True)
        raw=(ROOT/'data/fixed_features.i8').read_bytes()[:490]
        output,checks=m.infer(np.frombuffer(raw,np.int8).reshape(1,49,10,1))
        self.assertEqual(output.tobytes(),(ROOT/'data/expected_logits.i8').read_bytes()[:12])
        self.assertEqual(checks,[])


if __name__=='__main__':unittest.main(verbosity=2)
