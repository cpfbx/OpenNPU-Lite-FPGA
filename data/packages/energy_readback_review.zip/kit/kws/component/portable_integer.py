"""Default-off portable integer logits component; not a board launcher.
Arithmetic mechanically retained from original quantized_probe/inspect_model.
TF2.14/gemmlowp rounding definitions referenced in the preserved original source.
No original native Interpreter, schema parser, softmax, voice gate or actions.
"""
import hashlib
import json
import math
from pathlib import Path
import numpy as np

class PortableInteger:
    def __init__(self, folder, *, enabled=False):
        if enabled is not True:
            raise ValueError('portable integer candidate default-off')
        folder=Path(folder)
        descriptor=json.loads((folder/'descriptor.json').read_bytes())
        if descriptor['model_sha256']!='aeea436800704fce17b17292e4412630ad856e9d777c044c64ef748a880bd0ae':
            raise ValueError('model identity')
        if hashlib.sha256((folder/'kws_ref_model.tflite').read_bytes()).hexdigest()!=descriptor['model_sha256']:
            raise ValueError('model byte drift')
        self.info=descriptor['info']
        self.options={int(k):v for k,v in descriptor['options'].items()}
        self.constants={}
        for key,item in descriptor['constants'].items():
            name=item['file']
            if Path(name).name!=name or '\\' in name or ':' in name:
                raise ValueError('constant basename required')
            raw=(folder/name).read_bytes()
            if len(raw)!=item['bytes'] or hashlib.sha256(raw).hexdigest()!=item['sha256']:
                raise ValueError('constant identity drift')
            if item['dtype'] not in ('|i1','<i4'):
                raise ValueError('exact INT8/INT32 constants required')
            self.constants[int(key)]=np.frombuffer(raw,dtype=item['dtype']).reshape(item['shape'])


def checked_i32(x):
    if np.any(x < -(1 << 31)) or np.any(x >= 1 << 31):
        raise OverflowError('INT32 range')
    return x.astype(np.int32)

def quant_multiplier(scale):
    if not math.isfinite(scale) or scale < 0:
        raise ValueError('invalid positive scale')
    if scale == 0:
        return (0, 0)
    fraction, exponent = math.frexp(scale)
    fixed = math.floor(fraction * (1 << 31) + 0.5)
    if fixed == 1 << 31:
        fixed //= 2
        exponent += 1
    if exponent < -31:
        return (0, 0)
    if exponent > 30:
        raise ValueError('unsupported scale exponent')
    return (fixed, exponent)

def multiply_quantized(x, multiplier, shift):
    if not 0 <= multiplier < 1 << 31 or not -31 <= shift <= 30:
        raise ValueError('invalid multiplier/shift')
    x = np.asarray(x, dtype=np.int64)
    checked_i32(x)
    shifted = x * (1 << max(shift, 0))
    checked_i32(shifted)
    product = shifted * int(multiplier)
    adjusted = product + np.where(product >= 0, 1 << 30, 1 - (1 << 30))
    high = np.where(adjusted >= 0, adjusted // (1 << 31), -(-adjusted // (1 << 31)))
    right = max(-shift, 0)
    mask = (1 << right) - 1
    threshold = (mask >> 1) + (high < 0).astype(np.int64)
    return (high >> right) + (high & mask > threshold).astype(np.int64)

def requantize(acc, scales, zero_point, activation):
    if acc.ndim != 2 or not -128 <= zero_point <= 127:
        raise ValueError('bad requant shape/zero point')
    if activation not in (0, 1):
        raise ValueError('unsupported activation')
    scales = np.broadcast_to(scales, (acc.shape[1],))
    out = np.empty(acc.shape, np.int8)
    lower = max(-128, zero_point) if activation == 1 else -128
    for col, scale in enumerate(scales):
        m, s = quant_multiplier(float(scale))
        value = multiply_quantized(acc[:, col], m, s) + zero_point
        out[:, col] = np.clip(value, lower, 127).astype(np.int8)
    return out

def conv_patches(x, weight_shape, output_shape, stride, padding, dilation, zero_point):
    if x.shape[0] != 1 or dilation != [1, 1]:
        raise ValueError('unsupported batch/dilation')
    _, kh, kw, channels = weight_shape
    _, oh, ow, _ = output_shape
    sh, sw = stride
    if padding == 0:
        ph = max((oh - 1) * sh + kh - x.shape[1], 0)
        pw = max((ow - 1) * sw + kw - x.shape[2], 0)
    elif padding == 1:
        ph = pw = 0
    else:
        raise ValueError('unsupported padding')
    padded = np.pad(x[0], ((ph // 2, ph - ph // 2), (pw // 2, pw - pw // 2), (0, 0)), constant_values=zero_point)
    patches = np.stack([padded[y * sh:y * sh + kh, z * sw:z * sw + kw, :].reshape(-1) for y in range(oh) for z in range(ow)])
    if patches.shape != (oh * ow, kh * kw * channels):
        raise ValueError('invalid patches')
    return patches

class IntegerReference(PortableInteger):
    def infer(self, x, compare=None):
        if x.dtype != np.int8 or list(x.shape) != [1, 49, 10, 1]:
            raise ValueError('input contract')
        values = dict(self.constants)
        values[self.info['inputs'][0]] = x
        checks = []
        for op in self.info['operators']:
            name = op['name']
            output = op['outputs'][0]
            ot = self.info['tensors'][output]
            if name == 'SOFTMAX':
                break
            src = op['inputs'][0]
            it = self.info['tensors'][src]
            a = values[src]
            if name in ('CONV_2D', 'DEPTHWISE_CONV_2D', 'FULLY_CONNECTED'):
                wi, bi = op['inputs'][1:]
                b = values[wi]
                bias = values[bi]
                wt = self.info['tensors'][wi]
                if any((z != 0 for z in wt['zero_points'])):
                    raise ValueError('non-symmetric weights')
                zp = it['zero_points'][0]
                if name == 'CONV_2D':
                    patches = conv_patches(a, b.shape, ot['shape'], op['stride'], op['padding'], op['dilation'], zp)
                    weight = b.reshape(b.shape[0], -1)
                    acc = (patches.astype(np.int32) @ weight.astype(np.int32).T).astype(np.int64)
                    acc += bias.astype(np.int64) - zp * weight.astype(np.int64).sum(axis=1)
                elif name == 'DEPTHWISE_CONV_2D':
                    if b.shape[-1] != a.shape[-1]:
                        raise ValueError('only depth multiplier 1')
                    _, kh, kw, c = b.shape
                    patches = conv_patches(a, (c, kh, kw, c), ot['shape'], op['stride'], op['padding'], op['dilation'], zp)
                    centered = patches.reshape(-1, kh * kw, c).astype(np.int64) - zp
                    acc = (centered * b.reshape(kh * kw, c).astype(np.int64)).sum(axis=1) + bias
                else:
                    acc = (a.reshape(-1, b.shape[1]).astype(np.int32) @ b.astype(np.int32).T).astype(np.int64)
                    acc += bias.astype(np.int64) - zp * b.astype(np.int64).sum(axis=1)
                checked_i32(acc)
                scale = np.array(wt['scales'], np.float64) * float(it['scales'][0]) / float(ot['scales'][0])
                activation = op.get('activation', self.options.get(op['index'], {}).get('activation', 0))
                result = requantize(acc, scale, ot['zero_points'][0], activation).reshape(ot['shape'])
            elif name == 'AVERAGE_POOL_2D':
                opts = self.options[op['index']]
                if opts['padding'] != 1 or opts['activation'] != 0 or ot['shape'] != [1, 1, 1, 64]:
                    raise ValueError('unsupported pool configuration')
                if it['scales'] != ot['scales'] or it['zero_points'] != ot['zero_points']:
                    raise ValueError('pool quantization drift')
                h, w = opts['filter']
                count = h * w
                if h > a.shape[1] or w > a.shape[2]:
                    raise ValueError('invalid pool window')
                total = a[0, :h, :w, :].astype(np.int64).sum(axis=(0, 1))
                result = (np.sign(total) * ((np.abs(total) + count // 2) // count)).astype(np.int8).reshape(ot['shape'])
            elif name == 'RESHAPE':
                result = a.reshape(ot['shape'])
            else:
                raise ValueError('unsupported operator ' + name)
            values[output] = result
            if compare is not None:
                expected = compare(output)
                mismatch = int(np.count_nonzero(result != expected))
                checks.append(dict(op_index=op['index'], name=name, values=int(result.size), mismatch=mismatch))
                if mismatch:
                    raise ValueError('candidate/reference mismatch op ' + str(op['index']) + ': ' + str(mismatch))
        return (values[33].copy(), checks)
