"""Offline pinned MLPerf model inspection; never a deployment or board runner.

Reference intermediates come from TFLite BUILTIN_REF (delegates disabled).
Checks only dense/conv accumulator mapping, NOT requantization equivalence.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re

import numpy as np
import tflite

MODEL_SHA = 'aeea436800704fce17b17292e4412630ad856e9d777c044c64ef748a880bd0ae'

def enum_names(cls):
    return {v:k for k,v in vars(cls).items() if isinstance(v,int)}

def tensor_record(graph,index):
    t=graph.Tensors(index);q=t.Quantization()
    return dict(index=index,name=t.Name().decode(),shape=t.ShapeAsNumpy().tolist(),
        dtype=enum_names(tflite.TensorType)[t.Type()],buffer=t.Buffer(),
        scales=q.ScaleAsNumpy().tolist() if q and q.ScaleLength() else [],
        zero_points=q.ZeroPointAsNumpy().tolist() if q and q.ZeroPointLength() else [],
        quantized_dimension=q.QuantizedDimension() if q else None)

def inventory(raw):
    if hashlib.sha256(raw).hexdigest()!=MODEL_SHA:raise ValueError('foreign model bytes')
    m=tflite.Model.GetRootAsModel(raw,0)
    if m.SubgraphsLength()!=1:raise ValueError('only one reference subgraph supported')
    g=m.Subgraphs(0);ops=[]
    tensors=[tensor_record(g,i) for i in range(g.TensorsLength())]
    for i in range(g.OperatorsLength()):
        o=g.Operators(i);code=m.OperatorCodes(o.OpcodeIndex())
        name=enum_names(tflite.BuiltinOperator)[code.BuiltinCode()]
        row=dict(index=i,name=name,inputs=o.InputsAsNumpy().tolist(),outputs=o.OutputsAsNumpy().tolist())
        if name in ('CONV_2D','DEPTHWISE_CONV_2D'):
            cls=tflite.Conv2DOptions if name=='CONV_2D' else tflite.DepthwiseConv2DOptions
            opt=cls();table=o.BuiltinOptions();opt.Init(table.Bytes,table.Pos)
            row.update(stride=[opt.StrideH(),opt.StrideW()],padding=opt.Padding(),
                dilation=[opt.DilationHFactor(),opt.DilationWFactor()],activation=opt.FusedActivationFunction())
        if name in ('CONV_2D','DEPTHWISE_CONV_2D','FULLY_CONNECTED'):
            shape=tensors[row['inputs'][1]]['shape'];out=tensors[row['outputs'][0]]['shape']
            if name=='CONV_2D':row['mnk']=[int(np.prod(out[:-1])),shape[0],int(np.prod(shape[1:]))]
            elif name=='FULLY_CONNECTED':row['mnk']=[int(np.prod(out[:-1])),shape[0],shape[1]]
            row['macs']=int(np.prod(out))*int(np.prod(shape[1:3]) if name=='DEPTHWISE_CONV_2D' else (np.prod(shape[1:])))
        ops.append(row)
    return dict(model_sha256=MODEL_SHA,tensors=tensors,operators=ops,
        inputs=g.InputsAsNumpy().tolist(),outputs=g.OutputsAsNumpy().tolist())

def conv_patches(x,weight_shape,output_shape,stride,padding,dilation,zero_point):
    if x.shape[0]!=1 or dilation!=[1,1]:raise ValueError('unsupported batch/dilation')
    _,kh,kw,channels=weight_shape
    _,oh,ow,_=output_shape;sh,sw=stride
    if padding==tflite.Padding.SAME:
        ph=max((oh-1)*sh+kh-x.shape[1],0);pw=max((ow-1)*sw+kw-x.shape[2],0)
    elif padding==tflite.Padding.VALID:ph=pw=0
    else:raise ValueError('unsupported padding')
    padded=np.pad(x[0],((ph//2,ph-ph//2),(pw//2,pw-pw//2),(0,0)),constant_values=zero_point)
    patches=np.stack([padded[y*sh:y*sh+kh,z*sw:z*sw+kw,:].reshape(-1)
        for y in range(oh) for z in range(ow)])
    if patches.shape!=(oh*ow,kh*kw*channels):raise ValueError('invalid patches')
    return patches

def verify_accumulator(a,b,bias,zero_point):
    """INT8 GEMM + constant correction versus independently reduced INT64 sums."""
    if not isinstance(zero_point,(int,np.integer)) or not -128<=zero_point<=127:
        raise ValueError('bad activation zero point')
    if a.dtype!=np.int8 or b.dtype!=np.int8 or bias.dtype!=np.int32:
        raise ValueError('unsupported tensor types')
    if a.ndim!=2 or b.ndim!=2 or a.shape[1]!=b.shape[1] or bias.shape!=(b.shape[0],):
        raise ValueError('incompatible matrices')
    # Existing signed-int8 matrix interface need not represent (a-z) as int8.
    correction=bias.astype(np.int64)-zero_point*b.astype(np.int64).sum(axis=1)
    raw=a.astype(np.int32)@b.astype(np.int32).T
    mapped=raw.astype(np.int64)+correction
    centered=a.astype(np.int64)-zero_point
    direct=np.empty_like(mapped)
    for col in range(b.shape[0]):
        direct[:,col]=np.sum(centered*b[col].astype(np.int64),axis=1)+int(bias[col])
    if not np.array_equal(mapped,direct):raise ValueError('accumulator mismatch')
    limits=np.iinfo(np.int32)
    if np.any(mapped<limits.min) or np.any(mapped>limits.max):raise OverflowError('accumulator overflow')
    if np.any(correction<limits.min) or np.any(correction>limits.max):raise OverflowError('bias correction overflow')
    # Prove INT32 raw GEMM cannot wrap at this K, independently of observed data.
    if a.shape[1]*128*128>limits.max:raise OverflowError('raw GEMM worst-case overflow')
    return dict(values=int(mapped.size),exact=True,min=int(mapped.min()),max=int(mapped.max()),
        raw_a_bytes=a.nbytes,weight_bytes=b.nbytes,raw_output_bytes=raw.nbytes,
        corrected_bias_int32=True,accumulator_sha256=hashlib.sha256(mapped.astype('<i4').tobytes()).hexdigest())

def reference_runs(model_path,info,sample_source):
    from tflite_runtime.interpreter import Interpreter,OpResolverType
    # Do not execute downloaded Python code; parse the official C integer initializer.
    text=sample_source.read_text();initializer=text.split('= {',1)[1].split('};',1)[0]
    sample=np.array([int(v) for v in re.findall(r'-?\d+',initializer)],dtype=np.int16)
    if sample.size!=490 or np.any(sample<-128) or np.any(sample>127):raise ValueError('bad official sample')
    interp=Interpreter(model_path=str(model_path),num_threads=1,experimental_preserve_all_tensors=True,
        experimental_op_resolver_type=OpResolverType.BUILTIN_REF)
    interp.allocate_tensors();input_detail=interp.get_input_details()[0]
    if input_detail['shape'].tolist()!=[1,49,10,1] or input_detail['dtype']!=np.int8:raise ValueError('bad input contract')
    rng=np.random.default_rng(20261015)
    inputs=[('official_initializer',sample.astype(np.int8).reshape(1,49,10,1)),
        ('synthetic_min',np.full((1,49,10,1),-128,dtype=np.int8)),
        ('synthetic_max',np.full((1,49,10,1),127,dtype=np.int8)),
        ('synthetic_random',rng.integers(-128,128,size=(1,49,10,1),dtype=np.int8))]
    records=[]
    for name,x in inputs:
        interp.set_tensor(input_detail['index'],x);interp.invoke();checks=[]
        for op in info['operators']:
            if 'mnk' not in op:continue
            ix,iw,ib=op['inputs'];a=interp.get_tensor(ix);b=interp.get_tensor(iw);bias=interp.get_tensor(ib)
            zp=info['tensors'][ix]['zero_points'][0]
            if any(v!=0 for v in info['tensors'][iw]['zero_points']):raise ValueError('non-symmetric weights')
            if op['name']=='CONV_2D':
                a=conv_patches(a,b.shape,info['tensors'][op['outputs'][0]]['shape'],
                    op['stride'],op['padding'],op['dilation'],zp)
                b=b.reshape(b.shape[0],-1)
            else:a=a.reshape(-1,b.shape[1])
            check=verify_accumulator(a,b,bias,zp);check.update(op_index=op['index'],mnk=op['mnk']);checks.append(check)
        output=interp.get_tensor(interp.get_output_details()[0]['index'])
        records.append(dict(input=name,input_sha256=hashlib.sha256(x.tobytes()).hexdigest(),
            reference_output=output.tolist(),reference_argmax=int(np.argmax(output)),mapping_checks=checks))
    return dict(runtime='tflite-runtime 2.14.0 BUILTIN_REF x86_64; one thread; delegates disabled',
        samples=records,accumulator_values_exact=sum(c['values'] for r in records for c in r['mapping_checks']),
        accuracy_evaluated=False,frontend_verified=False,requantization_verified=False,
        hardware_tested=False,speedup_evaluated=False)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--assets',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--run-reference',action='store_true');a=p.parse_args()
    model=a.assets/'benchmark/training/keyword_spotting/trained_models/kws_ref_model.tflite'
    result=inventory(model.read_bytes())
    if a.run_reference:result['reference']=reference_runs(model,result,a.assets/'benchmark/reference_submissions/keyword_spotting/kws/kws_input_data.cc')
    result.update(board_access=False,promotion=False,scope='offline model structure and accumulator mapping only')
    with a.output.open('x',encoding='utf-8') as out:json.dump(result,out,indent=2)
    print(json.dumps(dict(model_sha256=MODEL_SHA,operators=result['operators'],reference=result.get('reference'))),flush=True)
if __name__=='__main__':main()
