"""PC-only DS-CNN integer candidate through pre-softmax logits.

Default-off study; not an ARM/FPGA driver. Mathematical rounding follows the
TensorFlow v2.14 double-rounding reference and gemmlowp fixedpoint definitions.
Sources: tensorflow/lite/kernels/internal/{common.cc,quantization_util.cc},
google/gemmlowp fixedpoint/fixedpoint.h (Apache-2.0). No training/weight changes.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import numpy as np
import tflite
from inspect_model import inventory,conv_patches,MODEL_SHA

def checked_i32(x):
    if np.any(x < -(1<<31)) or np.any(x >= (1<<31)):raise OverflowError('INT32 range')
    return x.astype(np.int32)

def quant_multiplier(scale):
    if not math.isfinite(scale) or scale<0:raise ValueError('invalid positive scale')
    if scale==0:return 0,0
    fraction,exponent=math.frexp(scale)
    fixed=math.floor(fraction*(1<<31)+0.5)
    if fixed==(1<<31):fixed//=2;exponent+=1
    if exponent < -31:return 0,0
    if exponent>30:raise ValueError('unsupported scale exponent')
    return fixed,exponent

def multiply_quantized(x,multiplier,shift):
    if not 0<=multiplier<(1<<31) or not -31<=shift<=30:raise ValueError('invalid multiplier/shift')
    x=np.asarray(x,dtype=np.int64)
    checked_i32(x)
    shifted=x*(1<<max(shift,0));checked_i32(shifted)
    product=shifted*int(multiplier)
    # Signed integer division in C++ truncates toward zero, unlike Python //.
    adjusted=product+np.where(product>=0,1<<30,1-(1<<30))
    high=np.where(adjusted>=0,adjusted//(1<<31),-((-adjusted)//(1<<31)))
    right=max(-shift,0);mask=(1<<right)-1
    threshold=(mask>>1)+(high<0).astype(np.int64)
    return (high>>right)+((high & mask)>threshold).astype(np.int64)

def requantize(acc,scales,zero_point,activation):
    if acc.ndim!=2 or not -128<=zero_point<=127:raise ValueError('bad requant shape/zero point')
    if activation not in (tflite.ActivationFunctionType.NONE,tflite.ActivationFunctionType.RELU):
        raise ValueError('unsupported activation')
    scales=np.broadcast_to(scales,(acc.shape[1],));out=np.empty(acc.shape,np.int8)
    lower=max(-128,zero_point) if activation==tflite.ActivationFunctionType.RELU else -128
    for col,scale in enumerate(scales):
        m,s=quant_multiplier(float(scale));value=multiply_quantized(acc[:,col],m,s)+zero_point
        out[:,col]=np.clip(value,lower,127).astype(np.int8)
    return out

class IntegerCandidate:
    def __init__(self,model_path):
        raw=Path(model_path).read_bytes();self.info=inventory(raw)
        model=tflite.Model.GetRootAsModel(raw,0);graph=model.Subgraphs(0)
        self.constants={};self.options={}
        for t in self.info['tensors']:
            buffer=model.Buffers(t['buffer'])
            if buffer.DataLength():
                dtype={'INT8':'i1','INT32':'<i4'}.get(t['dtype'])
                if dtype is None:raise ValueError('unknown constant dtype')
                self.constants[t['index']]=np.frombuffer(buffer.DataAsNumpy().tobytes(),dtype=dtype).reshape(t['shape'])
        for op in self.info['operators']:
            schema=graph.Operators(op['index']);table=schema.BuiltinOptions()
            if op['name']=='AVERAGE_POOL_2D':
                option=tflite.Pool2DOptions();option.Init(table.Bytes,table.Pos)
                self.options[op['index']]=dict(filter=[option.FilterHeight(),option.FilterWidth()],
                    stride=[option.StrideH(),option.StrideW()],padding=option.Padding(),activation=option.FusedActivationFunction())
            elif op['name']=='FULLY_CONNECTED':
                option=tflite.FullyConnectedOptions();option.Init(table.Bytes,table.Pos)
                self.options[op['index']]=dict(activation=option.FusedActivationFunction())

    def infer(self,x,compare=None):
        if x.dtype!=np.int8 or list(x.shape)!=[1,49,10,1]:raise ValueError('input contract')
        values=dict(self.constants);values[self.info['inputs'][0]]=x;checks=[]
        for op in self.info['operators']:
            name=op['name'];output=op['outputs'][0];ot=self.info['tensors'][output]
            if name=='SOFTMAX':break  # not reimplemented, never claim probability equivalence
            src=op['inputs'][0];it=self.info['tensors'][src];a=values[src]
            if name in ('CONV_2D','DEPTHWISE_CONV_2D','FULLY_CONNECTED'):
                wi,bi=op['inputs'][1:];b=values[wi];bias=values[bi];wt=self.info['tensors'][wi]
                if any(z!=0 for z in wt['zero_points']):raise ValueError('non-symmetric weights')
                zp=it['zero_points'][0]
                if name=='CONV_2D':
                    patches=conv_patches(a,b.shape,ot['shape'],op['stride'],op['padding'],op['dilation'],zp)
                    weight=b.reshape(b.shape[0],-1)
                    acc=(patches.astype(np.int32)@weight.astype(np.int32).T).astype(np.int64)
                    acc+=bias.astype(np.int64)-zp*weight.astype(np.int64).sum(axis=1)
                elif name=='DEPTHWISE_CONV_2D':
                    if b.shape[-1]!=a.shape[-1]:raise ValueError('only depth multiplier 1')
                    _,kh,kw,c=b.shape
                    patches=conv_patches(a,(c,kh,kw,c),ot['shape'],op['stride'],op['padding'],op['dilation'],zp)
                    centered=patches.reshape(-1,kh*kw,c).astype(np.int64)-zp
                    acc=(centered*b.reshape(kh*kw,c).astype(np.int64)).sum(axis=1)+bias
                else:
                    acc=(a.reshape(-1,b.shape[1]).astype(np.int32)@b.astype(np.int32).T).astype(np.int64)
                    acc+=bias.astype(np.int64)-zp*b.astype(np.int64).sum(axis=1)
                checked_i32(acc)
                scale=np.array(wt['scales'],np.float64)*float(it['scales'][0])/float(ot['scales'][0])
                activation=op.get('activation',self.options.get(op['index'],{}).get('activation',0))
                result=requantize(acc,scale,ot['zero_points'][0],activation).reshape(ot['shape'])
            elif name=='AVERAGE_POOL_2D':
                opts=self.options[op['index']]
                if opts['padding']!=tflite.Padding.VALID or opts['activation']!=0 or ot['shape']!=[1,1,1,64]:
                    raise ValueError('unsupported pool configuration')
                if it['scales']!=ot['scales'] or it['zero_points']!=ot['zero_points']:raise ValueError('pool quantization drift')
                h,w=opts['filter'];count=h*w
                if h>a.shape[1] or w>a.shape[2]:raise ValueError('invalid pool window')
                total=a[0,:h,:w,:].astype(np.int64).sum(axis=(0,1))
                result=(np.sign(total)*((np.abs(total)+count//2)//count)).astype(np.int8).reshape(ot['shape'])
            elif name=='RESHAPE':result=a.reshape(ot['shape'])
            else:raise ValueError('unsupported operator '+name)
            values[output]=result
            if compare is not None:
                expected=compare(output)
                mismatch=int(np.count_nonzero(result!=expected))
                checks.append(dict(op_index=op['index'],name=name,values=int(result.size),mismatch=mismatch))
                if mismatch:raise ValueError('candidate/reference mismatch op '+str(op['index'])+': '+str(mismatch))
        return values[33].copy(),checks

def main():
    from tflite_runtime.interpreter import Interpreter,OpResolverType
    p=argparse.ArgumentParser();p.add_argument('--assets',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();model=a.assets/'benchmark/training/keyword_spotting/trained_models/kws_ref_model.tflite'
    candidate=IntegerCandidate(model)
    reference=Interpreter(model_path=str(model),num_threads=1,experimental_preserve_all_tensors=True,
        experimental_op_resolver_type=OpResolverType.BUILTIN_REF);reference.allocate_tensors()
    source=a.assets/'benchmark/reference_submissions/keyword_spotting/kws/kws_input_data.cc'
    init=source.read_text().split('= {',1)[1].split('};',1)[0]
    official=np.array([int(v) for v in re.findall(r'-?\d+',init)],np.int8).reshape(1,49,10,1)
    rng=np.random.default_rng(20261015);rows=[]
    inputs=[('official',official),('min',np.full_like(official,-128)),('max',np.full_like(official,127))]
    inputs += [('random_'+str(i),rng.integers(-128,128,official.shape,dtype=np.int8)) for i in range(8)]
    for name,x in inputs:
        reference.set_tensor(0,x);reference.invoke()
        logits,checks=candidate.infer(x,reference.get_tensor)
        rows.append(dict(input=name,input_sha256=hashlib.sha256(x.tobytes()).hexdigest(),
            logits=logits.tolist(),checks=checks,pre_softmax_argmax=int(np.argmax(logits))))
        print(name+': all 12 pre-softmax operators exact',flush=True)
    result=dict(model_sha256=MODEL_SHA,scope='PC integer candidate through pre-softmax logits',samples=rows,
        exact_values=sum(c['values'] for r in rows for c in r['checks']),softmax_reimplemented=False,
        frontend_verified=False,accuracy_evaluated=False,board_access=False,promotion=False)
    with a.output.open('x',encoding='utf-8') as out:json.dump(result,out,indent=2)
if __name__=='__main__':main()
