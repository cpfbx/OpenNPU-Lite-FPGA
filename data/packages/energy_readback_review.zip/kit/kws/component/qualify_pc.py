"""PC qualification ONLY: fixed features to integer logits, not an ARM RUN."""
import argparse
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import sys
import textwrap
import time

HERE=Path(__file__).resolve().parent


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def qualify(pin,output):
    # Explicitly refuse use on the board: no canonical-lock/outer guard yet.
    if platform.machine().lower() not in ('amd64','x86_64'):
        raise RuntimeError('PC qualification only; ARM launch requires reviewed outer wrapper')
    result=load('portable_inventory',HERE/'verify_candidate.py').verify(HERE,pin)
    if output.exists() or output.resolve()==HERE or HERE in output.resolve().parents:
        raise ValueError('fresh output directory outside candidate required')
    forbidden=('pynq','tensorflow','tflite_runtime','tflite','flatbuffers')
    if any(n in sys.modules for n in forbidden):raise ValueError('clean native/schema-free process required')
    source=ast.parse((HERE/'portable_integer.py').read_text(encoding='utf-8'))
    oldq=ast.parse((HERE/'provenance/quantized_probe_original.py').read_text(encoding='utf-8'))
    oldi=ast.parse((HERE/'provenance/inspect_model_original.py').read_text(encoding='utf-8'))
    class Normalize(ast.NodeTransformer):
        def visit_Attribute(self,node):
            values={'tflite.ActivationFunctionType.NONE':0,'tflite.ActivationFunctionType.RELU':1,
                    'tflite.Padding.SAME':0,'tflite.Padding.VALID':1}
            name=ast.unparse(node)
            return ast.Constant(values[name]) if name in values else self.generic_visit(node)
    compared=[]
    for name,tree in [('checked_i32',oldq),('quant_multiplier',oldq),('multiply_quantized',oldq),
                      ('requantize',oldq),('conv_patches',oldi)]:
        before=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
        after=next(n for n in source.body if isinstance(n,ast.FunctionDef) and n.name==name)
        if ast.dump(Normalize().visit(before))!=ast.dump(after):raise ValueError('arithmetic AST drift: '+name)
        compared.append(name)
    old_cls=next(n for n in oldq.body if isinstance(n,ast.ClassDef) and n.name=='IntegerCandidate')
    new_cls=next(n for n in source.body if isinstance(n,ast.ClassDef) and n.name=='IntegerReference')
    before=next(n for n in old_cls.body if isinstance(n,ast.FunctionDef) and n.name=='infer')
    after=next(n for n in new_cls.body if isinstance(n,ast.FunctionDef) and n.name=='infer')
    if ast.dump(Normalize().visit(before))!=ast.dump(after):raise ValueError('infer arithmetic AST drift')
    import numpy as np
    model=load('portable_integer_reference',HERE/'portable_integer.py')
    try:model.IntegerReference(HERE/'model')
    except ValueError:pass
    else:raise ValueError('default-off guard failed')
    reference=model.IntegerReference(HERE/'model',enabled=True)
    features=np.frombuffer((HERE/'data/fixed_features.i8').read_bytes(),np.int8).reshape(420,1,49,10,1)
    expected=(HERE/'data/expected_logits.i8').read_bytes()
    raw=bytearray();started=time.monotonic()
    for i,x in enumerate(features):
        logits,checks=reference.infer(x)
        if checks or logits.shape!=(1,12) or logits.dtype!=np.int8:
            raise ValueError('pre-softmax contract')
        chunk=logits.tobytes()
        if chunk!=expected[12*i:12*(i+1)]:raise ValueError('final logits mismatch at '+str(i))
        raw.extend(chunk)
    if any(n in sys.modules for n in forbidden):raise ValueError('unexpected native/schema import')
    seconds=time.monotonic()-started
    load('portable_inventory_final',HERE/'verify_candidate.py').verify(HERE,pin)
    output.mkdir()
    (output/'logits.i8').write_bytes(raw)
    summary=dict(PC_qualification_pass=True,samples=420,exact_pre_softmax_INT8_values=len(raw),
       logits_sha256=hashlib.sha256(raw).hexdigest(),arithmetic_AST_exact_after_enum_replacement=compared+['infer'],
       original_native_or_schema_imported=False,numpy=np.__version__,platform=platform.platform(),
       elapsed_seconds_PC_diagnostic=seconds,default_off_probe_rejected=True,
       WAV_frontend_reexecuted=False,all_intermediate_values_reaudited=False,
       ARM_tested=False,board_access=False,deployable=False,promotion=False)
    with (output/'receipt.json').open('x',encoding='utf-8') as stream:json.dump(summary,stream,indent=2)
    print(json.dumps(summary))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--manifest-sha',required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();qualify(a.manifest_sha,a.output.absolute())
