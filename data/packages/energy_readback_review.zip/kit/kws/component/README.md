# DS-CNN ARM CPU参考准备：固定特征到logits组件

内部默认关闭候选；当前只在PC资格验证，没有ARM启动入口。不能在板上直接执行qualify_pc.py，脚本会拒绝ARM架构。ARM使用需后续受控规范锁/进程/退出/资源回执及独立审查，由bx批准操作。

原模型、所有常量和INT8整数推理算术不改。作者PC一次性从原模型解出常量/选项，生成只需NumPy的运行组件；不含x86 TFLite ELF、schema/flatbuffers，也不依赖TensorFlow。原源码、模型及派生记录保留；四整数函数/conv_patches/infer的AST只替换已核实枚举值，PC资格脚本逐项检查。

按外部manifest核对后，可在已有NumPy的x86-64电脑运行（输出必须在包外新目录）：

```text
python -I -B verify_candidate.py --manifest-sha <EXTERNAL_MANIFEST_SHA>
python -I -B qualify_pc.py --manifest-sha <EXTERNAL_MANIFEST_SHA> --output <NEW_ABSOLUTE_OUTPUT_OUTSIDE_CANDIDATE>
```

本轮只重算420个已有精确INT8特征的5040个pre-softmax logits，与已核验历史参考精确比较；不宣称重新读取原WAV/全部中间值审计、ARM性能或识别质量提升。现有420窗不是新盲测，前处理接线/ARM数值/资源/时延/softmax和门控均另有范围，不在此升级deployable。

数据和模型来源许可沿原MLCommons候选单独核定；原helper引用TF/gemmlowp数学定义，保留源码说明，不把这些来源整体改称团队原创。本目录仅内部研究组件，不自动公开或替换旧三层应用。缺NumPy则停，不安装/跳过/修改oracle来凑通过。
