"""Offline artifact audit only. Does not open the canonical lock or run inference."""
import argparse
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'src'))
from common import verify,read,decode,sha,publish,encode,request,require
from audit import evaluate


def audit_return(root,pin,evidence,request_sha,output):
    root,evidence,output=[Path(p).absolute() for p in (root,evidence,output)]
    verify(root,pin)
    for source in (root,evidence):
        require(source.resolve()==source and source.is_dir(),'canonical source tree')
        require(output!=source and source not in output.parents and output not in source.parents,'separate audit output')
    require(output.resolve()==output and not output.exists(),'fresh audit output')
    output.mkdir()
    sources={}
    def raw(path,size):
        value=read(path,size);sources[Path(path)]=sha(value);return value
    def doc(path,size=16384):return decode(raw(path,size))
    report=dict(operation_success=False,board_access=False,source_origin_authenticated=False,
                independently_reexecuted_inference=False,deployable=False,promotion=False)
    try:
        chosen_raw=raw(evidence/'request.json',16384)
        require(sha(chosen_raw)==request_sha,'external request identity')
        chosen=request(decode(chosen_raw))
        outer=doc(evidence/'outer_receipt.json',1024*1024)
        observed=doc(evidence/'observation/actual_exit.json')
        worker=doc(evidence/'worker_final.json',1024*1024)
        numerical=doc(evidence/'worker/numerical/numerical_receipt.json',1024*1024)
        checks=evaluate(observed,worker,numerical,
            raw(evidence/'worker/numerical/features.i8',205800),
            raw(evidence/'worker/numerical/logits.i8',5040),outer.get('release_readback',{}),chosen,
            doc(root/'data/cohort.json',1024*1024))
        require(all(checks.values()),'recorded OS/numeric/lock checks')
        require(outer.get('operation_success') is True and outer.get('manifest_sha256')==pin
            and outer.get('request_sha256')==request_sha and outer.get('stop_signals')==[]
            and outer.get('handler_restore_errors')==[] and outer.get('deployable') is False
            and outer.get('promotion') is False and outer.get('FPGA_access') is False
            and outer.get('energy_evaluated') is False and outer.get('board_access') is True
            and encode(outer.get('checks'))==encode(checks)
            and encode(outer.get('observed_os'))==encode(observed)
            and encode(outer.get('worker'))==encode(worker),'outer/raw records differ')
        report.update(operation_success=True,checks=checks,mode=chosen['mode'],samples=420)
    except Exception as error:
        report.update(operation_success=False,error_type=type(error).__name__,error=str(error))
    finally:
        changed=[]
        for path,pin_value in sources.items():
            try:
                if sha(read(path,1024*1024))!=pin_value:changed.append(str(path))
            except (OSError,ValueError):changed.append(str(path))
        report['sources_unchanged']=not changed
        if changed:report['operation_success']=False
        report['source_sha256']={str(k):v for k,v in sources.items()}
        try:verify(root,pin);report['package_unchanged']=True
        except (ValueError,OSError):report['package_unchanged']=False;report['operation_success']=False
        publish(output/'readback.json',report)
    return report


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--manifest-sha',required=True);p.add_argument('--request-sha',required=True)
    p.add_argument('--evidence',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();r=audit_return(ROOT,a.manifest_sha,a.evidence,a.request_sha,a.output)
    print(dict(operation_success=r['operation_success'],board_access=False,promotion=False))
    raise SystemExit(0 if r['operation_success'] else 1)
