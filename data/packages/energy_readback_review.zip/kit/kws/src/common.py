"""Pure bounded candidate data and dependency binding; no board actions."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat

COMPONENT_SHA = 'dfb084d794106230aee524978e2ff62fe4249ff5ab50a6dc4434330a8f55e3a9'
FEATURE_SHA = '9fd7517250011f7b9e1d8e70e96085041f2136aa5e13f1392ff204bf6e7e4480'
LOGITS_SHA = 'de2b0d1355fdcbfc296bbb5b4c2f18e4748e346af779c1c71884f5c60f3320c8'
LOCK = '/tmp/opennpu-kws-chain.lock'


def require(value, message):
    if not value: raise ValueError(message)


def sha(raw): return hashlib.sha256(raw).hexdigest()


def decode(raw):
    def pairs(items):
        result = {}
        for k, v in items:
            require(k not in result, 'duplicate JSON key')
            result[k] = v
        return result
    def bad(value): raise ValueError('nonfinite JSON')
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=bad)


def encode(value):
    return (json.dumps(value, sort_keys=True, allow_nan=False)+'\n').encode('utf-8')


def read(path, limit):
    path = Path(path).absolute()
    require(path.resolve() == path and stat.S_ISREG(path.lstat().st_mode), 'canonical regular input')
    with path.open('rb') as stream: raw = stream.read(limit+1)
    require(len(raw) <= limit, 'input byte bound')
    return raw


def publish(path, value):
    raw = value if type(value) is bytes else encode(value)
    with Path(path).open('xb') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify(root, pin):
    root = Path(root).absolute()
    result = load('_kws_runtime_inventory', root/'verify_kit.py').verify(root, pin)
    load('_kws_component_inventory', root/'component/verify_candidate.py').verify(root/'component', COMPONENT_SHA)
    return result


def request(value):
    fields = {'component_manifest_sha256', 'mode', 'samples', 'board_serial', 'pynq_image', 'boot_id',
              'expected_lock', 'operator', 'scope'}
    require(type(value) is dict and set(value) == fields, 'exact explicit CPU reference request')
    require(value['component_manifest_sha256'] == COMPONENT_SHA, 'original integer component')
    require(type(value['mode']) is str and value['mode'] in ('fixed_features', 'public_wav'), 'explicit input mode')
    require(type(value['samples']) is int and value['samples'] == 420, 'fixed 420 cohort only')
    require(value['board_serial'] == 'ftdi-1234-tulB' and value['pynq_image'] == 'pynq-z2-v3.1.1', 'original declarations')
    require(value['operator'] == 'bx' and value['scope'] == 'CPU-REFERENCE-NO-PL-NO-DEPLOYMENT', 'diagnostic scope')
    require(type(value['boot_id']) is str and re.fullmatch('[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}',value['boot_id']), 'explicit boot id')
    lock = value['expected_lock']
    require(type(lock) is dict and set(lock) == {'path','device','inode','uid','mode','links'}, 'exact expected lock')
    require(lock['path'] == LOCK, 'canonical lock only')
    for key in ('device','inode','uid','mode','links'):
        require(type(lock[key]) is int and lock[key] >= 0, 'integer lock property')
    require(lock['inode'] > 0 and lock['uid'] == 1000 and lock['mode'] == 0o644 and lock['links'] == 1,
            'original single-link lock identity')
    return decode(encode(value))


def check_lock_stat(info, expected):
    require(stat.S_ISREG(info.st_mode), 'regular existing lock')
    actual = dict(path=LOCK,device=info.st_dev,inode=info.st_ino,uid=info.st_uid,
                  mode=stat.S_IMODE(info.st_mode),links=info.st_nlink)
    require(encode(actual) == encode(expected), 'canonical lock identity changed')
    return actual
