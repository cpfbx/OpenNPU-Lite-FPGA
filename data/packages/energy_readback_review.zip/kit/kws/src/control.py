"""CPU-only lease lifecycle. Unknown descriptor release remains quarantined."""
import contextlib
import os
from pathlib import Path
import platform
import re
import signal
import stat
import sys
import time
from common import require, read, decode, encode, publish, request, verify, check_lock_stat, LOCK, sha

_RETAINED = []


@contextlib.contextmanager
def stopping(stops):
    previous = {}; errors = []
    def latch(number,frame):
        if number not in stops: stops.append(number)
    try:
        for name in ('SIGINT','SIGTERM','SIGHUP'):
            if not hasattr(signal,name): continue
            n = getattr(signal,name); previous[n] = signal.getsignal(n); signal.signal(n,latch)
        yield errors
    finally:
        for n,handler in previous.items():
            try: signal.signal(n,handler)
            except BaseException as error: errors.append(dict(signal=n,error_type=type(error).__name__))


def arm_only():
    require(platform.system()=='Linux' and platform.machine()=='armv7l' and sys.byteorder=='little'
            and platform.release()=='6.6.10-xilinx-v2024.1-g3c0eca68c652','original ARMv7 runtime only')
    require(os.geteuid()==0,'original root operator required')


def preflight(chosen):
    chosen = request(chosen)
    arm_only()
    require(read('/proc/sys/kernel/random/boot_id',128).decode().strip()==chosen['boot_id'],'current boot identity')
    return check_lock_stat(os.lstat(LOCK),chosen['expected_lock'])


def stopped(path,signals):
    path = Path(path)
    if path.exists() or path.is_symlink():
        read(path,4096)  # Reject aliases/special files instead of treating them as harmless flags.
        return True
    return bool(signals)


def released(expected,*,stat_reader=os.lstat,locks_reader=None):
    check_lock_stat(stat_reader(LOCK),expected)
    text = (read('/proc/locks',4*1024*1024).decode('ascii') if locks_reader is None else locks_reader())
    target = (os.major(expected['device']),os.minor(expected['device']),expected['inode'])
    for line in text.splitlines():
        for token in line.split():
            if re.fullmatch('[0-9a-fA-F]+:[0-9a-fA-F]+:[0-9]+',token):
                a,b,c = token.split(':')
                require((int(a,16),int(b,16),int(c))!=target,'canonical inode still has a kernel lock')
    return dict(path=LOCK,device=expected['device'],inode=expected['inode'],lock_released_same_inode=True,
                source='lstat + read-only proc/locks; no acquisition probe',proof_is_snapshot=True)


def no_own_descriptor(expected):
    """After a failed enter, observe whether its original helper closed its fd."""
    for entry in Path('/proc/self/fd').iterdir():
        try: opened=entry.stat()
        except FileNotFoundError: continue
        if (opened.st_dev,opened.st_ino)==(expected['device'],expected['inode']): return False
    return True


def worker_core(root,pin,chosen,output,stop_path,signals,*,lease_factory,reference_factory,
                acquisition_failure_closed=no_own_descriptor,fixture=False):
    """Trusted seam for offline fakes, never injectable through the CLI."""
    from engine import run
    chosen=request(chosen)
    output=Path(output);output.mkdir()
    report=dict(operation_success=False,fixture=fixture,board_access=not fixture,FPGA_access=False,
                deployable=False,promotion=False,lease_released=False,quarantined=False,
                component_manifest_sha256=chosen['component_manifest_sha256'],request=chosen)
    lease=None;entered=False;error=None;last_proof=None
    try:
        require(not stopped(stop_path,signals),'stop before lease acquisition')
        lease=lease_factory()
        lease.__enter__();entered=True
        def guard():
            nonlocal last_proof
            proof=lease.audit()
            require(type(proof) is dict and proof.get('path')==LOCK
                    and type(proof.get('device')) is int and type(proof.get('inode')) is int
                    and (proof['device'],proof['inode'])==(chosen['expected_lock']['device'],chosen['expected_lock']['inode'])
                    and proof.get('exclusive_flock') is True and proof.get('cloexec') is True,'fresh original lease proof')
            last_proof=proof
        guard()
        require(not stopped(stop_path,signals),'stop before model initialization')
        reference=reference_factory(root,chosen['mode'])
        guard()
        result=run(reference,output/'numerical',guard,lambda:stopped(stop_path,signals),fixture=fixture)
        report['numerical']=dict(operation_success=result['operation_success'],started=result['started'],
            completed=result['completed'],exact_checked=result['exact_checked'],accepted=result['accepted'],
            features_sha256=result['features_sha256'],logits_sha256=result['logits_sha256'])
        if not result['operation_success']: raise RuntimeError('numerical loop incomplete/failed/stopped')
        guard()
        require(not stopped(stop_path,signals),'stop before worker completion')
        report['operation_success']=True
    except BaseException as failure:
        error=failure
        report.update(operation_success=False,error_type=type(failure).__name__,error=str(failure))
    finally:
        if lease is not None:
            try:
                if entered:
                    lease.__exit__(None,None,None)
                    report['lease_released']=True
                elif acquisition_failure_closed(chosen['expected_lock']) is True:
                    report['lease_released']=True
                    report['acquire_failed_no_own_descriptor']=True
                else:
                    raise RuntimeError('acquisition failed but original fd closure is unknown')
            except BaseException as cleanup:
                report.update(operation_success=False,quarantined=True,cleanup_error_type=type(cleanup).__name__)
                _RETAINED.append(lease)  # Keep generator/context alive; private CLI must stay alive too.
        report['last_lock_proof']=last_proof
        report['stop_signals']=list(signals)
        if signals: report['operation_success']=False
        publish(output/'worker_receipt.json',report)
    return report


def quarantine_forever():
    # No cleanup retry, no automatic timeout, no SIGKILL. A live process is
    # necessary: exiting would cause the kernel to close a quarantined fd.
    print('QUARANTINE: cleanup unknown; process retains lease. Human follow-up required.',flush=True)
    while True: time.sleep(1)
