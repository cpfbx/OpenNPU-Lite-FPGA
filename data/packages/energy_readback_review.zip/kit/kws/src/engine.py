"""Bounded CPU reference loop. Guards are fresh; entered windows finish on stop."""
from pathlib import Path
import time
from common import decode, read, sha, require, load, publish, FEATURE_SHA, LOGITS_SHA


class UnitFailure(ValueError):
    def __init__(self,message,features=b'',logits=b''):
        super().__init__(message)
        self.features,self.logits=features,logits


class Reference:
    def __init__(self,root,mode):
        import numpy as np
        self.np = np
        self.root = Path(root)
        require(mode in ('fixed_features','public_wav'),'exact reference mode')
        self.mode = mode
        self.features = read(self.root/'component/data/fixed_features.i8',205800)
        self.expected = read(self.root/'component/data/expected_logits.i8',5040)
        require(len(self.features)==205800 and sha(self.features)==FEATURE_SHA,'fixed features identity')
        require(len(self.expected)==5040 and sha(self.expected)==LOGITS_SHA,'fixed logits identity')
        self.items = decode(read(self.root/'data/cohort.json',1024*1024))
        require(type(self.items) is list and len(self.items)==420,'fixed cohort')
        model = load('_arm_integer_reference',self.root/'component/portable_integer.py')
        self.model = model.IntegerReference(self.root/'component/model',enabled=True)
        self.frontend = None
        if mode == 'public_wav':
            from frontend import Frontend
            self.frontend = Frontend(self.root)

    def compute(self,index,guard):
        np = self.np
        expected = self.features[index*490:(index+1)*490]
        guard()  # Fresh lock/owner-health proof, not a reusable permit.
        started = time.perf_counter_ns()
        if self.frontend is None:
            value = np.frombuffer(expected,np.int8).reshape(49,10)
            extra = dict(WAV_frontend_reexecuted=False)
        else:
            value,extra = self.frontend.process(self.items[index])
            extra['WAV_frontend_reexecuted'] = True
        if type(value) is not np.ndarray or value.dtype!=np.int8 or value.shape!=(49,10):
            raise UnitFailure('feature shape/type')
        raw = value.tobytes(order='C')
        frontend_ns = time.perf_counter_ns()-started
        if raw != expected:
            raise UnitFailure('exact feature mismatch',features=raw)
        guard()  # Finish an already-entered window even if stop was latched.
        started = time.perf_counter_ns()
        logits,checks = self.model.infer(value.reshape(1,49,10,1))
        inference_ns = time.perf_counter_ns()-started
        if checks or logits.shape!=(1,12) or logits.dtype!=np.int8:
            raise UnitFailure('logits shape/type/intermediate contract',features=raw)
        return raw,logits.tobytes(order='C'),dict(frontend_ns=frontend_ns,inference_ns=inference_ns,**extra)


def run(reference,output,guard,stopped,*,samples=420,fixture=False):
    require(type(samples) is int and 0 < samples <= 420,'bounded reference loop')
    output=Path(output);output.mkdir()
    report=dict(operation_success=False,started=0,completed=0,exact_checked=0,accepted=0,
        samples=samples,rows=[],stop_requested=False,fixture=fixture,deployable=False,promotion=False,
        classification_quality_accepted=False,FPGA_access=False,energy_evaluated=False,
        scope='fixed CPU numerical reference, not new independent quality evaluation')
    feature_output=bytearray();logit_output=bytearray();failure_features=b'';failure_logits=b''
    try:
        for index in range(samples):
            if stopped() is not False:
                report['stop_requested']=True
                break
            guard()
            # A signal may latch while auditing; recheck immediately before entry.
            if stopped() is not False:
                report['stop_requested']=True
                break
            report['started']+=1
            raw,logits,timing=reference.compute(index,guard)
            require(type(raw) is bytes and len(raw)==490 and type(logits) is bytes and len(logits)==12,'exact output extents')
            report['completed']+=1
            feature_output.extend(raw);logit_output.extend(logits)
            expected_features=reference.features[index*490:(index+1)*490]
            expected_logits=reference.expected[index*12:(index+1)*12]
            if raw!=expected_features or logits!=expected_logits:
                raise UnitFailure('exact reference mismatch',features=raw,logits=logits)
            report['exact_checked']+=1
            guard()
            stop=stopped() is not False
            report['rows'].append(dict(index=index,source_id=reference.items[index]['source_id'],
                feature_sha256=sha(raw),logits_sha256=sha(logits),exact=True,accepted=not stop,**timing))
            if stop:
                report['stop_requested']=True
                break
            report['accepted']+=1
        report['operation_success']=report['accepted']==samples and not report['stop_requested']
    except BaseException as error:
        report.update(operation_success=False,error_type=type(error).__name__,error=str(error))
        failure_features=getattr(error,'features',b'');failure_logits=getattr(error,'logits',b'')
    finally:
        report.update(features_sha256=sha(feature_output),logits_sha256=sha(logit_output))
        report['persistence_errors']=[]
        artifacts=[('features.i8',bytes(feature_output)),('logits.i8',bytes(logit_output))]
        if failure_features:artifacts.append(('first_failure_features.i8',failure_features))
        if failure_logits:artifacts.append(('first_failure_logits.i8',failure_logits))
        for name,raw in artifacts:
            try:publish(output/name,raw)
            except BaseException as error:
                report['operation_success']=False
                report['persistence_errors'].append(dict(file=name,error_type=type(error).__name__))
        try:publish(output/'numerical_receipt.json',report)
        except BaseException as error:
            report['operation_success']=False
            report['persistence_errors'].append(dict(file='numerical_receipt.json',error_type=type(error).__name__))
    return report
