"""Single fixed-parameter public-WAV path; no TF, labels or answer-table lookup."""
import io
from pathlib import Path
import wave
import numpy as np
from common import decode, read, sha, require, load


class Frontend:
    def __init__(self, root):
        self.root = Path(root)
        folder = self.root/'frontend'
        self.fft = load('_runtime_fft512', folder/'KWS-upstream-five-20261022_01/fft512_probe.py')
        self.base = self.fft.source()
        self.dct = load('_runtime_dct', folder/'dct_probe.py')
        self.lut = self.base.tables(folder/'TensorFFT.h')
        params = decode(read(folder/'parameters/manifest.json',16384))
        self.params = {}
        for name, shape in [('tf_hann.f32',(480,)),('tf_mel_weights.f32',(257,40))]:
            raw = read(folder/'parameters'/name, 50000)
            require(sha(raw) == params['files'][name]['sha256'] and len(raw) == params['files'][name]['bytes'], 'parameter bytes')
            value = np.frombuffer(raw,'<f4').reshape(shape)
            require(np.isfinite(value).all(),'finite fixed parameters')
            self.params[name] = value

    def process(self, item):
        name = item['wav']
        require(type(name) is str and Path(name).name == name and name.endswith('.wav'), 'public WAV basename')
        raw = read(self.root/'public_wav'/name, 16*1024*1024)
        require(sha(raw) == item['source_sha256'], 'public WAV source identity')
        with wave.open(io.BytesIO(raw),'rb') as stream:
            require((stream.getnchannels(),stream.getsampwidth(),stream.getframerate()) == (1,2,16000), 'original WAV domain')
            require(type(item['offset']) is int and 0 <= item['offset'] < stream.getnframes(), 'fixed offset')
            stream.setpos(item['offset'])
            pcm = np.frombuffer(stream.readframes(16000),'<i2').copy()
        require(0 < len(pcm) <= 16000 and int(pcm.max()) > 0, 'unchanged positive-max normalization domain')
        padded = np.pad(pcm,(0,16000-len(pcm))).astype('<i2')
        require(sha(padded.tobytes()) == item['pcm_sha256'], 'fixed padded PCM identity')
        # Same order as the independently replayed reference-parameter variant.
        audio = np.pad(pcm.astype(np.float32)/np.float32(pcm.max()),(0,16000-len(pcm)))
        frames = np.stack([audio[i*320:i*320+480] for i in range(49)])
        spectrum = self.fft.rfft512(frames*self.params['tf_hann.f32'],self.lut,self.base)
        magnitude = np.hypot(spectrum.real,spectrum.imag)
        logmel = np.log(magnitude@self.params['tf_mel_weights.f32']+np.float32(1e-6))
        features = self.dct.rotate_rfft(self.base.rfft80(logmel,self.lut))
        return self.dct.source_cast(features), dict(original_samples=len(pcm),pcm_sha256=sha(padded.tobytes()),
            fixed_reference_parameters=True,float_MFCC_bit_exact_claimed=False)
