"""Pure artifact/OS consistency checks, not hardware authentication or quality."""
from common import sha, encode, COMPONENT_SHA, FEATURE_SHA, LOGITS_SHA, LOCK, request


def evaluate(observed,worker,numerical,features,logits,release,chosen,cohort):
    chosen=request(chosen)
    checks={}
    def put(key,value):checks[key]=value is True
    put('actual_exit',type(observed.get('actual_child_exit_code')) is int and observed['actual_child_exit_code']==0)
    put('process_group_absent',observed.get('process_group_absent') is True and observed.get('group_query_injected') is False)
    put('clean_observer',observed.get('observer_clean') is True and observed.get('stop_requested') is False)
    put('worker',worker.get('operation_success') is True and worker.get('fixture') is False
        and worker.get('board_access') is True and worker.get('FPGA_access') is False
        and worker.get('lease_released') is True and worker.get('quarantined') is False
        and worker.get('handler_restore_errors')==[] and worker.get('stop_signals')==[]
        and worker.get('deployable') is False and worker.get('promotion') is False)
    put('request',encode(worker.get('request'))==encode(chosen)
        and worker.get('component_manifest_sha256')==COMPONENT_SHA)
    runtime=worker.get('runtime',{})
    put('runtime',runtime.get('system')=='Linux' and runtime.get('machine')=='armv7l'
        and runtime.get('kernel')=='6.6.10-xilinx-v2024.1-g3c0eca68c652' and runtime.get('byteorder')=='little'
        and runtime.get('forbidden_modules_imported') is False
        and type(runtime.get('numpy')) is str and bool(runtime['numpy'])
        and runtime.get('thread_environment')==dict(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1'))
    proof=worker.get('last_lock_proof',{})
    put('owned_lease',type(proof.get('pid')) is int and proof['pid']==observed.get('child_pid')
        and proof.get('path')==LOCK and proof.get('exclusive_flock') is True and proof.get('cloexec') is True
        and all(type(proof.get(k)) is int and proof[k]==chosen['expected_lock'][k] for k in ('device','inode')))
    put('release',release.get('lock_released_same_inode') is True and release.get('path')==LOCK
        and all(type(release.get(k)) is int and release[k]==chosen['expected_lock'][k] for k in ('device','inode')))
    put('counts',all(type(numerical.get(k)) is int and numerical[k]==420
                    for k in ('samples','started','completed','exact_checked','accepted')))
    put('numerical',numerical.get('operation_success') is True and numerical.get('stop_requested') is False
        and numerical.get('fixture') is False and numerical.get('FPGA_access') is False
        and numerical.get('persistence_errors')==[]
        and numerical.get('deployable') is False and numerical.get('promotion') is False
        and numerical.get('energy_evaluated') is False and numerical.get('classification_quality_accepted') is False)
    put('raw_features',type(features) is bytes and len(features)==205800 and sha(features)==FEATURE_SHA
        and numerical.get('features_sha256')==FEATURE_SHA)
    put('raw_logits',type(logits) is bytes and len(logits)==5040 and sha(logits)==LOGITS_SHA
        and numerical.get('logits_sha256')==LOGITS_SHA)
    put('worker_counts_and_hashes',encode(worker.get('numerical'))==encode({k:numerical.get(k) for k in (
        'operation_success','started','completed','exact_checked','accepted','features_sha256','logits_sha256')}))
    rows=numerical.get('rows');valid=type(rows) is list and len(rows)==420 and type(cohort) is list and len(cohort)==420
    if valid:
        for i,row in enumerate(rows):
            valid=valid and (type(row) is dict and type(row.get('index')) is int and row['index']==i
                and row.get('source_id')==cohort[i]['source_id'] and row.get('exact') is True and row.get('accepted') is True
                and row.get('WAV_frontend_reexecuted') is (chosen['mode']=='public_wav')
                and row.get('feature_sha256')==sha(features[i*490:(i+1)*490])
                and row.get('logits_sha256')==sha(logits[i*12:(i+1)*12])
                and all(type(row.get(k)) is int and row[k]>=0 for k in ('frontend_ns','inference_ns')))
            if not valid:break
            if chosen['mode']=='public_wav':
                valid=(row.get('pcm_sha256')==cohort[i]['pcm_sha256'] and row.get('fixed_reference_parameters') is True
                    and row.get('float_MFCC_bit_exact_claimed') is False
                    and type(row.get('original_samples')) is int and 0<row['original_samples']<=16000)
                if not valid:break
    put('all_420_rows',valid)
    return checks
