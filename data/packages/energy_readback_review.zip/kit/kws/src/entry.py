"""Review-only CPU reference outer. Public check only; no approved board RUN."""
import argparse
import os
from pathlib import Path
import sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent.parent
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'frozen')]
from common import verify,read,decode,sha,publish,request,require,LOCK
import control


def outside(root,path,*,fresh):
    path=Path(path).absolute()
    require(path.resolve()==path and path!=root and root not in path.parents and path not in root.parents,'separate canonical evidence tree')
    require(not path.exists() if fresh else path.is_dir(),'fresh/existing evidence tree required')
    return path


def worker(pin,chosen,evidence):
    control.preflight(chosen)
    evidence=outside(ROOT,evidence,fresh=False)
    from os_evidence import ObservedLease
    from kws_threeway_entry_support_draft import existing_shared_lock_draft
    stops=[];result=None
    with control.stopping(stops) as restore_errors:
        try:
            forbidden=('pynq','tensorflow','tflite_runtime','tflite','flatbuffers')
            require(not any(n in sys.modules for n in forbidden),'fresh schema/native/device-free worker')
            # Only now import NumPy and the exact original integer component.
            from engine import Reference
            result=control.worker_core(ROOT,pin,chosen,evidence/'worker',evidence/'stop.flag',stops,
                lease_factory=lambda:ObservedLease(existing_shared_lock_draft),reference_factory=Reference)
            require(not any(n in sys.modules for n in forbidden),'unexpected schema/native/device import')
            import platform
            numpy=sys.modules.get('numpy')
            result['runtime']=dict(python=sys.version,machine=platform.machine(),system=platform.system(),
                kernel=platform.release(),byteorder=sys.byteorder,
                numpy=None if numpy is None else numpy.__version__,numpy_file=None if numpy is None else numpy.__file__,
                thread_environment={k:os.environ.get(k) for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')},
                forbidden_modules_imported=False)
        except BaseException as error:
            result=dict(operation_success=False,error_type=type(error).__name__,promotion=False,
                        deployable=False,quarantined=bool(control._RETAINED))
        if result.get('quarantined'):
            result['handlers_retained_during_quarantine']=True
            try:publish(evidence/'worker_final.json',result)
            finally:control.quarantine_forever()
    result['handler_restore_errors']=restore_errors
    result['stop_signals']=list(stops)
    if restore_errors or stops: result['operation_success']=False
    try:
        if control.stopped(evidence/'stop.flag',stops):result['operation_success']=False
    except BaseException as stop_error:
        result.update(operation_success=False,stop_readback_error_type=type(stop_error).__name__)
    publish(evidence/'worker_final.json',result)
    return result


def parent(pin,chosen,evidence):
    control.preflight(chosen)
    evidence=outside(ROOT,evidence,fresh=True);evidence.mkdir()
    publish(evidence/'request.json',chosen)
    request_sha=sha(read(evidence/'request.json',16384))
    from batch_observer import observe
    command=[sys.executable,'-I','-B',str(ROOT/'src/entry.py'),'_worker','--manifest-sha',pin,
        '--request',str(evidence/'request.json'),'--request-sha',request_sha,'--evidence',str(evidence),
        '--enable-private-candidate']
    stop=[];errors=[];sent=False;report=dict(operation_success=False,board_access=True,FPGA_access=False,
        manifest_sha256=pin,request_sha256=request_sha,deployable=False,promotion=False,energy_evaluated=False)
    def send_stop():
        nonlocal sent
        if not sent:
            sent=True
            flag=evidence/'stop.flag'
            if not flag.exists():publish(flag,b'CPU reference stop\n')
    try:
        with control.stopping(stop) as errors:
            # Child-only thread limits. No parent/system environment mutation.
            import subprocess
            def spawn(argv,**kwargs):
                env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',
                         PYTHONDONTWRITEBYTECODE='1')
                env.pop('PYTHONPATH',None);kwargs['env']=env
                return subprocess.Popen(argv,**kwargs)
            observed=observe(command,evidence/'observation',lambda:control.stopped(evidence/'stop.flag',stop),
                             send_stop,enabled=True,popen_factory=spawn)
            report['observed_os']=observed
            final=decode(read(evidence/'worker_final.json',1024*1024))
            report['worker']=final
            require(type(observed.get('actual_child_exit_code')) is int and observed['actual_child_exit_code']==0
                    and observed.get('process_group_absent') is True and observed.get('observer_clean') is True
                    and observed.get('group_query_injected') is False and observed.get('stop_requested') is False,'actual clean OS exit required')
            require(final.get('operation_success') is True and final.get('lease_released') is True
                    and final.get('quarantined') is False and final.get('handler_restore_errors')==[], 'worker completion/lease proof')
            require(not control.stopped(evidence/'stop.flag',stop),'stop before outer acceptance')
            report['release_readback']=control.released(chosen['expected_lock'])
            from audit import evaluate
            numerical=decode(read(evidence/'worker/numerical/numerical_receipt.json',1024*1024))
            proof=evaluate(observed,final,numerical,
                read(evidence/'worker/numerical/features.i8',205800),
                read(evidence/'worker/numerical/logits.i8',5040),report['release_readback'],chosen,
                decode(read(ROOT/'data/cohort.json',1024*1024)))
            report['checks']=proof
            require(all(proof.values()),'outer exact artifact/count/provenance checks')
            verify(ROOT,pin)
            report['operation_success']=True
        report['handler_restore_errors']=errors
        if errors:report['operation_success']=False
    except BaseException as error:
        report.update(operation_success=False,error_type=type(error).__name__,error=str(error))
        path=evidence/'observation/actual_exit.json'
        if path.exists():
            report['observed_os']=decode(read(path,16384))
            if (type(report['observed_os'].get('actual_child_exit_code')) is int
                    and report['observed_os'].get('process_group_absent') is True):
                try:report['release_readback']=control.released(chosen['expected_lock'])
                except BaseException as proof_error:report['release_readback_error_type']=type(proof_error).__name__
    finally:
        report['stop_signals']=stop
        report['handler_restore_errors']=errors
        if stop or errors:report['operation_success']=False
        try:
            if control.stopped(evidence/'stop.flag',stop):report['operation_success']=False
        except BaseException as stop_error:
            report.update(operation_success=False,stop_readback_error_type=type(stop_error).__name__)
        publish(evidence/'outer_receipt.json',report)
    return report


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('operation',choices=['check','parent','_worker'])
    parser.add_argument('--manifest-sha',required=True)
    parser.add_argument('--request',type=Path);parser.add_argument('--request-sha')
    parser.add_argument('--evidence',type=Path)
    parser.add_argument('--enable-private-candidate',action='store_true')
    args=parser.parse_args();verify(ROOT,args.manifest_sha)
    if args.operation=='check':
        print('CHECK ONLY: exact CPU reference bytes; no lock/native/model/board load.');return 0
    require(args.enable_private_candidate is True,'private runtime disabled; no released board RUN')
    raw=read(args.request,16384);require(sha(raw)==args.request_sha,'external request pin required')
    chosen=request(decode(raw))
    if args.operation=='parent':
        require(input('bx only: exact reviewed CPU-only request/UTC/idle/wiring approved? Type CPU420: ')=='CPU420','operator confirmation')
        result=parent(args.manifest_sha,chosen,args.evidence)
    else:result=worker(args.manifest_sha,chosen,args.evidence)
    print(dict(operation_success=result['operation_success'],deployable=False,promotion=False))
    return 0 if result['operation_success'] else 1


if __name__=='__main__':raise SystemExit(main())
