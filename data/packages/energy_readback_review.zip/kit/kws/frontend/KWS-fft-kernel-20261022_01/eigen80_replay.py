# Diagnostic translation of Eigen TensorFFT arithmetic for the fixed length 80.
# Based on TensorFFT.h, Copyright (C) 2015 Jianwei Cui <thucjw@gmail.com>.
# This file is subject to the Mozilla Public License, v. 2.0.
# https://mozilla.org/MPL/2.0/ ; source provenance: source_notes.md.
# No production use, no answer tables, no changed quantization policy.
import hashlib
import math
from pathlib import Path
import re
import numpy as np

HEADER_SHA='d352382b28211235c36795efa512f4cefd40c2319add9a2b57bb7e1df8828ba8'


def cmul(left,right):
    # Explicit scalar-product rounding, matching the observed sampled ELF code.
    # Do not rely on NumPy's complex ufunc implementation or fused instructions.
    real=np.float32(left.real*right.real)-np.float32(left.imag*right.imag)
    imag=np.float32(left.real*right.imag)+np.float32(left.imag*right.real)
    result=np.asarray(real,dtype=np.complex64).copy();result.imag=imag
    return result


def tables(header):
    raw=Path(header).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=HEADER_SHA:raise ValueError('installed TensorFFT header drift')
    text=raw.decode('utf-8')
    result=[]
    for name in ('m_sin_PI_div_n_LUT','m_minus_sin_2_PI_div_n_LUT'):
        match=re.search(re.escape(name)+r'\[32\]\s*=\s*\{(.*?)\};',text,re.S)
        if not match:raise ValueError('twiddle table not found')
        values=re.findall(r'RealScalar\(\s*([^()]+)\)',match.group(1))
        if len(values)!=32:raise ValueError('twiddle table size')
        result.append(np.array([float(x) for x in values],dtype=np.float32))
    return result


def butterfly8(data,inverse):
    u=np.empty_like(data);v=np.empty_like(data)
    sign=1 if inverse else -1
    quarter=np.complex64(complex(0,sign))
    for k in (0,4):
        u[:,k]=data[:,k]+data[:,k+1];u[:,k+1]=data[:,k]-data[:,k+1]
        u[:,k+2]=data[:,k+2]+data[:,k+3];u[:,k+3]=cmul(data[:,k+2]-data[:,k+3],quarter)
    for k in (0,4):
        v[:,k]=u[:,k]+u[:,k+2];v[:,k+1]=u[:,k+1]+u[:,k+3]
        v[:,k+2]=u[:,k]-u[:,k+2];v[:,k+3]=u[:,k+1]-u[:,k+3]
    root=.7071067811865476
    v[:,5]=cmul(u[:,5]+u[:,7],np.complex64(complex(root,sign*root)))
    v[:,6]=cmul(u[:,4]-u[:,6],quarter)
    v[:,7]=cmul(u[:,5]-u[:,7],np.complex64(complex(-root,sign*root)))
    data[:,:4]=v[:,:4]+v[:,4:];data[:,4:]=v[:,:4]-v[:,4:]


def merge(data,inverse,lut):
    n=data.shape[1];k=n.bit_length()-1
    real,imag=lut[0][k],lut[1][k]
    if inverse:imag=-imag
    wp=np.complex64(complex(real,imag))+np.complex64(1)
    wp2=cmul(wp,wp);wp3=cmul(wp2,wp);wp4=cmul(wp3,wp)
    w=np.complex64(1);half=n//2
    for i in range(0,half,4):
        tmp0=cmul(data[:,i+half],w)
        tmp1=cmul(cmul(data[:,i+1+half],w),wp)
        tmp2=cmul(cmul(data[:,i+2+half],w),wp2)
        tmp3=cmul(cmul(data[:,i+3+half],w),wp3)
        w=cmul(w,wp4)
        for j,tmp in enumerate((tmp0,tmp1,tmp2,tmp3)):
            a=data[:,i+j].copy();data[:,i+j+half]=a-tmp;data[:,i+j]=a+tmp


def pow2_fft(value,inverse,lut):
    n=value.shape[1]
    if n not in (256,):raise ValueError('diagnostic fixed internal FFT size only')
    bits=n.bit_length()-1
    reverse=[int(format(i,'0'+str(bits)+'b')[::-1],2) for i in range(n)]
    data=value[:,reverse].copy()
    def recurse(part):
        if part.shape[1]==8:butterfly8(part,inverse)
        else:
            half=part.shape[1]//2;recurse(part[:,:half]);recurse(part[:,half:]);merge(part,inverse,lut)
    recurse(data);return data


def rfft80(value,lut):
    if type(value) is not np.ndarray or value.dtype!=np.dtype('float32'):
        raise ValueError('exact float32 ndarray required')
    if value.ndim!=2 or value.shape[1] not in (40,80) or not 1<=len(value)<=64:
        raise ValueError('fixed 1..64 rows, 40 padded to 80 or full 80 required')
    if not value.flags.c_contiguous or not np.isfinite(value).all():raise ValueError('finite contiguous input required')
    padded=np.zeros((len(value),80),dtype=np.complex64);padded[:,:value.shape[1]]=value
    chirp=np.empty(81,dtype=np.complex64)
    for j in range(81):
        arg=((math.pi*j)*j)/80
        chirp[j]=np.complex64(complex(math.cos(arg),math.sin(arg)))
    a=np.zeros((len(value),256),dtype=np.complex64);b=np.zeros((1,256),dtype=np.complex64)
    a[:,:80]=cmul(padded,np.conj(chirp[:80]));b[0,:80]=chirp[:80]
    b[0,176:]=chirp[np.arange(80,0,-1)]
    product=cmul(pow2_fft(a,False,lut),pow2_fft(b,False,lut))
    inverse=pow2_fft(product,True,lut)
    # std::complex /= real performs separate real and imaginary division.
    result=np.empty_like(inverse);result.real=inverse.real/np.float32(256);result.imag=inverse.imag/np.float32(256)
    return cmul(result[:,:80],np.conj(chirp[:80]))[:,:41].copy()
