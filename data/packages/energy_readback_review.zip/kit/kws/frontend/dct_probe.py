"""Fixed diagnostic DCT alternatives, not a deployable frontend or changed oracle."""
import numpy as np


def checked(value):
    if type(value) is not np.ndarray or value.dtype != np.dtype('float32'):
        raise ValueError('exact float32 ndarray required')
    if value.ndim != 2 or value.shape[0] < 1 or value.shape[1] != 40:
        raise ValueError('expected nonempty frames x 40 mel bins')
    if not np.isfinite(value).all():
        raise ValueError('finite input required')
    if not value.flags.c_contiguous:
        raise ValueError('C-contiguous component input required; layout affects floating reduction')
    return value


def matrix32(value):
    value = checked(value)
    angle = ((np.arange(40, dtype=np.float32)[:, None] + np.float32(.5))
             * np.arange(10, dtype=np.float32)[None, :] * np.float32(np.pi/40))
    return (value @ (np.cos(angle)*np.float32(np.sqrt(2/40)))).astype(np.float32)


def matrix64(value):
    value = checked(value)
    angle = (np.arange(40, dtype=np.float64)[:, None]+.5)*np.arange(10)[None, :]*(np.pi/40)
    return (value.astype(np.float64) @ (np.cos(angle)*np.sqrt(2/40))).astype(np.float32)


def rotate_rfft(spectrum):
    # Same algebraic order as installed TF dct_ops.py type-II, then mfcc_ops.py.
    # Matching the algebra does not establish floating-point kernel equivalence.
    phase = -np.arange(40, dtype=np.float32)*np.float32(np.pi)
    phase = phase*np.float32(.5)/np.float32(40)
    rotation = np.float32(2)*np.exp((1j*phase).astype(np.complex64))
    dct = (spectrum[:, :40].astype(np.complex64)*rotation).real
    return (dct*np.float32(1/np.sqrt(np.float32(80))))[:, :10].copy()


def rfft32(value):
    value = checked(value)
    return rotate_rfft(np.fft.rfft(value, n=80, axis=-1))


def source_cast(value):
    if value.ndim != 2 or value.shape[1] != 10 or not np.isfinite(value).all():
        raise ValueError('finite frames x 10 required')
    scaled = value/np.float32(.5847029089927673)+np.float32(83)
    # Explicit original truncation and wrapping; not rounding or clipping.
    return ((np.trunc(scaled).astype(np.int64)+128)%256-128).astype(np.int8)
