# Finite diagnostic composition of Eigen-style butterfly replay from the prior checkpoint.
# Eigen TensorFFT arithmetic provenance/MPL2 retained in KWS-fft-kernel-20261022_01.
import hashlib
import importlib.util
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
PREVIOUS=HERE.parent/'KWS-fft-kernel-20261022_01'
SOURCE_SHA='b8070d51d6ae2eb66a4f868f5b24c16fc26753c6b907fdf46f4d032cea45b0a5'


def source():
    path=PREVIOUS/'eigen80_replay.py'
    if hashlib.sha256(path.read_bytes()).hexdigest()!=SOURCE_SHA:raise ValueError('old numerical helper changed')
    spec=importlib.util.spec_from_file_location('private_frozen_eigen80',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def rfft512(value,lut,base):
    if type(value) is not np.ndarray or value.dtype!=np.dtype('float32'):
        raise ValueError('exact float32 ndarray required')
    if value.ndim!=2 or value.shape[1] not in (480,512) or not 1<=len(value)<=64:
        raise ValueError('fixed 1..64 frames of length 480/512 required')
    if not value.flags.c_contiguous or not np.isfinite(value).all():raise ValueError('finite C-contiguous frames required')
    # CPU Eigen real-forward path first forms full complex FFT, then slices positive bins.
    full=np.zeros((len(value),512),np.complex64);full[:,:value.shape[1]]=value
    reverse=[int(format(i,'09b')[::-1],2) for i in range(512)]
    data=full[:,reverse].copy()
    def recurse(part):
        if part.shape[1]==8:base.butterfly8(part,False)
        else:
            half=part.shape[1]//2;recurse(part[:,:half]);recurse(part[:,half:]);base.merge(part,False,lut)
    recurse(data);return data[:,:257].copy()


def magnitude_components(spectrum):
    return np.sqrt(np.float32(spectrum.real*spectrum.real)+np.float32(spectrum.imag*spectrum.imag))
