"""Thin launcher data gates. No SSH, lock creation, GUI or inference on import."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import stat
import sys

KWS_SHA = '05d439cc3e5b8e5281e27bd2803848e7a0bb117803c2245dcbdd8efb2d8de0df'
ENERGY_SHA = '456e6e783a7d85ff2393cafe7f7a990bf7b2a69d5778babfb6381bbfebf9d4f6'
LOCK = '/tmp/opennpu-kws-chain.lock'
KERNEL = '6.6.10-xilinx-v2024.1-g3c0eca68c652'
SCOPES = {'kws': 'CPU420-FIXED-REFERENCE-NO-PL-NO-DEPLOYMENT',
          'energy': 'ENERGY1808-NEW-FLAT-CONTIGUOUS-ENVELOPES'}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return (json.dumps(value, sort_keys=True, allow_nan=False) + '\n').encode()


def decode(raw):
    def pairs(items):
        result = {}
        for k, v in items:
            require(k not in result, 'duplicate JSON key')
            result[k] = v
        return result
    def bad(value):
        raise ValueError('nonfinite JSON')
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=bad)


def canonical(path):
    path = Path(path).absolute()
    require(path.resolve() == path and not path.is_symlink(), 'canonical nonalias path required')
    return path


def read(path, limit=16384):
    path = canonical(path)
    require(stat.S_ISREG(path.lstat().st_mode), 'regular nonspecial file required')
    with path.open('rb') as stream:
        raw = stream.read(limit+1)
    require(len(raw) <= limit, 'file byte bound')
    return raw


def publish(path, value):
    raw = value if type(value) is bytes else encode(value)
    with canonical(path).open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def outside(root, path, *, fresh):
    path = canonical(path)
    require(path != root and root not in path.parents and path not in root.parents,
            'output must be outside immutable package')
    require(not path.exists() if fresh else path.is_dir(), 'fresh/existing directory required')
    return path


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def verify(root, expected):
    root = canonical(root)
    require(type(expected) is str and re.fullmatch('[0-9a-f]{64}', expected), 'external kit manifest SHA required')
    raw = read(root/'kit_manifest.json', 250000)
    require(sha(raw) == expected, 'kit manifest mismatch')
    manifest = decode(raw)
    require(set(manifest) == {'schema', 'kws_identity', 'energy_identity', 'activation_approved', 'files'}
            and manifest['schema'] == 'metrics-thin-launch-kit-v1'
            and manifest['kws_identity'] == KWS_SHA and manifest['energy_identity'] == ENERGY_SHA
            and manifest['activation_approved'] is False, 'exact unapproved launcher candidate identity')
    indexed = manifest['files']
    require(type(indexed) is dict and 633 < len(indexed) < 660, 'bounded kit inventory')
    actual = set()
    for p in root.rglob('*'):
        mode = p.lstat().st_mode
        require(not p.is_symlink() and not getattr(p, 'is_junction', lambda: False)()
                and (stat.S_ISREG(mode) or stat.S_ISDIR(mode)), 'no aliases or special kit members')
        if stat.S_ISREG(mode):
            actual.add(p.relative_to(root).as_posix())
    require(actual == set(indexed) | {'kit_manifest.json'}, 'kit member set mismatch')
    for name, item in indexed.items():
        part = PurePosixPath(name)
        require(part.as_posix() == name and not part.is_absolute() and '..' not in part.parts
                and not any(c in name for c in '\\:\x00\r\n')
                and type(item) is dict and set(item) == {'bytes', 'sha256'}
                and type(item['bytes']) is int and 0 <= item['bytes'] <= 16000000, 'invalid indexed member')
        raw = read(root/name, item['bytes'])
        require(len(raw) == item['bytes'] and sha(raw) == item['sha256'], 'kit member changed: ' + name)
    for folder, pin in [('kws', KWS_SHA), ('energy', ENERGY_SHA)]:
        require(sha(read(root/folder/'review_manifest.json', 150000)) == pin, 'reviewed subtree manifest')
    return manifest


def bindings(root, kind):
    """Only import already-verified pure-data helpers, not runtime constructors."""
    if kind == 'kws':
        sys.path.insert(0, str(root/'kws/src'))
        return module('_launcher_kws_common', root/'kws/src/common.py')
    sys.path[:0] = [str(root/'energy/src'), str(root/'energy/legacy/candidate/src')]
    return module('_launcher_energy_common', root/'energy/legacy/candidate/src/integration_common.py')


def lock_identity(info):
    require(stat.S_ISREG(info.st_mode) and info.st_uid == 1000
            and stat.S_IMODE(info.st_mode) == 0o644 and info.st_nlink == 1, 'existing original single-link lock required')
    return dict(path=LOCK, device=info.st_dev, inode=info.st_ino, uid=info.st_uid,
                mode=stat.S_IMODE(info.st_mode), links=info.st_nlink)


def environment():
    """User-run read-only ARM probe; never calls PYNQ or acquires the lock."""
    require(platform.system() == 'Linux' and platform.machine() == 'armv7l'
            and platform.release() == KERNEL and sys.byteorder == 'little', 'original ARM Linux environment required')
    require(os.geteuid() == 0, 'original root operator required')
    boot = read('/proc/sys/kernel/random/boot_id', 128).decode().strip()
    require(re.fullmatch('[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', boot), 'current boot UUID')
    lock = lock_identity(os.lstat(LOCK))  # No creation, open, FLOCK, truncate or unlink.
    import numpy as np
    native = []
    for name, value in list(sys.modules.items()):
        path = getattr(value, '__file__', '')
        if name.startswith('numpy.') and name.endswith('._multiarray_umath') and path and Path(path).suffix in ('.so', '.pyd'):
            path = canonical(path)
            native.append(dict(path=str(path), sha256=sha(read(path, 32000000))))
    require(native, 'actual loaded NumPy core extension identity required')
    require(not any(n in sys.modules for n in ('pynq', 'tensorflow', 'tflite_runtime', 'tflite', 'flatbuffers')),
            'probe must not import device/schema/runtime libraries')
    # Python/venv executables commonly are legitimate symlinks. Record BOTH the
    # invocation and resolved binary; do not reject the original venv layout.
    exe = Path(sys.executable).resolve(strict=True)
    return dict(boot_id=boot, expected_lock=lock, system=platform.system(), machine=platform.machine(),
                kernel=platform.release(), byteorder=sys.byteorder, python=sys.version,
                invoked_executable=sys.executable, executable=str(exe),
                executable_sha256=sha(read(exe, 32000000)), prefix=str(canonical(sys.prefix)),
                numpy=np.__version__, numpy_file=str(canonical(np.__file__)),
                numpy_init_sha256=sha(read(np.__file__, 200000)), numpy_core=native)


def preflight_document(value):
    require(type(value) is dict and set(value) == {'schema', 'kit_manifest_sha256', 'environment', 'scope',
            'board_test_started', 'lock_acquired', 'promotion'}, 'explicit probe document')
    require(value['schema'] == 'metrics-launch-readonly-arm-preflight-v1'
            and value['board_test_started'] is False and value['lock_acquired'] is False
            and value['promotion'] is False, 'preflight is not a board test or approval')
    env = value['environment']
    require(type(env) is dict and type(env.get('numpy')) is str and bool(env['numpy'])
            and env.get('machine') == 'armv7l' and env.get('kernel') == KERNEL, 'explicit ARM dependency identity')
    return value
