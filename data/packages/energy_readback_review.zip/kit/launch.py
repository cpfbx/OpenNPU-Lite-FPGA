"""Explicit thin launch preparation. Only bx runs probes/launches on real systems."""
import argparse
from datetime import datetime, timezone
import os
from pathlib import Path
import sys
import uuid

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import kit_support as s


def pinned(path, pin, limit=16384):
    raw = s.read(path, limit)
    s.require(s.sha(raw) == pin, 'external document SHA mismatch')
    return raw, s.decode(raw)


def prepare(root, identity, kind, output, *, preflight=None, preflight_sha=None,
            mode=None, policy=None, policy_sha=None):
    s.require(kind in ('kws', 'energy'), 'explicit preparation kind')
    output = s.outside(root, output, fresh=True)
    helper = s.bindings(root, kind)
    probe = None
    probe_raw = None
    policy_raw = None
    if preflight is not None:
        probe_raw, probe = pinned(preflight, preflight_sha, 50000)
        probe = s.preflight_document(probe)
        s.require(probe['kit_manifest_sha256'] == identity, 'probe from another kit')
    if kind == 'kws':
        s.require(probe is not None and mode in ('fixed_features', 'public_wav'), 'KWS needs fresh user probe and explicit mode')
        env = probe['environment']
        chosen = helper.request(dict(component_manifest_sha256=helper.COMPONENT_SHA, mode=mode, samples=420,
            board_serial='ftdi-1234-tulB', pynq_image='pynq-z2-v3.1.1', boot_id=env['boot_id'],
            expected_lock=env['expected_lock'], operator='bx', scope='CPU-REFERENCE-NO-PL-NO-DEPLOYMENT'))
        chosen_name = 'request.json'
    else:
        s.require(policy is not None and policy_sha is not None, 'explicit policy file and SHA required; no default budget')
        policy_raw, selected = pinned(policy, policy_sha)
        selected = helper.consistency_policy(selected)
        chosen = helper.decode(s.read(root/'energy/legacy/settings.json'))
        chosen.update(session_id=uuid.uuid4().hex, consistency_policy=selected)
        chosen = helper.config(chosen)
        helper.validate_gui_budget(chosen, 30)
        chosen_name = 'settings.json'
    output.mkdir()
    s.publish(output/chosen_name, helper.encode(chosen))
    plan = dict(schema='metrics-launch-preparation-v1', kind=kind, kit_manifest_sha256=identity,
        candidate_identity_sha256=s.KWS_SHA if kind == 'kws' else s.ENERGY_SHA,
        payload=chosen_name, payload_sha256=s.sha(s.read(output/chosen_name)), operator='bx',
        confirm_scope=s.SCOPES[kind], preflight_sha256=preflight_sha,
        expected_environment=None if probe is None else probe['environment'],
        policy_source_sha256=policy_sha if kind == 'energy' else None,
        created_utc=datetime.now(timezone.utc).isoformat(), launch_id=uuid.uuid4().hex,
        activation_approved_by_package=False, runtime_started=False, promotion=False)
    s.publish(output/'plan.json', plan)
    if probe is not None:
        s.publish(output/'preflight.json', probe_raw)
    if policy_raw is not None:
        s.publish(output/'policy_source.json', policy_raw)
    return dict(work_directory=str(output), payload=str(output/chosen_name), payload_sha256=plan['payload_sha256'],
                plan_sha256=s.sha(s.read(output/'plan.json')), runtime_started=False, activation_approved=False)


def checked_plan(root, identity, work, pin):
    work = s.outside(root, work, fresh=False)
    _, plan = pinned(work/'plan.json', pin)
    fields = {'schema', 'kind', 'kit_manifest_sha256', 'candidate_identity_sha256', 'payload', 'payload_sha256',
              'operator', 'confirm_scope', 'preflight_sha256', 'expected_environment', 'policy_source_sha256',
              'created_utc', 'launch_id', 'activation_approved_by_package', 'runtime_started', 'promotion'}
    s.require(type(plan) is dict and set(plan) == fields and plan['schema'] == 'metrics-launch-preparation-v1', 'exact plan')
    kind = plan['kind']
    s.require(kind in s.SCOPES and plan['kit_manifest_sha256'] == identity and plan['operator'] == 'bx'
              and plan['confirm_scope'] == s.SCOPES[kind] and plan['activation_approved_by_package'] is False
              and plan['runtime_started'] is False and plan['promotion'] is False, 'plan identity/scope')
    s.require(plan['candidate_identity_sha256'] == (s.KWS_SHA if kind == 'kws' else s.ENERGY_SHA), 'exact reviewed candidate')
    s.require(plan['payload'] == ('request.json' if kind == 'kws' else 'settings.json'), 'fixed payload basename')
    raw, chosen = pinned(work/plan['payload'], plan['payload_sha256'])
    helper = s.bindings(root, kind)
    chosen = helper.request(chosen) if kind == 'kws' else helper.config(chosen)
    if plan['preflight_sha256'] is not None:
        _, probe = pinned(work/'preflight.json', plan['preflight_sha256'], 50000)
        probe = s.preflight_document(probe)
        s.require(probe['kit_manifest_sha256'] == identity
                  and s.encode(probe['environment']) == s.encode(plan['expected_environment']), 'probe/plan mismatch')
    if kind == 'kws':
        s.require(plan['expected_environment'] is not None
                  and chosen['boot_id'] == plan['expected_environment']['boot_id']
                  and s.encode(chosen['expected_lock']) == s.encode(plan['expected_environment']['expected_lock']), 'KWS boot/lock binding')
    else:
        helper.validate_gui_budget(chosen, 30)
        _, original_policy = pinned(work/'policy_source.json', plan['policy_source_sha256'])
        s.require(helper.encode(helper.consistency_policy(original_policy)) == helper.encode(chosen['consistency_policy']),
                  'payload differs from explicit policy source')
    for name in ('attempt.json', 'entry_return.json', 'evidence'):
        p = work/name
        s.require(not p.exists() and not p.is_symlink(), 'attempt/evidence already exists; no retry or overwrite')
    return work, plan, chosen


def energy_command(root, work, plan, role, host):
    command = [str(root/'energy/src/integration_entry.py'), '_board_abba_candidate' if role == 'board' else '_pc_capture',
        '--identity-sha', s.ENERGY_SHA, '--settings', str(work/'settings.json'), '--settings-sha', plan['payload_sha256'],
        '--output', str(work/'evidence'), '--enable-private-candidate']
    if role == 'board':
        command += ['--board-serial', 'ftdi-1234-tulB', '--pynq-image', 'pynq-z2-v3.1.1', '--peer-wait-s', '600']
    else:
        command += ['--csv-dir', host['csv_dir'], '--gui-wait-s', '30', '--host-pid', str(host['host_pid']),
            '--host-start-ticks', host['host_start_ticks'], '--exe-path', host['exe_path'],
            '--powershell-exe', host['powershell_exe'], '--powershell-sha', host['powershell_sha256']]
    return command


def on_windows():
    return os.name == 'nt'


def run(root, identity, work, plan_sha, role, confirm_scope, enabled, *, host_binding=None, host_sha=None):
    s.require(enabled is True, 'launcher candidate default-off; independent review and bx approval required')
    work, plan, chosen = checked_plan(root, identity, work, plan_sha)
    kind = plan['kind']
    s.require(confirm_scope == s.SCOPES[kind], 'exact separate launch scope required')
    s.require(role == 'board' or (kind == 'energy' and role == 'pc'), 'KWS is board-only; explicit role')
    host = None
    if role == 'board':
        s.require(plan['expected_environment'] is not None, 'board needs a fresh read-only preflight')
        s.require(s.encode(s.environment()) == s.encode(plan['expected_environment']), 'boot/lock/dependency identity changed')
        if kind == 'energy':
            s.require(plan['expected_environment']['prefix'] == '/usr/local/share/pynq-venv', 'original PYNQ Python environment required')
    else:
        s.require(on_windows(), 'PC capture requires original Windows host')
        _, value = pinned(host_binding, host_sha)
        definitions = s.module('_launcher_legacy_host', root/'energy/legacy/launch_abba.py')
        host = definitions.host_binding(value)
        s.require(s.sha(s.read(host['exe_path'], 32000000)) == host['host_exe_sha256']
                  and s.sha(s.read(host['powershell_exe'], 32000000)) == host['powershell_sha256'], 'current host/PowerShell bytes changed')
    token = 'CPU420' if kind == 'kws' else 'ENERGY1808'
    print('PLAN:', plan_sha, 'PAYLOAD:', plan['payload_sha256'], flush=True)
    if kind == 'energy':
        print('POLICY:', s.encode(chosen['consistency_policy']).decode().strip(), flush=True)
    else:
        print('KWS MODE:', chosen['mode'], 'FIXED WINDOWS:', chosen['samples'], flush=True)
    s.require(input('bx: exact new package/config approved; UTC/idle/wiring/dependencies verified? Type '+token+': ') == token,
              'fresh operator confirmation absent')
    if role == 'board':
        s.require(s.encode(s.environment()) == s.encode(plan['expected_environment']), 'state changed during confirmation')
    else:
        s.require(s.sha(s.read(host['exe_path'], 32000000)) == host['host_exe_sha256']
                  and s.sha(s.read(host['powershell_exe'], 32000000)) == host['powershell_sha256'],
                  'host/runtime changed during confirmation')
    s.verify(root, identity)
    s.publish(work/'attempt.json', dict(plan_sha256=plan_sha, payload_sha256=plan['payload_sha256'], role=role,
        operator='bx', operator_confirmed_this_launch=True, created_utc=datetime.now(timezone.utc).isoformat(),
        host_binding_sha256=host_sha, package_authorizes_run=False, promotion=False))
    if host is not None:
        s.publish(work/'launcher_host_binding.json', s.read(host_binding))
    print('EVIDENCE:', str(work/'evidence'), flush=True)
    # In-process handoff: no extra launcher Python parent for the frozen workload scanner.
    previous = list(sys.argv)
    code = None
    error = None
    try:
        if kind == 'kws':
            entry = s.module('_prepared_kws_entry', root/'kws/src/entry.py')
            sys.argv = [str(root/'kws/src/entry.py'), 'parent', '--manifest-sha', s.KWS_SHA,
                '--request', str(work/'request.json'), '--request-sha', plan['payload_sha256'],
                '--evidence', str(work/'evidence'), '--enable-private-candidate']
        else:
            sys.path[:0] = [str(root/'energy/src'), str(root/'energy/legacy/candidate/src')]
            entry = s.module('_prepared_energy_entry', root/'energy/src/integration_entry.py')
            sys.argv = energy_command(root, work, plan, role, host)
        returned = entry.main()
        s.require(returned is None or type(returned) is int, 'entry return type')
        code = 0 if returned is None else returned
    except BaseException as failure:
        error = type(failure).__name__
        raise
    finally:
        sys.argv = previous
        try:
            s.publish(work/'entry_return.json', dict(entry_return_code=code, error_type=error,
                scope='in-process function return; not an independent OS exit observation',
                promotion=False))
        except BaseException as receipt_error:
            if error is None:
                raise
            print(s.encode(dict(secondary_entry_receipt_error_type=type(receipt_error).__name__,
                primary_error_type=error, promotion=False)).decode(), file=sys.stderr, end='')
    return code


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('operation', choices=['check', 'preflight', 'prepare', 'run'])
    p.add_argument('--manifest-sha', required=True)
    p.add_argument('--kind', choices=['kws', 'energy'])
    for name in ('output', 'preflight', 'policy', 'work', 'host-binding'):
        p.add_argument('--'+name, type=Path)
    for name in ('preflight-sha', 'policy-sha', 'plan-sha', 'host-sha', 'confirm-scope'):
        p.add_argument('--'+name)
    p.add_argument('--mode', choices=['fixed_features', 'public_wav'])
    p.add_argument('--role', choices=['board', 'pc'])
    p.add_argument('--enable-reviewed-launcher', action='store_true')
    a = p.parse_args()
    s.verify(ROOT, a.manifest_sha)
    if a.operation == 'check':
        print(s.encode(dict(check_pass=True, scope='offline package bytes only', activation_approved=False,
            board_access=False, gui_access=False, lock_acquired=False, promotion=False)).decode(), end='')
        return 0
    if a.operation == 'preflight':
        s.require(a.output is not None, 'explicit fresh probe file required')
        output = s.outside(ROOT, a.output, fresh=True)
        s.require(input('bx only: UTC/idle/wiring verified; read-only ARM/NumPy/lock-stat probe? Type PROBEONLY: ') == 'PROBEONLY', 'probe unconfirmed')
        env = s.environment()
        s.publish(output, dict(schema='metrics-launch-readonly-arm-preflight-v1', kit_manifest_sha256=a.manifest_sha,
            environment=env, scope='read-only dependency/boot/lock lstat; not idle proof or approval',
            board_test_started=False, lock_acquired=False, promotion=False))
        print(s.encode(dict(preflight_sha256=s.sha(s.read(output, 50000)), output=str(output), board_test_started=False)).decode(), end='')
        return 0
    if a.operation == 'prepare':
        s.require(a.kind is not None and a.output is not None, 'explicit preparation kind/output')
        print(s.encode(prepare(ROOT, a.manifest_sha, a.kind, a.output,
            preflight=a.preflight, preflight_sha=a.preflight_sha, mode=a.mode,
            policy=a.policy, policy_sha=a.policy_sha)).decode(), end='')
        return 0
    return run(ROOT, a.manifest_sha, a.work, a.plan_sha, a.role, a.confirm_scope,
               a.enable_reviewed_launcher, host_binding=a.host_binding, host_sha=a.host_sha)


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        print(s.encode(dict(error_type=type(error).__name__, error=str(error), promotion=False)).decode(), file=sys.stderr, end='')
        raise SystemExit(2)
