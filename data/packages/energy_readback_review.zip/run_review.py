"""Portable LOCAL ONLY replay. No device/GUI/network use; fresh output required."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def main():
    root=Path(__file__).resolve().parent
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    out=args.output.absolute()
    if out.resolve()!=out or out.exists() or out==root or out.is_relative_to(root) or root.is_relative_to(out):
        raise ValueError('fresh output outside review bundle required')
    manifest=json.loads((root/'MANIFEST.json').read_bytes())
    def inventory():
        result={}
        for p in root.rglob('*'):
            if p.is_symlink() or getattr(p,'is_junction',lambda:False)(): raise ValueError('aliased review input')
            if p.is_file() and p!=root/'MANIFEST.json':
                raw=p.read_bytes()
                result[p.relative_to(root).as_posix()]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
        return result
    before=inventory()
    if before!=manifest['files']: raise ValueError('review bundle identity mismatch')
    out.mkdir()
    commands=[
        [sys.executable,'-I','-B',str(root/'test_recompute.py')],
        [sys.executable,'-I','-B',str(root/'intake.py'), '--archive',str(root/'original_board.tar.gz'),
         '--kit',str(root/'kit'),'--pc-work',str(root/'pc'), '--output',str(out/'intake')],
        [sys.executable,'-I','-B',str(root/'recompute.py'),
         '--board-work',str(out/'intake/board/energy_prepare_AadlGFiu/work'),
         '--pc-work',str(root/'pc'),'--kit',str(root/'kit'),
         '--frozen-readback',str(out/'intake/frozen_readback_01/readback.json'),'--output',str(out/'arithmetic')]
    ]
    receipts=[]
    for i,command in enumerate(commands):
        p=subprocess.run(command,capture_output=True)
        (out/f'{i:02d}.stdout.txt').write_bytes(p.stdout)
        (out/f'{i:02d}.stderr.txt').write_bytes(p.stderr)
        receipts.append(dict(command=command,actual_exit=p.returncode,stdout=f'{i:02d}.stdout.txt',stderr=f'{i:02d}.stderr.txt'))
        if p.returncode: break
    unchanged=inventory()==before
    frozen=out/'intake/intake.json'
    frozen_exit=json.loads(frozen.read_bytes())['frozen_actual_exit'] if frozen.exists() else None
    passed=len(receipts)==3 and all(x['actual_exit']==0 for x in receipts) and frozen_exit==0 and unchanged
    result=dict(operation_success=passed,commands=receipts,frozen_actual_exit=frozen_exit,
        input_bundle_unchanged=unchanged,board_access=False,GUI_access=False,promotion=False,
        scope='local replay only; executor must identify themselves separately')
    (out/'review_receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(operation_success=passed,commands=len(receipts),frozen_actual_exit=frozen_exit,input_bundle_unchanged=unchanged)))
    return 0 if passed else 1


if __name__=='__main__':
    raise SystemExit(main())
