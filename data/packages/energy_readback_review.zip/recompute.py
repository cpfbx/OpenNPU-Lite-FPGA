"""Separate arithmetic implementation: Fraction CSV + INT64 matrix replay.

No runtime/driver imports, sockets, GUI, or writes to any source evidence.
This is author-side cross-checking, NOT independent-person review.
"""
import csv
import argparse
import hashlib
import io
import json
import math
from decimal import Decimal, localcontext
from fractions import Fraction as F
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
BOARD = HERE/'intake_01/board/energy_prepare_AadlGFiu/work'
PC = BASE/'energy-activation-20261024_02/pc_snapshot_01/work'
KIT = BASE/'metrics-msaa-compat-20261024_01/candidate_01'


def require(ok, why):
    if not ok:
        raise ValueError(why)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def text(value):
    with localcontext() as ctx:
        ctx.prec = 80
        return format(Decimal(value.numerator)/Decimal(value.denominator), 'f')


def consistency(endpoint, integral):
    difference = abs(endpoint-integral)
    return difference <= F('1.01') and difference <= F('0.001')*max(abs(endpoint), abs(integral))


def parse(raw):
    require(type(raw) is bytes and 0 < len(raw) <= 4*1024*1024 and raw.endswith(b'\n'), 'bounded complete CSV')
    rows = list(csv.reader(io.StringIO(raw.decode('gb18030')), strict=True))
    require(rows[0] == ['电压(mV)','电流(mA)','功率(W)','D+(V)','D-(V)','电阻(R)','电量(Wh)','时间(ms)',''], 'fixed observed header')
    fields = rows[1:]
    require(2 <= len(fields) <= 30000, 'CSV row bounds')
    require(all(len(r) == 9 and r[-1] == '' for r in fields), 'row width')
    require(all(re.fullmatch(r'[0-9]+(?:\.[0-9]+)?', x) for r in fields for x in r[:8]), 'finite nonnegative decimal fields')
    values = [[F(x) for x in r[:8]] for r in fields]
    require(all(r[7].denominator == 1 for r in values), 'integer milliseconds')
    require(all(b[7]-a[7] == 100 for a,b in zip(values,values[1:])), '100ms grid')
    require(all(b[6] >= a[6] for a,b in zip(values,values[1:])), 'nondecreasing host Wh')
    require(all(F('4.5') <= r[0] <= F('5.5') for r in values), 'declared conditional 5V interpretation')
    product_error = max(abs(r[0]*r[1]-r[2]) for r in values)
    require(product_error <= F('0.00001'), 'P=VI under prior V/A mapping')
    peak = max(r[2] for r in values)
    require(peak <= 5, 'power budget basis')
    endpoint_texts = [fields[0][6],fields[-1][6]]
    quanta = [F(10)**Decimal(x).as_tuple().exponent for x in endpoint_texts]
    require(all(q <= F('0.000001') for q in quanta), 'original endpoint lexical precision')
    span = (values[-1][7]-values[0][7])/1000
    require(60 <= span < 1800, 'span basis')
    endpoint = (values[-1][6]-values[0][6])*3600
    integral = sum(((a[2]+b[2])*(b[7]-a[7])/2000 for a,b in zip(values,values[1:])), F(0))
    right = sum((b[2]*(b[7]-a[7])/1000 for a,b in zip(values,values[1:])), F(0))
    require(consistency(endpoint, integral), 'absolute AND relative consistency')
    difference = abs(endpoint-integral)
    return dict(rows=len(values), bytes=len(raw), sha256=sha(raw), span_s=text(span),
        endpoint_Wh_text=endpoint_texts, endpoint_lexical_quanta_Wh=[text(q) for q in quanta],
        endpoint_J=text(endpoint), trapezoid_J=text(integral), right_rectangle_J=text(right),
        mean_integral_power_W=text(integral/span), absolute_difference_J=text(difference),
        relative_difference=text(difference/max(endpoint,integral)), peak_W=text(peak),
        max_P_minus_VI_W=text(product_error), basis_and_consistency_pass=True)


def stats(ns):
    require(ns and all(type(x) is int and x > 0 for x in ns), 'positive integer timing')
    ordered = sorted(ns)
    n = len(ordered)
    return dict(n=n, mean_ms=text(F(sum(ns), n*1000000)),
        median_ms=text(F(ordered[(n-1)//2]+ordered[n//2], 2000000)),
        p95_nearest_rank_ms=text(F(ordered[math.ceil(n*.95)-1],1000000)),
        min_ms=text(F(ordered[0],1000000)), max_ms=text(F(ordered[-1],1000000)))


def check_metrics(m, index):
    fixed = dict(jobs=64, chain_jobs_completed=64, mode=11, input_bytes=4198400,
        output_bytes=1048576, output_valid_bytes=1048576, effective_macs=134217728,
        first_job_id=1+index*64, batch_pl_index=index, error_code=0, counter_contract_version=2)
    require(all(type(m.get(k)) is int and m[k] == v for k,v in fixed.items()), 'work/sequence counters')
    require(m.get('host_path_candidate') == 'flat_contiguous' and m.get('layout') == 'k_major'
        and m.get('counter_contract') == 'd007_global_work_v2', 'new path/mode contract')
    require(type(m.get('status')) is int and m['status'] & 14 == 4, 'clean DONE status')
    keys = ['pl_total_cycles','pl_work_union_cycles','pl_no_work_cycles','pl_overlap_credit_cycles',
        'pl_array_output_work_overlap_cycles','pl_compute_wait_bank_cycles','pl_output_wait_tready_cycles']
    engines = [m['pl_'+e+'_work_cycles'] for e in ('load','array','store','output')]
    require(all(type(m[k]) is int and m[k] >= 0 for k in keys) and all(type(x) is int and x >= 0 for x in engines), 'nonnegative counters')
    total, union = m['pl_total_cycles'],m['pl_work_union_cycles']
    require(total == union+m['pl_no_work_cycles'] and sum(engines) == union+m['pl_overlap_credit_cycles'], 'counter conservation')
    require(m['pl_array_output_work_overlap_cycles'] <= min(engines[1],engines[3])
        and m['pl_compute_wait_bank_cycles'] <= total and m['pl_output_wait_tready_cycles'] <= total
        and max(engines) <= union <= sum(engines) and max(engines) <= total
        and m['pl_overlap_credit_cycles'] <= 3*union, 'counter subset bounds')


def main():
    global BOARD, PC, KIT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--board-work', type=Path, default=BOARD)
    parser.add_argument('--pc-work', type=Path, default=PC)
    parser.add_argument('--kit', type=Path, default=KIT)
    parser.add_argument('--frozen-readback', type=Path, default=HERE/'intake_01/frozen_readback_01/readback.json')
    parser.add_argument('--output', type=Path, default=HERE/'recompute_01')
    args=parser.parse_args()
    BOARD,PC,KIT=[p.resolve(strict=True) for p in (args.board_work,args.pc_work,args.kit)]
    out=args.output.absolute()
    require(out.resolve()==out and all(out!=p and not out.is_relative_to(p) and not p.is_relative_to(out) for p in (BOARD,PC,KIT)), 'isolated output')
    require(not out.exists(), 'fresh output required')
    import numpy as np
    sources = {}
    def raw(p):
        b = p.read_bytes()
        sources[str(p)] = sha(b)
        return b
    def doc(p):
        return json.loads(raw(p))
    frozen = doc(args.frozen_readback.resolve(strict=True))
    windows = []
    for w in range(4):
        item = parse(raw(PC/('evidence/window_%d.csv'%w)))
        prior = frozen['windows'][w]['import_result']
        for new,old in [('rows','rows'),('bytes','source_bytes'),('sha256','source_sha256'),('span_s','csv_time_span_seconds'),
                        ('endpoint_J','host_wh_endpoint_difference_J'),('trapezoid_J','power_trapezoid_J'),('right_rectangle_J','power_right_rectangle_J')]:
            require(item[new] == prior[old] if type(item[new]) is int or new == 'sha256' else F(item[new]) == F(prior[old]), 'Fraction/Decimal agreement '+new)
        item.update(window=w,backend='openblas_2t' if w in (0,3) else 'fpga_flat_contiguous')
        windows.append(item)
    bank = KIT/'energy/component/core/frozen/bank'
    spec = doc(bank/'bank.json')
    golden = {}
    for pair in (42,43):
        operands = []
        for suffix in ('a','b'):
            name = f'input_{pair}_{suffix}.bin'
            data = raw(bank/name)
            require(len(data) == spec['members'][name]['bytes'] and sha(data) == spec['members'][name]['sha256'], 'pinned bank operands')
            operands.append(np.frombuffer(data,np.int8).reshape(512,512).astype(np.int64))
        output64 = operands[0] @ operands[1]
        require(output64.min() >= -(2**31) and output64.max() < 2**31, 'INT32 range')
        output = output64.astype('<i4').tobytes()
        golden[pair] = sha(output)
        require(golden[pair] == spec['members'][f'input_{pair}_expected.bin']['sha256'], 'fresh INT64 golden digest')
        for w in range(4):
            retained = raw(BOARD/f'evidence/worker/outputs/window_{w}_input_{pair}.bin')
            require(retained == output, 'full representative output INT64 replay')
    calls = doc(BOARD/'evidence/worker/outputs/calls.json')
    require(len(calls) == 1824, 'all calls present')
    pl = 0
    for position,row in enumerate(calls):
        w,index = divmod(position,456)
        fields = dict(window=w,index=index,input_id=42+index%2,phase_index=index if index<4 else index-4)
        require(all(type(row.get(k)) is int and row[k] == v for k,v in fields.items()), 'exact call schedule')
        require(row.get('phase') == ('warmup' if index<4 else 'measured') and row.get('accepted') is True and row.get('exact') is True, 'call success')
        require(row.get('backend') == ('openblas_2t' if w in (0,3) else 'fpga_cached'), 'call backend')
        require(row.get('output_sha256') == row.get('expected_sha256') == golden[row['input_id']], 'call digest matches recomputed golden')
        require(type(row['begin_ns']) is int and type(row['end_ns']) is int and row['end_ns'] > row['begin_ns'], 'timing extent')
        if w in (1,2):
            check_metrics(row['metrics'], pl)
            pl += 1
        else:
            require(row['metrics'] == {}, 'CPU has no PL counters')
    require(pl == 912, 'PL calls')
    per_window=[]
    for w in range(4):
        subset=[r for r in calls if r['window']==w and r['phase']=='measured']
        require(len(subset)==452, 'formal per window')
        per_window.append(dict(window=w,backend=windows[w]['backend'],
            complete_request=stats([r['end_ns']-r['begin_ns'] for r in subset]),
            process_CPU=stats([r['process_cpu_ns'] for r in subset])))
    groups={}
    for backend,ids in [('openblas_2t',(0,3)),('fpga_flat_contiguous',(1,2))]:
        subset=[r for r in calls if r['window'] in ids and r['phase']=='measured']
        groups[backend]=dict(windows=list(ids),formal_calls=len(subset),
            complete_request=stats([r['end_ns']-r['begin_ns'] for r in subset]),
            process_CPU=stats([r['process_cpu_ns'] for r in subset]),
            mean_endpoint_J=text(sum((F(windows[i]['endpoint_J']) for i in ids),F(0))/2),
            mean_trapezoid_J=text(sum((F(windows[i]['trapezoid_J']) for i in ids),F(0))/2))
    comparisons={}
    cpu,fpga=groups['openblas_2t'],groups['fpga_flat_contiguous']
    for key in ('mean_endpoint_J','mean_trapezoid_J'):
        a,b=F(cpu[key]),F(fpga[key])
        comparisons[key]=dict(fpga_minus_cpu=text(b-a),fpga_minus_cpu_percent=text((b/a-1)*100),
            descriptive_only=True,significance_evaluated=False)
    previous=BOARD.parent.parent/'energy_prepare_m934k11g/work'
    old=doc(previous/'evidence/outer_receipt.json')
    oldexit=raw(previous/'launcher_exit.txt').decode().strip()
    require(oldexit=='2' and old['error_type']=='TimeoutError' and old['observed_os']=={}
        and not (previous/'evidence/worker').exists(), 'old pre-worker timeout kept separate')
    require(all(sha(Path(p).read_bytes()) == pin for p,pin in sources.items()), 'sources unchanged')
    result=dict(operation_success=True,author_crosscheck_not_independent_review=True,
        CSV_arithmetic='exact rational Fraction; Decimal only formatting',windows=windows,
        new_INT64_oracle_pairs=2,retained_full_outputs_recomputed=8,call_digest_rows=1824,
        PL_counter_rows_recomputed=pl,formal_calls=1808,warmup_calls=16,
        unsaved_outputs_independently_replayed=False,per_window_timings=per_window,groups=groups,
        comparisons=comparisons,old_timeout=dict(actual_wrapper_exit=int(oldexit),worker_directory_present=False),
        originals_unchanged=True,source_sha256=sources,board_access=False,GUI_access=False,
        joules_per_task_evaluated=False,meter_accuracy_verified=False,promotion=False,
        environment=dict(python=sys.version,numpy=np.__version__,executable=sys.executable))
    out.mkdir()
    (out/'recompute.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('source_sha256','windows','per_window_timings','environment')},indent=2))


if __name__ == '__main__':
    main()
