"""Build and exercise a self-contained offline review bundle; preserve inputs."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

HERE=Path(__file__).resolve().parent
BASE=HERE.parent


def sha(raw): return hashlib.sha256(raw).hexdigest()


def inventory(root):
    return {p.relative_to(root).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))
        for p in sorted(root.rglob('*')) if p.is_file() and p!=root/'MANIFEST.json'}


def main():
    bundle=HERE/'review_bundle_01'
    if bundle.exists(): raise ValueError('fresh review bundle required')
    bundle.mkdir()
    sourcekit=BASE/'metrics-msaa-compat-20261024_01/candidate_01'
    sourcepc=BASE/'energy-activation-20261024_02/pc_snapshot_01/work'
    kitbefore,pcbefore=inventory(sourcekit),inventory(sourcepc)
    shutil.copytree(sourcekit,bundle/'kit')
    shutil.copytree(sourcepc,bundle/'pc')
    for name in ('intake.py','recompute.py','test_recompute.py','run_review.py','report.md','review_request.md'):
        shutil.copy2(HERE/name,bundle/name)
    shutil.copy2(BASE/'energy-activation-20261024_02/approval.md',bundle/'approval.md')
    shutil.copy2(BASE/'energy-activation-20261024_02/pc_snapshot_01/manifest.json',bundle/'pc_snapshot_origin.json')
    archive=BASE/'energy-activation-20261024_02/board_return_3f13083a36bc43e9919508d87110f96d/energy_AadlGFiu_evidence_v1.tar.gz'
    shutil.copy2(archive,bundle/'original_board.tar.gz')
    def manifest():
        (bundle/'MANIFEST.json').write_text(json.dumps(dict(schema='energy-board-readback-review-v1',files=inventory(bundle)),indent=2)+'\n',encoding='utf-8')
    manifest()
    command=[sys.executable,'-I','-B',str(bundle/'run_review.py'),'--output',str(HERE/'validation_01')]
    process=subprocess.run(command,capture_output=True)
    (HERE/'validation.stdout.txt').write_bytes(process.stdout)
    (HERE/'validation.stderr.txt').write_bytes(process.stderr)
    if process.returncode:
        raise RuntimeError('bundle replay failed; keep partial directory and logs')
    validation=HERE/'validation_01'
    verdict=json.loads((validation/'review_receipt.json').read_bytes())
    if not verdict['operation_success']: raise ValueError('review replay receipt')
    results=bundle/'author_results'
    results.mkdir()
    for src,name in [(validation/'intake/intake.json','intake.json'),
                     (validation/'intake/frozen_readback_01/readback.json','frozen_readback.json'),
                     (validation/'arithmetic/recompute.json','recompute.json'),
                     (validation/'review_receipt.json','review_receipt.json')]:
        shutil.copy2(src,results/name)
    for p in validation.glob('*.txt'): shutil.copy2(p,results/p.name)
    for p in (validation/'intake').glob('frozen.*.txt'): shutil.copy2(p,results/p.name)
    shutil.copy2(HERE/'build_review.py',bundle/'build_review.py')
    manifest()
    # Verify actual transport ZIP members and bytes, including the manifest.
    zip_path=HERE/'opennpu_candidate_energy_board_readback_v1_review.zip'
    if zip_path.exists(): raise ValueError('fresh ZIP required')
    with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(bundle.rglob('*')):
            if p.is_file(): z.write(p,p.relative_to(bundle).as_posix())
    pins=inventory(bundle)
    with zipfile.ZipFile(zip_path) as z:
        expected=set(pins)|{'MANIFEST.json'}
        if len(z.namelist())!=len(expected) or set(z.namelist())!=expected or z.testzip() is not None: raise ValueError('ZIP member/integrity check')
        for name,pin in pins.items():
            raw=z.read(name)
            if len(raw)!=pin['bytes'] or sha(raw)!=pin['sha256']: raise ValueError('ZIP byte drift '+name)
    if inventory(sourcekit)!=kitbefore or inventory(sourcepc)!=pcbefore: raise ValueError('original input mutated')
    result=dict(operation_success=True,review_zip=str(zip_path),zip_bytes=zip_path.stat().st_size,
        zip_sha256=sha(zip_path.read_bytes()),zip_members=len(pins)+1,full_kit_files=len(kitbefore),PC_files=len(pcbefore),
        actual_replay_exit=process.returncode,frozen_exit=verdict['frozen_actual_exit'],
        original_inputs_unchanged=True,independent_review_completed=False,board_access=False,GUI_access=False,promotion=False)
    (HERE/'delivery.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__': main()
