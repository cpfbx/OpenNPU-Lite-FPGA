"""Pure in-memory negative checks. No board access and no altered raw files."""
import copy
import importlib.util
import json
from pathlib import Path
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('arithmetic_under_test',HERE/'recompute.py')
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def fixture():
    lines=['电压(mV),电流(mA),功率(W),D+(V),D-(V),电阻(R),电量(Wh),时间(ms),']
    for i in range(601):
        lines.append(f'5.0,0.4,2.0,0.0,0.0,12.5,{1+i/18000:.6f},{i*100},')
    return lines


def raw(lines):
    return ('\n'.join(lines)+'\n').encode('gb18030')


class ArithmeticChecks(unittest.TestCase):
    def test_positive(self):
        r=m.parse(raw(fixture()))
        self.assertEqual(r['trapezoid_J'],'120')
        self.assertEqual(r['rows'],601)
    def reject(self,change):
        lines=fixture()
        change(lines)
        with self.assertRaises(ValueError):
            m.parse(raw(lines))
    def test_missing_newline(self):
        with self.assertRaises(ValueError): m.parse(raw(fixture()).rstrip(b'\n'))
    def test_wrong_header(self): self.reject(lambda x:x.__setitem__(0,x[0].replace('(mV)','(V)')))
    def test_missing_row(self): self.reject(lambda x:x.pop(100))
    def test_duplicate_timestamp(self): self.reject(lambda x:x.__setitem__(100,x[99]))
    def test_missing_trailing_field(self): self.reject(lambda x:x.__setitem__(100,x[100][:-1]))
    def test_P_VI_mismatch(self): self.reject(lambda x:x.__setitem__(100,x[100].replace(',2.0,',',2.1,')))
    def test_negative(self): self.reject(lambda x:x.__setitem__(100,'-'+x[100]))
    def test_voltage(self): self.reject(lambda x:x.__setitem__(100,x[100].replace('5.0,0.4,2.0','6.0,0.4,2.4')))
    def test_peak_above_basis(self): self.reject(lambda x:x.__setitem__(100,x[100].replace('5.0,0.4,2.0','5.0,1.2,6.0')))
    def test_Wh_reset(self): self.reject(lambda x:x.__setitem__(100,x[100].replace('1.005500','0.000000')))
    def test_endpoint_lexical_precision(self): self.reject(lambda x:x.__setitem__(1,x[1].replace('1.000000','1.0')))
    def test_too_short(self): self.reject(lambda x:x.pop())
    def test_consistency_failure(self): self.reject(lambda x:x.__setitem__(-1,x[-1].replace('1.033333','1.050000')))
    def test_AND_not_OR(self):
        self.assertFalse(m.consistency(m.F(100),m.F('100.2')))  # abs passes, rel fails
        self.assertFalse(m.consistency(m.F(10000),m.F('10002'))) # rel passes, abs fails
    def test_stats_include_outlier(self):
        r=m.stats([1_000_000,1_000_000,100_000_000])
        self.assertEqual(r['max_ms'],'100')
        self.assertEqual(r['mean_ms'],'34')


class CounterChecks(unittest.TestCase):
    def setUp(self):
        self.metrics=dict(jobs=64,chain_jobs_completed=64,mode=11,input_bytes=4198400,
            output_bytes=1048576,output_valid_bytes=1048576,effective_macs=134217728,
            first_job_id=1,batch_pl_index=0,error_code=0,counter_contract_version=2,
            host_path_candidate='flat_contiguous',layout='k_major',counter_contract='d007_global_work_v2',status=5,
            pl_total_cycles=20,pl_work_union_cycles=15,pl_no_work_cycles=5,pl_overlap_credit_cycles=7,
            pl_array_output_work_overlap_cycles=2,pl_compute_wait_bank_cycles=0,pl_output_wait_tready_cycles=0,
            pl_load_work_cycles=5,pl_array_work_cycles=10,pl_store_work_cycles=4,pl_output_work_cycles=3)
    def test_positive(self): m.check_metrics(self.metrics,0)
    def reject(self,key,value):
        self.metrics[key]=value
        with self.assertRaises(ValueError): m.check_metrics(self.metrics,0)
    def test_count(self): self.reject('chain_jobs_completed',63)
    def test_boolean_integer(self): self.reject('error_code',False)
    def test_path(self): self.reject('host_path_candidate','flat')
    def test_sequence(self): self.reject('first_job_id',65)
    def test_total_conservation(self): self.reject('pl_total_cycles',21)
    def test_work_conservation(self): self.reject('pl_overlap_credit_cycles',8)
    def test_overlap_subset(self): self.reject('pl_array_output_work_overlap_cycles',4)
    def test_wait_bound(self): self.reject('pl_output_wait_tready_cycles',21)
    def test_error_status(self): self.reject('status',13)


if __name__=='__main__':
    unittest.main(verbosity=2)
