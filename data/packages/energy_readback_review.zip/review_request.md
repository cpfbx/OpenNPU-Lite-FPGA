# 新路径 ENERGY1808 实板原件：独立审查请求

审查范围仅为离线回读，不授权SSH、GUI、板测、预算/默认修改或重新采集。请标明实际审查人、环境和命令退出码。不得把作者的交叉算式称为独立人员审查。

请先核对外部ZIP SHA与MANIFEST.json，阅读report.md及approval.md。包内提供完整638文件冻结kit、原始板端tar.gz（包含成功和旧超时会话）、完整102文件PC快照、作者结果和脚本，不只是两份说明。

可用Python3.10+及NumPy，在解包目录以外的新目录执行：

```text
python -I -B /absolute/path/bundle/run_review.py --output /absolute/path/fresh-review-output
```

该入口只做本地单测、安全解包、调用冻结只读readback_candidate.py及另写的Fraction/INT64复算。保存所有实际退出码/标准流；错误即停，不覆盖输入。NumPy缺失明确报错，不联网安装，不运行kit的launch/preflight/prepare/driver入口。审查者可直接另写标准库复算，不必相信作者脚本。

重点核查：

1. 外部kit/plan/settings/policy固定值与现场批准对应；旧TimeoutError不混入新样本。
2. 1824行精确计划，1808正式/16预热/912PL。8份二进制独立INT64重算；其余仅有运行时核验/摘要，不写成1824份离线数值重放。
3. 每条FPGA工作量/序号/状态/global-work-v2守恒及新路径标记。冻结回读不替代新脚本的额外计数器检查。
4. 主worker与两个CPU进程实际退出/组消失、同inode规范锁、资源清理，39helper原始流与4次保存OFF闭合。
5. 四CSV全原字节、ACK大小与SHA、原表头/条件V/A解释、100ms/跨度/峰值/原端点词法精度。端点×3600、P(t)梯形积分及1.01J AND0.001，只按事前合同计算。
6. 两种能量口径均值及约1.4%仅本次完整保存包络描述，无J/次、空闲扣除、显著性/精度认证、跨日或KWS外推；所有正式慢点保留。
7. 便携复跑与反例测试，原件及冻结kit前后不变；首次失败不掩盖。当前资料没有正式能量晋升或默认合并批准。

原始tar SHA：0958892fc925f59b5a52afa40aab82ec2ad424ca98e8cf5b6b69816c523701ff。
