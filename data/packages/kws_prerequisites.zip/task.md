# 固定12窗完整混合推理：实现任务与交接范围

2026-10-27；人类负责人/最终决定者bx。用户安排外部人员或会话先尝试实现，Codex /root负责本机离线验收；未完成可验收候选时由Codex接手。外部实际执行者尚未提供，开始实现前填写姓名/会话和独立工作目录，不虚构认领或直接写共享工作树。

## 本次目标

在全新默认关闭候选内完成：**公共WAV→既有固定前处理→ARM/PC参考前缀→已有共享driver Op2→CPU DW3→已有共享driver Op4→CPU后缀→最终INT8 pre-softmax logits→分类及冻结门控兼容输出**。

这是纯离线功能候选，不操作开发板、真实规范锁、SSH/Jupyter、UT70或Vivado。共享调用使用原WireEnvironment软件夹具；它从实际提交wire字节算返回，不读黄金输出模拟设备。保留board_access=false/real_DMA_executed=false/real_cross_layer_PL_execution=false/promotion=false，不生成板端激活入口。

固定窗口索引：`0,30,60,90,120,150,180,210,240,270,300,400`。只卸载operator2和4，其余算子沿原整数CPU定义，不增加Op6/8卸载。不训练、不改MFCC/量化/模型/门限/标签顺序/既有硬件及监督合同。

## 模型与决策边界

模型固定SHA `aeea436800704fce17b17292e4412630ad856e9d777c044c64ef748a880bd0ae`；descriptor SHA `8bd3019d159ea3264164f09e90622423c29650647e8b340fe933b70a9030be08`。两基线的descriptor、模型和21份常量已逐字节核对，见prerequisites.json。

冻结CPU参考执行到tensor33的INT8 pre-softmax logits（operators0..11），后续由冻结门控做反量化及稳定softmax。不要把此路径表述为已经执行TFLite内部quantized SOFTMAX算子12/tensor34；若提供该支路须单列，不能替换主logits/门控定义。

**VAD来源必须单列。**现有质量包保存同PCM的历史NativeVAD flags，不含可跨平台运行的NativeVAD库。此次要求WAV前处理和完整模型动态计算；门控兼容回归可复用严格绑定source_id/PCM SHA的冻结VAD flags，必须写`vad_recomputed=false`及`vad_source=historical_fixed_pcm`。不得宣称新实现从WAV重算了VAD或实时决策；门控输出仅为离线建议，不执行任何物理/虚拟动作。若希望重算NativeVAD，请先报告依赖缺口，不改算法、伪造flags或私自扩任务。

## 冻结基线与新增范围

五份source_bundles原字节保持，禁止就地修订其manifest、源码、oracle、驱动、安全检查。新代码写在独立candidate目录，以绝对路径/受检私有命名空间绑定原组件；先确认相同源/类身份，再接线，避免预导入pynq或同名模块污染。

新增范围是图执行/算子后端分派与完整张量流、固定12窗运行入口和正反验证。原`IntegerReference.infer(compare=...)`仅在CPU算子执行后比对，不具备替换算子能力；只使用compare回调不足以完成任务。需要独立完整图执行器或适配接口，目标op2/4实际由共享call产生张量，随后被CPU算子消费。oracle可以另行调用冻结完整CPU参考，但不参与填补候选张量。

参考参数与黄金可以用于检验；候选WAV特征不能从fixed_features直接读取，候选op2输入不能从derive()['a']回填，op4结果之后不能读取期望logits替代CPU后缀。共享call内部原有derive/封存只作核验，不能借它绕过候选数据流。

保持单SharedOwner/单资源会话、12窗交替24次call、48jobs与ID1..48，一次初始化/一次正常close，原permit/类型/尾块/FFFF/计数/hold/停止规则不改。片上和驱动算术原样复用。

## 交付给Codex验收的文件

1. 新候选源码、manifest及版本说明；列出新增/改变文件，冻结源应零改。
2. 包外新目录PC入口与真实命令/退出码/stdout/stderr；测试方法数、skip、失败分开。
3. 12窗全特征、边界张量、raw/校正/INT8、wire、logits/决策与资源轨迹；来源与golden独立列明。
4. 正例与acceptance.md各反例的可运行代码和结果，保留失败首件，禁止自动重试到成功。
5. `handoff.md`：实际执行者/会话、base包pins、环境、完成与未完成项、所有失败、命令和进程状态。

先做1窗接缝冒烟，再固定12窗；不要先开发UI、生产推理库或新薄启动器。本包不含新候选实现，不记为功能已通过。

若失败：完整保留源码与日志，说明最后成功阶段及首个阻塞；由bx把原件交回Codex决定修正或接手，不把单纯超时/暂时无消息视为接手授权。Codex接手后仍需独立审查核心增量，不能自写自批。
