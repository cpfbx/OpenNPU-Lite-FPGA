"""Verify handoff bytes and unpack pinned prerequisites; never run their code."""
import argparse
import hashlib
import json
import shutil
import stat
import zipfile
from pathlib import Path, PurePosixPath

ROOT=Path(__file__).resolve().parent


def need(ok,why):
    if not ok:raise ValueError(why)


def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def verify(expected):
    raw=(ROOT/'manifest.json').read_bytes()
    need(pin(raw)['sha256']==expected,'external handoff manifest pin')
    files=json.loads(raw)['files'];actual={}
    for p in ROOT.rglob('*'):
        need(not p.is_symlink() and not getattr(p,'is_junction',lambda:False)(),'plain handoff tree')
        if p.is_file() and p!=ROOT/'manifest.json':actual[p.relative_to(ROOT).as_posix()]=pin(p.read_bytes())
    need(actual==files,'handoff file set/size/SHA drift')


def unpack(source,target,manifest_name,manifest_sha):
    with zipfile.ZipFile(source) as z:
        infos=z.infolist();need(len(infos)<1500,'bounded member count');seen=set();total=0
        need(pin(z.read(manifest_name))['sha256']==manifest_sha,'original source manifest pin')
        source_files=json.loads(z.read(manifest_name))['files']
        need({i.filename for i in infos if not i.is_dir()}==set(source_files)|{manifest_name},'exact source file set')
        for info in infos:
            n=info.filename;p=PurePosixPath(n)
            need(n and '\\' not in n and ':' not in n and not p.is_absolute() and '..' not in p.parts and p.as_posix()==n.rstrip('/'),'safe source path')
            need(n.casefold() not in seen and not info.flag_bits&1 and not stat.S_ISLNK(info.external_attr>>16),'plain unique source member')
            seen.add(n.casefold());total+=info.file_size
            need(total<96*1024*1024 and info.file_size<32*1024*1024,'bounded source extraction')
            dest=target.joinpath(*p.parts)
            if info.is_dir():dest.mkdir(parents=True,exist_ok=True);continue
            raw=z.read(info)
            if n!=manifest_name:need(pin(raw)==source_files[n],'source member SHA')
            dest.parent.mkdir(parents=True,exist_ok=True)
            with dest.open('xb') as stream:stream.write(raw)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--manifest-sha',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    verify(a.manifest_sha)
    out=a.output.resolve();need(not out.exists() and out.parent.is_dir() and not out.is_relative_to(ROOT) and not ROOT.is_relative_to(out),'fresh external source directory')
    out.mkdir();meta=json.loads((ROOT/'prerequisites.json').read_bytes())
    for name,row in meta['source_bundles'].items():
        source=ROOT/'source_bundles'/name;need(pin(source.read_bytes())==row['identity'],'source ZIP/tar external pin')
        if row['kind']=='zip':unpack(source,out/row['destination'],row['manifest_name'],row['manifest_sha256'])
        else:
            dest=out/'board_records'/name;dest.parent.mkdir(exist_ok=True)
            shutil.copyfile(source,dest)
    shutil.copyfile(ROOT/'selection12.json',out/'selection12.json')
    verify(a.manifest_sha)
    result=dict(operation_success=True,output=str(out),source_bundle_count=len(meta['source_bundles']),board_access=False,
                source_code_executed=False,inference_reexecuted=False,implementation_completed=False,promotion=False)
    (out/'unpack_receipt.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n',encoding='utf8');print(json.dumps(result))


if __name__=='__main__':main()
