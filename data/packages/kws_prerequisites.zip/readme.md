# KWS完整混合推理：前置文件与任务包

这是给bx指定实现者的自包含前置包，不含新候选实现，也不是板测授权。

阅读顺序：task.md → interfaces.md → acceptance.md → prerequisites.json。冻结基线以原ZIP及manifest为准，不以历史README里的旧“未ARM/待审”覆盖更新的evidence_notes。

五份source_bundles已提供：公共WAV/CPU完整参考、共享资源与wire模型、冻结决策/历史VAD、真实共享链原件、CPU420原件。无需获取当前工作区全部目录，也无需重新录音/下载/上板。CPU和共享基线的模型、descriptor及21份常量已逐字节核对。

先按包外交付单核ZIP/manifest，再在Python3.10+执行（替换路径，输出父目录已存在、目标未存在）：

```text
python -I -B /absolute/handoff/unpack_sources.py --manifest-sha <external_manifest_sha256> --output /absolute/fresh_sources
```

该命令只验证并展开文件，不运行里面的parent/worker/check/推理，不触碰板、锁或网络。实现/运行阶段另需已有NumPy。建议短的独立目录，勿在原工程共享工作树或本handoff目录内写新源码/pycache。

selection12.json中期望值只作oracle，候选必须实际从WAV重算特征，经完整动态模型至logits。门控历史VAD侧输入与重算VAD的边界详见task.md，禁止声称已重算NativeVAD。

请交回新源码ZIP、清单、真实日志和产物，不只交PASS摘要。由Codex进行离线验收；若Codex接手实现，仍要独立审查，最终准入由bx决定。
