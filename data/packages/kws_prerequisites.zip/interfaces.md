# 前置接口地图

先运行unpack_sources.py，只验证并解包，不执行任何基线入口。以下路径相对于新输出目录。

| 部分 | 精确位置 | 如何使用 |
| --- | --- | --- |
| 真实WAV前处理 | `cpu/candidate_05/src/frontend.py`：Frontend.process(item) | 从public_wav按cohort原偏移读16kHz单声道PCM，实际生成49×10 INT8特征；FFT/Hann/mel/DCT沿原参数 |
| 固定窗列表 | `cpu/candidate_05/data/cohort.json` | 420条原名单，仅取selection12.json指定索引；不更换窗口/样本 |
| WAV本体 | `cpu/candidate_05/public_wav/` | 401份公共WAV均已提供，不需板卡、新录音或下载 |
| 完整整数参考 | `cpu/candidate_05/component/portable_integer.py`：IntegerReference | 读取component/model，冻结oracle，输出tensor33 INT8 logits。不能将compare误用为执行后端 |
| 模型与常量 | `cpu/candidate_05/component/model/` | descriptor/原TFLite/constant_01..21；无需TF/TFLite native运行库；保留许可与来源 |
| 旧完整CPU参考循环 | `cpu/candidate_05/src/engine.py` | 只读接口参考，不要调用board parent/_worker；它依次校验并运行CPU全模型 |
| 共享接线组装 | `shared/core/device_binding.py`：configure(enabled=True) | 冷绑定；Components提供call/owner/CPU DW3/envelope/原runner等 |
| 单共享资源 | `shared/core/device_session.py`：SharedDeviceSession | 保留既有owner/permit/资源与close；只能在显式PC夹具环境内使用 |
| 实际wire软件模型 | `shared/core/device_fixture.py`：WireEnvironment | 从发送缓冲按wire解码计算，无set_case/黄金reply；禁止将其说成真实DMA |
| 现有部分链循环 | `shared/core/device_loop.py`：execute | 目前在out4结束；展示动态out2→DW3→out4及22种产物保存模式，不能直接称完整应用 |
| 共享call/策略 | `shared/core/frozen_process/frozen_shared/shared_call.py` / shared_policy.py | 24请求交替/1..48作业号；输入需owning C-contiguous int8(125,64)，exact InputEnvelope，身份与数值保留 |
| 原完整参考源 | `shared/core/frozen_process/frozen_shared/frozen_combo/frozen_kit/core/driver/frozen_op4/frozen_op2/frozen/reference.py` | 数学实现/比较回调语义参考；冷绑定/命名空间沿原，不随意import多个同名模块 |
| 决策帮助函数 | `quality/project/.offline-results/KWS-dscnn-quality-20261022_01/quality_core.py` | frozen gate加载、logits反量化和VAD flags校验 |
| 冻结门控源码 | `quality/project/.board-work/FPGA-20-zip-test-20261013/apps/kws/experiments/voice_gate_candidate.py` | gate.decide；policy=mode0/min_voiced3/run3/score0.95/gap0，不改门限 |
| 冻结VAD与旧policy | `quality/project/.offline-results/WP4-voice-gate-20261015_01/experiment_02/` | frozen_policy.json与evaluation/raw.jsonl；历史flags仅作固定PCM侧输入，准确标记未重算 |
| 新模型既有决策记录 | `quality/project/.offline-results/KWS-dscnn-quality-20261022_01/inference_02/raw.jsonl` | oracle_only，与新候选动态输出单独比较，禁止直接当候选结果返回 |
| 实板/ARM原件 | source_bundles中shared_board.tar.gz与cpu420_board.tar.gz | 用于核对身份/历史黄金；不运行其中命令，不复用旧boot/锁/plan |

## 必须保持的数据流

descriptor是实际拓扑依据。Op2为tensor23→24；DW3为24→25；Op4为25→26。前缀须从本窗实际MFCC特征算出23；后缀须从实际26继续算至33。Op2/4均为125×64×64（两jobs：64行＋61行有效/3行零填充）。两层权重不同，不能凭相同形状互换。

新图执行器的后端接口可由实现者自行设计，但应能记录operator_index、input/output tensor、窗口身份和张量摘要/数据流引用。只对2/4派发SharedCall，其他算子按冻结CPU语义；不会因为图执行器算出同样的结果就允许删除原返回raw/计数校验。

## 两套参考数学的关系

portable_integer.py和shared中reference.py因移除TFLite枚举依赖而不保证源文件SHA相同；**模型、descriptor和21份常量字节相同**已核实。新增代码需核对实际函数与量化语义，不能强制把两个模块互换成同一类来绕过现有绑定。CPU oracle与候选可共享冻结数学定义，其“独立”是执行路径/返回源分离，不冒充独立训练或音频前端。

Python3.10+、NumPy即可进行本任务主要PC计算；Linux x86_64优先，也应记录实际Windows/Linux版本与skip。无需Vivado、开发板、麦克风、仪表、TensorFlow或TFLite native库。公共WAV与库/模型来源许可只供原内部研究授权范围，不自动公开发布。
