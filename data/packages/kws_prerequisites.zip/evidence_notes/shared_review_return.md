# 共享12窗实板回读独审回件核对

2026-10-27，人类负责人bx，回件核对Codex /root；工程base仍为fb6b2f7。本次实际收到MD与ZIP两个附件，不将贴文中的Canvas同步说明当作附件缺失或执行授权。

## 对象与实际工作

独审报告36652 B，SHA256 `96232919300a3093d4cc89b9b39d6aa40d3aee02c1acdafae9fc19f5a71de44d`；Linux日志ZIP28793 B，SHA256 `3bc5718b1fadb1278763eaee8184d6cdb3051fa5757fd9a87f2a4d4722da8c9f`，19普通成员、18索引，顶层清单2694 B，SHA256 `cf5dee9e91dd4e1e902d268b23392b32050a43bca7495efe8dda4b17d6142434`。原字节保存在inputs，解包在linux_logs。intake_review.py实际exit0，CRC/全成员SHA/路径与类型边界通过。

自写audit_review.py实际exit0：核对原638文件包及两交付ZIP未变、20份源码SHA/AST行锚点、10份完整stdout/stderr流、三条便携内层命令实际退出[0,0,0]、reader实际退出0、264项二进制索引、24条metric JSON和原生命周期对应。Linux/Windows binary_index、metric_rows、scalar_and_lifecycle是JSON语义相同，换行字节不同；冻结readback1117 B则与原件/作者两套输出逐字节相同。附属代码只作AST/文本审查，没有执行reviewer_counterexamples.py，没有新推理、点积或板访问。

reviewer_audit_summary中27项rejected=true断言与源码对应，5项CLI结构化退出均1、拒绝原因与源码匹配。27是断言数，部分同一篡改分别针对标量审计和reader，不记作27个独立unittest方法，更不是实板故障测试。附件未另附reviewer_counterexamples整次执行的独立stdout/stderr及OS退出观察，也未提供完整Linux Python/NumPy/内核版本记录；以报告、结构化回执及源码交叉核对为证据层级，不编造本机复跑或缺失流。

## 裁决与P3

接受独审PASS的适用范围：固定12窗真实Op2→CPU DW3→Op4共享会话回件、正常进程/锁清理及8类各96000值复算。本阶段独审及回件核对完成，无默认晋升；按既定范围不安排追加上板。

P3事实成立：冻结fpga_evidence.validate_cleanup检查外层build_id/phase/error和recovery.confirmed，未显式校验fresh_accelerator_identity内部完整版本字典；原run_verify也未补该通用门。本次原件内该字典已由独审源码显式断言，且由本轮audit_review再核实为：

```json
{"build_id":539414645,"capabilities":528126,"counter_contract_version":1,"error":0,"expected_counter_contract_version":1,"phase":"post-soft-reset-before-start"}
```

原件outer与terminal中的该字典一致，字段类型正确。因此当前记录正确，P3不等于本次清理失败，也不需要补板测。本轮仅登记P3并核对当前数据，未修改冻结门禁、kit、原包或原件；通用离线加固仍是待办，不写成已经修复或风险接受晋升。若后续需要实施，建议单独PC补充审计完整六字段及反例，不改v1或重新上板；本提议不是附件自动授权。

## 口径

正式表述为“12窗×每类8000值×8类＝768000个标量检查点，零差异”。不是“256000元素×三处”，不是768000条独立语音样本。12次ARM DW3与24次真实Pointwise调用成立，但输入仍为固定CPU前缀，未变成420质量或全模型部署结论。性能/能量/异常恢复/长稳仍未评估，静态ARM_tested=false及认证false标记保留。

报告数字和方法描述的勘误单列于report_clarifications.md，原报告不改、不为文字问题重封或重测。下一步按已确认方向进入设计报告、复现指南及交付整理，图表在文档阶段统一做。当前未连接板卡；只知道26日该会话已正常结束，27日是否通电未核实。
