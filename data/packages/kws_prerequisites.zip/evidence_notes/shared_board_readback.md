# 固定12窗共享会话实板回件：本机只读复核

2026-10-26。人类负责人、范围批准者及现场确认者：bx。经本次明确例外授权，实际浏览器/Jupyter命令操作者为 Codex /root；bx 负责接线、Windows管理员提示及 LOCKONLY / PROBEONLY / PREPARE_SHARED12 / SHARED12 本人确认。此例外不延伸到后续板测。工程 base：`fb6b2f7b94de81a821bb08ebde0660d12752ba66`，既有工作树差异保留，未提交、推送、修改生产默认或晋升。

本轮完成固定12窗 `Op2 -> CPU depthwise3 -> Op4` 的单个真实资源会话正常执行。24次Pointwise调用、48个job全部完成，返回原件经冻结回读器及独立标准库标量算术复核通过。结论仅限该三算子部分链、固定输入与正常生命周期；外部独立审查尚待进行。

## 原件与现场身份

| 对象 | 身份 |
|---|---|
| 实板归档 | `shared12_evidence_v1.tar.gz`，1,956,826 B，SHA256 `7786d5eee69b1cd17c1296beee522d324ca5d7fff9cc3e6e1a3aea39010651b7` |
| 运行ZIP | `pynq_kws_shared12_launch_20261026_v1.zip`，6,374,135 B，263成员，SHA256 `68a39ff1994851f2c169fdd388ce7346929e60dc6930bcffb2d64fd19f3f7c16` |
| Kit清单 | `26747c4a3f4b31321708a0508c4a6d3111c5cb9e29faed997bba84f1b8bf5e03` |
| Core清单 | `a9b97371db2cae602f1b500384c2f4063436e08772960f05d532dbc62686b403`，253文件 |
| Plan | `5874317f809279569bf2c1a259bfc4aa3d3298ecdede1fe18b358faa5c715a14` |
| Request | `5a8af15e58d93921a092b463545cc23f5de10e8641fd788f0d27906c0f0140ae` |
| Preflight | `42648fbfc1a729ead5b9ddaa89955f46b4526b49d585e95fd1ab2e6fff3c9ac5` |
| 启动会话 | `7afdaa81-e698-4c10-9b74-448dc3b4028c`，Linux armv7l / Python3.10.4 / NumPy1.21.5 |
| 正常运行父/子 | PID5505 / PID5626；以各自proc启动ticks绑定，而非仅PID |
| 规范锁 | `/tmp/opennpu-kws-chain.lock`，device45826 / inode214968 / uid1000 / mode0644 / links1 |
| D075 BIT | `opennpu_gemm_accelerator.bit`，4,045,769 B，`47ae0a3640ef6d31db467118fd1822c04d465cd31171275fc04824824a20451c` |
| HWH | `opennpu_gemm_accelerator.hwh`，288,097 B，`d727688adc43d526b853e158648023f230fab081dd84e2c8e86437c60d747294` |

板端原工作目录：`/home/xilinx/jupyter_notebooks/shared12_run_7yju35dv`。原归档：`/home/xilinx/shared_return_8009880999a54f9492c251126aad031a/shared12_evidence_v1.tar.gz`。原件保留；另将字节相同的副本放入新目录 `shared12_browser_download_xyp9v469`，经已登录Jupyter浏览器网络栈下载。板端、浏览器下载和电脑保留件的大小及SHA全同，不把SHA同一性称作来源认证。

## 数值、数据流与计数

固定窗口为 `0,30,60,90,120,150,180,210,240,270,300,400`。每窗先完成实际Op2，再以其INT8输出运行CPU depthwise3，现算输出进入Op4实际wire。Op2输入仍来自冻结CPU前缀，不是从真实麦克风开始的全模型部署。两层各有首64行、尾61有效行及3行零填充，连续job_id为1..48。

8类结果分别逐值检查96,000项：Op2 raw/PS校正/INT8、DW3累加器/INT8、Op4 raw/PS校正/INT8，总计768,000个标量检查点，零差异。标准库复算器来自已审薄交付包的 `device_math.py` / `scalar_math.py`，原字节复制，不导入候选算术、NumPy或推理引擎；量化、wire索引与点积独立实现，但参数/描述符仍共享冻结来源，不冒充独立音频前端或重新训练的oracle。

24条运行期驱动指标满足原MODE11版本2、`pynq_mmio_read`、精确成功哨兵65535、error_code0、status5及原工作/周期守恒；每条512,000 MAC，总计12,288,000 Pointwise MAC。CPU DW3为12次，864,000含填充逻辑MAC。本轮两层的pl_total_cycles均26876，仅作为计数合同检查，不据此形成延迟、吞吐或能量收益结论。

每窗22份二进制，总计264份。实板归档328个普通文件，展开3,266,980 B；worker共307文件，其中artifact_manifest精确索引303项，另外4项为terminal/manifest自身及对应ready标记。不得沿用其他单层测试的85或98项计数。

## 正常退出与复核

实际板端启动器及外层wrapper退出均0。父进程真实Popen.wait与未注入POSIX组查询确认子进程退出、进程组消失。24张permit消耗、24次驱动返回、49次复用检查、1次owner.close对应，保留资源数0，同inode释放通过原lstat+/proc/locks只读回读，无新增抢锁探测。软复位后初始化计数版本1与运行期MODE11版本2分列。

冻结 `shared.py readback` 在电脑异路径重定位后实际退出0，输出1117 B与归档readback.json逐字节一致。本机标准库标量与生命周期复核实际退出0，原件、kit、解包内容复核前后未变。作者复跑不增加窗口数、检查种类或独立单测方法数；本包没有新增候选核心代码或宣称新增单测方法。

原始回执中的 `ARM_tested=false` 保留。冻结 `device_contract.flags()` 无条件写该静态字段；它不是随真实运行更新的观测字段。本报告依据现场ARM指纹、真实进程/锁、MMIO和原件链条陈述本次实板执行，不改该原字段，也不据其外推其他ARM环境。`run_ready=false`、`promotion=false`同样保持，不自动晋升。

本轮没有执行停止注入、故障恢复验证或长稳；正常close中的既有软复位不能写成故障恢复测试通过。未做420窗KWS质量、其他模型层、全模型PS/PL、性能或能量验收。离线审计的board_access=false仅说明审计不接板，与原件中真实运行board_access=true不混同。来源与操作者退出记录仍无独立密码学认证。

## 后续状态

本次实板操作与取件已结束，原计划范围内无待启动的追加板测。此处为作者本机复核通过、待外部独审的交付，不是执行者自审自批。若独审发现需要额外实板证据，先提交具体问题和范围，由bx决定；不自动重跑。图表继续留到最终文档阶段。

电脑内置Realtek在板测前经bx批准关闭EEE与环保节能，单次重启后短时恢复100Mbps连接；之前有Hardware IO/ESD事件，不能称根因已消除或完成长期稳定认证。板测期间未继续改网卡设置。开发板未由Codex关机，终端保留在已结束的shell。
