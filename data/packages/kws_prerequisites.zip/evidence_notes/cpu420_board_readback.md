# 新 DS-CNN ARM CPU420：数值链通过，当前参考实现尚不实时

2026-10-23；人类负责人/唯一实板操作者 bx；包准备及本地复算 Codex/root。base HEAD `fb6b2f7b94de81a821bb08ebde0660d12752ba66`，原分支及7项tracked dirty保留，无模型、门限、默认或公开范围变更。

## 本轮裁决

**公共 WAV → 固定参数前处理 → 新 DS-CNN 整数 CPU 参考链在 ARM 上 420/420 窗口完成、逐窗精确核对通过。** 完整205,800个INT8特征、5,040个INT8 logits与冻结PC参考逐字节相同；14项OS/数值/资源记录检查由本地冻结回读器重放全部通过。

这是经bx明确批准的一次CPU数值参考运行，不是FPGA执行、实时系统或部署质量验收。**当前前处理＋推理平均3.191秒/一秒音频窗，尚不能按逐秒窗口串行连续实时处理。** 不因正确性通过替换旧三层模型或默认策略。

[机器回读](audit_01/audit.json)、[完整成员清单](audit_01/member_inventory.json)、[冻结核验器本地重放](audit_01/replayed_readback/readback.json)、[本地审计源码](audit_board_return.py)。

## 原件、授权与运行身份

- bx明确批准“同意本次 CPU420”，亲自在Jupyter终端运行，新外层和冻结内层各确认一次CPU420。操作由bx完成，Codex只做本地准备与原件复算。
- [原始归档](../metrics-launch-prepared-20261023_01/board_return_072b2708041a48fdb74079687afd2f2f/kws_cpu420_0ROstCki_20261023_v1.tar.gz)：196,310 B，SHA256 `5939c7c0ae2e565bc7e67cbd5e1b815e207db40961ed1a6972396fd05b64ccba`；与用户提供的板端值一致。73成员＝64常规文件＋9目录，无链接/特殊成员/私人录音。用户误粘中文说明后，在新终端完成核验及归档，没有重跑CPU420。
- 运行ZIP SHA `48af78e87c84855806946cfaff949098f1e57359d566ea003ce182fdf96e9404`；kit manifest `b5f56aca8e5b9b288ee654c3943e89d3fdf2fc7d75de7d759c8bdd1b5e6ede9d`；KWS manifest `05d439cc3e5b8e5281e27bd2803848e7a0bb117803c2245dcbdd8efb2d8de0df`。
- 计划SHA `02062b1333b41ef5fe8ba4fb4065daed849d71f4e21cc33a44ebbe0b88222e7c`；请求SHA `bcee70c6d3bdcea8e3122104fc597c2542366e9d3964e90545a52cdb48d0ada6`；预检SHA `961dfb301f93328c957c80adadd8869342448c94ba7a7e72ba1e3ae77233e37f`。核原文件字节，不从聊天粘贴的空格重建。
- ARMv7l、Python3.10.4、NumPy1.21.5；原内核`6.6.10-xilinx-v2024.1-g3c0eca68c652`；原PYNQ venv，实际解释器`/usr/bin/python3.10`。完整环境/依赖SHA保存在机器回读中。
- boot `f6ca726f-2dbf-49d5-8b72-49793b3039c2`；规范锁device45826/inode214904/uid1000/mode0644/单链接。bx通过LOCKONLY确认已审缺锁准备，bootstrap回执显示探测描述符关闭，正式worker随后自行获取会话锁。
- 板序列/镜像名是操作者声明，不是实物认证。原历史`board_run_authorized=false`、包未授权标志保持原样；本次运行批准来自bx上述明确确认，不改JSON制造批准。

## 本地实际核验

stdlib审计整体exit0；不导入NumPy/TF/TFLite/PYNQ、不执行推理或浮点MFCC、不连接板子、不访问规范锁。

1. 先验证归档外部SHA，再检查全体成员路径、重复/大小写冲突、链接/特殊类型和大小，解包到全新`audit_01/original/`；压缩原件及提取字节事后不变。
2. 计划/请求及预检的副本字节对应；attempt绑定同一计划、请求与bx确认。用户shell的`launcher_exit.txt`为`0\n`；`entry_return.json`只作函数返回，不能代替OS wait。
3. 原冻结回读器实际exit0，14/14检查与板端回读一致；板端回读记录的8个来源SHA全部吻合。候选包前/后check两次实际exit0，原638kit字节不变。
4. 独立核420行的顺序、源窗/PCM、特征/logits摘要、精确接受标志、原采样数和整数计时；完整特征及logits与冻结参考直接做全字节比较。
5. 标准库读取401个公共WAV来源，重核420个固定偏移及补零PCM摘要。46窗实际短于16000 samples；46只是输入长度统计，不能直接等同历史47差异窗或推导全部根因。本地未重新执行浮点前处理，不宣称跨平台浮点MFCC逐位一致。

特征SHA `9fd7517250011f7b9e1d8e70e96085041f2136aa5e13f1392ff204bf6e7e4480`；logits SHA `de2b0d1355fdcbfc296bbb5b4c2f18e4748e346af779c1c71884f5c60f3320c8`。这420窗是固定集合的ARM重放，不增加独立样本，不是新识别率评估；不能与旧三层模型的实板/107/120证据合并。

## 耗时：诊断数值，不是实时验收

单位ms；P95采用nearest-rank。

| 记录区间 | 均值 | 中位数 | P95 | 最小—最大 |
| --- | ---: | ---: | ---: | ---: |
| 前处理 | 2031.107 | 2032.383 | 2104.260 | 1958.172—2136.655 |
| 整数模型推理 | 1160.126 | 1169.227 | 1214.772 | 1117.061—1325.656 |
| 同窗两段之和 | 3191.233 | 3165.027 | 3310.705 | 3079.066—3409.558 |

两段累计853.065064463s＋487.252931391s＝**1340.317995854s（约22分20.318秒）**。这是逐窗两段之和，**不是完整启动器墙钟**；不含全部初始化、锁审计、外层等待和收尾。没有完整启动器单调时钟区间，不能用tar mtime或终端UTC差补成精确全程时长。

前处理区间含WAV读取、来源/PCM核验、归一化、FFT/mel/DCT、量化和字节导出等；推理区间是当前可审计NumPy整数参考调用，不等于优化TFLite/C/NEON性能。前处理比重较大，但没有逐算子profiler，不能把总成本直接归因于Python、某个FFT或卷积。

运行中至少一次用户手动轻量状态查询记录worker PID2739/elapsed16:31/累计CPU16:30/平均99.9%/RSS23572KiB；不是最终CPU时间或整机空闲率。可能存在少量查询干扰，本轮不作无干扰性能资格测试。44份`observation_*.json`只是父进程等待记录（最后索引1320），不是已完成窗数、重试次数或精确全程时长。

## 退出、反例与未覆盖项

真实Popen.wait记录子进程退出0、进程组消失、observer_clean=true；worker记录lease_released=true/quarantined=false。释放回读为同一device/inode的lstat及`/proc/locks`快照，不是重新取锁来推断过去。worker成功stdout、空stderr；无本轮实板停止注入/异常恢复/自动kill或重试。

deployable/promotion/classification_quality_accepted/FPGA_access/energy_evaluated全部false。本地审计是同一作者会话的原件复算，不称另一人完成独审；SHA一致也不是来源签名或实物认证。

[新增回归源码](test_audit_board_return.py)实际**21/21通过，exit0**；[原始stderr](tests_01.stderr.txt)、[实际退出回执](tests_01.receipt.json)保留。覆盖字节/逐行摘要/源窗/接受标志篡改、bool计数/索引/计时、负计时、缺行、重复JSON/非有限数，以及tar路径/软硬链接/特殊类型/大小写冲突。FIFO为合成tar类型拒绝，不冒称Windows创建了真实POSIX FIFO。21项是新审计方法，不加算为板测次数，也不与原312方法混算。

## 下一步

CPU420不重跑。优先准备`flat＋连续面板`矩阵候选的同N服务批次能量，新的policy/basis/session、UT70/host/接线/保存/锁准备及确切实跑仍由bx事前批准；本次CPU420不授权能量采集。可并行做新DS-CNN逐层PS/PL离线可行性分析，但尚未批准改RTL、正式移植或启动PL测试。图表继续后置；保留当前数值成果与3.191s/窗限制，不训练、不改门限、不晋升默认。
