"""User-operated fixed12 shared-device candidate. All actions default off."""
import argparse
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import launch_support as s

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--kit-manifest-sha',required=True)
    sub=p.add_subparsers(dest='mode',required=True);sub.add_parser('check')
    q=sub.add_parser('preflight');q.add_argument('--output',required=True);q.add_argument('--enable-readonly-probe',action='store_true')
    q=sub.add_parser('prepare')
    for name in ('preflight','preflight-sha','evidence-parent','board-declaration'):q.add_argument('--'+name,required=True)
    q.add_argument('--prepare-data-only',action='store_true')
    for name in ('inspect-plan','run','stop','readback','archive'):
        q=sub.add_parser(name);q.add_argument('--work',required=True);q.add_argument('--plan-sha',required=True)
        if name=='run':q.add_argument('--enable-board-candidate',action='store_true')
        elif name=='stop':q.add_argument('--cooperative-only',action='store_true')
        elif name=='readback':q.add_argument('--output',required=True)
        elif name=='archive':q.add_argument('--export-parent',required=True);q.add_argument('--preserve-only',action='store_true')
    a=p.parse_args();s.verify_kit(a.kit_manifest_sha)
    if a.mode=='check':result=dict(check_pass=True,scope='pinned local bytes only',board_activation_approved=False,hardware_access=False,lock_acquired=False,run_ready=False,promotion=False)
    elif a.mode in ('preflight','prepare','inspect-plan','run','stop'):
        import launch_actions as x
        if a.mode=='preflight':result=x.preflight(a.output,a.kit_manifest_sha,enabled=a.enable_readonly_probe)
        elif a.mode=='prepare':result=x.prepare(a.preflight,a.preflight_sha,a.evidence_parent,a.board_declaration,a.kit_manifest_sha,enabled=a.prepare_data_only)
        elif a.mode=='inspect-plan':result=x.inspect_plan(a.work,a.plan_sha,a.kit_manifest_sha)
        elif a.mode=='run':result=x.run(a.work,a.plan_sha,a.kit_manifest_sha,enabled=a.enable_board_candidate)
        else:result=x.stop(a.work,a.plan_sha,a.kit_manifest_sha,enabled=a.cooperative_only)
    else:
        import launch_readback as r
        if a.mode=='readback':
            out=s.outside(a.output);s.require(not out.exists(),'fresh readback result');result=r.verify(a.work,a.plan_sha,a.kit_manifest_sha);s.write_json(out,result)
        else:result=r.archive(a.work,a.plan_sha,a.kit_manifest_sha,a.export_parent,preserve_only=a.preserve_only)
    print(s.json.dumps(result,sort_keys=True));return 0

if __name__=='__main__':
    try:raise SystemExit(main())
    except (OSError,ValueError,RuntimeError,ImportError,KeyError,TypeError,EOFError) as error:
        print(s.json.dumps(dict(operation_success=False,error_type=type(error).__name__,automatic_retry=False,automatic_kill=False,run_ready=False,promotion=False)),file=sys.stderr)
        raise SystemExit(2)
