"""User-operated thin actions. No injectable execution dependencies."""
import os
from pathlib import Path
import tempfile
import uuid
import launch_support as s

def preflight(output,kit_pin,*,enabled=False):
    s.require(enabled is True,'read-only preflight default-off');s.verify_kit(kit_pin)
    out=s.outside(output);s.require(not os.path.lexists(out),'fresh preflight file');s.confirm('PROBEONLY')
    value=s.observe(kit_pin);pin=s.write_json(out,value)
    return dict(preflight=str(out),preflight_sha256=pin['sha256'],hardware_access=False,board_test_started=False,lock_acquired=False)

def prepare(preflight_path,preflight_pin,parent,board_declaration,kit_pin,*,enabled=False):
    s.require(enabled is True,'data preparation default-off');s.verify_kit(kit_pin)
    pre=s.validate_preflight(s.pinned(preflight_path,preflight_pin),kit_pin)
    s.require(type(board_declaration) is str and 0<len(board_declaration)<=128 and all(ord(c)>=32 for c in board_declaration),'declared physical board')
    parent=s.outside(parent);s.require(parent.is_dir(),'existing evidence parent')
    s.confirm('PREPARE_SHARED12');s.require(s.observe(kit_pin)==pre,'preparation live observation drift')
    work=Path(tempfile.mkdtemp(prefix='shared12_run_',dir=parent)).resolve();run_id=str(uuid.uuid4())
    request=dict(schema='shared-device-request-candidate-v1',scope='fixed12-op2-cpu-dw3-op4-correctness-only',run_id=run_id,operator='bx',
        candidate_manifest_sha256=s.CORE_SHA,expected_boot=pre['environment']['boot_id'],expected_lock=pre['lock']['identity'],fixture=False,
        declarations=dict(utc=True,idle=True,wiring=True,separate_scope_approved=True))
    s.load_device('device_contract').validate_request(request,fixture=False)
    reqsha=s.write_json(work/'request.json',request)['sha256'];presha=s.write(work/'preflight.json',s.read(preflight_path))['sha256']
    s.require(presha==preflight_pin,'preflight copy unchanged')
    plan=dict(schema='shared-launch-plan-candidate-v1',run_id=run_id,operator='bx',board_work=str(work),board_declaration=board_declaration,
        kit_manifest_sha256=kit_pin,core_manifest_sha256=s.CORE_SHA,preflight_sha256=presha,request_sha256=reqsha,evidence='evidence',scope=request['scope'])
    plansha=s.write_json(work/'plan.json',plan)['sha256']
    return dict(work_directory=str(work),plan_sha256=plansha,request_sha256=reqsha,runtime_started=False,hardware_access=False)

def inspect_plan(work,plan_pin,kit_pin):
    s.verify_kit(kit_pin);plan,_,_=s.validate_plan(work,plan_pin,kit_pin);work=s.outside(work)
    names=('invocation.json','evidence','shell_attempt.txt','launcher_exit.txt','attempt_'+plan['run_id']+'.json','attempt_'+plan['run_id']+'.json.ready')
    s.require(not any(os.path.lexists(work/n) for n in names),'fresh prepared session only')
    return dict(plan_pass=True,scope='prepared bytes only; no live observations',hardware_access=False,run_ready=False,promotion=False)

def run(work,plan_pin,kit_pin,*,enabled=False):
    s.require(enabled is True,'board candidate default-off');s.verify_kit(kit_pin)
    plan,pre,request=s.validate_plan(work,plan_pin,kit_pin);work=s.outside(work)
    s.require(not any(os.path.lexists(work/n) for n in ('invocation.json','evidence','launcher_exit.txt','attempt_'+plan['run_id']+'.json','attempt_'+plan['run_id']+'.json.ready')),'single prepared launch; no retry')
    if os.path.lexists(work/'shell_attempt.txt'):s.require(s.read(work/'shell_attempt.txt',65)==(plan_pin+'\n').encode('ascii'),'shell attempt pin')
    s.require(s.observe(kit_pin)==pre,'current boot/dependency/lock changed')
    s.confirm('SHARED12')
    s.verify_kit(kit_pin);s.validate_plan(work,plan_pin,kit_pin)
    s.require(s.observe(kit_pin)==pre,'state changed during confirmation')
    s.write_json(work/'invocation.json',dict(schema='shared-launch-invocation-candidate-v1',operator='bx',confirmation='SHARED12',plan_sha256=plan_pin,
        request_sha256=plan['request_sha256'],kit_manifest_sha256=kit_pin,run_id=request['run_id'],fixture=False,
        approval_is_operator_declaration=True,physical_identity_authenticated=False))
    import real_parent
    result=real_parent.launch(work,plan_pin,kit_pin,enabled=True)
    s.require(result.get('operation_success') is True,'shared parent did not report success')
    return result

def stop(work,plan_pin,kit_pin,*,enabled=False):
    s.require(enabled is True,'cooperative stop default-off');s.verify_kit(kit_pin)
    s.validate_plan(work,plan_pin,kit_pin);work=s.outside(work)
    s.require((work/'invocation.json').is_file() and (work/'evidence/launch.json.ready').is_file(),'existing started session required')
    s.confirm('STOPONLY');flag=work/'evidence/stop.flag'
    if os.path.lexists(flag):s.require(s.read(flag,0)==b'','existing plain stop flag')
    else:s.write(flag,b'')
    return dict(cooperative_stop_requested=True,child_exit_observed=False,lock_released_proven=False,automatic_kill=False,automatic_retry=False)
