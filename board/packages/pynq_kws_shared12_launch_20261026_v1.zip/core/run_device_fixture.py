"""Explicit local PC pair fixture. No device launch capability."""
import argparse
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import device_binding as b
import device_contract as ct
def main():
    p=argparse.ArgumentParser();p.add_argument('--candidate-sha',required=True);p.add_argument('--output',required=True);p.add_argument('--profile',choices=ct.PROFILES,default='normal');p.add_argument('--enable-PC-fixture',action='store_true');p.add_argument('--diagnostic-finite-parent',action='store_true');a=p.parse_args()
    b.need(a.enable_PC_fixture is True,'device fixture default-off');b.pc_only();b.verify(a.candidate_sha)
    out=ct.outside(a.output);b.need(not out.exists(),'fresh external adapter fixture output');out.mkdir(parents=True)
    req=ct.fixture_request(a.candidate_sha,a.profile);pin=ct.write_json(out/'request.json',req)['sha256']
    from device_parent import launch_pc
    result=launch_pc(out/'request.json',pin,out/'evidence',enabled=True,diagnostic_finite=a.diagnostic_finite_parent)
    print({k:result[k] for k in ('operation_success','actual_exit_code','actual_wait_observed','cleanup_verified','finite_supervisor_fixture','process_group_proof_real','TEST_ONLY_parent_diagnostic','board_access','promotion')})
    return 0 if result['operation_success'] else 1
if __name__=='__main__':
    try:raise SystemExit(main())
    except (ValueError,OSError,RuntimeError) as error:
        print(dict(error_type=type(error).__name__,board_access=False,promotion=False),file=sys.stderr);raise SystemExit(2)
