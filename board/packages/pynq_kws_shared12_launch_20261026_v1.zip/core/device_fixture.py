"""PC ONLY boundary model: compute response from actual transmitted wire bytes.

No case bank/golden response or set_case. Not RTL, DMA or real lock evidence.
Original runner, lease-entry, recovery, owner and submit bodies execute unchanged.
"""
from contextlib import contextmanager
import gc
import os
import struct
import sys
from types import ModuleType,SimpleNamespace
from unittest.mock import patch
import numpy as np
import device_binding as b
import device_contract as ct

PROFILES=('normal','raw_fault','stop','unsafe','no_go','parent_stop','stop_before_start','factory_error','allocation_error','lock_busy')

class FixtureEvidence:
    fixture=True
    def __init__(self,env,proof):self.env=env;self.proof=proof
    def snapshot(self):
        value=self.env.lstat(ct.LOCK)
        return dict(path=ct.LOCK,device=value.st_dev,inode=value.st_ino)
    def live(self,ticket,pid,identity):
        b.need(self.env.fd_live and self.env.held and self.snapshot()==identity==ct.FAKE_LOCK,'live synthetic lease')
        b.need(type(ticket) is dict and type(ticket.get('pid')) is int and ticket['pid']==pid and ticket.get('fd')==99
               and ticket.get('process_start_ticks')==123 and all(ticket.get(k)==v for k,v in identity.items()),'exact synthetic ticket')
        return True
    def cleanup(self,value,ticket,pid):return self.proof.validate_cleanup(value,ticket,pid)
    def released(self,identity):
        b.need(self.env.fd_live is False and self.env.held is False and self.snapshot()==identity,'synthetic same-inode lease released')
        return dict(identity,lock_released_same_inode=True,fixture=True,source='PC-boundary-model; no proc/locks access')

class FixtureParentEvidence:
    fixture=True
    def __init__(self,proof):self.proof=proof
    def snapshot(self):return dict(ct.FAKE_LOCK)
    def live(self,ticket,pid,identity):
        b.need(type(ticket) is dict and type(ticket.get('pid')) is int and ticket['pid']==pid and ticket.get('fd')==99 and ticket.get('process_start_ticks')==123
               and identity==ct.FAKE_LOCK and all(ticket.get(k)==v for k,v in identity.items()),'parent synthetic ticket, not kernel evidence')
        return True
    def cleanup(self,value,ticket,pid):return self.proof.validate_cleanup(value,ticket,pid)
    def released(self,identity):return dict(identity,lock_released_same_inode=True,fixture=True,source='PC parent boundary model; no real lock observation')

class WireEnvironment:
    def __init__(self,components,profile='normal',*,addresses=(0x31000000,0x42000000),allocation_failure=None,clock=100.,version='3.1.1'):
        b.pc_only();b.need(profile in PROFILES,'explicit fixture profile')
        driver=sys.modules['pynq_gemm'];self.driver=driver;self.components=components;self.profile=profile
        module=sys.modules['driver_fixture'];base=module.fixture
        self.env=module.FakeCanonicalEnvironment(factory_error=profile=='factory_error',busy=profile=='lock_busy')
        self.evidence=FixtureEvidence(self.env,components.fpga_evidence)
        self.overrides={'lease_factory':self.env.factory}  # Wrapper invokes the original helper under fake OS boundaries.
        self.events=[];self.buffers=[];self.frames=[];self.start_attempts=0;self.outputs_produced=0;self.stop=profile=='stop_before_start';self.before_teardown=None
        if profile=='allocation_error':allocation_failure=1
        self.allocation_failure=allocation_failure
        outer=self
        class DMARegisters:
            def __init__(self):self.values={0:1,4:2,0x30:1,0x34:2}
            def read(self,offset):return self.values.get(offset,0)
            def write(self,offset,value):
                outer.events.append(('dma_write',offset,value));self.values[offset]=value
                if value&4 and offset in (0,0x30):
                    self.values.update({0:0,4:2,0x30:0,0x34:2})
                elif offset in (0,0x30) and value&1:self.values[offset+4]=2
        registers=DMARegisters()
        class Channel(base.Channel):
            @property
            def running(self):return bool(self._mmio.read(self._offset)&1)
            def transfer(self,buffer,nbytes):
                super().transfer(buffer,nbytes);self.last_nbytes=nbytes
        self.dma=SimpleNamespace(sendchannel=Channel(registers,0,self.events,'send'),recvchannel=Channel(registers,0x30,self.events,'recv'))
        jobs=[SimpleNamespace(effective_macs=262144),SimpleNamespace(effective_macs=249856)]
        class Engine(base.MMIO):
            def write(self,offset,value):
                if offset==driver.REG_CONTROL and value==driver.CONTROL_START:
                    outer.start_attempts+=1
                    if profile=='unsafe' and outer.start_attempts==8:raise RuntimeError('TEST_ONLY opaque START failure after DMA scheduling')
                    tx=outer.dma.sendchannel._active_buffer
                    b.need(tx is not None and outer.dma.recvchannel._active_buffer is not None,'DMA channels armed before START')
                    wire=bytes(tx[:outer.dma.sendchannel.last_nbytes])
                    raw=outer.compute_wire(wire)
                    if profile=='raw_fault' and outer.start_attempts==8:raw=bytes([raw[0]^1])+raw[1:]
                    self.payload=raw;outer.frames.append(dict(bytes=len(wire),sha256=b.sha(wire),wire=wire))
                    self.values[driver.REG_FAILED_TILE]=65535
                    super().write(offset,value);outer.outputs_produced+=1;return
                super().write(offset,value)
        self.engine=Engine(self.events,self.dma,b'',jobs)
        self.fake=ModuleType('pynq');self.fake.__version__=version;self.fake.Clocks=SimpleNamespace(fclk0_mhz=clock)
        overlay=SimpleNamespace(ip_dict={'axi_dma':{'type':'xilinx.com:ip:axi_dma:7.1'},'accel':{'phys_addr':0x40000000,'addr_range':4096}},axi_dma=self.dma)
        def Overlay(path,download):
            b.need(PathEquivalent(path,components.bit_path),'original fixed BIT path used');self.events.append(('fake_overlay',download));return overlay
        self.fake.Overlay=Overlay;self.fake.MMIO=lambda address,extent:self.engine
        def allocate(shape,dtype):
            if self.allocation_failure==len(self.buffers):raise RuntimeError('TEST_ONLY allocation failure')
            b.need(len(self.buffers)<2,'only two root buffers')
            buf=base.Buffer(shape[0],addresses[len(self.buffers)],self.events,'tx' if not self.buffers else 'rx');self.buffers.append(buf);return buf
        self.fake.allocate=allocate
    @staticmethod
    def compute_wire(wire):
        b.need(type(wire) is bytes and len(wire)==16512,'actual two-job wire length')
        chunks=[];weight=None
        for j,rows in enumerate((64,61)):
            pos=j*8256;header=struct.unpack_from('<16I',wire,pos)
            b.need(header[0]==0x4f4e5055 and header[4:7]==(125,64,64) and header[7]==64*j and header[9]==rows+(64<<8)+(64<<16),'actual wire geometry')
            payload=np.frombuffer(wire[pos+64:pos+8256],dtype=np.int8)
            a=payload[:4096].reshape(8,64,8).transpose(0,2,1).reshape(64,64)
            w=payload[4096:].reshape(8,64,8).transpose(1,0,2).reshape(64,64)
            b.need(not np.any(a[rows:]),'zero tail padding in submitted wire')
            if weight is not None:b.need(np.array_equal(weight,w),'same actual weights across two jobs')
            weight=w.copy();values=a[:rows].astype(np.int64)@w.astype(np.int64)
            b.need(np.all(values>=-(1<<31)) and np.all(values<(1<<31)),'wire model raw INT32 bounds');chunks.append(values.astype('<i4').tobytes())
        return b''.join(chunks)
    @contextmanager
    def install(self):
        gc.collect()
        with self.env.install(),patch.dict(sys.modules,{'pynq':self.fake}):
            try:yield self
            finally:
                # Only synthetic retention bookkeeping; never close/free a held owner.
                if getattr(self,'_captured_owner',None) is not None:
                    retained=sys.modules['batch_owner']._RETAINED
                    if self._captured_owner in retained:retained.remove(self._captured_owner)
    def capture(self,session,terminal):
        self._captured_owner=session.owner
        self.before_teardown=dict(owner=session.observation(),fake_fd_live=self.env.fd_live,fake_lock_held=self.env.held,
            fake_overlay_initializations=sum(e[0]=='fake_overlay' for e in self.events),buffer_allocations=len(self.buffers),
            buffer_addresses=[v.physical_address for v in self.buffers],fake_dma_transfer_pairs=sum(e[:2]==('transfer','send') for e in self.events),
            fake_START_attempts=self.start_attempts,fake_outputs_produced=self.outputs_produced,
            free_events=sum(e[0]=='free' for e in self.events),fake_open_calls=self.env.events.count('fake_open'),fake_flock_calls=self.env.events.count('fake_flock'),
            actual_wire_inputs=[{k:v for k,v in r.items() if k!='wire'} for r in self.frames],fixture=True,real_lock_access=False,real_DMA_executed=False)
    def boundary(self,where,index):
        if self.profile=='stop' and where=='before_depthwise' and index==90:self.stop=True
def PathEquivalent(a,p):
    from pathlib import Path
    return Path(a).resolve()==p.resolve()
if __name__=='__main__':raise SystemExit('Fixture library only. No hardware entry.')
