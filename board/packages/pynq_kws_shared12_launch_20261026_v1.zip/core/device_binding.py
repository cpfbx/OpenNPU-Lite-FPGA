"""Cold pinned shared device components. Import never constructs hardware."""
import hashlib
import importlib.util
import json
import sys
from dataclasses import dataclass
from pathlib import Path
ROOT=Path(__file__).resolve().parent
FROZEN=ROOT/'frozen_process'
FROZEN_PIN='8eae2aa48df05eb5b8becdecd34f058f34640b24e5991a2a8cf69261d51e4eda'
BIT_SHA='47ae0a3640ef6d31db467118fd1822c04d465cd31171275fc04824824a20451c'
HWH_SHA='d727688adc43d526b853e158648023f230fab081dd84e2c8e86437c60d747294'
_components=None
def need(ok,why):
    if not ok:raise ValueError(why)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def inventory(root):
    result={}
    for p in sorted(root.rglob('*')):
        need(not p.is_symlink() and not getattr(p,'is_junction',lambda:False)(),'plain nonalias candidate tree')
        if p.is_file():
            raw=p.read_bytes();result[p.relative_to(root).as_posix()]=dict(bytes=len(raw),sha256=sha(raw))
    return result
def load(name,path):
    path=path.resolve()
    if name in sys.modules:
        need(Path(getattr(sys.modules[name],'__file__','')).resolve()==path,'foreign device module '+name)
        return sys.modules[name]
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def previous():return load('shared_process_binding',FROZEN/'shared_process_binding.py')
def verify(pin):
    raw=(ROOT/'candidate_manifest.json').read_bytes();need(type(pin) is str and sha(raw)==pin,'external device candidate pin')
    files=json.loads(raw)['files'];actual=inventory(ROOT)
    need(set(actual)==set(files)|{'candidate_manifest.json'} and all(actual[n]==p for n,p in files.items()),'device candidate source drift')
    previous().verify(FROZEN_PIN)
    need(len(inventory(FROZEN))==242,'242 unchanged process files')
@dataclass(frozen=True)
class Components:
    owner_type:object
    policy_type:object
    call_type:object
    reference:object
    runner_type:object
    bit_path:Path
    lease_factory:object
    recovery_factory:object
    supervisor:object
    fpga_evidence:object
    observer:object
    depthwise:object
    combination:object
    envelope_type:object
def configure(*,enabled=False):
    global _components
    need(enabled is True,'device binding default-off')
    need(not any(n==r or n.startswith(r+'.') for n in sys.modules for r in ('pynq','tensorflow','tflite_runtime')),'device cold binding required')
    if _components is not None:
        _components.reference.sources2();return _components
    p=previous();p.verify(FROZEN_PIN);shared=p.shared()
    # Select once while cold. The exact original factories remain authoritative.
    selected=sys.modules['adapter_binding'].select(enabled=True)
    import shared_owner,shared_policy,shared_call,shared_reference
    bridge,observer=p.controls()
    proof=load('fpga_evidence',p.CORE/'frozen_control/fpga_evidence.py')
    loop=load('_device_frozen_loop',FROZEN/'shared_session_loop.py')
    bit=selected.bit_path
    need(sha(bit.read_bytes())==BIT_SHA and sha(bit.with_suffix('.hwh').read_bytes())==HWH_SHA,'unchanged D075 BIT/HWH')
    _components=Components(shared_owner.SharedOwner,shared_policy.SharedPolicy,shared_call.SharedCall,shared_reference.REFERENCE,
        selected.runner_type,bit,selected.lease_factory,selected.recovery_factory,bridge.supervised,proof,observer,
        loop.depthwise,shared.old('combination'),sys.modules['op4_candidate'].InputEnvelope)
    return _components
def require_arm(request):
    p=previous();guard=load('_device_original_arm_guard',p.CORE/'runtime_binding.py')
    guard.require_arm();guard.require_boot(request['expected_boot'])
def pc_only():previous().pc_only()
if __name__=='__main__':raise SystemExit('Library only. No board activation entry.')
