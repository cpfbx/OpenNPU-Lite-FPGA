"""Explicitly enabled local PC Popen/file-handshake/wait fixture, never ARM."""
import argparse
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import shared_process_binding as b
import shared_process_contract as ct


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate-sha', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--scenario', choices=ct.SCENARIOS, default='normal')
    parser.add_argument('--enable-PC-fixture', action='store_true')
    args = parser.parse_args()
    b.need(args.enable_PC_fixture is True, 'local process probe default-off')
    b.pc_only()
    b.verify(args.candidate_sha)
    output = ct.outside(args.output)
    b.need(not output.exists(), 'fresh local process output')
    output.mkdir(parents=True)
    req = ct.request(args.candidate_sha, args.scenario)
    pin = ct.write_json(output / 'request.json', req)['sha256']
    from shared_process_parent import launch
    record = launch(output / 'request.json', pin, output / 'evidence', enabled=True)
    print({k: record[k] for k in ['operation_success', 'actual_exit_code', 'actual_wait_observed', 'cleanup_verified',
                                 'finite_supervisor_fixture', 'process_group_proof_real', 'board_access', 'promotion']})
    return 0 if record['operation_success'] else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (ValueError, OSError, RuntimeError) as error:
        print({'error_type': type(error).__name__, 'board_access': False, 'promotion': False}, file=sys.stderr)
        raise SystemExit(2)
