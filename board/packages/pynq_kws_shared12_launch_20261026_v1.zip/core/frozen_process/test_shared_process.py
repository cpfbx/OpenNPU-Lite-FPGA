"""PC contract/observer/terminal counterexamples. Preserve all mutated copies."""
import ast
import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parent))
import shared_process_binding as b
import shared_process_contract as ct
from shared_process_parent import launch, validate_ready, validate_terminal
from shared_process_fixture import Guardian

TEMPLATE = Path(sys.argv.pop()).resolve()
OUTPUT = Path(sys.argv.pop()).resolve()
OUTPUT.mkdir(parents=True, exist_ok=False)


class SharedProcessTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.req = ct.strict_json((TEMPLATE / 'request.json').read_bytes())
        cls.pin = b.sha((TEMPLATE / 'request.json').read_bytes())
        cls.worker = TEMPLATE / 'evidence/worker'
        cls.terminal = ct.terminal(cls.worker)
        cls.bridge, cls.observer = b.controls()

    def fresh(self):
        return Path(tempfile.mkdtemp(prefix=self._testMethodName + '_', dir=OUTPUT))

    def copy_worker(self):
        target = self.fresh() / 'worker'
        shutil.copytree(self.worker, target)
        return target

    def validate(self, folder):
        return validate_terminal(folder, self.terminal['pid'], self.req, self.pin)

    def overwrite(self, path, value):
        path.write_bytes((json.dumps(value, indent=2, sort_keys=True) + '\n').encode())

    def reseal(self, folder):
        terminal = ct.strict_json((folder / 'terminal.json').read_bytes())
        terminal['summary_sha256'] = b.sha((folder / 'data/summary.json').read_bytes())
        self.overwrite(folder / 'artifact_manifest.json', dict(files=ct.manifest(folder)))
        terminal['artifact_manifest_sha256'] = b.sha((folder / 'artifact_manifest.json').read_bytes())
        self.overwrite(folder / 'terminal.json', terminal)

    def mutate_summary(self, change):
        target = self.copy_worker()
        summary = ct.strict_json((target / 'data/summary.json').read_bytes())
        change(summary)
        self.overwrite(target / 'data/summary.json', summary)
        for row in summary['windows']:
            self.overwrite(target / 'data' / ('window_%03d' % row['cohort_index']) / 'result.json', row)
        self.reseal(target)
        return target

    def test_01_exact_fixed_request(self):
        self.assertEqual(ct.validate_request(dict(self.req)), self.req)

    def test_02_old_board_schema_rejected(self):
        with self.assertRaises(ValueError):
            ct.validate_request(dict(self.req, schema='pointwise-process-request-candidate-v1'))

    def test_03_extra_request_field_rejected(self):
        with self.assertRaises(ValueError):
            ct.validate_request(dict(self.req, expected_boot='board'))

    def test_04_fixture_integer_not_boolean(self):
        with self.assertRaises(ValueError):
            ct.validate_request(dict(self.req, fixture=1))

    def test_05_unknown_or_boolean_scenario(self):
        for value in [True, 'board']:
            with self.subTest(value=value), self.assertRaises(ValueError):
                ct.validate_request(dict(self.req, scenario=value))

    def test_06_parent_default_off_before_spawn(self):
        with patch('subprocess.Popen') as spawn, self.assertRaisesRegex(ValueError, 'default-off'):
            launch('', '', self.fresh() / 'evidence')
        spawn.assert_not_called()

    def test_07_worker_default_off(self):
        from shared_process_worker import run_worker
        with self.assertRaisesRegex(ValueError, 'default-off'):
            run_worker({}, '', '', {})

    def test_08_arm_rejected_before_any_child(self):
        with patch.object(b.platform, 'machine', return_value='armv7l'), self.assertRaisesRegex(ValueError, 'no ARM'):
            b.pc_only()

    def test_09_frozen230_byte_manifest(self):
        files = b.inventory(b.SHARED)
        manifest = ct.strict_json((b.SHARED / 'candidate_manifest.json').read_bytes())['files']
        self.assertEqual(len(files), 230)
        self.assertEqual({n: v for n, v in files.items() if n != 'candidate_manifest.json'}, manifest)
        self.assertEqual(b.sha((b.SHARED / 'candidate_manifest.json').read_bytes()), b.SHARED_PIN)

    def test_10_math_and_loop_ast_unchanged(self):
        old = ast.parse((b.SHARED / 'shared_run.py').read_bytes())
        new = ast.parse((b.ROOT / 'shared_session_loop.py').read_bytes())
        old_math = next(n for n in old.body if isinstance(n, ast.FunctionDef) and n.name == 'depthwise')
        new_math = next(n for n in new.body if isinstance(n, ast.FunctionDef) and n.name == 'depthwise')
        self.assertEqual(ast.dump(old_math), ast.dump(new_math))
        old_for = next(n for n in ast.walk(old) if isinstance(n, ast.For) and isinstance(n.target, ast.Name) and n.target.id == 'index')
        new_for = next(n for n in ast.walk(new) if isinstance(n, ast.For) and isinstance(n.target, ast.Name) and n.target.id == 'index')
        self.assertEqual(ast.dump(old_for), ast.dump(new_for))

    def test_11_duplicate_json_rejected(self):
        with self.assertRaisesRegex(ValueError, 'duplicate'):
            ct.strict_json(b'{"a":1,"a":2}')

    def test_12_nonfinite_json_rejected(self):
        with self.assertRaisesRegex(ValueError, 'nonfinite'):
            ct.strict_json(b'{"a":NaN}')

    def test_13_unpublished_json_not_parsed(self):
        path = self.fresh() / 'part.json'
        path.write_bytes(b'{partial')
        self.assertIsNone(ct.ready(path))

    def test_14_write_never_overwrites(self):
        path = self.fresh() / 'original'
        ct.write(path, b'original')
        with self.assertRaises(FileExistsError):
            ct.write(path, b'new')
        self.assertEqual(path.read_bytes(), b'original')

    def test_15_inside_candidate_output_rejected(self):
        with self.assertRaisesRegex(ValueError, 'outside immutable'):
            ct.outside(b.ROOT / 'forbidden')
        self.assertFalse((b.ROOT / 'forbidden').exists())

    def test_16_wrong_request_pin_before_spawn(self):
        with patch('subprocess.Popen') as spawn, self.assertRaisesRegex(ValueError, 'request pin'):
            launch(TEMPLATE / 'request.json', '0' * 64, self.fresh() / 'evidence', enabled=True)
        spawn.assert_not_called()

    def test_17_launch_other_run_rejected(self):
        binding = ct.launch_binding(self.req, self.pin)
        binding['run_id'] = '00000000-0000-0000-0000-000000000001'
        with self.assertRaisesRegex(ValueError, 'launch request'):
            ct.validate_launch(binding, self.req, self.pin)

    def test_18_boolean_parent_pid_rejected(self):
        binding = ct.launch_binding(self.req, self.pin)
        binding['parent']['pid'] = True
        with self.assertRaisesRegex(ValueError, 'parent process'):
            ct.validate_launch(binding, self.req, self.pin)

    def ready_value(self):
        value = ct.ready(self.worker / 'ready.json')
        value['pid'] = os.getpid()
        value['process'] = ct.process_identity(os.getpid())
        value['ticket']['pid'] = os.getpid()
        return value

    def test_19_wrong_fake_inode_rejected(self):
        value = self.ready_value()
        value['ticket']['inode'] = 12
        with self.assertRaisesRegex(ValueError, 'ticket binding'):
            validate_ready(value, SimpleNamespace(pid=os.getpid()), self.req, self.pin)

    def test_20_wrong_ready_pid_rejected(self):
        value = self.ready_value()
        value['pid'] += 1
        with self.assertRaisesRegex(ValueError, 'bound worker ready'):
            validate_ready(value, SimpleNamespace(pid=os.getpid()), self.req, self.pin)

    def test_21_actual_process_creation_identity(self):
        identity = ct.process_identity(os.getpid())
        self.assertEqual(identity, ct.process_identity(os.getpid()))
        self.assertGreater(identity['start'], 0)
        self.assertEqual(validate_ready(self.ready_value(), SimpleNamespace(pid=os.getpid()), self.req, self.pin)['pid'], os.getpid())

    def test_22_guardian_single_spawn(self):
        guardian = Guardian()
        guardian.begin()
        with self.assertRaisesRegex(ValueError, 'one child'):
            guardian.begin()

    def test_23_guardian_retains_unresolved_child(self):
        guardian = Guardian()
        child = object()
        guardian.begin()
        guardian.retain(child)
        guardian._hold(RuntimeError())
        with self.assertRaisesRegex(ValueError, 'unresolved'):
            guardian.forget(child)
        self.assertIs(guardian.child, child)

    def test_24_guardian_thread_drift(self):
        guardian = Guardian()
        errors = []
        def operation():
            try:
                guardian.begin()
            except ValueError:
                errors.append(True)
        thread = threading.Thread(target=operation)
        thread.start()
        thread.join()
        self.assertEqual(errors, [True])
        self.assertFalse(guardian.used)

    def child(self, result=0, timeouts=0):
        class Child:
            pid = os.getpid()
            waits = 0
            def wait(self, timeout):
                self.waits += 1
                if self.waits <= timeouts:
                    raise subprocess.TimeoutExpired('TEST_ONLY', timeout)
                return result
        return Child()

    def test_25_original_observer_waits_then_queries(self):
        child = self.child(timeouts=1)
        result = self.observer.observe_exit(child, Guardian(), lambda: False, lambda: None, group_query=lambda pid: True)
        self.assertEqual(child.waits, 2)
        self.assertTrue(result['actual_wait_observed'] and result['group_query_injected'])
        self.assertFalse(result['automatic_kill'])

    def test_26_observer_rejects_boolean_exit(self):
        guardian = Guardian()
        with self.assertRaisesRegex(ValueError, 'non-bool'):
            self.observer.observe_exit(self.child(True), guardian, lambda: False, lambda: None, group_query=lambda pid: True)
        self.assertTrue(guardian.held)

    def test_27_group_presence_preserves_partial_wait(self):
        guardian = Guardian()
        with self.assertRaises(RuntimeError) as caught:
            self.observer.observe_exit(self.child(), guardian, lambda: False, lambda: None, group_query=lambda pid: False)
        self.assertTrue(caught.exception.comparison_exit_observation['actual_wait_observed'])
        self.assertFalse(caught.exception.comparison_exit_observation['process_group_absent'])
        self.assertTrue(guardian.held)

    def test_28_stop_published_once_no_kill_or_retry(self):
        stops = []
        child = self.child(timeouts=2)
        result = self.observer.observe_exit(child, Guardian(), lambda: True, lambda: stops.append(True), group_query=lambda pid: True)
        self.assertEqual(stops, [True])
        self.assertEqual(child.waits, 3)
        self.assertTrue(result['stop_seen'])

    def test_29_original_signal_bridge_restores_handlers(self):
        previous = signal.getsignal(signal.SIGTERM)
        def operation(stopped):
            signal.raise_signal(signal.SIGTERM)
            self.assertTrue(stopped())
        with self.assertRaises(RuntimeError) as caught:
            self.bridge.supervised(Guardian(), operation, lambda value: None, lambda: False, enabled=True)
        self.assertIs(signal.getsignal(signal.SIGTERM), previous)
        self.assertIn(int(signal.SIGTERM), caught.exception.supervision_bridge_observation['stop_signals'])

    def test_30_actual_normal_terminal_accepted(self):
        self.assertTrue(self.validate(self.worker)['operation_success'])

    def test_31_missing_terminal_marker_rejected(self):
        target = self.copy_worker()
        (target / 'terminal.json.ready').unlink()
        with self.assertRaisesRegex(ValueError, 'published terminal'):
            self.validate(target)

    def test_32_unindexed_member_rejected(self):
        target = self.copy_worker()
        (target / 'extra.txt').write_bytes(b'x')
        with self.assertRaisesRegex(ValueError, 'final worker artifacts'):
            self.validate(target)

    def test_33_reindexed_extra_member_still_rejected(self):
        target = self.copy_worker()
        (target / 'extra.txt').write_bytes(b'x')
        self.reseal(target)
        with self.assertRaisesRegex(ValueError, 'scenario worker member'):
            self.validate(target)

    def raw_flip(self, name):
        target = self.copy_worker()
        path = target / 'data/window_000' / name
        raw = path.read_bytes()
        path.write_bytes(bytes([raw[0] ^ 1]) + raw[1:])
        summary = ct.strict_json((target / 'data/summary.json').read_bytes())
        summary['windows'][0]['artifacts'][name] = dict(bytes=len(raw), sha256=b.sha(path.read_bytes()))
        self.overwrite(path.parent / 'result.json', summary['windows'][0])
        self.overwrite(target / 'data/summary.json', summary)
        self.reseal(target)
        return target

    def test_34_raw_flip_resigned_and_relu_unchanged_rejected(self):
        with self.assertRaisesRegex(ValueError, 'frozen golden'):
            self.validate(self.raw_flip('op2_raw.i32'))

    def test_35_output_flip_resigned_rejected(self):
        with self.assertRaisesRegex(ValueError, 'frozen golden'):
            self.validate(self.raw_flip('op4_output.i8'))

    def test_36_wire_flip_resigned_rejected(self):
        with self.assertRaisesRegex(ValueError, 'frozen golden'):
            self.validate(self.raw_flip('op4_wire.bin'))

    def test_37_wrong_success_sentinel_rejected(self):
        target = self.mutate_summary(lambda s: s['windows'][0]['op4_fake_metrics'].update(failed_tile_index=0))
        with self.assertRaisesRegex(ValueError, 'counter gate'):
            self.validate(target)

    def test_38_boolean_counter_rejected(self):
        target = self.mutate_summary(lambda s: s['windows'][0]['op2_fake_metrics'].update(first_job_id=True))
        with self.assertRaisesRegex(ValueError, 'counter gate'):
            self.validate(target)

    def test_39_cross_window_source_rejected(self):
        target = self.mutate_summary(lambda s: s['windows'][0].update(source_id=s['windows'][1]['source_id']))
        with self.assertRaisesRegex(ValueError, 'window source'):
            self.validate(target)

    def test_40_completion_prefix_gap_rejected(self):
        target = self.mutate_summary(lambda s: s['completed_indices'].__setitem__(0, 30))
        with self.assertRaisesRegex(ValueError, 'completion prefix'):
            self.validate(target)

    def test_41_counter_version_rejected(self):
        target = self.mutate_summary(lambda s: s['windows'][0]['op4_fake_metrics'].update(counter_contract_version=1))
        with self.assertRaisesRegex(ValueError, 'counter gate'):
            self.validate(target)

    def test_42_cleanup_false_claim_rejected(self):
        target = self.copy_worker()
        terminal = ct.strict_json((target / 'terminal.json').read_bytes())
        terminal['cleanup']['before_test_teardown']['fake_lock_held'] = True
        self.overwrite(target / 'terminal.json', terminal)
        with self.assertRaisesRegex(ValueError, 'ticket/cleanup'):
            self.validate(target)

    def test_43_board_scope_forgery_rejected(self):
        target = self.copy_worker()
        terminal = ct.strict_json((target / 'terminal.json').read_bytes())
        terminal['board_access'] = True
        self.overwrite(target / 'terminal.json', terminal)
        with self.assertRaisesRegex(ValueError, 'fixed scope'):
            self.validate(target)

    def test_44_software_consumed_count_not_dma_completion(self):
        target = self.mutate_summary(lambda s: s['single_session_fixture']['before_test_teardown']['software_admission'].update(consumed=25))
        terminal = ct.strict_json((target / 'terminal.json').read_bytes())
        terminal['cleanup']['before_test_teardown']['software_admission']['consumed'] = 25
        self.overwrite(target / 'terminal.json', terminal)
        with self.assertRaisesRegex(ValueError, 'permit consumption'):
            self.validate(target)

    def test_45_forbidden_engine_submodule_rejected(self):
        with patch.dict(sys.modules, {'tensorflow.lite': object()}), self.assertRaisesRegex(ValueError, 'cold PC'):
            b.shared()

    def test_46_stop_before_supervised_operation(self):
        called = []
        with self.assertRaises(RuntimeError):
            self.bridge.supervised(Guardian(), lambda stopped: called.append(True), lambda value: None, lambda: True, enabled=True)
        self.assertEqual(called, [])

    def test_47_terminal_foreign_pid_rejected(self):
        with self.assertRaisesRegex(ValueError, 'process/request'):
            validate_terminal(self.worker, self.terminal['pid'] + 1, self.req, self.pin)

    def test_48_fake_finite_supervisor_cannot_claim_normal(self):
        target = self.copy_worker()
        terminal = ct.strict_json((target / 'terminal.json').read_bytes())
        terminal['finite_supervisor_fixture'] = True
        self.overwrite(target / 'terminal.json', terminal)
        with self.assertRaisesRegex(ValueError, 'lifecycle scope'):
            self.validate(target)

    def test_49_reindexed_nonempty_publication_rejected(self):
        target = self.copy_worker()
        (target / 'entered_000.json.ready').write_bytes(b'x')
        self.reseal(target)
        with self.assertRaisesRegex(ValueError, 'bounded single-link|publication'):
            self.validate(target)

    def test_50_resigned_foreign_progress_window_rejected(self):
        target = self.copy_worker()
        path = target / 'entered_000.json'
        value = ct.strict_json(path.read_bytes()); value['cohort_index'] = 30
        self.overwrite(path, value); self.reseal(target)
        with self.assertRaisesRegex(ValueError, 'entered window'):
            self.validate(target)

    def test_51_resigned_foreign_progress_pid_rejected(self):
        target = self.copy_worker()
        path = target / 'entered_000.json'
        value = ct.strict_json(path.read_bytes()); value['pid'] += 1
        self.overwrite(path, value); self.reseal(target)
        with self.assertRaisesRegex(ValueError, 'entered window'):
            self.validate(target)

    def test_52_resigned_boolean_window_rejected(self):
        target = self.copy_worker()
        path = target / 'entered_000.json'
        value = ct.strict_json(path.read_bytes()); value['cohort_index'] = False
        self.overwrite(path, value); self.reseal(target)
        with self.assertRaisesRegex(ValueError, 'entered window'):
            self.validate(target)

    def test_53_resigned_ready_ticket_drift_rejected(self):
        target = self.copy_worker()
        path = target / 'ready.json'
        value = ct.strict_json(path.read_bytes()); value['ticket']['inode'] += 1
        self.overwrite(path, value); self.reseal(target)
        with self.assertRaisesRegex(ValueError, 'ready matches terminal'):
            self.validate(target)

    def test_54_top_resource_snapshot_mismatch_rejected(self):
        target = self.copy_worker()
        path = target / 'terminal.json'
        value = ct.strict_json(path.read_bytes()); value['cleanup']['resources']['held'] = True
        self.overwrite(path, value)
        with self.assertRaisesRegex(ValueError, 'resource snapshot'):
            self.validate(target)

    def test_55_finite_test_hook_does_not_claim_original_execution(self):
        from shared_process_fixture import finite_supervised
        result = finite_supervised(Guardian(), lambda stop: True, lambda value: None, lambda: False, enabled=True)
        self.assertIs(result['signals']['original_supervisor_unchanged'], False)
        self.assertIs(result['signals']['TEST_ONLY_finite_retention'], True)


if __name__ == '__main__':
    unittest.main(verbosity=2)
