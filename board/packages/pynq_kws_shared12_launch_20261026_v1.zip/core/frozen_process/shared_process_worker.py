"""One x86 fake-resource worker: unchanged shared calls + controlled lifecycle."""
import os
import time
from pathlib import Path
import shared_process_binding as b
import shared_process_contract as ct


def run_worker(req, request_sha, folder, binding, *, enabled=False):
    b.need(enabled is True, 'worker default-off')
    b.pc_only()
    ct.validate_request(req)
    ct.digest(request_sha)
    ct.validate_launch(binding, req, request_sha)
    b.verify(req['candidate_manifest_sha256'])
    folder = ct.outside(folder)
    b.need(folder.is_dir() and not any(folder.iterdir()), 'fresh empty worker folder')
    shared = b.shared()
    from shared_reference import REFERENCE as ref
    from shared_fixture import SharedHarness, FakeCanonicalEnvironment
    from shared_session_loop import run_loop
    bridge, _ = b.controls()
    from shared_process_fixture import finite_supervised
    cases2 = {i: ref.derive(2, i) for i in ct.INDICES}
    cases4 = {i: ref.derive(4, i) for i in ct.INDICES}
    parameters = shared.old('combination').depthwise_parameters()
    h = SharedHarness(cases2[0])
    env = FakeCanonicalEnvironment()
    outer = folder.parent
    summary = None
    primary = None
    signals = None
    ticket = None
    stage = 'before_owner_start'
    active_stop = {'callback': None}
    finite = req['scenario'] == 'unsafe'

    def external_stopped():
        if req['scenario'] == 'stop_before_start':
            return True
        if os.path.lexists(outer / 'stop.flag'):
            return True
        try:
            return os.getppid() != binding['parent']['pid'] or ct.process_identity(binding['parent']['pid']) != binding['parent']
        except (OSError, ValueError):
            return True

    def publish(value):
        ct.write_json(folder / 'attention_retained.json', dict(value, run_id=req['run_id'], request_sha256=request_sha,
                                                              **ct.FLAGS))

    def ready(harness):
        nonlocal stage, ticket
        stage = 'ready_wait_go'
        harness.owner.stop_requested = lambda: active_stop['callback']() is not False
        ticket = harness.owner._lease.audit()
        value = dict(kind='ready', pid=os.getpid(), process=ct.process_identity(os.getpid()),
                     run_id=req['run_id'], request_sha256=request_sha, ticket=ticket,
                     identity=ct.FAKE_IDENTITY, fake_lock_evidence=True, **ct.FLAGS)
        ready_sha = ct.write_json(folder / 'ready.json', value)['sha256']
        deadline = time.monotonic() + 30.0
        while True:
            if active_stop['callback']() is not False:
                raise shared.old('combination').ChainStop('PC gate stop')
            go = ct.ready(outer / 'go.json')
            if go is not None:
                expected = dict(kind='go', pid=os.getpid(), parent=binding['parent'], run_id=req['run_id'],
                                request_sha256=request_sha, ready_sha256=ready_sha, fixture=True)
                b.need(go == expected, 'exact parent GO binding')
                return
            if time.monotonic() >= deadline:
                raise RuntimeError('PC_ONLY fake-resource handshake expired')
            time.sleep(0.025)

    def operation(stopped):
        nonlocal summary, stage
        active_stop['callback'] = stopped
        if stopped() is not False:
            raise shared.old('combination').ChainStop('stop before fake acquisition')

        def boundary(where, index):
            nonlocal stage
            stage = where
            if where == 'op2_before_submit':
                ct.write_json(folder / ('entered_%03d.json' % index),
                              dict(stage=where, cohort_index=index, pid=os.getpid(), run_id=req['run_id'], request_sha256=request_sha))
            if req['scenario'] == 'parent_stop' and where == 'before_depthwise' and index == 90:
                ct.write_json(folder / 'await_parent_stop.json', dict(stage=where, cohort_index=index, pid=os.getpid(), run_id=req['run_id']))
                deadline = time.monotonic() + 30.0
                while not stopped():
                    if time.monotonic() >= deadline:
                        raise RuntimeError('PC_ONLY cooperative-stop fixture wait expired')
                    time.sleep(0.025)
            return stopped()

        scene = req['scenario'] if req['scenario'] in ('normal', 'raw_fault', 'stop', 'unsafe') else 'normal'
        summary = run_loop(folder / 'data', h=h, env=env, cases2=cases2, cases4=cases4, parameters=parameters,
                           ready=ready, scenario=scene, stopped=boundary)
        if summary['operation_success'] is not True:
            raise RuntimeError('fixed offline chain did not complete')
        return True

    try:
        result = (finite_supervised if finite else bridge.supervised)(h.owner, operation, publish, external_stopped, enabled=True)
        signals = result['signals']
    except BaseException as error:
        primary = error
        signals = getattr(error, 'supervision_bridge_observation', None)
    status = h.owner.supervision_status
    unresolved = any(status[k] for k in ('held', 'safety_unresolved', 'lease_retained', 'runner_retained', 'root_buffers_retained'))
    b.need(not unresolved or finite, 'normal supervisor may not return unresolved resources')
    cleanup = dict(kind='TEST_ONLY_retained' if unresolved else ('closed_fake_owner' if ticket is not None else 'no_fake_resources'),
                   resources=status, before_test_teardown=h.before_teardown, synthetic_context_teardown=True,
                   fake_lock_evidence=True, real_lock_access=False)
    ok = primary is None and summary is not None and summary['operation_success'] is True and not unresolved
    if not ok:
        failure = None if summary is None else summary['failure']
        ct.write_json(folder / 'fault.json', dict(request_sha256=request_sha, pid=os.getpid(), run_id=req['run_id'],
                                                 stage=stage, error_type=type(primary).__name__ if primary else 'Incomplete',
                                                 chain_first_failure=failure, safety_unresolved=unresolved, **ct.FLAGS))
    terminal = dict(operation_success=ok, pid=os.getpid(), process=ct.process_identity(os.getpid()), run_id=req['run_id'],
                    request_sha256=request_sha, ticket=ticket, cleanup=cleanup,
                    completed_indices=[] if summary is None else summary['completed_indices'],
                    summary_sha256=None if summary is None else b.sha(ct.read(folder / 'data/summary.json')),
                    signals=signals, error_type=None if primary is None else type(primary).__name__,
                    safety_unresolved=unresolved, finite_supervisor_fixture=finite,
                    original_infinite_hold_executed=False, outer_process_exit_observed=False,
                    automatic_retry=False, automatic_kill=False, **ct.FLAGS)
    terminal['artifact_manifest_sha256'] = ct.write_json(folder / 'artifact_manifest.json', dict(files=ct.manifest(folder)))['sha256']
    ct.write_json(folder / 'terminal.json', terminal)
    return terminal


if __name__ == '__main__':
    raise SystemExit('Library only; no board activation.')
