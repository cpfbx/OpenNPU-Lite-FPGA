"""Pinned PC-only process assembly. No device or real canonical-lock access."""
import hashlib
import importlib.util
import json
import platform
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SHARED = ROOT / 'frozen_shared'
SHARED_PIN = 'b75fd43c1ed6c0a317edae6225aa7e4c4c230779adb360773b889a0eaed513aa'
CORE = SHARED / 'frozen_combo/frozen_kit/core'
HW = CORE / 'driver/frozen_driver/frozen_hw'


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def inventory(root):
    result = {}
    for path in sorted(root.rglob('*')):
        need(not path.is_symlink() and not getattr(path, 'is_junction', lambda: False)(), 'plain nonalias tree')
        if path.is_file():
            raw = path.read_bytes()
            result[path.relative_to(root).as_posix()] = dict(bytes=len(raw), sha256=sha(raw))
    return result


def verify(pin):
    raw = (ROOT / 'candidate_manifest.json').read_bytes()
    need(type(pin) is str and sha(raw) == pin, 'external shared process candidate pin')
    files = json.loads(raw)['files']
    actual = inventory(ROOT)
    need(set(actual) == set(files) | {'candidate_manifest.json'} and all(actual[n] == p for n, p in files.items()), 'shared process source drift')
    frozen = json.loads((SHARED / 'candidate_manifest.json').read_bytes())['files']
    need(sha((SHARED / 'candidate_manifest.json').read_bytes()) == SHARED_PIN, 'frozen shared pin')
    frozen_actual = inventory(SHARED)
    need(len(frozen_actual) == 230 and set(frozen_actual) == set(frozen) | {'candidate_manifest.json'}
         and all(frozen_actual[n] == p for n, p in frozen.items()), '230 unchanged shared files')


def load(name, path):
    path = path.resolve()
    if name in sys.modules:
        need(Path(getattr(sys.modules[name], '__file__', '')).resolve() == path, 'foreign process module ' + name)
        return sys.modules[name]
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def controls():
    load('batch_policy', HW / 'legacy/frozen_source/batch_policy.py')
    load('kws_device_supervision_candidate', HW / 'legacy/frozen_source/kws_device_supervision_candidate.py')
    load('os_evidence', HW / 'legacy/frozen_source/os_evidence.py')
    bridge = load('supervision_bridge', HW / 'src/supervision_bridge.py')
    observer = load('process_observer', CORE / 'frozen_control/process_observer.py')
    return bridge, observer


def pc_only():
    need(platform.machine().lower() in ('amd64', 'x86_64', 'x86', 'i386', 'i686'), 'x86 PC fixture only; no ARM entry')


def shared():
    need(not any(n == r or n.startswith(r + '.') for n in sys.modules for r in ('pynq', 'tensorflow', 'tflite_runtime')), 'cold PC reference only')
    sys.path.insert(0, str(SHARED))
    module = load('shared_binding', SHARED / 'shared_binding.py')
    module.verify(SHARED_PIN)
    module.configure(enabled=True)
    return module
