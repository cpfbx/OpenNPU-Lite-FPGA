"""Separate offline PC envelope; original board/protocol schemas are unchanged."""
import json
import os
import re
import stat
import uuid
from pathlib import Path
import shared_process_binding as b

INDICES = (0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 400)
SCENARIOS = ('normal', 'raw_fault', 'stop', 'unsafe', 'parent_stop', 'no_go', 'stop_before_start')
FAKE_IDENTITY = dict(path='/tmp/opennpu-kws-chain.lock', device=2048, inode=11)
FLAGS = dict(fixture=True, board_access=False, real_lock_access=False, real_DMA_executed=False,
             real_cross_layer_PL_execution=False, ARM_tested=False, run_ready=False, promotion=False)


def canonical(path):
    result = Path(path).absolute()
    b.need(result.resolve() == result and not result.is_symlink(), 'canonical nonalias path')
    return result


def digest(value):
    b.need(type(value) is str and re.fullmatch('[a-f0-9]{64}', value) is not None, 'lowercase SHA required')
    return value


def strict_json(raw):
    def pairs(rows):
        result = {}
        for key, value in rows:
            b.need(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    def bad(value):
        raise ValueError('nonfinite JSON number')
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=bad)


def read(path, limit=1000000):
    path = canonical(path)
    value = path.lstat()
    b.need(stat.S_ISREG(value.st_mode) and value.st_nlink == 1 and value.st_size <= limit, 'bounded single-link file')
    with path.open('rb') as handle:
        raw = handle.read(limit + 1)
    b.need(len(raw) <= limit, 'read byte limit')
    return raw


def write(path, raw):
    path = canonical(path)
    with path.open('xb') as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    return dict(bytes=len(raw), sha256=b.sha(raw))


def write_json(path, value):
    raw = (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode('utf8')
    identity = write(path, raw)
    write(Path(str(path) + '.ready'), b'')
    return identity


def ready(path, limit=1000000):
    if not os.path.lexists(str(path) + '.ready'):
        return None
    b.need(read(str(path) + '.ready', 0) == b'', 'empty publication marker')
    return strict_json(read(path, limit))


def outside(path):
    path = canonical(path)
    b.need(not path.is_relative_to(b.ROOT) and not b.ROOT.is_relative_to(path), 'output outside immutable process candidate')
    return path


def request(pin, scenario='normal', run_id=None):
    return validate_request(dict(schema='shared-session-PC-process-fixture-v1', scope='fixed12-op2-cpu-dw3-op4-offline-only',
                                 run_id=run_id or str(uuid.uuid4()), operator='bx', fixture=True,
                                 candidate_manifest_sha256=digest(pin), scenario=scenario))


def validate_request(value):
    b.need(type(value) is dict and set(value) == {'schema', 'scope', 'run_id', 'operator', 'fixture', 'candidate_manifest_sha256', 'scenario'}, 'exact offline process request')
    b.need(value['schema'] == 'shared-session-PC-process-fixture-v1' and value['scope'] == 'fixed12-op2-cpu-dw3-op4-offline-only'
           and value['operator'] == 'bx' and value['fixture'] is True, 'exact PC fixture scope')
    b.need(type(value['scenario']) is str and value['scenario'] in SCENARIOS, 'fixed process scenario')
    b.need(type(value['run_id']) is str and str(uuid.UUID(value['run_id'])) == value['run_id'], 'canonical run UUID')
    digest(value['candidate_manifest_sha256'])
    return value


def read_request(path, pin):
    path = outside(path)
    raw = read(path, 30000)
    b.need(b.sha(raw) == digest(pin), 'process request pin')
    return validate_request(strict_json(raw))


def process_identity(pid):
    b.need(type(pid) is int and pid > 1, 'exact process PID')
    if os.name == 'posix':
        _, _observer = b.controls()
        import os_evidence
        token = os_evidence.process_start((Path('/proc') / str(pid) / 'stat').read_text(encoding='ascii'))
        return dict(pid=pid, start=token, kind='proc-stat-start-ticks')
    if os.name == 'nt':
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
        kernel.GetProcessTimes.restype = wintypes.BOOL
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel.CloseHandle.restype = wintypes.BOOL
        handle = kernel.OpenProcess(0x1000, False, pid)
        if not handle:
            raise OSError('read-only process identity unavailable')
        times = [wintypes.FILETIME() for _ in range(4)]
        try:
            b.need(bool(kernel.GetProcessTimes(handle, *(ctypes.byref(t) for t in times))), 'process creation identity')
            token = (times[0].dwHighDateTime << 32) | times[0].dwLowDateTime
        finally:
            kernel.CloseHandle(handle)
        return dict(pid=pid, start=token, kind='windows-process-creation-filetime')
    raise RuntimeError('process identity unsupported')


def launch_binding(req, request_sha, parent=None):
    return dict(request_sha256=digest(request_sha), run_id=req['run_id'], parent=parent or process_identity(os.getpid()), fixture=True)


def validate_launch(value, req, request_sha):
    b.need(type(value) is dict and set(value) == {'request_sha256', 'run_id', 'parent', 'fixture'}, 'exact launch envelope')
    b.need(value['request_sha256'] == request_sha and value['run_id'] == req['run_id'] and value['fixture'] is True, 'bound launch request')
    parent = value['parent']
    b.need(type(parent) is dict and set(parent) == {'pid', 'start', 'kind'}
           and type(parent['pid']) is int and parent['pid'] > 1 and type(parent['start']) is int and parent['start'] > 0
           and parent['kind'] in ('proc-stat-start-ticks', 'windows-process-creation-filetime'), 'exact parent process identity')
    return value


def manifest(folder):
    excluded = {'artifact_manifest.json', 'artifact_manifest.json.ready', 'terminal.json', 'terminal.json.ready'}
    return {n: p for n, p in b.inventory(folder).items() if n not in excluded}


def terminal(folder):
    value = ready(folder / 'terminal.json')
    b.need(type(value) is dict, 'published terminal required')
    entry = ready(folder / 'artifact_manifest.json', 2000000)
    b.need(type(entry) is dict and set(entry) == {'files'} and value['artifact_manifest_sha256'] == b.sha(read(folder / 'artifact_manifest.json', 2000000)), 'terminal manifest pin')
    actual = b.inventory(folder)
    b.need(set(actual) == set(entry['files']) | {'artifact_manifest.json', 'artifact_manifest.json.ready', 'terminal.json', 'terminal.json.ready'}
           and manifest(folder) == entry['files'], 'exact final worker artifacts')
    return value
