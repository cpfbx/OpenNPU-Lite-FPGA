"""Layer-scoped envelope + byte-identical frozen driver-call body, private globals."""
import os,threading,weakref
from types import MappingProxyType
import numpy as np
import shared_binding as b
from shared_policy import validate_shared_policy
from shared_owner import SharedOwner
from shared_reference import REFERENCE as ref
from op4_candidate import InputEnvelope
from batch_policy import BatchStop
OriginalCall=b.old('pointwise_driver_call').PointwiseDriverCall
_g=dict(OriginalCall.__call__.__globals__);_g.update(validate_pointwise_policy=validate_shared_policy,sources=ref.sources2,make_jobs=ref.make_jobs)
_body=b.clone(OriginalCall.__call__,_g)
class SharedCall:
    def __init__(self,owner,case,*,enabled=False):
        b.need(enabled is True,'shared call default-off');b.need(type(owner) is SharedOwner,'exact shared call owner')
        self.owner=owner;self.used=self.failed=self.accepted=False;self.first_failure=None
        self.pid,self.thread=os.getpid(),threading.get_ident();self._guard=threading.Lock();self._envelope_guard=threading.Lock()
        try:
            b.need(owner._session_failed is False,'failed shared session cannot continue');validate_shared_policy(owner.policy);ref.authorize(owner)
            self.spec=owner.policy.request(owner._index)
            b.need(type(case) is dict and type(case.get('cohort_index')) is int and case['cohort_index']==self.spec.cohort_index,'scheduled shared window')
            oracle=ref.derive(self.spec.operator_index,self.spec.cohort_index)
            b.need(set(case)==set(oracle),'exact shared case fields')
            for key in ['a','weights','bias','scales','expected']:
                v=case.get(key);o=oracle[key]
                b.need(type(v) is np.ndarray and v.dtype==o.dtype and v.shape==o.shape and np.array_equal(v,o),'sealed shared case '+key)
            for key,value in oracle.items():
                if type(value) is not np.ndarray:b.need(type(case[key]) is type(value) and case[key]==value,'shared case metadata '+key)
            for key,value in oracle.items():
                if type(value) is np.ndarray:oracle[key]=value.copy(order='C');oracle[key].flags.writeable=False
            self.case=MappingProxyType(oracle);self._input=None;self._producer_key=object()
            callref=weakref.ref(self)
            producer_key=self._producer_key
            def make_bound_jobs(a,weights):
                call=callref();b.need(call is not None,'live job permit call required');return call._make_bound_jobs(a,weights,producer_key)
            private=dict(_g);private['make_jobs']=make_bound_jobs
            self._call_body=b.clone(OriginalCall.__call__,private)
        except BaseException:owner._session_failed=True;raise
    def _make_bound_jobs(self,a,weights,producer_key):
        b.need(self.owner._active_call is self and self.owner._session_failed is False,'job producer active call')
        b.need(producer_key is self._producer_key,'private job producer token required')
        b.need(a is self._input and weights is self.case['weights'] and np.array_equal(a,self.case['a']),'job producer exact sealed operands')
        jobs,records=ref.make_jobs(a,weights);self.owner.issue_permit(self,jobs,producer_key);return jobs,records
    def __call__(self,envelope):
        b.need((os.getpid(),threading.get_ident())==(self.pid,self.thread),'shared call process/thread drift')
        b.need(self._envelope_guard.acquire(blocking=False),'shared envelope nonreentrant')
        try:self.owner.begin_call(self,self._producer_key)
        except BaseException:self._envelope_guard.release();raise
        try:
            b.need(not self.used and not self.failed and not self.owner._session_failed,'one-shot failed shared session')
            b.need(self.owner.policy.request(self.owner._index)==self.spec,'shared schedule changed')
            if self.owner.stop_requested() is not False:raise BatchStop('shared stop before construction')
            b.need(type(envelope) is InputEnvelope,'exact shared input envelope')
            b.need(type(envelope.operator_index) is int and type(envelope.tensor_index) is int
                and (envelope.operator_index,envelope.tensor_index)==(self.spec.operator_index,self.spec.input_tensor),'shared layer identity')
            b.need(type(envelope.cohort_index) is int and envelope.cohort_index==self.spec.cohort_index
                and type(envelope.source_id) is str and envelope.source_id==self.case['source_id']
                and type(envelope.feature_sha256) is str and envelope.feature_sha256==self.case['feature_sha256'],'shared window identity')
            a=envelope.values;b.need(type(a) is np.ndarray and a.dtype==np.int8 and a.shape==(125,64)
                and a.flags.c_contiguous and a.flags.owndata and a.base is None and np.array_equal(a,self.case['a']),'shared owning exact input')
            self._input=a
            return self._call_body(self,a)
        except BaseException as error:
            self.used=self.failed=True;self.owner._session_failed=True
            if self.first_failure is None:self.first_failure=dict(error_type=type(error).__name__,cohort_index=self.spec.cohort_index,payload=None,accepted=False,automatic_retry=False,return_diagnostic=None)
            raise
        finally:
            self._input=None
            try:self.owner.end_call(self)
            finally:self._envelope_guard.release()
