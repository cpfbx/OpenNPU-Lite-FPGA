"""Internal job-bound one-shot permit. Not a same-process security sandbox."""
from dataclasses import dataclass,field,fields
import math
import shared_binding as b

def snapshot_job(job,tile):
    allowed=(tile.TileTransaction,tile.TileConfig,tile.BlockLayout)
    def freeze(value,depth=0):
        b.need(depth<=4,'bounded job metadata depth')
        if type(value) is int:return ('int',value)
        if type(value) is bytes:
            b.need(len(value)<=8192,'bounded job bytes');return ('bytes',value)
        if type(value) is tile.Layout:return ('layout',value.value)
        if type(value) is tuple:
            b.need(len(value)<=8,'bounded job metadata tuple');return ('tuple',tuple(freeze(v,depth+1) for v in value))
        b.need(type(value) in allowed,'exact job metadata types')
        return (type(value).__name__,tuple((f.name,freeze(getattr(value,f.name),depth+1)) for f in fields(value)))
    b.need(type(job) is tile.TileTransaction and type(job.payload) is bytes and len(job.payload)==8192,'exact fixed tile transaction')
    return freeze(job)

def validate_options(options,spec):
    b.need(set(options)=={'first_job_id','timeout_s','mode_override','launch_order','profile_host'}
        and type(options['first_job_id']) is int and options['first_job_id']==spec.first_job_id
        and type(options['mode_override']) is int and options['mode_override']==11
        and type(options['launch_order']) is str and options['launch_order']=='dma-first' and options['profile_host'] is True
        and type(options['timeout_s']) in (int,float) and math.isfinite(options['timeout_s']) and 0<options['timeout_s']<=60,'job permit exact options')

@dataclass(frozen=True,eq=False)
class JobPermit:
    owner:object
    call:object
    spec:object
    producer_key:object
    jobs:tuple
    snapshots:tuple
    consumed:bool=field(default=False,init=False)
    def revoke(self):object.__setattr__(self,'consumed',True)
    def consume(self,owner,call,spec,jobs,options,tile):
        b.need(self.consumed is False,'job permit already consumed')
        self.revoke()  # Attempted consumption is final, including rejection.
        b.need(self.owner is owner and self.call is call and self.spec==spec,'job permit owner/call/slot identity')
        b.need(self.producer_key is owner._active_producer and self.producer_key is call._producer_key,'job permit private producer identity')
        b.need(type(jobs) is list and len(jobs)==len(self.jobs)==2 and all(x is y for x,y in zip(jobs,self.jobs)),'job permit exact job objects')
        b.need(tuple(snapshot_job(j,tile) for j in jobs)==self.snapshots,'job permit immutable job content')
        validate_options(options,spec)
