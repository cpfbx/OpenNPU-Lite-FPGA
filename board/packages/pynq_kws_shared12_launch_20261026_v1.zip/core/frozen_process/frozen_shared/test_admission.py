"""New one-shot permit and callback counterexamples. Software fixtures only."""
import sys,unittest
from pathlib import Path
from contextlib import contextmanager
from dataclasses import replace,FrozenInstanceError
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import shared_binding as b
b.configure(enabled=True)
from shared_reference import REFERENCE as ref
from shared_owner import SharedOwner
from shared_call import SharedCall,OriginalCall,_body
from shared_fixture import SharedHarness,FakeCanonicalEnvironment
from job_permit import JobPermit,snapshot_job
from op4_candidate import InputEnvelope
from batch_policy import BatchStop

class AdmissionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.case=ref.derive(2,0)
    @contextmanager
    def started(self):
        h=SharedHarness(self.case);e=FakeCanonicalEnvironment()
        with e.install(),h.resident(e):
            h.set_case(self.case);yield h,e,SharedCall(h.owner,self.case,enabled=True)
    def env(self,values=None):
        return InputEnvelope(2,23,0,self.case['source_id'],self.case['feature_sha256'],self.case['a'].copy() if values is None else values)
    def options(self):return dict(first_job_id=1,timeout_s=60.,mode_override=11,launch_order='dma-first',profile_host=True)
    def transfers(self,h):return len([e for e in h.events if e[0]=='transfer'])//2
    def clean(self,h,call):
        self.assertIsNone(h.owner._admission);self.assertIsNone(h.owner._active_call);self.assertIsNone(h.owner._active_producer);self.assertFalse(h.owner._call_guard.locked());self.assertIsNone(call._input)
    def reject_execute(self,change,pattern):
        with self.started() as (h,e,call):
            original=h.owner.execute_chain
            def altered(jobs,**opts):
                jobs,opts=change(jobs,opts);return original(jobs,**opts)
            h.owner.execute_chain=altered
            with self.assertRaisesRegex(ValueError,pattern):call(self.env())
            self.assertEqual(self.transfers(h),0);self.assertEqual(h.owner._index,0);self.assertTrue(h.owner._session_failed);self.clean(h,call)
            self.assertEqual((h.owner._permits_issued,h.owner._permits_consumed,h.owner._permits_revoked),(1,0,1))
    def callback_case(self,where):
        with self.started() as (h,e,call):
            custom=self.case['a'].copy();custom[0,0]^=1;jobs=list(ref.make_jobs(custom,self.case['weights'])[0]);attempts=[]
            def callback():
                active=h.owner._active_call is call
                selected=(where=='early' and active and call._input is None or where=='pre_jobs' and active and call._input is not None and h.owner._index==0 and not h.owner._guard.locked()
                    or where=='inside' and active and h.owner._guard.locked() or where=='after_return' and active and h.owner._index==1)
                if selected and not attempts:
                    attempts.append(dict(index=h.owner._index,submissions=self.transfers(h),permit=h.owner._admission,guard=h.owner._guard.locked()))
                    with self.assertRaisesRegex(ValueError,'job-bound admission'):h.owner.execute_chain(jobs,**self.options())
                    self.assertEqual(h.owner._index,attempts[0]['index']);self.assertEqual(self.transfers(h),attempts[0]['submissions'])
                return False
            h.owner.stop_requested=callback
            out,_=call(self.env());self.assertTrue(np.array_equal(out,self.case['expected']));self.assertEqual(len(attempts),1);self.assertIsNone(attempts[0]['permit'])
            self.assertEqual(h.owner._index,1);self.assertEqual(self.transfers(h),1);self.clean(h,call)
    def test_01_body_code_object_preserved(self):
        with self.started() as (h,e,call):
            self.assertIs(call._call_body.__code__,OriginalCall.__call__.__code__);self.assertIsNot(call._call_body.__globals__,_body.__globals__)
    def test_02_private_job_producer_per_call(self):
        with self.started() as (h,e,call):
            other=SharedCall(h.owner,self.case,enabled=True)
            self.assertIsNot(call._call_body.__globals__['make_jobs'],other._call_body.__globals__['make_jobs']);self.assertIs(_body.__globals__['make_jobs'],ref.make_jobs)
    def test_03_early_callback_no_permit(self):self.callback_case('early')
    def test_04_original_pre_jobs_callback_no_submission(self):self.callback_case('pre_jobs')
    def test_05_inside_owner_callback_consumed_before_poll(self):self.callback_case('inside')
    def test_06_after_return_callback_no_second_submission(self):self.callback_case('after_return')
    def test_07_same_call_reentry_denied(self):
        with self.started() as (h,e,call):
            attempts=[]
            def callback():
                if call._input is not None and not attempts:
                    attempts.append(True)
                    with self.assertRaisesRegex(ValueError,'envelope nonreentrant'):call(self.env())
                return False
            h.owner.stop_requested=callback;call(self.env());self.assertEqual(self.transfers(h),1);self.assertEqual(attempts,[True]);self.clean(h,call)
    def test_08_second_call_reentry_denied(self):
        with self.started() as (h,e,call):
            other=SharedCall(h.owner,self.case,enabled=True);attempts=[]
            def callback():
                if call._input is not None and not attempts:
                    attempts.append(True)
                    with self.assertRaisesRegex(ValueError,'owner call busy'):other(self.env())
                    self.assertFalse(other.used);self.assertFalse(other._envelope_guard.locked())
                return False
            h.owner.stop_requested=callback;call(self.env());self.assertEqual(self.transfers(h),1);self.assertTrue(call.accepted);self.clean(h,call)
    def test_09_no_permit_for_invalid_envelope(self):
        with self.started() as (h,e,call):
            with self.assertRaises(ValueError):call(replace(self.env(),operator_index=4))
            self.assertEqual(h.owner._permits_issued,0);self.clean(h,call)
    def test_10_job_producer_requires_active_call(self):
        with self.started() as (h,e,call),self.assertRaisesRegex(ValueError,'active call'):call._make_bound_jobs(self.case['a'],call.case['weights'],call._producer_key)
    def test_11_bound_tuple_to_list_normal_path(self):
        with self.started() as (h,e,call):
            call(self.env());self.assertEqual((h.owner._permits_issued,h.owner._permits_consumed,h.owner._permits_revoked),(1,1,0));self.clean(h,call)
    def test_12_value_equal_copied_job_objects_rejected(self):self.reject_execute(lambda jobs,opts:([replace(j) for j in jobs],opts),'exact job objects')
    def test_13_job_reordering_rejected(self):self.reject_execute(lambda jobs,opts:(list(reversed(jobs)),opts),'exact job objects')
    def test_14_same_job_payload_mutation_rejected(self):
        def change(jobs,opts):
            object.__setattr__(jobs[0],'payload',bytes([jobs[0].payload[0]^1])+jobs[0].payload[1:]);return jobs,opts
        self.reject_execute(change,'immutable job content')
    def test_15_nonwire_metadata_mutation_rejected(self):
        def change(jobs,opts):object.__setattr__(jobs[0],'effective_input_bytes',1);return jobs,opts
        self.reject_execute(change,'immutable job content')
    def test_16_nested_block_mutation_rejected(self):
        def change(jobs,opts):object.__setattr__(jobs[0].blocks[0],'a_offset',1);return jobs,opts
        self.reject_execute(change,'immutable job content')
    def test_17_options_full_contract_rejected(self):
        for key,value in [('first_job_id',3),('first_job_id',True),('mode_override',0),('launch_order','pl-first'),('profile_host',1),('timeout_s',0),('timeout_s',float('nan')),('timeout_s',True)]:
            with self.subTest(key=key,value=value):self.reject_execute(lambda j,o:(j,dict(o,**{key:value})),'exact options')
    def test_18_second_permit_for_same_call_rejected(self):
        with self.started() as (h,e,call):
            def duplicate():
                permit=h.owner._admission;h.owner.issue_permit(call,permit.jobs,call._producer_key)
            call._call_body.__globals__['sources']=duplicate
            with self.assertRaisesRegex(ValueError,'one permit'):call(self.env())
            self.assertEqual(self.transfers(h),0);self.assertEqual(h.owner._permits_revoked,1);self.clean(h,call)
    def test_19_legacy_request_metadata_is_not_permit(self):
        with self.started() as (h,e,call):
            h.owner._admission=call.spec
            with self.assertRaisesRegex(ValueError,'job-bound admission'):h.owner.execute_chain([],**self.options())
            self.assertEqual(self.transfers(h),0);self.assertIsNone(h.owner._admission)
    def test_20_unsafe_failure_clears_only_software_permit(self):
        h=SharedHarness(self.case);e=FakeCanonicalEnvironment()
        with e.install(),h.resident(e):
            h.fail_before_return=True;call=SharedCall(h.owner,self.case,enabled=True)
            with self.assertRaises(RuntimeError):call(self.env())
            self.clean(h,call);self.assertTrue(h.owner._held and h.owner._unsafe);self.assertIsNone(call.first_failure['payload'])
        r=h.report(e);self.assertEqual((r['close_attempts'],r['free_events']),(0,0));self.assertEqual(r['before_test_teardown']['resources']['root_buffers_retained'],2)
    def test_21_stop_after_mint_revokes_without_submit(self):
        with self.started() as (h,e,call):
            def stop():raise BatchStop('TEST_ONLY after job permit mint')
            call._call_body.__globals__['sources']=stop
            with self.assertRaises(BatchStop):call(self.env())
            self.assertEqual(self.transfers(h),0);self.assertEqual((h.owner._permits_issued,h.owner._permits_consumed,h.owner._permits_revoked),(1,0,1));self.clean(h,call)
    def test_22_exception_after_mint_revokes_without_submit(self):
        with self.started() as (h,e,call):
            def fail():raise RuntimeError('TEST_ONLY after job permit mint')
            call._call_body.__globals__['sources']=fail
            with self.assertRaises(RuntimeError):call(self.env())
            self.assertEqual(self.transfers(h),0);self.assertEqual(h.owner._permits_revoked,1);self.assertIsNone(call.first_failure['payload']);self.clean(h,call)
    def capture_permit(self,h,call,check):
        original=call._call_body.__globals__['sources']
        def hook():check(h.owner._admission);return original()
        call._call_body.__globals__['sources']=hook
    def test_23_wrong_owner_cannot_consume(self):
        with self.started() as (h,e,call):
            def check(p):
                with self.assertRaisesRegex(ValueError,'owner/call/slot'):p.consume(object(),call,call.spec,list(p.jobs),self.options(),ref.sources2()[0])
            self.capture_permit(h,call,check)
            with self.assertRaisesRegex(ValueError,'already consumed'):call(self.env())
            self.assertEqual(self.transfers(h),0);self.clean(h,call)
    def test_24_wrong_call_cannot_consume(self):
        with self.started() as (h,e,call):
            def check(p):
                with self.assertRaisesRegex(ValueError,'owner/call/slot'):p.consume(h.owner,object(),call.spec,list(p.jobs),self.options(),ref.sources2()[0])
            self.capture_permit(h,call,check)
            with self.assertRaisesRegex(ValueError,'already consumed'):call(self.env())
            self.assertEqual(self.transfers(h),0)
    def test_25_wrong_window_slot_cannot_consume(self):
        with self.started() as (h,e,call):
            def check(p):
                with self.assertRaisesRegex(ValueError,'owner/call/slot'):p.consume(h.owner,call,h.owner.policy.request(2),list(p.jobs),self.options(),ref.sources2()[0])
            self.capture_permit(h,call,check)
            with self.assertRaisesRegex(ValueError,'already consumed'):call(self.env())
            self.assertEqual(self.transfers(h),0)
    def test_26_consumed_permit_cannot_replay(self):
        with self.started() as (h,e,call):
            captured=[];self.capture_permit(h,call,lambda p:captured.append(p));call(self.env());p=captured[0]
            self.assertTrue(p.consumed)
            with self.assertRaisesRegex(ValueError,'already consumed'):p.consume(h.owner,call,call.spec,list(p.jobs),self.options(),ref.sources2()[0])
            self.assertEqual(self.transfers(h),1);self.clean(h,call)
    def test_27_callback_cannot_mint_for_alternate_array(self):
        with self.started() as (h,e,call):
            changed=self.case['a'].copy();changed[0,0]^=1;attempts=[]
            def callback():
                if call._input is not None and not attempts:
                    attempts.append(True)
                    with self.assertRaisesRegex(ValueError,'sealed operands'):call._make_bound_jobs(changed,call.case['weights'],call._producer_key)
                    self.assertIsNone(h.owner._admission)
                return False
            h.owner.stop_requested=callback;call(self.env());self.assertEqual(self.transfers(h),1);self.assertEqual(h.owner._permits_issued,1)
    def test_28_snapshot_rejects_oversize_payload(self):
        tile=ref.sources2()[0];jobs=ref.make_jobs(self.case['a'],self.case['weights'])[0]
        with self.assertRaisesRegex(ValueError,'fixed tile'):snapshot_job(replace(jobs[0],payload=jobs[0].payload+b'0'),tile)
    def test_29_permit_metadata_frozen(self):
        with self.started() as (h,e,call):
            def check(p):
                with self.assertRaises(FrozenInstanceError):p.spec=h.owner.policy.request(1)
            self.capture_permit(h,call,check);call(self.env());self.clean(h,call)
    def test_30_normal_teardown_admission_balances(self):
        with self.started() as (h,e,call):call(self.env())
        state=h.report(e)['before_test_teardown']['software_admission'];self.assertEqual(state,dict(active_call_cleared=True,producer_cleared=True,call_guard_released=True,issued=1,consumed=1,revoked=0))
    def producer_callback(self,kind):
        with self.started() as (h,e,call):
            other=SharedCall(h.owner,self.case,enabled=True);jobs=ref.make_jobs(self.case['a'],self.case['weights'])[0];attempts=[]
            def callback():
                if call.used and h.owner._index==0 and not h.owner._guard.locked() and not attempts:
                    attempts.append(True)
                    with self.assertRaisesRegex(ValueError,'private job producer token'):
                        if kind=='missing':h.owner.issue_permit(call,jobs)
                        else:h.owner.issue_permit(call,jobs,object() if kind=='foreign' else other._producer_key)
                    self.assertIsNone(h.owner._admission);self.assertEqual(h.owner._permits_issued,0)
                return False
            h.owner.stop_requested=callback;call(self.env());self.assertEqual(attempts,[True]);self.assertEqual(self.transfers(h),1);self.clean(h,call)
    def test_31_callback_cannot_mint_without_producer(self):self.producer_callback('missing')
    def test_32_callback_cannot_mint_with_foreign_producer(self):self.producer_callback('foreign')
    def test_33_callback_cannot_mint_with_another_call_producer(self):self.producer_callback('other')

if __name__=='__main__':unittest.main(verbosity=2)
