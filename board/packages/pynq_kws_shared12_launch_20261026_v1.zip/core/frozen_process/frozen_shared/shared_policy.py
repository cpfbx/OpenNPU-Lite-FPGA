"""New experimental exact24 schedule; never coerce a frozen twelve-call policy."""
from dataclasses import dataclass
INDICES=(0,30,60,90,120,150,180,210,240,270,300,400)
@dataclass(frozen=True)
class Geometry:
    shape:tuple=(125,64,64)
    jobs:int=2
    input_bytes:int=16512
    output_bytes:int=32000
    macs:int=512000
@dataclass(frozen=True)
class Request:
    index:int
    cohort_index:int
    first_job_id:int
    operator_index:int
    input_tensor:int
    output_tensor:int
    shape:tuple=(125,64,64)
    jobs:int=2
@dataclass(frozen=True)
class SharedPolicy:
    enabled:bool=False
    def __post_init__(self):
        if self.enabled is not True:raise ValueError('shared policy default-off')
    @property
    def geometry(self):return Geometry()
    def request(self,index):
        if type(index) is not int or not 0<=index<24:raise ValueError('exact alternating24 request index')
        layer=2 if index%2==0 else 4
        return Request(index,INDICES[index//2],1+2*index,layer,23 if layer==2 else 25,24 if layer==2 else 26)
def validate_shared_policy(policy):
    if type(policy) is not SharedPolicy:raise ValueError('exact SharedPolicy required')
    policy.__post_init__()
