"""Explicitly enabled PC-only shared-resource fixture. No board CLI."""
import argparse,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import shared_binding as b
def main():
    p=argparse.ArgumentParser();p.add_argument('--candidate-sha',required=True);p.add_argument('--output',required=True);p.add_argument('--scenario',choices=['normal','raw_fault','stop','unsafe'],default='normal');p.add_argument('--enable-offline-candidate',action='store_true');a=p.parse_args()
    b.need(a.enable_offline_candidate is True,'shared fixture default-off');b.verify(a.candidate_sha);before=b.inventory(b.ROOT)
    from shared_run import run
    result=run(a.output,enabled=True,scenario=a.scenario);b.need(b.inventory(b.ROOT)==before,'shared sources changed')
    print(json.dumps({k:v for k,v in result.items() if k not in ['windows','calls','single_session_fixture']}));return 0 if result['operation_success'] else 1
if __name__=='__main__':
    try:raise SystemExit(main())
    except (ValueError,OSError) as error:print(type(error).__name__+': '+str(error),file=sys.stderr);raise SystemExit(2)
