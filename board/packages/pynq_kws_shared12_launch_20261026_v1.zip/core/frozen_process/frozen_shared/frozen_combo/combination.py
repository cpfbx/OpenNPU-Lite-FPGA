"""Default-off offline Op2 output -> CPU DW3 -> Op4, with exact source accounting.

Frozen real-driver Python runs ONLY on its declared fake PYNQ/MMIO/DMA/proc/lock.
This module provides no board entry or OS/lock probe.
"""
from dataclasses import dataclass,replace
import json,struct
from pathlib import Path
import numpy as np
from sources import ROOT,INDICES,OP2_PIN,need,sha,configure

@dataclass(frozen=True)
class Upstream:
    operator_index:int
    tensor_index:int
    cohort_index:int
    source_id:str
    feature_sha256:str
    op2_output_source:str
    output_sha256:str
    values:np.ndarray

class ChainStop(RuntimeError):pass

def checked_array(a):
    need(type(a) is np.ndarray and a.dtype==np.int8 and a.shape==(125,64)
        and a.flags.c_contiguous and a.flags.owndata and a.base is None,'owning C-order INT8 matrix')
    return a

def validate_upstream(item,case,mode):
    need(type(item) is Upstream,'exact upstream envelope')
    need(type(item.operator_index) is int and type(item.tensor_index) is int
        and (item.operator_index,item.tensor_index)==(2,24),'upstream layer identity')
    need(type(item.cohort_index) is int and item.cohort_index==case['cohort_index']
        and item.source_id==case['source_id'] and item.feature_sha256==case['feature_sha256'],'upstream window identity')
    need(type(mode) is str and mode in ('replay','fixture') and item.op2_output_source==mode,'upstream source mode')
    a=checked_array(item.values)
    need(type(item.output_sha256) is str and sha(a.tobytes())==item.output_sha256,'upstream byte digest drift')
    need(np.array_equal(a,case['expected']),'upstream against sealed Op2 oracle')
    return a

def make_upstream(raw,case,mode):
    need(type(raw) is bytes and len(raw)==8000,'Op2 output byte extent')
    a=np.frombuffer(raw,np.int8).reshape(125,64).copy(order='C');a.flags.writeable=False
    item=Upstream(2,24,case['cohort_index'],case['source_id'],case['feature_sha256'],mode,sha(raw),a)
    validate_upstream(item,case,mode);return item

def depthwise_parameters():
    import runtime_reference as rr
    ref=rr.sources()[3]
    folder=ROOT/'frozen_kit/core/driver/frozen_op4/frozen_op2/frozen/model'
    model=ref.PortableInteger(folder,enabled=True);op=model.info['operators'][3]
    need(op['name']=='DEPTHWISE_CONV_2D' and op['inputs']==[24,8,7] and op['outputs']==[25]
        and op['stride']==op['dilation']==[1,1] and op['padding']==0 and op['activation']==1,'DW3 exact topology')
    it,wt,ot=[model.info['tensors'][i] for i in (24,8,25)]
    need(it['shape']==ot['shape']==[1,25,5,64] and wt['shape']==[1,3,3,64]
        and it['zero_points']==ot['zero_points']==[-128] and wt['zero_points']==[0]*64,'DW3 quantization domain')
    weights=model.constants[8].copy();bias=model.constants[7].copy()
    scales=np.array(wt['scales'],np.float64)*float(it['scales'][0])/float(ot['scales'][0])
    for a in (weights,bias,scales):a.flags.writeable=False
    return dict(weights=weights,bias=bias,scales=scales)

def depthwise_kernel(a,parameters):
    """Only one DW operator: consumes a, never reads a prefix/oracle activation."""
    checked_array(a)
    import runtime_reference as rr
    ref=rr.sources()[3];b=parameters['weights'];bias=parameters['bias'];scales=parameters['scales']
    need(type(b) is np.ndarray and b.dtype==np.int8 and b.shape==(1,3,3,64)
        and type(bias) is np.ndarray and bias.dtype==np.int32 and bias.shape==(64,)
        and type(scales) is np.ndarray and scales.dtype==np.float64 and scales.shape==(64,),'DW3 parameter shapes')
    x=a.reshape(1,25,5,64)
    patches=ref.conv_patches(x,(64,3,3,64),(1,25,5,64),[1,1],0,[1,1],-128)
    acc=((patches.reshape(125,9,64).astype(np.int64)+128)*b.reshape(9,64).astype(np.int64)).sum(axis=1)+bias.astype(np.int64)
    ref.checked_i32(acc)
    out=ref.requantize(acc,scales,-128,1).reshape(125,64).copy(order='C')
    checked_array(out);return out,acc.astype('<i4')

def dynamic_envelope(upstream,dynamic,case):
    from op4_candidate import InputEnvelope
    checked_array(dynamic)
    need(type(upstream) is Upstream and upstream.cohort_index==case['cohort_index']
        and upstream.source_id==case['source_id'] and upstream.feature_sha256==case['feature_sha256'],'DW output window binding')
    need(np.array_equal(dynamic,case['a']),'DW3 result against sealed Op4 input oracle')
    # Payload object is the actual kernel return, not case['a'] or input_for(case).
    return InputEnvelope(4,25,upstream.cohort_index,upstream.source_id,upstream.feature_sha256,dynamic)

def wire_input(raw,first):
    need(type(raw) is bytes and len(raw)==16512,'wire extent');a=np.zeros((125,64),np.int8)
    for j,rows in enumerate((64,61)):
        h=struct.unpack_from('<16I',raw,j*8256)
        need(h[2]==first+j and h[7]==j*64,'wire job/offset')
        for r in range(64):
            for k in range(64):
                v=raw[j*8256+64+(r//8)*512+k*8+r%8]
                if r<rows:a[j*64+r,k]=v if v<128 else v-256
                else:need(v==0,'wire tail padding')
    return a

def checkpoint(stopped,stage,index):
    if stopped(stage,index) is not False:raise ChainStop('offline stop boundary')

def run(mode,output,*,enabled=False,stopped=lambda stage,index:False,inject_raw_window=None):
    need(enabled is True,'combination default-off');need(type(mode) is str and mode in ('replay','fixture'),'exact source mode')
    need(inject_raw_window is None or type(inject_raw_window) is int and inject_raw_window==90,'only planned raw fault at window90')
    need(callable(stopped),'stop callback');output=Path(output).absolute()
    need(output.resolve()==output and not output.exists() and not output.is_relative_to(ROOT) and not ROOT.is_relative_to(output),'fresh output outside candidate')
    configure(enabled=True)
    import runtime_reference as r2,op4_runtime as r4
    from op4_fixture import Op4Harness,FakeCanonicalEnvironment
    from pointwise_driver_call import PointwiseDriverCall
    from op4_driver_call import Op4DriverCall
    from sources import replay_bank
    # All references are validation oracles; actual DW inputs come from produced[] below.
    cases2={i:r2.derive(i) for i in INDICES};cases4={i:r4.derive(i) for i in INDICES}
    parameters=depthwise_parameters();output.mkdir(parents=True)
    produced={};op2data={};rows=[];sessions=[];failure=None;call=None;index=None;stage='op2_source';dw_executed=0;op4_accepted=0
    def save(folder,name,b):
        with (folder/name).open('xb') as f:f.write(b)
        return dict(bytes=len(b),sha256=sha(b))
    def session_record(layer,h,env):
        transfers=[e for e in h.events if e[0]=='transfer'];need(len(transfers)%2==0 and transfers==[('transfer','recv',32000),('transfer','send',16512)]*(len(transfers)//2),'fake transfer sequence')
        need(h.owner._closed and not env.held and not env.fd_live,'fake session closed')
        sessions.append(dict(operator_index=layer,session_id='op%d-fixture'%layer,fixture_submissions=len(transfers)//2,fixture_jobs=len(transfers),synthetic_cleanup=h.owner.cleanup_readback,real_lock_access=False))
    try:
        if mode=='fixture':
            h=Op4Harness(cases2[0]);env=FakeCanonicalEnvironment()
            try:
                with env.install(),h.resident(env):
                    for index in INDICES:
                        stage='op2_before_submit';checkpoint(stopped,stage,index);case=cases2[index];h.set_case(case)
                        call=PointwiseDriverCall(h.owner,case,enabled=True);stage='op2_call';out,data=call(case['a'].copy(order='C'))
                        produced[index]=make_upstream(out.tobytes(),case,mode);op2data[index]=data
            finally:session_record(2,h,env)
        else:
            bank=replay_bank()
            for index in INDICES:produced[index]=make_upstream(bank[index],cases2[index],mode)
        h=Op4Harness(cases4[0]);env=FakeCanonicalEnvironment()
        try:
            with env.install(),h.resident(env):
                for index in INDICES:
                    stage='before_depthwise';checkpoint(stopped,stage,index)
                    source=produced[index];a=validate_upstream(source,cases2[index],mode)
                    stage='depthwise_kernel';dynamic,acc=depthwise_kernel(a,parameters);dw_executed+=1
                    stage='dynamic_input_validation';envelope=dynamic_envelope(source,dynamic,cases4[index])
                    need(envelope.values is dynamic,'actual dynamic payload object')
                    stage='op4_before_submit';checkpoint(stopped,stage,index)
                    # TEST payload is emulated from the actual dynamic input.
                    # Frozen oracle still independently guards the call below.
                    h.set_case(dict(cases4[index],a=dynamic))
                    call=Op4DriverCall(h.owner,cases4[index],enabled=True)
                    if index==inject_raw_window:
                        b=h.engine.payload;h.engine.payload=bytes([b[0]^1])+b[1:]
                    stage='op4_call';out,data=call(envelope);op4_accepted+=1
                    need(np.array_equal(wire_input(data['input_chain'],call.spec.first_job_id),dynamic),'submitted Op4 wire equals dynamic DW3 output')
                    stage='after_op4';checkpoint(stopped,stage,index)
                    folder=output/('window_%03d'%index);folder.mkdir()
                    artifacts={
                        'op2_input.i8':cases2[index]['a'].tobytes(),'op2_weights.i8':cases2[index]['weights'].tobytes(),
                        'op2_bias.i32':cases2[index]['bias'].astype('<i4').tobytes(),'op2_scales.f64':cases2[index]['scales'].astype('<f8').tobytes(),
                        'op2_output.i8':source.values.tobytes(),'dw3_input.i8':a.tobytes(),
                        'dw3_weights.i8':parameters['weights'].tobytes(),'dw3_bias.i32':parameters['bias'].astype('<i4').tobytes(),
                        'dw3_scales.f64':parameters['scales'].astype('<f8').tobytes(),'dw3_acc.i32':acc.astype('<i4').tobytes(),
                        'dw3_output.i8':dynamic.tobytes(),'op4_input.i8':envelope.values.tobytes(),
                        'op4_weights.i8':cases4[index]['weights'].tobytes(),'op4_bias.i32':cases4[index]['bias'].astype('<i4').tobytes(),
                        'op4_scales.f64':cases4[index]['scales'].astype('<f8').tobytes(),
                        'op4_wire.bin':data['input_chain'],'op4_raw.i32':data['raw'].astype('<i4').tobytes(),
                        'op4_corrected.i32':data['corrected'].astype('<i4').tobytes(),'op4_output.i8':out.tobytes()}
                    if mode=='fixture':
                        d=op2data[index];artifacts.update({'op2_wire.bin':d['input_chain'],'op2_raw.i32':d['raw'].astype('<i4').tobytes(),'op2_corrected.i32':d['corrected'].astype('<i4').tobytes()})
                    row=dict(cohort_index=index,source_id=source.source_id,feature_sha256=source.feature_sha256,
                        op2_output_source=mode,op2_output_sha256=source.output_sha256,
                        replay_archive_sha256=OP2_PIN if mode=='replay' else None,
                        dynamic_payload_is_kernel_return=True,op4_wire_consumes_dynamic=True,
                        op2_first_job_id=1+2*INDICES.index(index) if mode=='fixture' else None,
                        op4_first_job_id=call.spec.first_job_id,
                        op2_fake_metrics=op2data[index]['driver_metrics'] if mode=='fixture' else None,
                        op4_fake_metrics=data['driver_metrics'],artifacts={n:save(folder,n,b) for n,b in artifacts.items()})
                    save(folder,'result.json',(json.dumps(row,sort_keys=True,indent=2)+'\n').encode());rows.append(row)
                    print(mode,index,'actual source -> DW3 -> submitted Op4 wire verified',flush=True)
        finally:session_record(4,h,env)
    except Exception as error:
        first=None if call is None else call.first_failure
        payload=first.get('payload') if type(first) is dict else getattr(first,'payload',None)
        failure=dict(cohort_index=index,stage=stage,error_type=type(error).__name__,automatic_retry=False)
        if type(payload) is bytes and len(payload)<=32000:failure['payload']=save(output,'first_failure.bin',payload)
    ok=failure is None and len(rows)==12
    submissions=sum(s['fixture_submissions'] for s in sessions)
    result=dict(operation_success=ok,mode=mode,completed_indices=[r['cohort_index'] for r in rows],not_completed_indices=list(INDICES[len(rows):]),windows=rows,failure=failure,sessions=sessions,
        accepted_op2_fixture_calls=len(produced) if mode=='fixture' else 0,accepted_op4_fixture_calls=op4_accepted,fixture_submissions=submissions,fixture_pointwise_jobs=2*submissions,fixture_pointwise_MACs=512000*submissions,
        historical_op2_replayed_windows=len(produced) if mode=='replay' else 0,
        depthwise_executed_calls=dw_executed,depthwise_executed_logical_MACs=72000*dw_executed,completed_chain_depthwise_logical_MACs=72000*len(rows),depthwise_MAC_basis='dense 3x3 SAME including padded positions, per frozen descriptor',
        board_access=False,real_cross_layer_PL_execution=False,real_lock_access=False,real_DMA_executed=False,PL_simulated=False,
        fixture=True,counters_synthetic=True,model_and_thresholds_changed=False,full_model_inference=False,
        CPU_reference_selected_window_checks_reexecuted=True,independent_audio_frontend=False,
        classification_quality_evaluated=False,performance_evaluated=False,energy_evaluated=False,
        automatic_retry=False,automatic_kill=False,run_ready=False,promotion=False)
    save(output,'summary.json',(json.dumps(result,sort_keys=True,indent=2)+'\n').encode())
    return result

if __name__=='__main__':raise SystemExit('Library only. No board CLI.')
