"""TEST ONLY deterministic LSB witnesses, including quantization-masked changes.

No production gate is disabled. Direct kernel perturbations below are a diagnostic
seam, not acceptance of corrupt upstream data by the complete combination.
"""
import numpy as np
from sources import need,sha
from combination import checked_array,depthwise_kernel
def witnesses(a,parameters):
    checked_array(a);original,base=depthwise_kernel(a,parameters)
    import runtime_reference as rr
    ref=rr.sources()[3];w=parameters['weights'].reshape(3,3,64);result={}
    for pos in range(8000):
        y,x,ch=np.unravel_index(pos,(25,5,64));old=int(a[y*5+x,ch]);unsigned=(old&255)^1;new=unsigned if unsigned<128 else unsigned-256;delta=new-old
        acc=base.copy();changed=False
        for ky in range(3):
            for kx in range(3):
                oy,ox=y-ky+1,x-kx+1
                if 0<=oy<25 and 0<=ox<5:
                    acc[oy*5+ox,ch]+=delta*int(w[ky,kx,ch]);changed=True
        if not changed or np.array_equal(acc,base):continue
        column=ref.requantize(acc[:,ch:ch+1],parameters['scales'][ch:ch+1],-128,1)
        observable=not np.array_equal(column[:,0],original[:,ch]);kind='observable' if observable else 'masked'
        if kind in result:continue
        mutated=a.copy(order='C');mutated[y*5+x,ch]=new
        actual,actual_acc=depthwise_kernel(mutated,parameters)
        need(np.array_equal(actual_acc,acc),'local perturbation equals full actual kernel')
        need(bool(np.any(actual!=original))==observable,'actual INT8 witness classification')
        result[kind]=dict(position=pos,input_coordinates=[int(y),int(x),int(ch)],before=old,after=new,
            input_before_sha256=sha(a.tobytes()),input_after_sha256=sha(mutated.tobytes()),
            accumulator_changed_values=int(np.count_nonzero(actual_acc!=base)),INT8_changed_values=int(np.count_nonzero(actual!=original)),
            selection='first C-order input LSB within fixed window, diagnostics only',
            mutated=mutated,output=actual,acc=actual_acc)
        if len(result)==2:break
    need(set(result)=={'observable','masked'},'both observable and masked witnesses required')
    return result
