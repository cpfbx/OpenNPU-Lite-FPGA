"""Only a PC software fixture/replay entry, disabled unless explicitly enabled."""
import argparse,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import sources
def main():
    p=argparse.ArgumentParser();p.add_argument('--candidate-sha',required=True);p.add_argument('--mode',choices=('replay','fixture'),required=True);p.add_argument('--output',required=True);p.add_argument('--enable-offline-candidate',action='store_true');p.add_argument('--inject-op4-raw-window',type=int);p.add_argument('--stop-before-depthwise-window',type=int)
    a=p.parse_args();sources.need(a.enable_offline_candidate is True,'offline combination default-off');sources.verify(a.candidate_sha)
    before=sources.inventory(sources.ROOT)
    from combination import run
    sources.need(a.stop_before_depthwise_window is None or type(a.stop_before_depthwise_window) is int and a.stop_before_depthwise_window==90,'only planned stop at90')
    stopped=lambda stage,index:not (stage!='before_depthwise' or index!=a.stop_before_depthwise_window)
    result=run(a.mode,a.output,enabled=True,inject_raw_window=a.inject_op4_raw_window,stopped=stopped)
    sources.need(sources.inventory(sources.ROOT)==before,'source tree changed')
    print(json.dumps({k:v for k,v in result.items() if k not in ('windows','sessions')}));return 0 if result['operation_success'] else 1
if __name__=='__main__':
    try:raise SystemExit(main())
    except (ValueError,OSError) as error:print(type(error).__name__+': '+str(error),file=sys.stderr);raise SystemExit(2)
