"""Save test-only observable/masked upstream LSB diagnostics; no board execution."""
import argparse,json,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import sources as s
def main():
    p=argparse.ArgumentParser();p.add_argument('--candidate-sha',required=True);p.add_argument('--output',required=True);a=p.parse_args();s.verify(a.candidate_sha)
    output=Path(a.output).absolute();s.need(output.resolve()==output and not output.exists() and not output.is_relative_to(s.ROOT) and not s.ROOT.is_relative_to(output),'fresh external witnesses')
    s.configure(enabled=True)
    import runtime_reference as r2,op4_runtime as r4
    from combination import make_upstream,depthwise_parameters,validate_upstream
    from propagation import witnesses
    from op4_fixture import Op4Harness,FakeCanonicalEnvironment
    from op4_driver_call import Op4DriverCall
    from op4_candidate import InputEnvelope
    case2=r2.derive(0);case4=r4.derive(0);up=make_upstream(s.replay_bank()[0],case2,'replay');ws=witnesses(up.values,depthwise_parameters());output.mkdir();reports={}
    from dataclasses import replace
    for kind,w in ws.items():
        folder=output/kind;folder.mkdir();artifacts={}
        for name,raw in [('changed_op2_output.i8',w['mutated'].tobytes()),('changed_dw3_acc.i32',w['acc'].astype('<i4').tobytes()),('changed_dw3_output.i8',w['output'].tobytes())]:
            with (folder/name).open('xb') as f:f.write(raw)
            artifacts[name]=dict(bytes=len(raw),sha256=s.sha(raw))
        try:validate_upstream(replace(up,values=w['mutated']),case2,'replay');raise AssertionError('corrupt source accepted')
        except ValueError:upstream_rejected=True
        if kind=='observable':
            h=Op4Harness(case4);env=FakeCanonicalEnvironment()
            with env.install(),h.resident(env):
                call=Op4DriverCall(h.owner,case4,enabled=True)
                try:call(InputEnvelope(4,25,0,up.source_id,up.feature_sha256,w['output']));raise AssertionError('changed dynamic input accepted')
                except ValueError:pass
                s.need(not any(e[0]=='transfer' for e in h.events),'no fake submission after Op4 validation rejection')
            downstream_gate='unchanged Op4 input equality; rejected before fake DMA'
        else:
            s.need(w['INT8_changed_values']==0,'masked witness');downstream_gate='not called; DW INT8 unchanged, upstream identity gate rejects'
        reports[kind]={k:v for k,v in w.items() if k not in ('mutated','output','acc')}
        reports[kind].update(artifacts=artifacts,upstream_gate_rejected=upstream_rejected,downstream_gate=downstream_gate)
    result=dict(operation_success=True,cohort_index=0,witnesses=reports,scope='TEST ONLY injection past source boundary into pure kernel, all production gates retained',board_access=False,real_cross_layer_PL_execution=False,fixture=True,promotion=False)
    with (output/'witnesses.json').open('x',encoding='utf-8') as f:json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
    print(json.dumps(result));return 0
if __name__=='__main__':raise SystemExit(main())
