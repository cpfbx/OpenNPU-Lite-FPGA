"""Fixed twelve-window single-layer SOFTWARE evidence, no board or RTL execution."""
import argparse
import json
from pathlib import Path
import sys
import tarfile
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from binding import ROOT, sources, verify, require, sha
from real_case import APPROVED_INDICES, selected_items, derive
from pointwise_candidate import PointwiseCall, SoftwareTransport, make_jobs, validate_reply, scalar_quantized


def inventory():
    return {p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in ROOT.rglob('*') if p.is_file()}


def save(path,raw):
    with path.open('xb') as f:f.write(raw)
    return dict(bytes=len(raw),sha256=sha(raw))


def verify_original():
    with tarfile.open(ROOT/'cpu420_original.tar.gz','r:gz') as archive:
        for name,size in [('features.i8',205800),('logits.i8',5040)]:
            target='metrics_kws_prepare_0ROstCki/work/evidence/worker/numerical/'+name
            members=[m for m in archive.getmembers() if m.name==target]
            require(len(members)==1 and members[0].isfile() and members[0].size==size,'CPU420 original extent')
            require(archive.extractfile(members[0]).read(size+1)==(ROOT/'frozen/data'/name).read_bytes(),
                'CPU420 original bytes equal frozen bank')


def evaluate(case):
    """Every oracle uses complete values, not only output digests."""
    a,b=case['a'],case['weights']
    jobs,records=make_jobs(a,b)
    captured=[]
    def capture(reply):
        captured.append(reply)
        return reply
    transport=SoftwareTransport(capture)
    call=PointwiseCall(case,transport,enabled=True)
    try:
        actual,metrics=call(a)
    except BaseException as error:
        # Propagate only this bounded software first-failure payload to main.
        error.offline_first_failure=call.first_failure
        raise
    require(len(captured)==1 and transport.submissions==1 and call.accepted,'single accepted software submission')
    reply=captured[0]
    raw=validate_reply(jobs,records,reply)
    raw64=a.astype(np.int64)@b.astype(np.int64)
    require(np.array_equal(raw,raw64),'all raw INT32 against independent INT64')
    corrected=raw.astype(np.int64)+case['bias'].astype(np.int64)-case['input_zp']*b.astype(np.int64).sum(axis=0)
    _,_,_,ref=sources()
    ref.checked_i32(corrected)
    scalar=np.empty((125,64),np.int8)
    centered=np.empty((125,64),np.int64)
    quantizers=[ref.quant_multiplier(float(s)) for s in case['scales']]
    for y in range(125):
        for c in range(64):
            value=sum((int(a[y,k])-case['input_zp'])*int(b[k,c]) for k in range(64))+int(case['bias'][c])
            centered[y,c]=value
            scalar[y,c]=min(127,max(case['output_zp'],scalar_quantized(value,*quantizers[c])+case['output_zp']))
    require(np.array_equal(centered,corrected),'all corrected values versus scalar centered INT64 dot')
    require(np.array_equal(scalar,actual) and np.array_equal(actual,case['expected']),
        'all final INT8 versus frozen reference and scalar double rounding')
    feature=(ROOT/'frozen/data/features.i8').read_bytes()[case['cohort_index']*490:(case['cohort_index']+1)*490]
    artifacts={'feature.i8':feature,'pointwise_input.i8':a.tobytes(),'weights_kn.i8':b.tobytes(),
        'request_chain.bin':b''.join(r.bytes for r in records),'reply_tile_order.bin':reply.payload,
        'raw_output.i32':raw.astype('<i4').tobytes(),'raw_oracle.i64':raw64.astype('<i8').tobytes(),
        'corrected.i32':corrected.astype('<i4').tobytes(),'centered_oracle.i64':centered.astype('<i8').tobytes(),
        'expected_output.i8':case['expected'].tobytes(),'candidate_output.i8':actual.tobytes(),'scalar_output.i8':scalar.tobytes()}
    row=dict(cohort_index=case['cohort_index'],label=case['label'],source_id=case['source_id'],
        feature_sha256=case['feature_sha256'],prefix_original_API_compared=case['original_prefix_tensors_checked'],
        full_CPU_reference_logits_checked=case['full_CPU_reference_logits_checked'],operator_index=2,
        input_tensor=23,output_tensor=24,mnk=[125,64,64],logical_macs=512000,
        actual_job_rows=[j.actual_bm for j in jobs],input_bytes=sum(len(r.bytes) for r in records),
        output_transport_bytes=len(reply.payload),raw_I32_values_compared=8000,corrected_values_compared=8000,
        INT8_values_compared=8000,operation_success=True,metadata=metrics,
        counter_evidence=reply.metrics,counters_synthetic=True)
    return row,artifacts


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();output=args.output.absolute()
    require(output.resolve()==output and not output.exists() and output!=ROOT
        and not output.is_relative_to(ROOT) and not ROOT.is_relative_to(output),'fresh output outside candidate')
    verify();before=inventory();verify_original();selection=selected_items()
    output.mkdir()
    rows=[];active=None;failure=None
    try:
        for item in selection:
            active=item['cohort_index']
            case=derive(active)
            require(case['label']==item['label'] and case['source_id']==item['source_id'],'per-window binding')
            row,artifacts=evaluate(case)
            folder=output/('window_%03d'%active);folder.mkdir()
            row['artifacts']={n:save(folder/n,b) for n,b in artifacts.items()}
            save(folder/'result.json',(json.dumps(row,sort_keys=True,indent=2)+'\n').encode('utf-8'))
            rows.append(row)
        require(tuple(r['cohort_index'] for r in rows)==APPROVED_INDICES,'exact fixed window completion order')
        verify();require(inventory()==before,'candidate inputs unchanged')
    except Exception as error:
        failure=dict(cohort_index=active,error_type=type(error).__name__,error=str(error),automatic_retry=False)
        first=getattr(error,'offline_first_failure',None)
        if first is not None:
            payload=first.get('payload')
            if type(payload) is bytes and len(payload)<=32000:
                failure['payload']=save(output/'first_failure_tile_order.bin',payload)
            failure['first_error_type']=first['error_type']
    unchanged=inventory()==before
    ok=failure is None and len(rows)==12 and unchanged
    record=dict(operation_success=ok,selection_rule='first occurrence of each label in frozen cohort order; fixed before computation',
        selected_indices=list(APPROVED_INDICES),completed_indices=[r['cohort_index'] for r in rows],
        not_completed_indices=[i for i in APPROVED_INDICES if i not in [r['cohort_index'] for r in rows]],
        windows=rows,failure=failure,raw_I32_values_compared=sum(r['raw_I32_values_compared'] for r in rows),
        corrected_values_compared=sum(r['corrected_values_compared'] for r in rows),
        INT8_values_compared=sum(r['INT8_values_compared'] for r in rows),
        source_manifest_sha256=sha((ROOT/'source_manifest.json').read_bytes()),
        source='CPU420 original features; prefix activations generated on PC, not retained board intermediates',
        input_files_unchanged=unchanged,counters_synthetic=True,automatic_retry=False,
        board_access=False,PL_simulated=False,DMA_executed=False,hardware_runtime_implemented=False,
        board_stop_or_cleanup_tested=False,full_model_PS_PL_executed=False,classification_quality_accepted=False,
        performance_evaluated=False,energy_evaluated=False,deployable=False,promotion=False,
        environment=dict(python=sys.version,numpy=np.__version__))
    save(output/'result.json',(json.dumps(record,sort_keys=True,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({k:record[k] for k in ('operation_success','completed_indices','raw_I32_values_compared',
        'corrected_values_compared','INT8_values_compared','input_files_unchanged','board_access','promotion')}))
    return 0 if ok else 1

if __name__=='__main__':raise SystemExit(main())
