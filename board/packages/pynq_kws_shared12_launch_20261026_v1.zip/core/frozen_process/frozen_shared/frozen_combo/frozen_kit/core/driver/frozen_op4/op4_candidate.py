"""Default-off, poison-on-failure SOFTWARE call for fixed operator4 only."""
from dataclasses import dataclass,replace
from types import MappingProxyType
import numpy as np
from source_bindings import need,sources
from layer_case import LayerSpec,derive
@dataclass(frozen=True)
class InputEnvelope:
    operator_index:int
    tensor_index:int
    cohort_index:int
    source_id:str
    feature_sha256:str
    values:np.ndarray
def input_for(case):return InputEnvelope(4,25,case['cohort_index'],case['source_id'],case['feature_sha256'],case['a'].copy(order='C'))
@dataclass(frozen=True)
class FirstFailure:
    stage:str
    error_type:str
    payload:bytes|None
    accepted:bool=False
class OfflineStop(RuntimeError):pass
class SyntheticTransport:
    """Frozen software emulation with explicit synthetic D075 success sentinel."""
    fixture=True
    def __init__(self,mutate=None):
        need(mutate is None or callable(mutate),'software mutation callback');self.mutate=mutate;self.submissions=0
    def __call__(self,jobs,records):
        _,_,_,_,sw=sources();self.submissions+=1
        reply=sw.SoftwareTransport()(jobs,records)
        reply=replace(reply,metrics=dict(reply.metrics,failed_tile_index=65535))
        return reply if self.mutate is None else self.mutate(reply)
def sealed_case(case):
    need(type(case) is dict and type(case.get('spec')) is LayerSpec and case['spec']==LayerSpec(),'operator4 case identity')
    oracle=derive(case.get('cohort_index'))
    need(set(case)==set(oracle),'exact case fields')
    arrays={'a':(np.dtype('int8'),(125,64)),'weights':(np.dtype('int8'),(64,64)),'bias':(np.dtype('int32'),(64,)),'scales':(np.dtype('float64'),(64,)),'expected':(np.dtype('int8'),(125,64))}
    for name,value in oracle.items():
        supplied=case[name]
        if name in arrays:
            dtype,shape=arrays[name]
            need(type(supplied) is np.ndarray and supplied.dtype==dtype and supplied.shape==shape and np.array_equal(supplied,value),'case array differs from independent frozen reference: '+name)
        else:need(type(supplied) is type(value) and supplied==value,'case metadata differs from frozen reference: '+name)
    for name in arrays:
        oracle[name]=oracle[name].copy(order='C');oracle[name].flags.writeable=False
    oracle['prefix_tensors_checked']=tuple(oracle['prefix_tensors_checked'])
    return MappingProxyType(oracle)
class Op4Call:
    def __init__(self,case,transport,*,enabled=False):
        need(enabled is True,'operator4 candidate default-off')
        need(type(transport) is SyntheticTransport,'software transport only; no hardware adapter')
        self.case=sealed_case(case);self.transport=transport;self.used=False;self.accepted=False;self.failed=False;self.first_failure=None;self.last_reply=None
    def __call__(self,envelope,*,stopped=lambda:False):
        need(not self.used,'single call; no retry or repeat');self.used=True;payload=None;stage='before_construction'
        try:
            if stopped() is not False:raise OfflineStop('before construction')
            stage='validate_input'
            need(type(envelope) is InputEnvelope,'exact input envelope')
            need(type(envelope.operator_index) is int and envelope.operator_index==4 and type(envelope.tensor_index) is int and envelope.tensor_index==25,'input layer identity')
            need(type(envelope.cohort_index) is int and envelope.cohort_index==self.case['cohort_index'] and type(envelope.source_id) is str and envelope.source_id==self.case['source_id'] and type(envelope.feature_sha256) is str and envelope.feature_sha256==self.case['feature_sha256'],'input window identity')
            a=envelope.values
            need(type(a) is np.ndarray and a.dtype==np.int8 and a.shape==(125,64) and a.flags.c_contiguous and a.flags.owndata and np.array_equal(a,self.case['a']),'exact owning input bytes')
            stage='build_jobs';_,_,_,ref,sw=sources();jobs,records=sw.make_jobs(a,self.case['weights'])
            need(len(jobs)==2 and [j.actual_bm for j in jobs]==[64,61],'fixed 64/61 geometry')
            stage='before_submit'
            if stopped() is not False:raise OfflineStop('before software submission')
            stage='submit';reply=self.transport(jobs,records)
            if type(reply) is sw.Reply and type(reply.payload) is bytes and len(reply.payload)<=32000:payload=reply.payload
            stage='validate_reply';raw=sw.validate_reply(jobs,records,reply)
            need(type(reply.metrics.get('failed_tile_index')) is int and reply.metrics['failed_tile_index']==65535,'synthetic success sentinel')
            stage='raw_check';need(np.array_equal(raw,a.astype(np.int64)@self.case['weights'].astype(np.int64)),'raw INT32 versus independent INT64')
            stage='ps_check';corrected=raw.astype(np.int64)+self.case['bias'].astype(np.int64)+128*self.case['weights'].astype(np.int64).sum(axis=0);ref.checked_i32(corrected)
            stage='int8_check';out=ref.requantize(corrected,self.case['scales'],-128,1)
            need(np.array_equal(out,self.case['expected']),'all 8000 INT8 equal frozen operator4')
            stage='before_accept'
            if stopped() is not False:raise OfflineStop('after exact reply')
            self.accepted=True;self.last_reply=reply
            return out,dict(raw=raw.copy(),corrected=corrected.copy(),wire=b''.join(r.bytes for r in records),reply=payload,metrics=dict(reply.metrics),fixture=True,board_access=False,PL_simulated=False,DMA_executed=False,promotion=False)
        except BaseException as error:
            self.failed=True
            if self.first_failure is None:self.first_failure=FirstFailure(stage,type(error).__name__,payload)
            raise
