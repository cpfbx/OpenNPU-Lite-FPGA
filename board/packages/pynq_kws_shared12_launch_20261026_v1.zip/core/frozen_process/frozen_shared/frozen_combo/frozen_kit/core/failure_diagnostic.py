"""Finite ASCII diagnostics: never emits exception text, paths, or tracebacks."""
STAGES = ('before_owner_start', 'owner_start', 'bind_owner_reference', 'wait_parent_go',
    'derive_window', 'driver_call_init', 'driver_call_exec', 'write_window_artifacts', 'cleanup', 'complete')
REASONS = {
    'driver tuple': 'driver_tuple_mismatch',
    'exact returned records and CPU-owned bytes': 'return_records_mismatch',
    'work/sequence/byte counters': 'counter_fields_mismatch',
    'MODE11 conservation/clean DONE': 'mode11_state_mismatch',
    'unchanged normal MMIO read path and finite timing': 'mmio_or_timing_mismatch',
    'v2 synthetic transport evidence not accepted': 'synthetic_counter_evidence',
    'offline modules only': 'offline_reference_policy_conflict',
    'runtime reference forbidden engine': 'forbidden_engine',
    'runtime reference cold binding required': 'not_a_cold_process',
    'runtime reference module identity': 'reference_module_identity',
    'runtime reference module drift': 'reference_module_drift',
    'runtime reference unauthorized PYNQ state': 'unauthorized_pynq_state',
    'runtime reference initialized owner required': 'owner_not_initialized',
    'runtime reference owner already active': 'another_owner_active',
    'all raw INT32 values equal independent INT64 before requantization': 'raw_int32_mismatch',
    'all 8000 fixed-reference INT8 values': 'requantized_int8_mismatch',
}

def diagnostic(stage, error):
    stage = stage if type(stage) is str and stage in STAGES else 'before_owner_start'
    args = getattr(error, 'args', ())
    reason = REASONS.get(args[0], 'unclassified_exception') if type(args) is tuple and args and type(args[0]) is str else 'unclassified_exception'
    return dict(failure_stage=stage, diagnostic_summary=reason)

def valid(stage, reason, success):
    if success:
        return stage is None and reason is None
    return type(stage) is str and stage in STAGES and type(reason) is str and reason in set(REASONS.values()) | {'unclassified_exception'}
