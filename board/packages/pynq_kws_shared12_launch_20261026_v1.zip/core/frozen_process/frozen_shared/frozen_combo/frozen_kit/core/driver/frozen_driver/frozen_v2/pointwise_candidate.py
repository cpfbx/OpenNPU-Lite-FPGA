"""Default-off SINGLE LAYER SOFTWARE candidate, not a PYNQ/board adapter.

All transport counters below are SYNTHETIC fixtures, never PL observations.
No production owner/driver/counter/schema or frozen helper is modified.
"""
from dataclasses import dataclass
import math
import numpy as np
from binding import sources, require, sha


def scalar_quantized(value,multiplier,shift):
    """Separate scalar integer double-rounding implementation for cross-checks."""
    require(type(value) is int and -(1<<31)<=value<(1<<31),'INT32 scalar')
    require(type(multiplier) is int and 0<=multiplier<(1<<31) and type(shift) is int and -31<=shift<=30,'multiplier and shift')
    shifted=value*(2**max(shift,0))
    require(-(1<<31)<=shifted<(1<<31),'left shift INT32 range')
    product=shifted*multiplier
    nudged=product+((1<<30) if product>=0 else 1-(1<<30))
    high=(abs(nudged)//(1<<31))*(1 if nudged>=0 else -1)
    divisor=2**max(-shift,0)
    quotient,remainder=divmod(high,divisor)
    return quotient+int(remainder>(divisor-1)//2+int(high<0))


def inspect_wire(jobs,records):
    """Separate address-loop decode of payloads, including EVERY padded lane."""
    _,chain,_,_=sources()
    require(len(jobs)==len(records)>0,'record count')
    for i,(job,record) in enumerate(zip(jobs,records)):
        require(record==chain.build_chain_record(job,i+1,chain_last=i==len(jobs)-1),'exact reconstructed records')
        require(record.header.version==2 and not record.header.fused,'raw I32 v2 only')
        cursor=0
        for block in job.blocks:
            acount=((job.actual_bm+7)//8)*512
            bcount=((job.actual_bn+7)//8)*512
            aa=np.zeros((job.actual_bm,block.actual_bk),np.int8)
            bb=np.zeros((block.actual_bk,job.actual_bn),np.int8)
            for g in range(acount//512):
                for k in range(64):
                    for lane in range(8):
                        v=int.from_bytes(record.payload[cursor+g*512+k*8+lane:cursor+g*512+k*8+lane+1],'little',signed=True)
                        if g*8+lane<job.actual_bm and k<block.actual_bk: aa[g*8+lane,k]=v
                        else: require(v==0,'nonzero A geometry padding')
            cursor+=acount
            for g in range(bcount//512):
                for k in range(64):
                    for lane in range(8):
                        v=int.from_bytes(record.payload[cursor+g*512+k*8+lane:cursor+g*512+k*8+lane+1],'little',signed=True)
                        if g*8+lane<job.actual_bn and k<block.actual_bk: bb[k,g*8+lane]=v
                        else: require(v==0,'nonzero B geometry padding')
            cursor+=bcount
            yield job,block,aa,bb
        require(cursor==len(record.payload),'complete payload consumed')


def make_jobs(a,b):
    tile,chain,_,_=sources()
    require(type(a) is np.ndarray and type(b) is np.ndarray and a.dtype==b.dtype==np.int8
        and a.ndim==b.ndim==2 and a.flags.c_contiguous and b.flags.c_contiguous,'plain C-order INT8 matrices')
    jobs=tuple(tile.iter_transactions(a,b,tile.TileConfig(layout=tile.Layout.K_MAJOR)))
    records=tuple(chain.build_chain_record(t,i+1,chain_last=i==len(jobs)-1) for i,t in enumerate(jobs))
    for job,block,aa,bb in inspect_wire(jobs,records):
        require(np.array_equal(aa,a[job.m_offset:job.m_offset+job.actual_bm,block.k_offset:block.k_offset+block.actual_bk])
            and np.array_equal(bb,b[block.k_offset:block.k_offset+block.actual_bk,job.n_offset:job.n_offset+job.actual_bn]),'wire operand identity')
    return jobs,records


@dataclass(frozen=True)
class Reply:
    payload: bytes
    records: tuple
    metrics: dict


class SoftwareTransport:
    fixture=True
    def __init__(self,mutate=None):
        self.mutate=mutate
        self.submissions=0
    def __call__(self,jobs,records):
        tile,_,_,_=sources()
        self.submissions+=1
        chunks=[]
        for job,record in zip(jobs,records):
            raw=tile.emulate_transaction(job)
            chunks.append(raw+bytes(record.header.output_transport_bytes-len(raw)))
        # Deliberately synthetic, internally consistent values. Not timings.
        m=dict(mode=11,jobs=len(jobs),chain_jobs_completed=len(jobs),first_job_id=1,error_code=0,status=5,
            input_bytes=sum(len(r.bytes) for r in records),output_bytes=sum(r.header.output_transport_bytes for r in records),
            output_valid_bytes=sum(r.header.output_valid_bytes for r in records),effective_macs=sum(j.effective_macs for j in jobs),
            layout='k_major',counter_contract='d007_global_work_v2',counter_contract_version=2,
            pl_total_cycles=120,pl_work_union_cycles=110,pl_no_work_cycles=10,pl_overlap_credit_cycles=30,
            pl_load_work_cycles=20,pl_array_work_cycles=100,pl_store_work_cycles=10,pl_output_work_cycles=10,
            pl_array_output_work_overlap_cycles=5,pl_compute_wait_bank_cycles=0,pl_output_wait_tready_cycles=0,
            counter_evidence='SYNTHETIC-SOFTWARE-FIXTURE-NOT-PL')
        reply=Reply(b''.join(chunks),records,m)
        return reply if self.mutate is None else self.mutate(reply)


def validate_reply(jobs,records,reply):
    tile,chain,counter,_=sources()
    require(type(reply) is Reply and type(reply.payload) is bytes and type(reply.records) is tuple
        and type(reply.metrics) is dict,'plain bounded reply')
    require(reply.records==records,'echoed records differ')
    m=reply.metrics
    wanted=dict(mode=11,jobs=len(jobs),chain_jobs_completed=len(jobs),first_job_id=1,error_code=0,counter_contract_version=2,
        input_bytes=sum(len(r.bytes) for r in records),output_bytes=sum(r.header.output_transport_bytes for r in records),
        output_valid_bytes=sum(r.header.output_valid_bytes for r in records),effective_macs=sum(j.effective_macs for j in jobs))
    require(all(type(m.get(k)) is int and m[k]==v for k,v in wanted.items()),'work/sequence counter mismatch')
    require(type(m.get('status')) is int and m['status']&14==4 and m.get('layout')=='k_major'
        and m.get('counter_contract')=='d007_global_work_v2' and m.get('counter_evidence')=='SYNTHETIC-SOFTWARE-FIXTURE-NOT-PL','status/layout/synthetic provenance')
    require(all(counter.validate_summary(m).values()) and m['pl_total_cycles']>0,'global-work-v2 conservation')
    chunks=chain.split_chain_output(reply.payload,records)
    out=np.zeros((jobs[0].matrix_m,jobs[0].matrix_n),np.int32)
    for job,chunk in zip(jobs,chunks): tile.place_output(out,job,chunk)
    return out


class Stopped(RuntimeError): pass


class PointwiseCall:
    """Poison-on-failure offline boundary. No fallback or automatic retry."""
    def __init__(self,case,transport,*,enabled=False):
        require(enabled is True,'pointwise candidate default-off')
        require(type(transport) is SoftwareTransport,'software fixture only; hardware adapter not implemented')
        require(case['weights'].shape==(64,64) and case['bias'].shape==(64,)
            and case['expected'].shape==(125,64) and case['input_zp']==-128 and case['output_zp']==-128
            and case['activation']==1,'fixed layer case')
        require(case['weights'].dtype==np.int8 and case['bias'].dtype==np.int32
            and case['expected'].dtype==np.int8 and case['scales'].shape==(64,)
            and np.isfinite(case['scales']).all() and (case['scales']>0).all(),'exact model parameter types')
        self.case={k:(v.copy() if type(v) is np.ndarray else v) for k,v in case.items()}
        for v in self.case.values():
            if type(v) is np.ndarray: v.flags.writeable=False
        self.transport=transport
        self.failed=False
        self.first_failure=None
        self.accepted=False
    def __call__(self,a,*,stopped=lambda:False):
        require(not self.failed,'failed/stopped call cannot retry')
        payload=None
        try:
            if stopped() is not False: raise Stopped('before construction')
            require(type(a) is np.ndarray and a.dtype==np.int8 and a.shape==(125,64)
                and a.flags.c_contiguous and a.flags.owndata,'owning fixed-shape INT8 input')
            require(np.array_equal(a,self.case['a']),'fixed layer input identity')
            jobs,records=make_jobs(a,self.case['weights'])
            require(len(jobs)==2 and [j.actual_bm for j in jobs]==[64,61],'fixed two-job geometry')
            if stopped() is not False: raise Stopped('before software submission')
            reply=self.transport(jobs,records)
            if type(reply) is Reply and type(reply.payload) is bytes: payload=reply.payload
            raw=validate_reply(jobs,records,reply)
            require(np.array_equal(raw,a.astype(np.int64)@self.case['weights'].astype(np.int64)),
                'all raw INT32 values must equal independent INT64 dot product')
            _,_,_,ref=sources()
            corrected=raw.astype(np.int64)+self.case['bias'].astype(np.int64)-self.case['input_zp']*self.case['weights'].astype(np.int64).sum(axis=0)
            ref.checked_i32(corrected)
            result=ref.requantize(corrected,self.case['scales'],self.case['output_zp'],self.case['activation'])
            require(np.array_equal(result,self.case['expected']),'all 8000 INT8 values must equal frozen layer reference')
            if stopped() is not False: raise Stopped('returned exact but not accepted')
            self.accepted=True
            return result,dict(fixture=True,board_access=False,PL_simulated=False,promotion=False,
                logical_macs=512000,jobs=2,input_bytes=16512,output_bytes=32000,
                output_sha256=sha(result.tobytes()),raw_output_sha256=sha(raw.astype('<i4').tobytes()),
                exact_values=8000,counter_source='synthetic software fixture only')
        except BaseException as error:
            self.failed=True
            if self.first_failure is None:
                self.first_failure=dict(error_type=type(error).__name__,payload=None if payload is None or len(payload)>32000 else payload,
                    accepted=False,scope='software fixture returned tile-order payload; not real hardware evidence')
            raise
