"""Explicit thin operations; real launch has no injectable execution dependencies."""
import os
from pathlib import Path
import tempfile
import uuid
import site_support as s
def preflight(output,kit_pin,*,enabled=False):
    s.require(enabled is True,'readonly probe default-off');s.verify_kit(kit_pin)
    out=s.outside(output);s.require(not os.path.lexists(out),'fresh preflight file');s.confirm('PROBEONLY')
    value=s.observe(kit_pin);pin=s.write_json(out,value)
    return dict(preflight=str(out),preflight_sha256=pin['sha256'],hardware_access=False,board_test_started=False,lock_acquired=False)
def prepare(preflight_path,preflight_pin,parent,board_declaration,kit_pin,*,enabled=False):
    s.require(enabled is True,'data preparation default-off');s.verify_kit(kit_pin)
    pre=s.validate_preflight(s.pinned(preflight_path,preflight_pin),kit_pin)
    s.require(type(board_declaration) is str and 0<len(board_declaration)<=128 and all(ord(c)>=32 for c in board_declaration),'declared physical board')
    parent=s.outside(parent);s.require(parent.is_dir(),'existing evidence parent')
    s.confirm('PREPARE_OP4POINTWISE12');s.require(s.observe(kit_pin)==pre,'live boot/dependency/lock observation drift')
    work=Path(tempfile.mkdtemp(prefix='op4pointwise12_run_',dir=parent)).resolve();run_id=str(uuid.uuid4())
    request=dict(schema='pointwise-process-request-candidate-v1',run_id=run_id,operator='bx',board_declaration=board_declaration,
        image='pynq-z2-v3.1.1',scope='fixed-twelve-operator4-correctness-only',candidate_manifest_sha256=s.CORE_SHA,
        expected_boot=pre['environment']['boot_id'],expected_lock=pre['lock']['identity'],
        declarations=dict(utc=True,idle=True,wiring=True,separate_scope_approved=True))
    s.load_core('runtime_contract').validate_request(request)
    request_sha=s.write_json(work/'request.json',request)['sha256'];pre_sha=s.write(work/'preflight.json',s.read(preflight_path))['sha256']
    s.require(pre_sha==preflight_pin,'preflight copy unchanged')
    plan=dict(schema='pointwise-launch-plan-candidate-v1',run_id=run_id,operator='bx',board_work=str(work),kit_manifest_sha256=kit_pin,
        core_manifest_sha256=s.CORE_SHA,preflight_sha256=pre_sha,request_sha256=request_sha,evidence='evidence',
        scope='operator4-pointwise-12-correctness-no-performance-no-energy')
    plan_sha=s.write_json(work/'plan.json',plan)['sha256']
    return dict(work_directory=str(work),plan_sha256=plan_sha,request_sha256=request_sha,runtime_started=False,hardware_access=False)
def run(work,plan_pin,kit_pin,*,enabled=False):
    s.require(enabled is True,'board launch default-off');s.verify_kit(kit_pin)
    plan,pre,request=s.validate_plan(work,plan_pin,kit_pin);work=s.outside(work)
    s.require(not any(os.path.lexists(work/n) for n in ('invocation.json','evidence','attempt_'+plan['run_id']+'.json')),'single prepared launch; no retry')
    s.require(s.observe(kit_pin)==pre,'current boot/dependency/lock changed')
    s.confirm('OP4POINTWISE12')
    # Recheck after operator interaction, before the irreversible attempt.
    s.verify_kit(kit_pin);s.validate_plan(work,plan_pin,kit_pin)
    s.require(s.observe(kit_pin)==pre,'state changed during confirmation')
    s.write_json(work/'invocation.json',dict(schema='pointwise-launch-invocation-candidate-v1',operator='bx',confirmation='OP4POINTWISE12',
        plan_sha256=plan_pin,request_sha256=plan['request_sha256'],kit_manifest_sha256=kit_pin,run_id=plan['run_id'],fixture=False,
        approval_is_operator_declaration=True,physical_identity_authenticated=False))
    # No try/finally that kills, closes, or changes the reviewed supervision.
    result=s.load_core('pointwise_parent').launch(work/'request.json',plan['request_sha256'],work/'evidence',enabled=True,confirmed=True)
    s.require(result.get('operation_success') is True,'reviewed parent did not report success');return result
def stop(work,plan_pin,kit_pin,*,enabled=False):
    s.require(enabled is True,'cooperative stop default-off');s.verify_kit(kit_pin)
    plan,_,_=s.validate_plan(work,plan_pin,kit_pin);work=s.outside(work)
    s.require((work/'invocation.json').is_file() and (work/'evidence/launch.json.ready').is_file(),'existing started session required')
    s.confirm('STOPONLY');flag=work/'evidence/stop.flag'
    if os.path.lexists(flag):s.require(s.read(flag,0)==b'','existing plain stop flag')
    else:s.write(flag,b'')
    return dict(cooperative_stop_requested=True,child_exit_observed=False,lock_released_proven=False,automatic_kill=False,automatic_retry=False)
