"""TEST ONLY: synthetic PYNQ/MMIO/DMA/proc/flock; never real devices or FDs.

Original Python constructor/driver/owner/lock code runs over fake boundaries.
Fake START copies a software-emulated payload: not RTL or hardware arithmetic.
"""
from contextlib import contextmanager,ExitStack
import errno
import os
import stat
import sys
from types import ModuleType,SimpleNamespace
from unittest.mock import patch
from pathlib import Path
import numpy as np
import adapter_binding as ab
from return_diagnostic import SUCCESS_NO_FAILED_TILE

components=ab.configure()
fixture=ab.load('_driver_test_fixture',ab.ROOT/'frozen_hw/legacy/offline_fixture.py')
import os_evidence
import lease_entry_candidate
import kws_threeway_entry_support_draft as helper
import batch_owner
import pynq_gemm as driver
from pointwise_policy import PointwisePolicy
from pointwise_owner import PointwiseOwner
from pointwise_candidate import make_jobs,SoftwareTransport

class FakeCanonicalEnvironment:
    def __init__(self,*,missing=False,busy=False,drift=False,close_error=False,factory_error=False):
        self.missing,self.busy,self.drift,self.close_error,self.factory_error=missing,busy,drift,close_error,factory_error
        self.fd_live=self.held=False;self.contexts=[];self.events=[]
        self.fake_os=SimpleNamespace(name='posix',getpid=os.getpid,O_NOFOLLOW=0x100,O_RDONLY=0,O_NONBLOCK=0x200,
            lstat=self.lstat,open=self.open,fstat=self.fstat,close=self.close,
            get_inheritable=lambda fd:False,major=lambda device:8,minor=lambda device:0)
        self.fcntl=ModuleType('fcntl');self.fcntl.LOCK_EX=2;self.fcntl.LOCK_NB=4;self.fcntl.flock=self.flock
        env=self
        class FakePath:
            def __init__(self,path):self.path=str(path)
            @property
            def name(self):return self.path.rsplit('/',1)[-1]
            def is_dir(self):return True
            def iterdir(self):return iter([FakePath('/proc/self/fd/99')])
        self.fake_path=FakePath
    def lstat(self,path):
        if self.missing:raise FileNotFoundError('synthetic missing canonical lock')
        return SimpleNamespace(st_mode=stat.S_IFREG|0o644,st_nlink=1,st_dev=2048,st_ino=12 if self.drift and self.held else 11)
    def open(self,*args):
        self.events.append('fake_open');self.fd_live=True;return 99
    def fstat(self,fd):
        if not self.fd_live:raise OSError(errno.EBADF,'synthetic FD closed')
        return SimpleNamespace(st_mode=stat.S_IFREG|0o644,st_dev=2048,st_ino=11)
    def flock(self,fd,flags):
        self.events.append('fake_flock')
        if self.busy:raise BlockingIOError(errno.EAGAIN,'synthetic lock busy')
        self.held=True
    def close(self,fd):
        self.events.append('fake_close')
        if self.close_error:raise OSError('synthetic close failure')
        self.fd_live=self.held=False
    def read_text(self,path,limit=65536):
        if path.endswith('/fdinfo/99'):
            return f'flags:\t02000000\nino:\t11\nlock:\t1: FLOCK ADVISORY WRITE {os.getpid()} 08:00:11 0 EOF\n'
        if path=='/proc/self/stat':return f'{os.getpid()} (synthetic) S '+('0 '*18)+'123'
        raise AssertionError('unexpected fake proc path')
    def factory(self):
        self.events.append('fake_factory')
        if self.factory_error:raise RuntimeError('synthetic opaque factory failure')
        context=helper.existing_shared_lock_draft();self.contexts.append(context);return context
    @contextmanager
    def install(self):
        with ExitStack() as stack:
            stack.enter_context(patch.object(helper,'os',self.fake_os))
            stack.enter_context(patch.object(os_evidence,'os',self.fake_os))
            stack.enter_context(patch.object(os_evidence,'Path',self.fake_path))
            stack.enter_context(patch.object(os_evidence,'read_text',side_effect=self.read_text))
            stack.enter_context(patch.object(lease_entry_candidate,'os',self.fake_os))
            stack.enter_context(patch.object(lease_entry_candidate,'Path',self.fake_path))
            stack.enter_context(patch.dict(sys.modules,{'fcntl':self.fcntl}))
            try:yield self
            finally:
                # Fixture teardown only. No real resource ever existed.
                for context in self.contexts:
                    generator=getattr(context,'gen',None)
                    if generator is not None:generator.close()

class Harness:
    def __init__(self,case,*,allocation_failure=None,clock=100.,version='3.1.1'):
        self.dependencies=ab.select(enabled=True)
        self.stop=False;self.events=[];self.buffers=[];self.recovery_ok=True;self.after_submit=None
        self.owner=PointwiseOwner(PointwisePolicy(enabled=True),lambda:self.stop,enabled=True)
        jobs,records=make_jobs(case['a'],case['weights'])
        response=SoftwareTransport()(jobs,records)
        runner,_,_,self.events=fixture.fixture(jobs,response.payload)
        self.engine=runner.mmio;self.dma=runner.dma
        original_write=self.engine.write
        def write(offset,value):
            original_write(offset,value)
            if offset==driver.REG_CONTROL and value==driver.CONTROL_START and self.after_submit:
                self.after_submit(self)
        self.engine.write=write
        self.fake=ModuleType('pynq');self.fake.__version__=version
        self.fake.Clocks=SimpleNamespace(fclk0_mhz=clock)
        overlay=SimpleNamespace(ip_dict={'axi_dma':{'type':'xilinx.com:ip:axi_dma:7.1'},
            'accel':{'phys_addr':0x40000000,'addr_range':4096}},axi_dma=self.dma)
        def fake_overlay(path,download):
            self.events.append(('fake_overlay',download));return overlay
        self.fake.Overlay=fake_overlay;self.fake.MMIO=lambda address,extent:self.engine
        def allocate(shape,dtype):
            if allocation_failure==len(self.buffers):raise RuntimeError('synthetic allocation failure')
            buf=fixture.Buffer(shape[0],0x10000000+len(self.buffers)*0x10000000,self.events,'tx' if not self.buffers else 'rx')
            self.buffers.append(buf);return buf
        self.fake.allocate=allocate
        harness=self
        class Recovery:
            last_diagnostics={'scope':'synthetic fixture recovery; NOT hardware recovery'}
            def recover_and_confirm(self,runner):
                harness.events.append(('fake_recovery',))
                harness.engine.values[0x12c]=1;harness.engine.values[driver.REG_STATUS]=1
                return harness.recovery_ok
        self.recovery=lambda *args,**kwargs:Recovery()
    def set_case(self,case):
        jobs,records=make_jobs(case['a'],case['weights'])
        self.engine.payload=SoftwareTransport()(jobs,records).payload
    def start(self,env):
        with patch.dict(sys.modules,{'pynq':self.fake}):
            self.owner.start(self.dependencies.runner_type,Path('SYNTHETIC_NOT_A_DEVICE.bit'),env.factory,self.recovery)
            # Explicit new fixture adapter: the frozen legacy fixture remains
            # unchanged, while this D075 MODE11 model uses its real sentinel.
            self.engine.values[driver.REG_FAILED_TILE]=SUCCESS_NO_FAILED_TILE
    def discard_synthetic_hold(self):
        # Does not call close/free/release; remove only fake test retention.
        if self.owner in batch_owner._RETAINED:batch_owner._RETAINED.remove(self.owner)
