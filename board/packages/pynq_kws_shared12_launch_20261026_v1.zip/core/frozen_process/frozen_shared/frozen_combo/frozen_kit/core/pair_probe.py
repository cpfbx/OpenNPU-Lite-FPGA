"""Actual LOCAL PC parent/child handshake/wait. Hardware/lock still injected."""
import argparse
import os
from pathlib import Path
import platform
import subprocess
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import runtime_binding as rb
import runtime_contract as ct
from process_fixture import request,finite_fixture_supervise
from pointwise_parent import launch

def run_one(root,fault=False):
    root.mkdir();req=request();cfg=root/'request.json';pin=ct.write_json(cfg,req)['sha256'];evidence=root/'evidence'
    spawned=[]
    def popen(command,**options):
        # Fixed no-device x86 fixture entry, NOT arbitrary child code.
        command=list(command);command[3]=str(rb.ROOT/'pc_child_entry.py')
        command[-1]='--enabled-PC-fixture'
        if fault:command+=['--fault-index','90']
        child=subprocess.Popen(command,**options);spawned.append(child);return child
    error=None
    try:
        value=launch(cfg,pin,evidence,enabled=True,confirmed=True,fixture=True,popen_factory=popen,
            snapshot=lambda:req['expected_lock'],live_query=lambda ticket,pid,identity:ticket['pid']==pid,
            release_query=lambda identity:dict(identity,lock_released_same_inode=True,source='SYNTHETIC lock only'),
            group_query=(lambda pid:True) if os.name!='posix' else None,
            fixture_supervise=finite_fixture_supervise,fixture_parent_start=lambda:123)
    except (ValueError,RuntimeError) as caught:error=type(caught).__name__
    result=ct.ready_json(evidence/'outer_receipt.json',400000)
    rb.require(type(result) is dict and len(spawned)==1 and result['actual_wait_observed'] is True
        and result['actual_exit_code']==(1 if fault else 0) and result['process_group_absent'] is True,'actual known PC child wait')
    rb.require(result['cleanup_verified'] is True and result['fixture'] is True and result['evidence_injected'] is True,'fixture release/cleanup labels')
    if fault:
        rb.require(error is not None and result['operation_success'] is False
            and result['child_terminal']['completed_indices']==[0,30,60],'fault child stopped before later windows')
    else:rb.require(error is None and result['operation_success'] is True and result['parent_go_sent'] is True,'normal actual file handshake')
    return dict(expected_fault=fault,actual_exit_code=result['actual_exit_code'],child_pid=spawned[0].pid,
        actual_wait_observed=True,group_query_injected=result['group_query_injected'],
        accepted_calls=result['child_terminal']['accepted_calls'],operation_success=result['operation_success'])
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    rb.require(platform.machine().lower() in ('amd64','x86_64','x86','i386','i686'),'PC fixture probe, never ARM')
    out=ct.canonical(a.output);rb.require(not out.exists() and not out.is_relative_to(rb.ROOT),'fresh PC pair output');out.mkdir()
    normal=run_one(out/'normal');fault=run_one(out/'fault',True)
    record=dict(operation_success=True,scope='real LOCAL PC Popen/file-handshake/wait; FAKE hardware and canonical lock',
        normal=normal,fault=fault,real_parent_child_pair=True,original_production_parent_hold_loop_executed=False,
        real_canonical_lock_access=False,real_board_access=False,real_process_group_query=os.name=='posix',
        ARM_tested=False,run_ready=False,promotion=False)
    ct.write_json(out/'result.json',record);print(record)
if __name__=='__main__':main()
