"""Fixed operator4, with original prefix including depthwise operator3."""
from dataclasses import dataclass
import json
import numpy as np
from source_bindings import FROZEN,need,sha,sources
INDICES=(0,30,60,90,120,150,180,210,240,270,300,400)
LABELS=('down','go','left','no','off','on','right','stop','up','yes','_unknown_','_silence_')
@dataclass(frozen=True)
class LayerSpec:
    operator_index:int=4
    input_tensor:int=25
    weight_tensor:int=19
    bias_tensor:int=9
    output_tensor:int=26
    def __post_init__(self):
        need(all(type(v) is int for v in vars(self).values()) and tuple(vars(self).values())==(4,25,19,9,26),'fixed operator4 spec')
def selection():
    sources();cohort=json.loads((FROZEN/'frozen/data/cohort.json').read_bytes());need(type(cohort) is list and len(cohort)==420,'cohort extent')
    first={}
    for i,row in enumerate(cohort):first.setdefault(row['label'],i)
    need(tuple(first)==LABELS and tuple(first.values())==INDICES,'fixed first-label indices')
    return tuple(dict(cohort_index=i,**cohort[i]) for i in INDICES)
def derive(index,spec=LayerSpec()):
    need(type(spec) is LayerSpec and spec==LayerSpec(),'exact operator4 spec')
    need(type(index) is int and index in INDICES,'fixed integer window index')
    item=next(r for r in selection() if r['cohort_index']==index);_,_,_,ref,_=sources()
    model=ref.IntegerReference(FROZEN/'frozen/model',enabled=True)
    op=model.info['operators'][4]
    need(op['index']==4 and op['name']=='CONV_2D' and op['mnk']==[125,64,64] and op['inputs']==[25,19,9] and op['outputs']==[26] and op['stride']==op['dilation']==[1,1] and op['activation']==1,'frozen operator4 identity')
    feature=(FROZEN/'frozen/data/features.i8').read_bytes()[index*490:(index+1)*490];need(len(feature)==490,'feature extent')
    x=np.frombuffer(feature,np.int8).reshape(1,49,10,1);values={0:x};baseline={}
    for current in model.info['operators'][:5]:
        src,wi,bi=current['inputs'];dst=current['outputs'][0];it,wt,ot=[model.info['tensors'][i] for i in (src,wi,dst)]
        a,b,bias=values[src],model.constants[wi],model.constants[bi];zp=it['zero_points'][0]
        need(all(z==0 for z in wt['zero_points']),'symmetric prefix weights')
        if current['name']=='CONV_2D':
            patches=ref.conv_patches(a,b.shape,ot['shape'],current['stride'],current['padding'],current['dilation'],zp)
            weights=b.reshape(b.shape[0],-1)
            acc=patches.astype(np.int64)@weights.astype(np.int64).T+bias.astype(np.int64)-zp*weights.astype(np.int64).sum(axis=1)
        else:
            need(current['name']=='DEPTHWISE_CONV_2D','prefix operator kind')
            _,kh,kw,c=b.shape;patches=ref.conv_patches(a,(c,kh,kw,c),ot['shape'],current['stride'],current['padding'],current['dilation'],zp)
            acc=((patches.reshape(-1,kh*kw,c).astype(np.int64)-zp)*b.reshape(kh*kw,c).astype(np.int64)).sum(axis=1)+bias
        ref.checked_i32(acc);scales=np.array(wt['scales'],np.float64)*float(it['scales'][0])/float(ot['scales'][0])
        result=ref.requantize(acc,scales,ot['zero_points'][0],current['activation']).reshape(ot['shape']);values[dst]=result;baseline[dst]=result.copy()
    need(list(baseline)==[22,23,24,25,26],'depthwise3 retained in prefix')
    class PrefixComplete(Exception):pass
    seen=[]
    def compare(tensor):
        if tensor not in baseline:raise PrefixComplete()
        seen.append(tensor);return baseline[tensor]
    try:model.infer(x,compare=compare);raise ValueError('prefix did not stop')
    except PrefixComplete:need(seen==[22,23,24,25,26],'original reference five tensor comparisons')
    logits,checks=model.infer(x);need(not checks and logits.tobytes()==(FROZEN/'frozen/data/logits.i8').read_bytes()[index*12:(index+1)*12],'frozen selected-window logits')
    it,wt,ot=[model.info['tensors'][i] for i in (25,19,26)]
    need(it['shape']==ot['shape']==[1,25,5,64] and wt['shape']==[64,1,1,64] and wt['zero_points']==[0]*64 and it['zero_points']==ot['zero_points']==[-128],'fixed pointwise quantization domain')
    return dict(spec=spec,cohort_index=index,label=item['label'],source_id=item['source_id'],feature_sha256=sha(feature),a=values[25].reshape(125,64).copy(),weights=model.constants[19].reshape(64,64).T.copy(),bias=model.constants[9].copy(),scales=np.array(wt['scales'],np.float64)*float(it['scales'][0])/float(ot['scales'][0]),expected=values[26].reshape(125,64).copy(),input_zp=-128,output_zp=-128,activation=1,prefix_tensors_checked=seen,selected_CPU_logits_checked=True)
