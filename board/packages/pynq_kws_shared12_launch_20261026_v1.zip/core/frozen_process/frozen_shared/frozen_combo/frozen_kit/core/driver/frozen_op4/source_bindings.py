"""Cold pinned CPU-only imports. Never mutates frozen module globals."""
import hashlib,importlib.util,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
FROZEN=ROOT/'frozen_op2'
FROZEN_PIN='1fb87ca56ffb8f60b08d6427438cce0f1b69184d326865059957b2bfd95a6d5b'
def need(ok,msg):
    if not ok:raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def inventory(root):
    result={}
    for p in root.rglob('*'):
        need(not p.is_symlink() and not getattr(p,'is_junction',lambda:False)(),'plain frozen file')
        if p.is_file():result[p.relative_to(root).as_posix()]=dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))
    return result
def forbidden():need(not any(n==r or n.startswith(r+'.') for n in sys.modules for r in ('pynq','tensorflow','tflite_runtime')),'CPU-only modules required')
def verify_frozen():
    forbidden();raw=(FROZEN/'candidate_manifest.json').read_bytes();need(sha(raw)==FROZEN_PIN,'frozen op2 pin')
    pins=json.loads(raw)['files'];actual=inventory(FROZEN)
    need(set(actual)==set(pins)|{'candidate_manifest.json'} and all(actual[n]==v for n,v in pins.items()),'frozen op2 exact bytes')
    return actual
def load(name,path):
    path=path.resolve()
    if name in sys.modules:
        need(Path(getattr(sys.modules[name],'__file__','')).resolve()==path,'foreign module '+name);return sys.modules[name]
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def sources():
    verify_frozen();b=load('binding',FROZEN/'binding.py');tile,chain,counter,ref=b.sources()
    sw=load('pointwise_candidate',FROZEN/'pointwise_candidate.py');return tile,chain,counter,ref,sw
def verify_candidate(pin):
    raw=(ROOT/'candidate_manifest.json').read_bytes();need(type(pin) is str and len(pin)==64 and sha(raw)==pin,'external candidate pin')
    pins=json.loads(raw)['files'];actual=inventory(ROOT)
    need(set(actual)==set(pins)|{'candidate_manifest.json'} and all(actual[n]==v for n,v in pins.items()),'candidate exact bytes');verify_frozen();return actual
