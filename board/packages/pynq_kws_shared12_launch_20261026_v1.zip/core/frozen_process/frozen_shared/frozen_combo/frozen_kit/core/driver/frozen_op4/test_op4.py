"""32 distinct methods; subcases and repeated runs are not extra methods."""
from dataclasses import replace
import copy,sys,unittest
from pathlib import Path
from types import ModuleType
from unittest.mock import patch
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import source_bindings as sb
from layer_case import INDICES,LayerSpec,derive,selection
from op4_candidate import InputEnvelope,Op4Call,SyntheticTransport,OfflineStop,input_for
from independent_math import decode
class Op4Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cases=[derive(i) for i in INDICES];cls.case=cls.cases[0]
        cls.old=sb.load('real_case',sb.FROZEN/'real_case.py').derive(0)
    def call(self,c=None,t=None):return Op4Call(self.case if c is None else c,SyntheticTransport() if t is None else t,enabled=True)
    def test_01_fixed_spec(self):self.assertEqual(vars(LayerSpec()),dict(operator_index=4,input_tensor=25,weight_tensor=19,bias_tensor=9,output_tensor=26))
    def test_02_reject_foreign_or_bool_spec(self):
        for k,v in [('operator_index',2),('operator_index',6),('input_tensor',23),('weight_tensor',18),('operator_index',True)]:
            with self.subTest(field=k,value=v),self.assertRaises(ValueError):replace(LayerSpec(),**{k:v})
    def test_03_fixed_metadata_selection(self):self.assertEqual(tuple(r['cohort_index'] for r in selection()),INDICES)
    def test_04_reject_bad_index(self):
        for i in [True,False,0.0,'0',np.int64(0),None,-1,1,419,420]:
            with self.subTest(value=repr(i)),self.assertRaises(ValueError):derive(i)
    def test_05_full_prefix_includes_depthwise3_all_windows(self):
        for c in self.cases:self.assertEqual(c['prefix_tensors_checked'],[22,23,24,25,26]);self.assertIs(c['selected_CPU_logits_checked'],True)
    def test_06_layer_parameters_exact(self):
        _,_,_,ref,_=sb.sources();model=ref.IntegerReference(sb.FROZEN/'frozen/model',enabled=True)
        self.assertTrue(np.array_equal(self.case['weights'],model.constants[19].reshape(64,64).T));self.assertTrue(np.array_equal(self.case['bias'],model.constants[9]))
    def test_07_cannot_reuse_operator2_parameters_or_input(self):
        self.assertFalse(np.array_equal(self.case['weights'],self.old['weights']));self.assertFalse(np.array_equal(self.case['a'],self.old['a']))
        with self.assertRaises(ValueError):self.call(self.old)
    def test_08_default_off(self):
        with self.assertRaises(ValueError):Op4Call(self.case,SyntheticTransport())
    def test_09_no_hardware_transport(self):
        with self.assertRaises(ValueError):Op4Call(self.case,object(),enabled=True)
    def test_10_forged_expected_rejected_before_submission(self):
        c=copy.deepcopy(self.case);c['expected'][0,0]^=np.int8(1);t=SyntheticTransport()
        with self.assertRaisesRegex(ValueError,'expected'):self.call(c,t)
        self.assertEqual(t.submissions,0)
    def test_11_wrong_weights_bias_scales_rejected(self):
        for key in ('weights','bias','scales'):
            c=copy.deepcopy(self.case);c[key].flat[0]+=1
            with self.subTest(key=key),self.assertRaisesRegex(ValueError,key):self.call(c)
    def test_12_wrong_case_metadata_rejected(self):
        for k,v in [('feature_sha256','0'*64),('source_id','wrong'),('label','wrong')]:
            c=copy.deepcopy(self.case);c[k]=v
            with self.subTest(key=k),self.assertRaisesRegex(ValueError,k):self.call(c)
    def test_13_arrays_detached_and_readonly(self):
        c=copy.deepcopy(self.case);call=self.call(c);c['weights'][0,0]^=np.int8(1)
        self.assertFalse(np.shares_memory(c['weights'],call.case['weights']));self.assertFalse(call.case['weights'].flags.writeable)
        with self.assertRaises(TypeError):call.case['operator_index']=2
        out,_=call(input_for(self.case));self.assertTrue(np.array_equal(out,self.case['expected']))
    def test_14_plain_input_without_envelope_rejected(self):
        t=SyntheticTransport();call=self.call(t=t)
        with self.assertRaisesRegex(ValueError,'envelope'):call(self.case['a'])
        self.assertEqual(t.submissions,0)
    def test_15_wrong_input_layer_rejected_before_jobs(self):
        for k,v in [('operator_index',2),('tensor_index',23),('operator_index',True)]:
            call=self.call();_,_,_,_,sw=sb.sources()
            with patch.object(sw,'make_jobs',wraps=sw.make_jobs) as builder:
                with self.assertRaisesRegex(ValueError,'layer identity'):call(replace(input_for(self.case),**{k:v}))
                self.assertEqual(builder.call_count,0)
    def test_16_cross_window_identity_rejected_before_jobs(self):
        for c,other in zip(self.cases,self.cases[1:]+self.cases[:1]):
            call=self.call(c);_,_,_,_,sw=sb.sources()
            with patch.object(sw,'make_jobs',wraps=sw.make_jobs) as builder:
                with self.assertRaisesRegex(ValueError,'window identity'):call(input_for(other))
                self.assertEqual(builder.call_count,0)
    def test_17_wrong_input_byte_rejected_before_jobs(self):
        env=input_for(self.case);env.values[0,0]^=np.int8(1);call=self.call();_,_,_,_,sw=sb.sources()
        with patch.object(sw,'make_jobs',wraps=sw.make_jobs) as builder:
            with self.assertRaisesRegex(ValueError,'owning input'):call(env)
            self.assertEqual(builder.call_count,0)
    def test_18_nonowning_noncontiguous_or_subclass_rejected(self):
        class Array(np.ndarray):pass
        for values in [self.case['a'].view(),self.case['a'][:,::-1],self.case['a'].view(Array),self.case['a'].astype(np.int16)]:
            with self.subTest(dtype=str(values.dtype)),self.assertRaisesRegex(ValueError,'owning input'):self.call()(replace(input_for(self.case),values=values))
    def test_19_all_windows_exact_software(self):
        for c in self.cases:
            t=SyntheticTransport();call=self.call(c,t);out,proof=call(input_for(c))
            self.assertTrue(np.array_equal(out,c['expected']));self.assertEqual(t.submissions,1);self.assertEqual(proof['metrics']['failed_tile_index'],65535);self.assertIs(proof['fixture'],True);self.assertIs(proof['board_access'],False)
    def test_20_success_cannot_repeat(self):
        call=self.call();call(input_for(self.case))
        with self.assertRaisesRegex(ValueError,'single call'):call(input_for(self.case))
        self.assertEqual(call.transport.submissions,1)
    def test_21_raw_bit_rejected_each_window_first_failure_no_retry(self):
        def mutate(r):return replace(r,payload=bytes([r.payload[0]^1])+r.payload[1:])
        for c in self.cases:
            t=SyntheticTransport(mutate);call=self.call(c,t)
            with self.assertRaisesRegex(ValueError,'raw INT32'):call(input_for(c))
            first=call.first_failure;self.assertEqual(first.stage,'raw_check');self.assertEqual(len(first.payload),32000)
            with self.assertRaises(ValueError):call(input_for(c))
            self.assertIs(call.first_failure,first);self.assertEqual(t.submissions,1)
    def test_22_wrong_success_sentinel(self):
        for value in (0,1,0xffffffff,True):
            def mutate(r,v=value):return replace(r,metrics=dict(r.metrics,failed_tile_index=v))
            with self.subTest(value=value),self.assertRaisesRegex(ValueError,'sentinel'):self.call(t=SyntheticTransport(mutate))(input_for(self.case))
    def test_23_work_counters_not_relaxed(self):
        for key in ('jobs','input_bytes','output_bytes','effective_macs','first_job_id','counter_contract_version'):
            def mutate(r,k=key):return replace(r,metrics=dict(r.metrics,**{k:r.metrics[k]+1}))
            with self.subTest(key=key),self.assertRaisesRegex(ValueError,'counter'):self.call(t=SyntheticTransport(mutate))(input_for(self.case))
    def test_24_error_or_dirty_status_rejected(self):
        for key,value in [('error_code',1),('status',13),('status',7)]:
            def mutate(r,k=key,v=value):return replace(r,metrics=dict(r.metrics,**{k:v}))
            with self.subTest(key=key,value=value),self.assertRaises(ValueError):self.call(t=SyntheticTransport(mutate))(input_for(self.case))
    def test_25_short_reply_rejected(self):
        call=self.call(t=SyntheticTransport(lambda r:replace(r,payload=r.payload[:-1])))
        with self.assertRaises(ValueError):call(input_for(self.case))
        self.assertFalse(call.accepted)
    def test_26_oversize_payload_not_retained(self):
        call=self.call(t=SyntheticTransport(lambda r:replace(r,payload=r.payload+b'xxxx')))
        with self.assertRaises(ValueError):call(input_for(self.case))
        self.assertIsNone(call.first_failure.payload)
    def test_27_wrong_return_records_rejected(self):
        call=self.call(t=SyntheticTransport(lambda r:replace(r,records=r.records[::-1])))
        with self.assertRaisesRegex(ValueError,'echoed records'):call(input_for(self.case))
    def test_28_stop_before_construction(self):
        call=self.call();_,_,_,_,sw=sb.sources()
        with patch.object(sw,'make_jobs',wraps=sw.make_jobs) as builder:
            with self.assertRaises(OfflineStop):call(input_for(self.case),stopped=lambda:True)
            self.assertEqual(builder.call_count,0)
        self.assertEqual(call.transport.submissions,0)
    def test_29_stop_before_submission(self):
        call=self.call();values=iter([False,True])
        with self.assertRaises(OfflineStop):call(input_for(self.case),stopped=lambda:next(values))
        self.assertEqual(call.transport.submissions,0);self.assertEqual(call.first_failure.stage,'before_submit')
    def test_30_stop_after_exact_reply_not_accepted(self):
        call=self.call();values=iter([False,False,True])
        with self.assertRaises(OfflineStop):call(input_for(self.case),stopped=lambda:next(values))
        self.assertFalse(call.accepted);self.assertEqual(call.transport.submissions,1);self.assertEqual(call.first_failure.stage,'before_accept')
    def test_31_tail_padding_independent_decoder(self):
        _,_,_,_,sw=sb.sources();_,records=sw.make_jobs(self.case['a'],self.case['weights']);wire=bytearray(b''.join(r.bytes for r in records));wire[8256+64+7*512+5]^=1
        with self.assertRaisesRegex(ValueError,'tail padding'):decode(bytes(wire))
    def test_32_forbidden_engine_is_refused(self):
        for name in ('pynq','tensorflow','tflite_runtime'):
            with self.subTest(module=name),patch.dict(sys.modules,{name:ModuleType(name)}),self.assertRaisesRegex(ValueError,'CPU-only'):sb.sources()
if __name__=='__main__':unittest.main(verbosity=2)
