"""New exact single-layer schedule. Never loosen/convert old matrix policies."""
from dataclasses import dataclass
from real_case import APPROVED_INDICES

@dataclass(frozen=True)
class Geometry:
    shape:tuple=(125,64,64)
    jobs:int=2
    input_bytes:int=16512
    output_bytes:int=32000
    macs:int=512000

@dataclass(frozen=True)
class Request:
    index:int
    cohort_index:int
    first_job_id:int
    shape:tuple=(125,64,64)
    jobs:int=2

@dataclass(frozen=True)
class PointwisePolicy:
    enabled:bool=False
    def __post_init__(self):
        if self.enabled is not True:raise ValueError('pointwise driver policy default-off')
    @property
    def geometry(self):return Geometry()
    def request(self,index):
        if type(index) is not int or not 0<=index<12:raise ValueError('exact twelve-request index')
        return Request(index,APPROVED_INDICES[index],1+2*index)

def validate_pointwise_policy(policy):
    if type(policy) is not PointwisePolicy:raise ValueError('exact new PointwisePolicy required')
    policy.__post_init__()
