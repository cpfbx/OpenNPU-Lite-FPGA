"""Independent address-loop decode and scalar integer double rounding."""
import math,struct
import numpy as np
from source_bindings import need
def decode(raw):
    need(type(raw) is bytes and len(raw)==16512,'wire extent');parts=[];weight=None
    for j,(rows,offset) in enumerate(((64,0),(61,64))):
        h=struct.unpack_from('<16I',raw,j*8256)
        need(h==(0x4f4e5055,2+(64<<16),j+1,32+((1<<31) if j else 0),125,64,64,offset,0,rows+(64<<8)+(64<<16),8192,rows*256,rows*256,0,0,0),'independent wire header')
        payload=raw[j*8256+64:(j+1)*8256];a=np.zeros((64,64),np.int8);b=np.zeros((64,64),np.int8)
        for g in range(8):
            for k in range(64):
                for lane in range(8):
                    v=payload[g*512+k*8+lane];w=payload[4096+g*512+k*8+lane]
                    a[g*8+lane,k]=v if v<128 else v-256;b[k,g*8+lane]=w if w<128 else w-256
        need(not np.any(a[rows:]),'nonzero tail padding')
        if weight is None:weight=b
        else:need(np.array_equal(b,weight),'two weight panels differ')
        parts.append(a[:rows].copy())
    return np.concatenate(parts),weight
def fixed_multiplier(s):
    need(math.isfinite(s) and s>0,'positive scale');f,e=math.frexp(s);q=int(math.floor(f*2147483648+0.5))
    if q==2147483648:q=1073741824;e+=1
    if e<-31:return 0,0
    need(e<=30,'scale exponent');return q,e
def rounded(value,q,e):
    shifted=int(value)*2**max(e,0);need(-(1<<31)<=shifted<(1<<31),'shifted INT32')
    product=shifted*q;n=product+(1073741824 if product>=0 else -1073741823)
    high=(abs(n)//2147483648)*(1 if n>=0 else -1);div=2**max(-e,0);quot,rem=divmod(high,div)
    return quot+int(rem>(div-1)//2+int(high<0))
def check(case,wire,raw,corrected,out):
    a,b=decode(wire);need(np.array_equal(a,case['a']) and np.array_equal(b,case['weights']),'wire operands against operator4 reference')
    raw64=a.astype(np.int64)@b.astype(np.int64);need(np.array_equal(raw,raw64),'independent raw INT64')
    centered=(a.astype(np.int64)+128)@b.astype(np.int64)+case['bias'].astype(np.int64)
    need(np.array_equal(corrected,centered),'independent centered correction')
    scalar=np.empty((125,64),np.int8)
    for col,s in enumerate(case['scales']):
        q,e=fixed_multiplier(float(s))
        for row in range(125):scalar[row,col]=min(127,max(-128,rounded(int(centered[row,col]),q,e)-128))
    need(np.array_equal(scalar,out) and np.array_equal(out,case['expected']),'independent scalar INT8')
    return raw64,centered,scalar
