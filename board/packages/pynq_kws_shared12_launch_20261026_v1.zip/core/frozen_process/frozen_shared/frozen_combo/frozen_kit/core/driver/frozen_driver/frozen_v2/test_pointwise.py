"""Explicit offline fixtures; no device, real counter or recovery tests."""
from dataclasses import replace
from pathlib import Path
import sys
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from binding import ROOT,sources,verify,require,load
from real_case import derive
from pointwise_candidate import (PointwiseCall,SoftwareTransport,Reply,Stopped,
    make_jobs,validate_reply,inspect_wire,scalar_quantized)


class LayerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.case=derive()
    def invoke_bad(self,mutate):
        transport=SoftwareTransport(mutate)
        call=PointwiseCall(self.case,transport,enabled=True)
        with self.assertRaises((ValueError,OverflowError)):
            call(self.case['a'])
        self.assertTrue(call.failed)
        self.assertFalse(call.accepted)
        first=call.first_failure
        with self.assertRaises(ValueError):call(self.case['a'])
        self.assertIs(call.first_failure,first)
        self.assertEqual(transport.submissions,1)
        return call
    def bad_metric(self,key,value):
        return self.invoke_bad(lambda r:replace(r,metrics=dict(r.metrics,**{key:value})))
    def test_real_8000(self):
        call=PointwiseCall(self.case,SoftwareTransport(),enabled=True)
        out,info=call(self.case['a'])
        self.assertTrue(np.array_equal(out,self.case['expected']))
        self.assertEqual(info['exact_values'],8000)
        self.assertFalse(info['board_access'])
    def test_default_off(self):
        with self.assertRaises(ValueError):PointwiseCall(self.case,SoftwareTransport())
    def test_integer_enable_not_bool(self):
        with self.assertRaises(ValueError):PointwiseCall(self.case,SoftwareTransport(),enabled=1)
    def test_no_hardware_transport(self):
        with self.assertRaises(ValueError):PointwiseCall(self.case,lambda *x:None,enabled=True)
    def test_wrong_shape(self):
        call=PointwiseCall(self.case,SoftwareTransport(),enabled=True)
        with self.assertRaises(ValueError):call(np.zeros((124,64),np.int8))
        self.assertEqual(call.transport.submissions,0)
    def test_wrong_dtype(self):
        call=PointwiseCall(self.case,SoftwareTransport(),enabled=True)
        with self.assertRaises(ValueError):call(self.case['a'].astype(np.int32))
    def test_changed_real_input(self):
        a=self.case['a'].copy();a[0,0]^=1
        call=PointwiseCall(self.case,SoftwareTransport(),enabled=True)
        with self.assertRaises(ValueError):call(a)
    def test_strided_input(self):
        call=PointwiseCall(self.case,SoftwareTransport(),enabled=True)
        with self.assertRaises(ValueError):call(self.case['a'][:,::-1])
    def test_subclass_input(self):
        class Sub(np.ndarray):pass
        call=PointwiseCall(self.case,SoftwareTransport(),enabled=True)
        with self.assertRaises(ValueError):call(self.case['a'].view(Sub))
    def test_input_view_not_owning(self):
        call=PointwiseCall(self.case,SoftwareTransport(),enabled=True)
        with self.assertRaises(ValueError):call(self.case['a'].view())
    def test_raw_one_bit_fault_and_first_payload(self):
        call=self.invoke_bad(lambda r:replace(r,payload=bytes([r.payload[0]^1])+r.payload[1:]))
        self.assertEqual(len(call.first_failure['payload']),32000)
    def test_short_output(self):self.invoke_bad(lambda r:replace(r,payload=r.payload[:-1]))
    def test_extra_output(self):self.invoke_bad(lambda r:replace(r,payload=r.payload+b'\0'))
    def test_nonbytes_output(self):self.invoke_bad(lambda r:replace(r,payload=memoryview(r.payload)))
    def test_records_swapped(self):self.invoke_bad(lambda r:replace(r,records=r.records[::-1]))
    def test_records_missing(self):self.invoke_bad(lambda r:replace(r,records=r.records[:-1]))
    def test_jobs_counter(self):self.bad_metric('chain_jobs_completed',1)
    def test_input_bytes_counter(self):self.bad_metric('input_bytes',16511)
    def test_output_bytes_counter(self):self.bad_metric('output_bytes',31999)
    def test_MAC_counter(self):self.bad_metric('effective_macs',511999)
    def test_job_id_counter(self):self.bad_metric('first_job_id',2)
    def test_boolean_counter(self):self.bad_metric('error_code',False)
    def test_error_status(self):self.bad_metric('status',13)
    def test_version(self):self.bad_metric('counter_contract_version',1)
    def test_total_conservation(self):self.bad_metric('pl_total_cycles',121)
    def test_work_conservation(self):self.bad_metric('pl_overlap_credit_cycles',31)
    def test_overlap_subset(self):self.bad_metric('pl_array_output_work_overlap_cycles',11)
    def test_wait_bound(self):self.bad_metric('pl_compute_wait_bank_cycles',121)
    def test_negative_counter(self):self.bad_metric('pl_no_work_cycles',-1)
    def test_missing_counter(self):
        def missing(r):
            m=dict(r.metrics);del m['pl_work_union_cycles']
            return replace(r,metrics=m)
        self.invoke_bad(missing)
    def test_no_real_PL_counter_claim(self):self.bad_metric('counter_evidence','observed PL')
    def test_stop_before_construct(self):
        call=PointwiseCall(self.case,SoftwareTransport(),enabled=True)
        with self.assertRaises(Stopped):call(self.case['a'],stopped=lambda:True)
        self.assertEqual(call.transport.submissions,0)
    def test_stop_before_submit(self):
        call=PointwiseCall(self.case,SoftwareTransport(),enabled=True)
        flags=iter([False,True])
        with self.assertRaises(Stopped):call(self.case['a'],stopped=lambda:next(flags))
        self.assertEqual(call.transport.submissions,0)
    def test_stop_after_exact_return(self):
        call=PointwiseCall(self.case,SoftwareTransport(),enabled=True)
        flags=iter([False,False,True])
        with self.assertRaises(Stopped):call(self.case['a'],stopped=lambda:next(flags))
        self.assertFalse(call.accepted)
        self.assertEqual(len(call.first_failure['payload']),32000)
    def test_case_arrays_sealed(self):
        local={k:(v.copy() if type(v) is np.ndarray else v) for k,v in self.case.items()}
        call=PointwiseCall(local,SoftwareTransport(),enabled=True)
        local['weights'].fill(0);local['expected'].fill(0)
        out,_=call(local['a'])
        self.assertTrue(np.array_equal(out,self.case['expected']))


class WireAndArithmeticTests(unittest.TestCase):
    def test_actual_M125_tail(self):
        a=np.zeros((125,64),np.int8);b=np.zeros((64,64),np.int8)
        jobs,records=make_jobs(a,b)
        self.assertEqual([x.actual_bm for x in jobs],[64,61])
        self.assertEqual(sum(len(r.bytes) for r in records),16512)
    def test_nonzero_tail_A_rejected(self):
        tile,chain,_,_=sources()
        jobs,records=make_jobs(np.zeros((125,64),np.int8),np.zeros((64,64),np.int8))
        raw=bytearray(jobs[1].payload);raw[7*512+5]=1  # row61, k0, padded lane
        changed=replace(jobs[1],payload=bytes(raw));jj=(jobs[0],changed)
        rr=(records[0],chain.build_chain_record(changed,2,chain_last=True))
        with self.assertRaises(ValueError):list(inspect_wire(jj,rr))
    def test_nonzero_tail_B_rejected(self):
        _,chain,_,_=sources()
        jobs,records=make_jobs(np.zeros((1,40),np.int8),np.zeros((40,9),np.int8))
        raw=bytearray(jobs[0].payload);raw[512+512+1]=1 # padded col9
        changed=replace(jobs[0],payload=bytes(raw))
        rr=(chain.build_chain_record(changed,1,chain_last=True),)
        with self.assertRaises(ValueError):list(inspect_wire((changed,),rr))
    def test_nonzero_K_padding_rejected(self):
        _,chain,_,_=sources()
        jobs,records=make_jobs(np.zeros((1,40),np.int8),np.zeros((40,1),np.int8))
        raw=bytearray(jobs[0].payload);raw[40*8]=1
        changed=replace(jobs[0],payload=bytes(raw))
        with self.assertRaises(ValueError):list(inspect_wire((changed,),(chain.build_chain_record(changed,1,chain_last=True),)))
    def test_nonzero_output_transport_padding(self):
        jobs,records=make_jobs(np.ones((1,1),np.int8),np.ones((1,1),np.int8))
        r=SoftwareTransport()(jobs,records)
        with self.assertRaises(ValueError):validate_reply(jobs,records,replace(r,payload=r.payload[:-1]+b'\1'))
    def test_unknown_header_flags(self):
        _,chain,_,_=sources()
        jobs,records=make_jobs(np.ones((1,1),np.int8),np.ones((1,1),np.int8))
        words=list(chain.CHAIN_HEADER.unpack(records[0].header_bytes));words[3]|=1<<6
        with self.assertRaises(ValueError):chain.parse_chain_header(chain.CHAIN_HEADER.pack(*words))
    def test_negative_K_dimension(self):
        with self.assertRaises(ValueError):make_jobs(np.zeros((1,0),np.int8),np.zeros((0,1),np.int8))
    def test_K576_rejected(self):
        with self.assertRaises(ValueError):make_jobs(np.zeros((125,576),np.int8),np.zeros((576,64),np.int8))
    def test_double_rounding_extremes(self):
        _,_,_,ref=sources()
        for value in [-(1<<31),-1000001,-129,-128,-3,-2,-1,0,1,2,3,127,128,1000001,(1<<31)-1]:
            for multiplier in [0,1,1<<30,(1<<31)-1]:
                for shift in [-31,-4,-1,0]:
                    want=int(ref.multiply_quantized(np.array([value],np.int64),multiplier,shift)[0])
                    self.assertEqual(scalar_quantized(value,multiplier,shift),want)
    def test_left_shift_overflow_rejected(self):
        with self.assertRaises(ValueError):scalar_quantized((1<<31)-1,1<<30,1)
    def test_direct_center_INT8_is_not_safe(self):
        a=np.array([127],np.int8)
        self.assertEqual(int(a.astype(np.int64)[0])-(-128),255)
        self.assertNotEqual(int((a.astype(np.int16)+128).astype(np.int8)[0]),255)
    def test_frozen_helpers_not_replaced(self):
        tile,chain,_,_=sources()
        a_helper=tile._k_major_a_bytes;b_helper=tile._k_major_b_bytes
        make_jobs(np.zeros((7,9),np.int8),np.zeros((9,3),np.int8))
        self.assertIs(a_helper,tile._k_major_a_bytes)
        self.assertIs(b_helper,tile._k_major_b_bytes)
        verify()
    def test_foreign_module_not_overwritten(self):
        import json
        original=sys.modules['json']
        with self.assertRaises(ValueError):load('json',ROOT/'frozen/reference.py')
        self.assertIs(sys.modules['json'],original)


if __name__=='__main__':unittest.main(verbosity=2)
