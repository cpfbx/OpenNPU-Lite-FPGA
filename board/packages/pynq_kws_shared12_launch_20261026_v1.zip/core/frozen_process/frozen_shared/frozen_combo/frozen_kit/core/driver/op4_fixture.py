"""TEST ONLY: original synthetic PYNQ/MMIO/DMA/proc/lock, CPU-computed replies.

No RTL simulation, no real PYNQ/device/lock; no real recovery certification.
"""
from contextlib import contextmanager
import gc,sys
from unittest.mock import patch
import op4_binding as binding
binding.configure(enabled=True)
fixture=binding.load('driver_fixture',binding.ROOT/'frozen_driver/driver_fixture.py')
import op4_runtime as reference

class Op4Harness(fixture.Harness):
    def __init__(self,*args,**kwargs):
        # Collect unreachable cyclic TEST fixtures; never mark a held owner closed
        # or bypass original rejection of a still-referenced active owner.
        gc.collect();super().__init__(*args,**kwargs)
    def set_case(self,case):
        # The fixture copies independently CPU-emulated tile bytes on fake START.
        # Avoid the original offline SoftwareTransport's intentional PYNQ refusal.
        tile=reference.sources()[0];jobs,_=reference.make_jobs(case['a'],case['weights'])
        self.engine.payload=b''.join(tile.emulate_transaction(job) for job in jobs)
    @contextmanager
    def resident(self,env):
        self.start(env)
        with patch.dict(sys.modules,{'pynq':self.fake}):
            reference.authorize_owner(self.owner)
            try:yield self
            finally:
                if not self.owner._held and not self.owner._closed:self.owner.close()
                self.discard_synthetic_hold()
FakeCanonicalEnvironment=fixture.FakeCanonicalEnvironment
