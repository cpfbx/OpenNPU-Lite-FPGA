"""Pinned offline modules only; no native/device libraries or global monkeypatch."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
SOURCE_SHA='2254e27316cb5303a406901a8e9c8aa1ce3c67fba3f4d6ff4c20a97cf61cc29c'


def require(ok,message):
    if not ok: raise ValueError(message)


def sha(raw): return hashlib.sha256(raw).hexdigest()


def verify():
    raw=(ROOT/'source_manifest.json').read_bytes()
    require(sha(raw)==SOURCE_SHA,'external source manifest pin')
    doc=json.loads(raw)
    frozen=ROOT/'frozen'
    require({p.relative_to(frozen).as_posix() for p in frozen.rglob('*') if p.is_file()}==set(doc['files']),'exact frozen member set')
    for n,s in doc['files'].items():
        p=frozen/n
        require(not p.is_symlink() and p.resolve().is_relative_to(frozen.resolve()),'plain source')
        b=p.read_bytes()
        require(len(b)==s['bytes'] and sha(b)==s['sha256'],'source drift '+n)
    require(sha((ROOT/'cpu420_original.tar.gz').read_bytes())==doc['cpu420_archive_sha256'],'CPU420 origin archive')
    return doc


def load(name,path):
    path=path.resolve()
    if name in sys.modules:
        require(Path(sys.modules[name].__file__).resolve()==path,'fresh process needed: cross-candidate import '+name)
        return sys.modules[name]
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    sys.modules[name]=mod
    spec.loader.exec_module(mod)
    return mod


def sources():
    verify()
    f=ROOT/'frozen'
    tile=load('tiled_gemm',f/'tiled_gemm.py')
    chain=load('chain_protocol',f/'chain_protocol.py')
    counter=load('_pointwise_counter',f/'d007_mode11_contract.py')
    ref=load('_pointwise_reference',f/'reference.py')
    require(not any(x in sys.modules for x in ('pynq','tensorflow','tflite_runtime')),'offline modules only')
    return tile,chain,counter,ref
