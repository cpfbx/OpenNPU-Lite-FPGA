# Operator 4 固定 12 窗薄交付候选 v1

此包当前仅完成离线准备，等待独立审查；不是实板激活授权。仅 bx 可执行以后另行批准的实板操作。不得把包装检查通过当作 ARM、PL/DMA、420 窗质量、全模型或性能/能量验收。

core 清单 SHA256：`ea75b9e112bc2e22df7acbf5a507d9ef4bfa34774794987138b0217b8a56c84a`；201 个原文件不变，绑定 Operator 4、输入 tensor 25、输出 tensor 26，固定窗 `0/30/60/90/120/150/180/210/240/270/300/400`。保留前驱 depthwise3；只测该 pointwise 层。每窗 2 job、8,000 输出，总 24 job、6,144,000 MAC，raw/校正/INT8 各 96,000 值。原 owner、数学、计数、FFFF 精确哨兵、监督、锁及默认均不改。

## 运行前条件

独审通过后，再由 bx 确认精确套件和本次现场范围。需核对 UTC、原单板/镜像、空闲与接线，并用新预检绑定真实 boot、既有规范锁 inode 和 venv/Python/NumPy 指纹。沿用 `/tmp/opennpu-kws-chain.lock`，缺失或异常即停止；本入口不创建、修理或替换锁。若缺锁，另外按已冻结 bootstrap 的精确身份、范围与用户确认准备，不能用 touch 或另换锁绕过。

请把 kit 解至新建 `/tmp/op4pointwise12_kit_XXXXXXXX`，工作与预检放在 `/home/xilinx/jupyter_notebooks/` 下新目录。输出不能位于 kit 内，也不能是 kit 的祖先目录。不要将 kit 解在输出 evidence-parent 下：包/数据分开可避免此前已遇到的祖先路径拒绝。

以下为 CLI 接口说明，**不是当前现场可直接运行的批准脚本**。`KIT_SHA` 必须来自本次发布身份；路径/pin 由后续现场回件确定，不能填历史 boot/inode 或示例 SHA。

```text
python3 -I -B <kit>/pointwise.py --kit-manifest-sha KIT_SHA check
python3 -I -B <kit>/pointwise.py --kit-manifest-sha KIT_SHA preflight --output <new-preflight.json> --enable-readonly-probe
python3 -I -B <kit>/pointwise.py --kit-manifest-sha KIT_SHA prepare --preflight <preflight.json> --preflight-sha PREFLIGHT_SHA --evidence-parent <existing-parent> --board-declaration <bounded-declaration> --prepare-data-only
python3 -I -B <kit>/pointwise.py --kit-manifest-sha KIT_SHA inspect-plan --work <work> --plan-sha PLAN_SHA
bash <kit>/run_board.sh KIT_SHA <work> PLAN_SHA --enable-board-candidate
```

`check` 只核字节；`preflight` 需要 `PROBEONLY`，读取环境与 lstat/释放记录，不取锁或证明空闲；`prepare` 需要 `PREPARE_OP4POINTWISE12`，只生成 plan/request；`run` 需显式开关与 **`OP4POINTWISE12`**，确认前后重核环境，唯一调用原 parent。没有隧道或 UT70 依赖。本层正确性测试不采能量、不另跑推理质量或预热。

所有实际运行都用新 work。Bash 先验 plan、再独占创建 `shell_attempt.txt`；Python 独占写 invocation，然后原 parent 私有派发。失败目录保留，原 work 不可再次启动。`launcher_exit.txt` 仅在 Python 实际返回后由 shell 写入；它是操作者记录，不是来源认证。断线或长时间等待先查原进程和证据，不自动重试/强杀、重启或删锁。

协作停止接口为 `stop --work ... --plan-sha ... --cooperative-only`，确认 `STOPONLY` 后只写原证据目录的 `stop.flag`，不承诺已退出或锁已释放。若原监督处于不确定资源状态，仍按已审无限 hold 合同保留给人类处置，本轮离线未验证真实无限 hold。

## 回件

```text
python3 -I -B <kit>/pointwise.py --kit-manifest-sha KIT_SHA readback --work <work-or-relocated-work> --plan-sha PLAN_SHA --output <new-report.json>
python3 -I -B <kit>/pointwise.py --kit-manifest-sha KIT_SHA archive --work <work> --plan-sha PLAN_SHA --export-parent <parent-outside-work>
```

readback 只读已有证据，拒绝夹具/注入、非零 shell wait、缺发布标记、串层、计数/数值/正常清理不符；不访问实时规范锁、不重推理。离线证据自洽不等于来源认证。失败且 shell 已返回时，archive 的 `--preserve-only` 只保全，不接受数值或证明资源已安全清理。归档读回前后核文件哈希，原件不覆盖。

`transfer_windows.ps1` 由 bx 在 Windows PowerShell 运行，只有 Upload/Download 两种显式模式。上传只作远端新路径不存在检查及 scp；下载仅限此包归档路径并核 SHA，不远程运行准备或测试。上传/下载与测量时序都由操作者安排。脚本不会更改 ExecutionPolicy；如系统阻止执行，停止并报告，不自动绕过策略。板端 Bash 与 Windows PowerShell 不可互相粘贴。
