"""44 distinct offline adapter methods. Every device/lock boundary is synthetic."""
from contextlib import contextmanager
from dataclasses import FrozenInstanceError,replace
import copy,sys,unittest
from pathlib import Path
from types import ModuleType
from unittest.mock import patch
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import op4_binding as binding
deps=binding.configure(enabled=True)
from op4_driver_call import Op4DriverCall,DriverFailure
from op4_candidate import InputEnvelope,input_for
from op4_fixture import Op4Harness,FakeCanonicalEnvironment
import op4_runtime as reference
import pointwise_driver_call as original_call
import runtime_reference as original_reference
from batch_policy import BatchStop

class Op4DriverTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.case=reference.derive(0);cls.other=reference.derive(30)
    @contextmanager
    def started(self,**options):
        h=Op4Harness(self.case,**options);env=FakeCanonicalEnvironment()
        with env.install(),h.resident(env):yield h,env
    def call(self,h,case=None):return Op4DriverCall(h.owner,self.case if case is None else case,enabled=True)
    def reject_input(self,change,pattern):
        with self.started() as (h,env):
            call=self.call(h);envelope=change(input_for(self.case))
            with patch.object(original_call,'make_jobs',side_effect=AssertionError('job construction reached')) as jobs:
                with self.assertRaisesRegex(ValueError,pattern):call(envelope)
            self.assertEqual(jobs.call_count,0);self.assertFalse(any(e[0]=='transfer' for e in h.events))
            self.assertIsInstance(call.first_failure,DriverFailure);self.assertFalse(call.accepted)
    def metric_fault(self,name,value):
        with self.started() as (h,env):
            run=h.owner._runner.run_chain
            def changed(*a,**kw):
                raw,records,metrics=run(*a,**kw);metrics=dict(metrics);metrics[name]=value;return raw,records,metrics
            h.owner._runner.run_chain=changed;call=self.call(h)
            with self.assertRaises(ValueError):call(input_for(self.case))
            self.assertFalse(call.accepted);self.assertEqual(len(call.first_failure.payload),32000)
    def test_01_binding_default_off(self):
        for value in (False,1,None,'yes'):
            with self.subTest(value=value),self.assertRaises(ValueError):binding.configure(enabled=value)
    def test_02_call_default_off(self):
        with self.started() as (h,e),self.assertRaises(ValueError):Op4DriverCall(h.owner,self.case)
    def test_03_no_software_transport_owner(self):
        with self.assertRaises(ValueError):Op4DriverCall(object(),self.case,enabled=True)
    def test_04_unchanged_submit_body_and_owner(self):
        import pynq_gemm,pointwise_owner,pointwise_policy
        self.assertIs(deps.runner_type._submit_chain,pynq_gemm.PynqGemm._submit_chain)
        self.assertIs(deps.owner_type,pointwise_owner.PointwiseOwner);self.assertIs(deps.policy_type,pointwise_policy.PointwisePolicy)
        self.assertEqual([deps.policy_type(True).request(i).first_job_id for i in range(12)],list(range(1,24,2)))
    def test_05_real_driver_body_called_with_operator4(self):
        with self.started() as (h,e):
            with patch.object(original_call.PointwiseDriverCall,'__call__',autospec=True,return_value='BODY') as call:
                self.assertEqual(self.call(h)(input_for(self.case)),'BODY');self.assertTrue(np.array_equal(call.call_args.args[1],self.case['a']))
    def test_06_original_reference_globals_not_rebound(self):
        import layer_case,op4_candidate,source_bindings
        self.assertIs(layer_case.sources,source_bindings.sources);self.assertIs(op4_candidate.derive,layer_case.derive)
        self.assertIsNot(reference._clones['derive'],layer_case.derive)
        self.assertIs(reference._clones['derive'].__code__,layer_case.derive.__code__)
        self.assertIs(reference._clones['sealed_case'].__code__,op4_candidate.sealed_case.__code__)
    def test_07_full_correctness_raw_and_int8(self):
        with self.started() as (h,e):
            out,data=self.call(h)(input_for(self.case));self.assertTrue(np.array_equal(out,self.case['expected']))
            self.assertTrue(np.array_equal(data['raw'],self.case['a'].astype(np.int64)@self.case['weights'].astype(np.int64)))
            self.assertEqual(data['driver_metrics']['failed_tile_index'],65535)
    def test_08_recv_before_send_two_transfers(self):
        with self.started() as (h,e):
            self.call(h)(input_for(self.case));self.assertEqual([x for x in h.events if x[0]=='transfer'],[('transfer','recv',32000),('transfer','send',16512)])
    def test_09_owner_case_wrong_window(self):
        with self.started() as (h,e),self.assertRaisesRegex(ValueError,'scheduled operator4 window'):self.call(h,self.other)
    def test_10_operator2_case_rejected(self):
        old=original_reference.derive(0)
        with self.started() as (h,e),self.assertRaises(ValueError):self.call(h,old)
    def test_11_forged_expected_rejected(self):
        case=copy.deepcopy(self.case);case['expected'][0,0]^=np.int8(1)
        with self.started() as (h,e),self.assertRaisesRegex(ValueError,'expected'):self.call(h,case)
    def test_12_wrong_parameters_rejected(self):
        for name in ('weights','bias','scales'):
            case=copy.deepcopy(self.case);case[name].flat[0]+=1
            with self.subTest(field=name),self.started() as (h,e),self.assertRaisesRegex(ValueError,name):self.call(h,case)
    def test_13_extra_case_fields_rejected(self):
        with self.started() as (h,e),self.assertRaisesRegex(ValueError,'exact case fields'):self.call(h,dict(self.case,extra=True))
    def test_14_sealed_readonly_detached_arrays(self):
        with self.started() as (h,e):
            call=self.call(h);self.assertEqual(type(call.case).__name__,'mappingproxy')
            for name in ('a','weights','bias','scales','expected'):
                self.assertFalse(call.case[name].flags.writeable);self.assertFalse(np.shares_memory(call.case[name],self.case[name]))
    def test_15_exact_envelope_type(self):
        class Derived(InputEnvelope):pass
        self.reject_input(lambda x:Derived(**vars(x)),'exact operator4 input envelope')
    def test_16_cross_layer_operator2_rejected_before_jobs(self):self.reject_input(lambda x:replace(x,operator_index=2,tensor_index=23),'input layer identity')
    def test_17_skipped_depthwise_tensor24_rejected(self):self.reject_input(lambda x:replace(x,tensor_index=24),'input layer identity')
    def test_18_operator6_rejected(self):self.reject_input(lambda x:replace(x,operator_index=6,tensor_index=27),'input layer identity')
    def test_19_cross_window_rejected(self):self.reject_input(lambda x:input_for(self.other),'input window identity')
    def test_20_boolean_index_rejected(self):self.reject_input(lambda x:replace(x,cohort_index=False),'input window identity')
    def test_21_source_id_and_feature_hash_rejected(self):
        for name in ('source_id','feature_sha256'):
            with self.subTest(field=name):self.reject_input(lambda x:replace(x,**{name:'wrong'}),'input window identity')
    def test_22_nonowning_and_wrong_dtype_rejected(self):
        for make in (lambda a:a.view(),lambda a:a.astype(np.int32),lambda a:np.asfortranarray(a),lambda a:a[::-1]):
            self.reject_input(lambda x:replace(x,values=make(x.values)),'exact owning operator4 input bytes')
    def test_23_input_bit_rejected_before_jobs(self):
        def changed(x):
            x.values[0,0]^=np.int8(1);return x
        self.reject_input(changed,'exact owning operator4 input bytes')
    def test_24_success_one_shot(self):
        with self.started() as (h,e):
            call=self.call(h);call(input_for(self.case));n=len(h.events)
            with self.assertRaises(ValueError):call(input_for(self.case))
            self.assertEqual(len(h.events),n)
    def test_25_input_failure_one_shot_immutable_first(self):
        with self.started() as (h,e):
            call=self.call(h)
            with self.assertRaises(ValueError):call(replace(input_for(self.case),tensor_index=24))
            first=call.first_failure
            with self.assertRaises(ValueError):call(input_for(self.case))
            self.assertIs(first,call.first_failure)
            with self.assertRaises(FrozenInstanceError):first.payload=b'fake'
    def test_26_raw_bit_masked_by_relu_rejected(self):
        with self.started() as (h,e):
            call=self.call(h);raw=h.engine.payload;h.engine.payload=bytes([raw[0]^1])+raw[1:]
            with self.assertRaisesRegex(ValueError,'all raw INT32'):call(input_for(self.case))
            self.assertEqual(call.first_failure.stage,'raw_int32');self.assertEqual(len(call.first_failure.payload),32000)
            first=call.first_failure;n=len(h.events)
            with self.assertRaises(ValueError):call(input_for(self.case))
            self.assertIs(first,call.first_failure);self.assertEqual(n,len(h.events))
    def test_27_exact_ffff_sentinel(self):
        for value in (0,1,0xffffffff,True):
            with self.subTest(value=value):self.metric_fault('failed_tile_index',value)
    def test_28_boolean_counter_rejected(self):self.metric_fault('jobs',True)
    def test_29_conservation_rejected(self):self.metric_fault('pl_work_union_cycles',99)
    def test_30_synthetic_tag_rejected(self):self.metric_fault('counter_evidence','SYNTHETIC-SOFTWARE-FIXTURE-NOT-PL')
    def test_31_wrong_read_strategy_rejected(self):self.metric_fault('mode11_counter_read_strategy','other')
    def test_32_nonfinite_seconds_rejected(self):self.metric_fault('seconds',float('nan'))
    def test_33_swapped_records_retained(self):
        with self.started() as (h,e):
            run=h.owner._runner.run_chain
            def swapped(*a,**k):
                b,r,m=run(*a,**k);return b,list(reversed(r)),m
            h.owner._runner.run_chain=swapped;call=self.call(h)
            with self.assertRaises(ValueError):call(input_for(self.case))
            self.assertEqual(len(call.first_failure.payload),32000);self.assertEqual(call.first_failure.stage,'return_records')
    def test_34_oversize_payload_not_retained(self):
        with self.started() as (h,e):
            run=h.owner._runner.run_chain
            def oversize(*a,**k):
                b,r,m=run(*a,**k);return b+b'\0',r,m
            h.owner._runner.run_chain=oversize;call=self.call(h)
            with self.assertRaises(ValueError):call(input_for(self.case))
            self.assertIsNone(call.first_failure.payload)
    def test_35_stop_before_construction(self):
        with self.started() as (h,e):
            call=self.call(h);h.stop=True
            with self.assertRaises(BatchStop):call(input_for(self.case))
            self.assertEqual(call.first_failure.stage,'before_construction');self.assertIsNone(call.first_failure.payload)
    def test_36_stop_before_submit(self):
        with self.started() as (h,e):
            call=self.call(h);make=original_call.make_jobs
            def stop(*a):
                result=make(*a);h.stop=True;return result
            with patch.object(original_call,'make_jobs',side_effect=stop),self.assertRaises(BatchStop):call(input_for(self.case))
            self.assertFalse(any(x[0]=='transfer' for x in h.events));self.assertFalse(call.accepted)
    def test_37_stop_after_return_before_accept(self):
        with self.started() as (h,e):
            call=self.call(h);h.after_submit=lambda unused:setattr(h,'stop',True)
            with self.assertRaises(BatchStop):call(input_for(self.case))
            self.assertEqual(call.first_failure.stage,'stop_pending');self.assertEqual(len(call.first_failure.payload),32000);self.assertFalse(call.accepted)
    def test_38_driver_crash_holds_no_fabricated_payload(self):
        with self.started() as (h,e):
            h.owner._runner.run_chain=lambda *a,**k:(_ for _ in ()).throw(RuntimeError('synthetic crash'))
            call=self.call(h)
            with self.assertRaises(RuntimeError):call(input_for(self.case))
            self.assertTrue(h.owner._held and h.owner._unsafe);self.assertIsNone(call.first_failure.payload)
    def test_39_cold_bind_refuses_pynq(self):
        with patch.dict(sys.modules,{'pynq':ModuleType('pynq')}),self.assertRaisesRegex(ValueError,'cold'):binding.configure(enabled=True)
    def test_40_forbidden_engine_submodule_rejected(self):
        for name in ('tensorflow.lite','tflite_runtime.interpreter'):
            with self.subTest(module=name),patch.dict(sys.modules,{name:ModuleType(name)}),self.assertRaises(ValueError):reference.sources()
    def test_41_foreign_reference_module_rejected(self):
        fake=ModuleType('layer_case');fake.__file__='/foreign/layer_case.py'
        with patch.dict(sys.modules,{'layer_case':fake}),self.assertRaises(ValueError):reference.sources()
    def test_42_pynq_object_replacement_rejected(self):
        with self.started() as (h,e),patch.dict(sys.modules,{'pynq':ModuleType('pynq')}),self.assertRaises(ValueError):reference.sources()
    def test_43_resident_derive_constructor_and_execution_sequence(self):
        with self.started() as (h,e):
            case=reference.derive(0);call=self.call(h,case);out,_=call(input_for(case))
            self.assertIs(sys.modules['pynq'],h.fake);self.assertTrue(np.array_equal(out,case['expected']))
    def test_44_original_offline_sources_still_refuse_resident_pynq(self):
        import source_bindings
        with self.started() as (h,e):
            with self.assertRaisesRegex(ValueError,'CPU-only modules'):source_bindings.sources()
            self.assertEqual(reference.sources()[0].__name__,'tiled_gemm')

if __name__=='__main__':unittest.main(verbosity=2)
