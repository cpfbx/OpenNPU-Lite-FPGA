"""Pinned internal runtime selection. Import/check never constructs hardware."""
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import sys
ROOT=Path(__file__).resolve().parent
CATALOG_SHA='a72485788f9f80cdf72fbc728ad3a876450ab71777becf7c57c4e398059f080e'
DRIVER_SHA='326ba2b818800d61f13357a92490255210f64a91007ab7ccae021a5d22223014'
def require(ok,why):
    if not ok:raise ValueError(why)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def inventory(root):
    result={}
    for p in sorted(root.rglob('*')):
        require(not p.is_symlink() and not getattr(p,'is_junction',lambda:False)(),'no aliased members')
        if p.is_file():
            b=p.read_bytes();result[p.relative_to(root).as_posix()]=dict(bytes=len(b),sha256=sha(b))
    return result
def verify_sources():
    raw=(ROOT/'source_catalog.json').read_bytes();require(sha(raw)==CATALOG_SHA,'source catalog pin')
    d=json.loads(raw);raw=(ROOT/'driver/candidate_manifest.json').read_bytes()
    require(sha(raw)==DRIVER_SHA,'reviewed driver pin')
    pins=json.loads(raw)['files'];actual=inventory(ROOT/'driver')
    require(set(actual)==set(pins)|{'candidate_manifest.json'} and all(actual[n]==p for n,p in pins.items()),'reviewed driver unchanged')
    require(inventory(ROOT/'frozen_control')=={n:{k:v[k] for k in ('bytes','sha256')} for n,v in d['extra_control_files'].items()},'original control sources')
    expected={n:p for row in d['golden_bank'] for n,p in row['artifacts'].items()}
    require({'golden/'+n:p for n,p in inventory(ROOT/'golden').items()}==expected,'reviewed golden bytes')
    require(all(type(d.get(k)) is int and d[k]==v for k,v in {'operator_index':4,'input_tensor':25,'output_tensor':26}.items()),'operator4 source catalog identity')
    require([r['cohort_index'] for r in d['golden_bank']]==[0,30,60,90,120,150,180,210,240,270,300,400]
        and all(type(r.get(k)) is int and r[k]==v for r in d['golden_bank'] for k,v in {'operator_index':4,'input_tensor':25,'output_tensor':26}.items()),'operator4 golden bank identity')
    return d
def verify_candidate(pin):
    raw=(ROOT/'candidate_manifest.json').read_bytes();require(sha(raw)==pin,'external runtime candidate pin')
    pins=json.loads(raw)['files'];actual=inventory(ROOT)
    require(set(actual)==set(pins)|{'candidate_manifest.json'} and all(actual[n]==p for n,p in pins.items()),'runtime source drift')
    verify_sources();return actual
def load(name,path):
    path=path.resolve()
    if name in sys.modules:
        require(Path(getattr(sys.modules[name],'__file__','')).resolve()==path,'cross-candidate import '+name)
        return sys.modules[name]
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module;spec.loader.exec_module(module);return module
def configure():
    verify_sources()
    load('failure_diagnostic',ROOT/'failure_diagnostic.py')
    op4=load('op4_binding',ROOT/'driver/op4_binding.py');op4.configure(enabled=True)
    a=sys.modules['adapter_binding'];deps=a.select(enabled=True)
    load('op4_driver_call',ROOT/'driver/op4_driver_call.py')
    for name in ('fpga_evidence','process_observer'):load(name,ROOT/'frozen_control'/(name+'.py'))
    # Preserve the exact reviewed owner/runner/supervisor factories. Only the
    # worker's operator-specific reference/call selection changes.
    from types import SimpleNamespace
    def selected(*,enabled=False):
        require(enabled is True,'process component selection default-off');return deps
    return SimpleNamespace(select=selected)

def select():
    return configure().select(enabled=True)
def require_arm():
    require(platform.system()=='Linux' and platform.machine()=='armv7l' and sys.byteorder=='little'
        and platform.release()=='6.6.10-xilinx-v2024.1-g3c0eca68c652','original ARM Linux only; no PC fallback')
    require(sys.version_info[:3]==(3,10,4),'original ARM Python 3.10.4 required')
    import numpy as np
    require(np.__version__=='1.21.5','original ARM NumPy 1.21.5 required')
def require_boot(expected):
    require(Path('/proc/sys/kernel/random/boot_id').read_text(encoding='ascii').strip()==expected,'boot identity changed')

if __name__=='__main__':raise SystemExit('Check/import library only; no activation authority.')
