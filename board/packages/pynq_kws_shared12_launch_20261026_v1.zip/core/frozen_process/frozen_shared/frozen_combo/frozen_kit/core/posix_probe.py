"""Local x86 Linux stdlib-only wait/group + TEMPORARY lock evidence probe.

NEVER opens the board canonical lock. The only lock-path substitution is in
this isolated test process and is reported as injected TEMP fixture identity.
"""
import argparse
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import time
sys.path.insert(0,str(Path(__file__).resolve().parent))
import runtime_binding as rb

class Guardian:
    held=False
    def _hold(self,error):self.held=True
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    rb.require(platform.system()=='Linux' and platform.machine().lower() in ('x86_64','amd64'),'local x86 Linux only')
    rb.require(not a.output.exists(),'fresh local probe output')
    original=rb.ROOT/'driver/frozen_driver/frozen_hw/legacy/frozen_source'
    rb.load('os_evidence',original/'os_evidence.py')
    observer=rb.load('process_observer',rb.ROOT/'frozen_control/process_observer.py')
    evidence=rb.load('fpga_evidence',rb.ROOT/'frozen_control/fpga_evidence.py')
    temp=Path(tempfile.mkdtemp(prefix='opennpu_local_posix_probe_')).resolve()
    rb.require(temp.parent==Path('/tmp') and temp.name.startswith('opennpu_local_posix_probe_'),'bounded own temporary directory')
    lock=temp/'LOCAL_FIXTURE.lock';lock.write_bytes(b'')
    evidence.LOCK=str(lock)  # TEST PROCESS ONLY, never production or canonical path.
    rb.require(str(lock)!='/tmp/opennpu-kws-chain.lock','never canonical board lock')
    child_code="""
import fcntl,json,os,sys,time
from pathlib import Path
root=Path(sys.argv[1]);lock=root/'LOCAL_FIXTURE.lock'
fd=os.open(str(lock),os.O_RDONLY|os.O_CLOEXEC)
try:
 fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
 raw=Path('/proc/self/stat').read_text();start=int(raw[raw.rfind(')')+1:].split()[19])
 s=os.fstat(fd)
 ready=dict(pid=os.getpid(),fd=fd,device=s.st_dev,inode=s.st_ino,process_start_ticks=start,path=str(lock))
 (root/'ready.json').write_text(json.dumps(ready));(root/'ready.complete').write_bytes(b'')
 deadline=time.monotonic()+10
 while not (root/'release.flag').exists():
  if time.monotonic()>deadline:raise RuntimeError('bounded LOCAL fixture release wait expired')
  time.sleep(.02)
finally:os.close(fd)
"""
    before=evidence.snapshot();events=[];error=None;record={}
    child=subprocess.Popen([sys.executable,'-I','-B','-c',child_code,str(temp)],stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=True,start_new_session=True)
    try:
        until=time.monotonic()+5
        while not (temp/'ready.complete').exists():
            rb.require(time.monotonic()<until,'local fixture readiness deadline');time.sleep(.02)
        ticket=json.loads((temp/'ready.json').read_bytes())
        rb.require(evidence.verify_live(ticket,child.pid,before) is True,'real local proc/fdinfo live proof')
        try:evidence.released(before);raise AssertionError('held local FLOCK was not detected')
        except RuntimeError:record['held_lock_rejected']=True
        record['live_original_fdinfo_verified']=True
    except BaseException as e:error=e
    finally:
        (temp/'release.flag').touch(exist_ok=False)
        guardian=Guardian();wait=observer.observe_exit(child,guardian,lambda:False,lambda:None)
        out,err=child.communicate();(temp/'child.stdout').write_bytes(out);(temp/'child.stderr').write_bytes(err)
        record['wait']=wait
    if error is None:
        rb.require(wait['actual_exit_code']==0 and wait['group_query_injected'] is False and wait['process_group_absent'] is True,'actual local child exit/group')
        record['same_inode_release']=evidence.released(before)
        # Only our disposable fixture inode changes, never the board lock.
        lock.rename(temp/'retired_LOCAL_FIXTURE.lock');lock.write_bytes(b'')
        try:evidence.released(before);raise AssertionError('changed inode accepted')
        except RuntimeError:record['changed_inode_rejected']=True
        failed=subprocess.Popen([sys.executable,'-I','-B','-c','raise SystemExit(7)'],stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,close_fds=True,start_new_session=True)
        record['nonzero_wait']=observer.observe_exit(failed,Guardian(),lambda:False,lambda:None)
        rb.require(record['nonzero_wait']['actual_exit_code']==7,'nonzero actual wait not inferred success')
    record.update(operation_success=error is None,scope='LOCAL x86 Linux real OS probe; temporary lock-path injection only',
        temporary_directory=str(temp),canonical_board_lock_access=False,hardware_access=False,
        real_process_wait=True,real_process_group_query=True,real_tempfile_FLOCK=True,
        lock_path_injected=True,ARM_tested=False,run_ready=False,promotion=False,
        error_type=None if error is None else type(error).__name__)
    a.output.parent.mkdir(parents=True,exist_ok=True)
    with a.output.open('x',encoding='utf-8') as f:f.write(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record))
    return 0 if error is None else 1
if __name__=='__main__':raise SystemExit(main())
