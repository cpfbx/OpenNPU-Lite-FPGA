"""Explicitly enabled PC-only fixed12 operator4 synthetic-driver regression."""
import argparse,json,os,struct,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import op4_binding as binding

def save(path,raw):
    with path.open('xb') as stream:stream.write(raw)
    return dict(bytes=len(raw),sha256=binding.sha(raw))

def normalized_wire(wire,first_id):
    binding.need(type(wire) is bytes and len(wire)==16512 and type(first_id) is int and first_id in range(1,24,2),'fixed wire extent/ID')
    raw=bytearray(wire)
    for i,offset in enumerate((8,8264)):
        binding.need(struct.unpack_from('<I',wire,offset)[0]==first_id+i,'scheduled header job ID')
        struct.pack_into('<I',raw,offset,i+1)
    return bytes(raw)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate-sha',required=True);parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--enable-offline-candidate',action='store_true');parser.add_argument('--inject-raw-bit-window',type=int)
    args=parser.parse_args();binding.need(args.enable_offline_candidate is True,'offline driver fixture default-off')
    binding.verify_candidate(args.candidate_sha)
    output=args.output.absolute();binding.need(output.resolve()==output and not os.path.lexists(output)
        and not output.is_relative_to(binding.ROOT) and not binding.ROOT.is_relative_to(output),'fresh output outside immutable candidate')
    binding.need(args.inject_raw_bit_window is None or args.inject_raw_bit_window==90,'only planned window90 raw-bit fault')
    before=binding.inventory(binding.ROOT);deps=binding.configure(enabled=True)
    import op4_runtime as reference
    from op4_candidate import input_for
    from op4_driver_call import Op4DriverCall
    from op4_fixture import Op4Harness,FakeCanonicalEnvironment
    from independent_math import check
    from layer_case import INDICES
    output.mkdir(parents=True);rows=[];failure=None;active=None;call=None
    case0=reference.derive(0);h=Op4Harness(case0);env=FakeCanonicalEnvironment()
    with env.install(),h.resident(env):
        for active in INDICES:
            try:
                # All these paths run with the same fake PYNQ resident, matching
                # the ordering which previously failed only after owner.start().
                case=reference.derive(active);h.set_case(case)
                call=Op4DriverCall(h.owner,case,enabled=True)
                if active==args.inject_raw_bit_window:
                    payload=h.engine.payload;h.engine.payload=bytes([payload[0]^1])+payload[1:]
                out,data=call(input_for(case))
                raw64,centered,scalar=check(case,normalized_wire(data['input_chain'],call.spec.first_job_id),data['raw'],data['corrected'],out)
                artifacts={'pointwise_input.i8':case['a'].tobytes(),'weights_kn.i8':case['weights'].tobytes(),
                    'bias.i32':case['bias'].astype('<i4').tobytes(),'scales.f64':case['scales'].astype('<f8').tobytes(),
                    'request_chain.bin':data['input_chain'],'reply_tile_order.bin':data['reply_tile_order'],
                    'raw_output.i32':data['raw'].astype('<i4').tobytes(),'raw_oracle.i64':raw64.astype('<i8').tobytes(),
                    'corrected.i32':data['corrected'].astype('<i4').tobytes(),'centered_oracle.i64':centered.astype('<i8').tobytes(),
                    'candidate_output.i8':out.tobytes(),'expected_output.i8':case['expected'].tobytes(),'scalar_output.i8':scalar.tobytes()}
                folder=output/('window_%03d'%active);folder.mkdir()
                row=dict(cohort_index=active,operator_index=4,input_tensor=25,output_tensor=26,source_id=case['source_id'],
                    feature_sha256=case['feature_sha256'],prefix_tensors_checked=case['prefix_tensors_checked'],
                    selected_CPU_logits_checked=case['selected_CPU_logits_checked'],first_job_id=call.spec.first_job_id,
                    fake_mmio_driver_metrics=data['driver_metrics'],fixture=True,
                    artifacts={name:save(folder/name,raw) for name,raw in artifacts.items()})
                save(folder/'result.json',(json.dumps(row,sort_keys=True,indent=2)+'\n').encode());rows.append(row)
                print('WINDOW',active,'operator4 8000 raw/PS/INT8; fake PYNQ resident',flush=True)
            except Exception as error:
                first=None if call is None else call.first_failure
                failure=dict(cohort_index=active,error_type=type(error).__name__,stage=None if first is None else first.stage,automatic_retry=False)
                if first is not None:
                    if first.payload is not None:failure['payload']=save(output/'first_failure_tile_order.bin',first.payload)
                    if first.return_diagnostic_json is not None:save(output/'return_diagnostic.json',first.return_diagnostic_json)
                break
    binding.need(h.owner._closed and not env.held and not env.fd_live,'synthetic normal cleanup')
    unchanged=binding.inventory(binding.ROOT)==before
    transfers=[event for event in h.events if event[0]=='transfer'];submissions=len(transfers)//2
    binding.need(transfers==[('transfer','recv',32000),('transfer','send',16512)]*submissions,'exact fake DMA transfer order')
    ok=failure is None and len(rows)==12 and unchanged
    record=dict(operation_success=ok,candidate_sha256=args.candidate_sha,selected_indices=list(INDICES),
        completed_indices=[r['cohort_index'] for r in rows],not_completed_indices=list(INDICES[len(rows):]),windows=rows,failure=failure,
        successful_fixture_calls=len(rows),total_fixture_submissions=submissions,synthetic_transfer_calls=len(transfers),
        raw_values=8000*len(rows),corrected_values=8000*len(rows),INT8_values=8000*len(rows),
        synthetic_cleanup=h.owner.cleanup_readback,input_files_unchanged=unchanged,
        scope='operator4 fixed12 PC synthetic driver/PYNQ/MMIO/DMA/proc/lock; NOT board or RTL',
        counters_synthetic=True,normal_cleanup_synthetic=True,real_PYNQ_imported=False,real_board_access=False,
        real_lock_access=False,real_DMA_executed=False,PL_simulated=False,ARM_tested=False,
        classification_quality_evaluated=False,performance_evaluated=False,energy_evaluated=False,
        automatic_retry=False,board_activation_approved=False,run_ready=False,promotion=False)
    save(output/'result.json',(json.dumps(record,indent=2,sort_keys=True)+'\n').encode())
    print(json.dumps({k:v for k,v in record.items() if k not in ('windows','synthetic_cleanup')}));return 0 if ok else 1

if __name__=='__main__':
    try:raise SystemExit(main())
    except (ValueError,OSError) as error:print(type(error).__name__+': '+str(error),file=sys.stderr);raise SystemExit(2)
