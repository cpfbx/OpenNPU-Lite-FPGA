"""TEST ONLY x86 child. Always fake PYNQ/lock; cannot act as ARM board entry."""
import argparse
import os
from pathlib import Path
import platform
import sys
import time
sys.path.insert(0,str(Path(__file__).resolve().parent))
import runtime_binding as rb
import runtime_contract as ct
def main():
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('request','request-sha','launch','launch-sha','folder'):p.add_argument('--'+n,required=True)
    p.add_argument('--enabled-PC-fixture',action='store_true');p.add_argument('--fault-index',type=int,choices=[90])
    a=p.parse_args();rb.require(a.enabled_PC_fixture is True,'explicit PC fixture only')
    rb.require(platform.machine().lower() in ('amd64','x86_64','x86','i386','i686'),'x86 fixture child only, never ARM')
    req=ct.read_request(a.request,a.request_sha)
    rb.require(req['board_declaration']=='SYNTHETIC-PC-NOT-A-BOARD','never a physical board request')
    raw=ct.read(a.launch,30000);rb.require(rb.sha(raw)==a.launch_sha,'fixture launch pin')
    binding=ct.strict_json(raw);deadline=time.monotonic()+120
    from process_fixture import synthetic_worker
    # This bound belongs ONLY to a fake-resource PC test. Production worker has
    # no timeout-release mechanism, and remains under the frozen supervisor.
    result,h=synthetic_worker(req,a.request_sha,ct.canonical(a.folder),bad_window=a.fault_index,
        handshake=True,launch_value=binding,parent_alive=lambda:os.getppid()==binding['parent_pid'] and time.monotonic()<deadline)
    return 0 if result['operation_success'] is True else 1
if __name__=='__main__':raise SystemExit(main())
