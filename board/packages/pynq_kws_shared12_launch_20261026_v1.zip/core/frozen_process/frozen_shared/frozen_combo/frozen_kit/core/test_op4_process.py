"""32 distinct process-seam tests; all hardware and canonical locks are fake."""
import ast,copy,json,os,shutil,sys,tempfile,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parent))
import runtime_binding as rb
import runtime_contract as ct
rb.configure()
import pointwise_worker as worker
import pointwise_parent as parent
from driver_failure_bridge import read_first_failure
from op4_driver_call import Op4DriverCall,DriverFailure
from process_fixture import request,launch_binding,synthetic_worker,finite_fixture_supervise

class Op4ProcessTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory(prefix='op4_process_seams_');cls.root=Path(cls.temp.name).resolve()
        cls.req=request();cls.pin=ct.write_json(cls.root/'request.json',cls.req)['sha256'];cls.work=cls.root/'normal';cls.work.mkdir();cls.resident=[]
        def hook(case):cls.resident.append(('pynq' in sys.modules,case['spec'].operator_index,case['cohort_index']))
        cls.result,cls.h=synthetic_worker(cls.req,cls.pin,cls.work,case_hook=hook)
    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='op4_seam_case_');self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name).resolve()
    def clone(self):
        target=self.root/'worker';shutil.copytree(self.work,target);return target
    def save(self,path,value):path.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    def resign(self,folder):
        self.save(folder/'artifact_manifest.json',dict(files=ct.manifest(folder)))
        t=ct.ready_json(folder/'terminal.json');t['artifact_manifest_sha256']=rb.sha((folder/'artifact_manifest.json').read_bytes());self.save(folder/'terminal.json',t)
    def bad_row(self,mutate):
        folder=self.clone();row=ct.ready_json(folder/'window_000/result.json');mutate(row)
        self.save(folder/'window_000/result.json',row);t=ct.ready_json(folder/'terminal.json');t['windows'][0]=row;self.save(folder/'terminal.json',t);self.resign(folder);return folder
    def bare(self,first):
        call=object.__new__(Op4DriverCall);call.first_failure=first;return call
    def synthetic_fault(self,first,exception=ValueError('SECRET_DO_NOT_SERIALIZE')):
        folder=self.root/'fault_worker';folder.mkdir()
        def fail(call,envelope):call.first_failure=first;raise exception
        with patch.object(Op4DriverCall,'__call__',new=fail):result,h=synthetic_worker(request(),'b'*64,folder)
        self.assertFalse(result['operation_success']);self.assertEqual(result['accepted_calls'],0)
        raw=(folder/'fault.json').read_bytes()+(folder/'terminal.json').read_bytes()
        self.assertNotIn(b'SECRET_DO_NOT_SERIALIZE',raw)
        return folder,result
    def test_01_operator2_request_scope_rejected(self):
        req=request();req['scope']='fixed-twelve-single-operator-correctness-only'
        with self.assertRaisesRegex(ValueError,'fixed scope'):ct.validate_request(req)
    def test_02_normal_terminal_and_rows_bind_operator4(self):
        self.assertEqual((self.result['operator_index'],self.result['input_tensor'],self.result['output_tensor']),(4,25,26))
        for row in self.result['windows']:self.assertEqual((row['operator_index'],row['input_tensor'],row['output_tensor']),(4,25,26))
    def test_03_all_48_golden_files_are_from_reviewed_op4(self):
        archive=rb.ROOT.parent/'inputs/opennpu_kws_pointwise_op4_driver_call_v1_review.zip'
        with zipfile.ZipFile(archive) as z:
            for folder in (rb.ROOT/'golden').iterdir():
                for path in folder.iterdir():self.assertEqual(path.read_bytes(),z.read('author_validation_01/numerical/'+folder.name+'/'+path.name))
    def test_04_original_guardian_launch_and_validation_binding_AST(self):
        archive=rb.ROOT.parent/'inputs/pynq_kws_pointwise12_launch_20261024_v3.zip'
        with zipfile.ZipFile(archive) as z:
            for file,names in [('pointwise_parent.py',('Guardian','launch')),('pointwise_worker.py',('validate_launch',))]:
                original=ast.parse(z.read('core/'+file));actual=ast.parse((rb.ROOT/file).read_bytes())
                for name in names:
                    left=next(n for n in original.body if getattr(n,'name',None)==name);right=next(n for n in actual.body if getattr(n,'name',None)==name)
                    self.assertEqual(ast.dump(left),ast.dump(right))
            for file in ('fpga_evidence.py','process_observer.py'):
                self.assertEqual((rb.ROOT/'frozen_control'/file).read_bytes(),z.read('core/frozen_control/'+file))
    def test_05_failure_bridge_no_first_uses_only_bounded_payload(self):
        self.assertEqual(read_first_failure(None,b'x'*32000),(b'x'*32000,None))
        with self.assertRaises(ValueError):read_first_failure(None,b'x'*32001)
    def test_06_exact_immutable_failure_bridge(self):
        first=DriverFailure('raw_int32','ValueError',b'x'*32000)
        self.assertEqual(read_first_failure(self.bare(first),None),(b'x'*32000,None))
    def test_07_legacy_dictionary_failure_rejected(self):
        with self.assertRaisesRegex(ValueError,'exact immutable'):read_first_failure(self.bare({'payload':b'x','secret':'SECRET_DO_NOT_SERIALIZE'}),None)
    def test_08_oversize_failure_payload_rejected(self):
        with self.assertRaisesRegex(ValueError,'bounded driver failure payload'):read_first_failure(self.bare(DriverFailure('raw_int32','ValueError',b'x'*32001)),None)
    def test_09_nonbytes_payload_rejected(self):
        with self.assertRaisesRegex(ValueError,'bounded driver failure payload'):read_first_failure(self.bare(DriverFailure('raw_int32','ValueError',memoryview(b'x'))),None)
    def test_10_diagnostic_bound_rejected(self):
        with self.assertRaisesRegex(ValueError,'bounded ASCII'):read_first_failure(self.bare(DriverFailure('raw_int32','ValueError',None,b' '*8193)),None)
    def test_11_nonASCII_diagnostic_rejected(self):
        with self.assertRaisesRegex(ValueError,'bounded ASCII'):read_first_failure(self.bare(DriverFailure('raw_int32','ValueError',None,b'\xff')),None)
    def test_12_duplicate_diagnostic_keys_rejected(self):
        raw=b'{"check":"raw_int32","check":"secret","container_type":"missing","fields":{}}'
        with self.assertRaisesRegex(ValueError,'duplicate JSON key'):read_first_failure(self.bare(DriverFailure('raw_int32','ValueError',None,raw)),None)
    def test_13_unknown_diagnostic_field_rejected(self):
        raw=b'{"check":"raw_int32","container_type":"dict","fields":{"secret":"SECRET_DO_NOT_SERIALIZE"}}'
        with self.assertRaisesRegex(ValueError,'whitelisted'):read_first_failure(self.bare(DriverFailure('raw_int32','ValueError',None,raw)),None)
    def test_14_valid_missing_container_diagnostic(self):
        value=dict(check='not_returned',container_type='missing',fields={});raw=json.dumps(value).encode('ascii')
        self.assertEqual(read_first_failure(self.bare(DriverFailure('not_returned','ValueError',None,raw)),None),(None,value))
    def test_15_success_or_retry_failure_flags_rejected(self):
        for first in (DriverFailure('raw_int32','ValueError',None,accepted=True),DriverFailure('raw_int32','ValueError',None,automatic_retry=True)):
            with self.assertRaisesRegex(ValueError,'exact immutable'):read_first_failure(self.bare(first),None)
    def test_16_unknown_active_object_never_formatted(self):
        class Poison:
            def __repr__(self):raise AssertionError('repr must not run')
            def __str__(self):raise AssertionError('str must not run')
        with self.assertRaisesRegex(ValueError,'exact operator4 active'):read_first_failure(Poison(),None)
    def test_17_worker_bridge_preserves_raw_failure_and_diagnostic(self):
        folder=self.root/'bad';folder.mkdir();result,h=synthetic_worker(request(),'c'*64,folder,bad_window=0)
        fault=ct.ready_json(folder/'fault.json');self.assertEqual(fault['return_diagnostic']['check'],'raw_int32')
        self.assertEqual(fault['payload']['bytes'],32000);self.assertEqual(result['error_type'],'ValueError');self.assertEqual(result['secondary_error_types'],[])
    def test_18_worker_unknown_failure_object_is_safely_published(self):
        folder,result=self.synthetic_fault({'secret':'SECRET_DO_NOT_SERIALIZE','payload':b'unsafe'})
        fault=ct.ready_json(folder/'fault.json');self.assertIsNone(fault['payload']);self.assertIsNone(fault['return_diagnostic']);self.assertIn('ValueError',result['secondary_error_types'])
    def test_19_fault_publication_failure_preserves_primary_and_payload(self):
        folder=self.root/'bad';folder.mkdir();write=ct.write_json
        def failed(path,value):
            if Path(path).name=='fault.json':raise OSError('SECRET_DO_NOT_SERIALIZE')
            return write(path,value)
        with patch.object(ct,'write_json',side_effect=failed):result,h=synthetic_worker(request(),'d'*64,folder,bad_window=0)
        self.assertEqual(result['error_type'],'ValueError');self.assertIn('OSError',result['secondary_error_types']);self.assertEqual((folder/'first_failure_tile_order.bin').stat().st_size,32000)
        self.assertFalse((folder/'fault.json.ready').exists());self.assertNotIn(b'SECRET_DO_NOT_SERIALIZE',(folder/'terminal.json').read_bytes())
    def test_20_window_write_failure_preserves_returned_payload(self):
        folder=self.root/'partial';folder.mkdir();write=ct.write_bytes
        def failed(path,raw):
            if Path(path).name=='raw_output.i32':raise OSError('SECRET_DO_NOT_SERIALIZE')
            return write(path,raw)
        with patch.object(ct,'write_bytes',side_effect=failed):result,h=synthetic_worker(request(),'e'*64,folder)
        self.assertEqual(result['accepted_calls'],0);self.assertEqual(result['error_type'],'OSError');self.assertEqual(result['failure_stage'],'write_window_artifacts')
        self.assertEqual((folder/'first_failure_tile_order.bin').stat().st_size,32000);self.assertFalse((folder/'window_000/result.json.ready').exists())
    def test_21_resigned_operator2_terminal_identity_rejected(self):
        folder=self.clone();t=ct.ready_json(folder/'terminal.json');t['operator_index']=2;self.save(folder/'terminal.json',t)
        with self.assertRaisesRegex(ValueError,'terminal operator4 identity'):parent.validate_terminal(folder,os.getpid(),self.req,self.pin,True)
    def test_22_resigned_wrong_row_tensor_rejected(self):
        folder=self.bad_row(lambda row:row.update(input_tensor=23))
        with self.assertRaisesRegex(ValueError,'operator4 record'):parent.validate_terminal(folder,os.getpid(),self.req,self.pin,True)
    def test_23_resigned_operator2_raw_cannot_replace_operator4(self):
        archive=rb.ROOT.parent/'inputs/pynq_kws_pointwise12_launch_20261024_v3.zip'
        with zipfile.ZipFile(archive) as z:raw=z.read('core/golden/window_000/raw_output.i32')
        folder=self.clone();path=folder/'window_000/raw_output.i32';self.assertNotEqual(raw,path.read_bytes());path.write_bytes(raw)
        row=ct.ready_json(folder/'window_000/result.json');row['artifacts']['raw_output.i32']=dict(bytes=len(raw),sha256=rb.sha(raw));self.save(folder/'window_000/result.json',row)
        t=ct.ready_json(folder/'terminal.json');t['windows'][0]=row;self.save(folder/'terminal.json',t);self.resign(folder)
        with self.assertRaisesRegex(ValueError,'reviewed fixed golden'):parent.validate_terminal(folder,os.getpid(),self.req,self.pin,True)
    def test_24_parent_boolean_payload_counter_rejected(self):
        folder=self.bad_row(lambda row:row['driver_metrics'].update(input_payload_bytes=True))
        with self.assertRaisesRegex(ValueError,'parent counter contract'):parent.validate_terminal(folder,os.getpid(),self.req,self.pin,True)
    def test_25_parent_synthetic_transport_tag_rejected(self):
        folder=self.bad_row(lambda row:row['driver_metrics'].update(counter_evidence='SYNTHETIC'))
        with self.assertRaisesRegex(ValueError,'parent counter contract'):parent.validate_terminal(folder,os.getpid(),self.req,self.pin,True)
    def test_26_missing_ready_marker_not_complete(self):
        folder=self.clone();(folder/'terminal.json.ready').unlink()
        with self.assertRaisesRegex(ValueError,'completed child terminal'):parent.validate_terminal(folder,os.getpid(),self.req,self.pin,True)
    def test_27_catalog_tampering_is_not_layer_rebinding(self):
        target=self.root/'catalog_copy';target.mkdir();catalog=json.loads((rb.ROOT/'source_catalog.json').read_bytes());catalog['operator_index']=2;self.save(target/'source_catalog.json',catalog)
        with patch.object(rb,'ROOT',target),self.assertRaisesRegex(ValueError,'source catalog pin'):rb.verify_sources()
    def test_28_pynq_resident_during_all_twelve_windows(self):
        self.assertEqual(self.resident,[(True,4,index) for index in ct.INDICES])
        self.assertEqual([r['first_job_id'] for r in self.result['windows']],list(range(1,24,2)))
    def test_29_worker_oversize_failure_not_persisted(self):
        folder,result=self.synthetic_fault(DriverFailure('raw_int32','ValueError',b'x'*32001))
        self.assertFalse((folder/'first_failure_tile_order.bin').exists());self.assertIsNone(ct.ready_json(folder/'fault.json')['payload'])
    def test_30_worker_unwhitelisted_diagnostic_not_persisted(self):
        raw=b'{"check":"raw_int32","container_type":"dict","fields":{"secret":"SECRET_DO_NOT_SERIALIZE"}}'
        folder,result=self.synthetic_fault(DriverFailure('raw_int32','ValueError',b'x'*32000,raw))
        self.assertFalse((folder/'first_failure_tile_order.bin').exists());self.assertIsNone(ct.ready_json(folder/'fault.json')['return_diagnostic'])
    def test_31_uncertain_cleanup_has_no_completed_terminal(self):
        from pointwise_owner import PointwiseOwner
        folder=self.root/'uncertain';folder.mkdir()
        with patch.object(PointwiseOwner,'close',side_effect=OSError('TEST cleanup unknown')):
            with self.assertRaisesRegex(ValueError,'unresolved resources'):synthetic_worker(request(),'f'*64,folder,bad_window=0,supervise=finite_fixture_supervise)
        self.assertFalse((folder/'terminal.json').exists());self.assertTrue((folder/'attention_retained.json').exists())
    def test_32_parent_wrong_scope_rejected_before_spawn(self):
        req=request();req['scope']='fixed-twelve-single-operator-correctness-only';path=self.root/'old_scope.json';pin=ct.write_json(path,req)['sha256'];spawned=[]
        with self.assertRaisesRegex(ValueError,'fixed scope'):parent.launch(path,pin,self.root/'evidence',enabled=True,confirmed=True,fixture=True,popen_factory=lambda *a,**k:spawned.append(True))
        self.assertEqual(spawned,[]);self.assertFalse((self.root/'evidence').exists())

if __name__=='__main__':unittest.main(verbosity=2)
