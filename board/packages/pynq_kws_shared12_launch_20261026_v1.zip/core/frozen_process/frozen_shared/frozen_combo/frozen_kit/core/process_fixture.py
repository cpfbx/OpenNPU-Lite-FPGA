"""PC fixture boundaries only; production functions reject injected evidence."""
import os
from pathlib import Path
import sys
import uuid
import runtime_binding as rb
import runtime_contract as ct
rb.configure()
ad=sys.modules['adapter_binding']
of=rb.load('op4_fixture',rb.ROOT/'driver/op4_fixture.py')
df=of
from op4_runtime import derive
from pointwise_worker import run_worker
from pointwise_parent import launch

def request():
    return dict(schema='pointwise-process-request-candidate-v1',run_id=str(uuid.uuid4()),operator='bx',
        board_declaration='SYNTHETIC-PC-NOT-A-BOARD',image='pynq-z2-v3.1.1',scope='fixed-twelve-operator4-correctness-only',
        candidate_manifest_sha256='a'*64,expected_boot='00000000-0000-0000-0000-000000000001',
        expected_lock=dict(path=ct.LOCK,device=2048,inode=11),declarations=dict(utc=True,idle=True,wiring=True,separate_scope_approved=True))
def launch_binding(req,request_sha):
    return dict(request_sha256=request_sha,expected_lock=req['expected_lock'],parent_pid=os.getpid(),parent_start_ticks=123,run_id=req['run_id'])
def synthetic_worker(req,req_sha,folder,*,bad_window=None,stop_window=None,parent_alive=True,gate=None,handshake=False,launch_value=None,case_hook=None,supervise=None):
    case=derive(0);h=df.Op4Harness(case);env=df.FakeCanonicalEnvironment()
    original_recovery=h.recovery
    def recovery(*a,**k):
        r=original_recovery(*a,**k);r.last_diagnostics=dict(confirmed=True,fixture=True);return r
    h.recovery=recovery
    def before(case):
        h.set_case(case)
        if case_hook is not None:case_hook(case)
        if case['cohort_index']==bad_window:
            raw=h.engine.payload;h.engine.payload=bytes([raw[0]^1])+raw[1:]
        if case['cohort_index']==stop_window:
            ct.write_bytes(folder.parent/'stop.flag',b'')
    from contextlib import ExitStack
    from unittest.mock import patch
    with env.install(),ExitStack() as resident:
        def start():
            h.start(env);resident.enter_context(patch.dict(sys.modules,{'pynq':h.fake}))
        try:
            result=run_worker(req,req_sha,folder,launch_value or launch_binding(req,req_sha),enabled=True,fixture=True,
                fixture_owner=h.owner,fixture_start=start,fixture_gate=gate if gate is not None else (None if handshake else (lambda stopped:None)),
                fixture_parent_alive=parent_alive if callable(parent_alive) else (lambda:parent_alive),fixture_before_case=before,fixture_supervise=supervise)
        finally:h.discard_synthetic_hold() # TEST teardown only; never release a real resource.
    return result,h

def synthetic_parent(config,config_sha,folder,worker_template,*,wait_code=0,group_absent=True,release_ok=True,live_ok=True,
                     remove_terminal=False,fixture_supervise=None,final_release_ok=True):
    """Canned dead-child artifact fixture, NOT a test of real parent/worker ordering."""
    import shutil
    template=Path(worker_template)
    class Child:
        pid=os.getpid()
        waits=0
        def wait(self,timeout):self.waits+=1;return wait_code
    child=Child()
    def popen(command,**options):
        target=folder/'worker'
        for p in template.rglob('*'):
            if p.is_file():
                if remove_terminal and p.name=='terminal.json.ready':continue
                dest=target/p.relative_to(template);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
        return child
    calls=[]
    def release(identity):
        calls.append('release')
        return dict(identity,lock_released_same_inode=release_ok if len(calls)==1 else final_release_ok,source='SYNTHETIC release only')
    result=launch(config,config_sha,folder,enabled=True,confirmed=True,fixture=True,popen_factory=popen,
        group_query=lambda pid:group_absent,snapshot=lambda:ct.read_request(config,config_sha)['expected_lock'],
        live_query=lambda ticket,pid,identity:live_ok,release_query=release,fixture_parent_start=lambda:123,fixture_supervise=fixture_supervise)
    return result,child,calls

def finite_fixture_supervise(factory,operation,publish,external_stopped,*,enabled=False):
    """TEST ONLY: observe quarantine then return, never use for real resources.

    The production frozen supervisor keeps unresolved resources forever. This
    fixture does NOT execute or claim to test that infinite retention loop.
    """
    try:result=operation(external_stopped)
    except BaseException:
        status=factory.supervision_status
        if any(status[k] for k in ('held','safety_unresolved','runner_retained','lease_retained','root_buffers_retained')):
            publish(dict(status,test_only_retention_observed=True));raise RuntimeError('TEST ONLY unresolved fixture')
        raise
    return dict(result=result,signals=dict(stop_signals=[],handler_errors=[],handler_restore_errors=[],original_supervisor_unchanged=True))
