"""Offline exact-byte check, never imports the driver or PYNQ."""
import argparse,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import op4_binding as binding
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--candidate-sha',required=True);args=parser.parse_args()
    files=binding.verify_candidate(args.candidate_sha)
    print('CANDIDATE BYTES OK',len(files),'board_access=false promotion=false');return 0
if __name__=='__main__':
    try:raise SystemExit(main())
    except (ValueError,OSError) as error:print(type(error).__name__+': '+str(error),file=sys.stderr);raise SystemExit(2)
