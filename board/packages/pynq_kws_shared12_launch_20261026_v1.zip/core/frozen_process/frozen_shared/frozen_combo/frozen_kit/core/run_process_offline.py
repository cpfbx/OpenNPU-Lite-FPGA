"""Only an x86 PC fixture run. Never calls private real ARM parent or devices."""
import argparse
import os
from pathlib import Path
import platform
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import runtime_binding as rb
import runtime_contract as ct
from process_fixture import request,synthetic_worker,synthetic_parent

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    rb.require(platform.machine().lower() in ('amd64','x86_64','x86','i386','i686'),'desktop-only fixture runner')
    out=ct.canonical(a.output);rb.require(not os.path.lexists(out) and not out.is_relative_to(rb.ROOT),'fresh fixture output outside candidate')
    before=rb.inventory(rb.ROOT);out.mkdir()
    req=request();cfg=out/'request.json';pin=ct.write_json(cfg,req)['sha256']
    child_root=out/'synthetic_child_session';child_root.mkdir();worker=child_root/'worker';worker.mkdir()
    result,h=synthetic_worker(req,pin,worker)
    rb.require(result['operation_success'] is True and result['accepted_calls']==12,'twelve fixture worker calls')
    parent,child,events=synthetic_parent(cfg,pin,out/'synthetic_parent_session',worker)
    rb.require(parent['operation_success'] is True and child.waits==1 and parent['fixture'] is True
        and parent['evidence_injected'] is True,'synthetic parent validation, not real wait')
    badreq=request();badcfg=out/'fault_request.json';badpin=ct.write_json(badcfg,badreq)['sha256']
    badroot=out/'synthetic_fault_session';badroot.mkdir();badwork=badroot/'worker';badwork.mkdir()
    bad,badh=synthetic_worker(badreq,badpin,badwork,bad_window=90)
    rb.require(bad['operation_success'] is False and bad['completed_indices']==[0,30,60]
        and bad['not_completed_indices']==[90,120,150,180,210,240,270,300,400],'first failed window stops batch')
    rb.require((badwork/'first_failure_tile_order.bin').stat().st_size==32000,'first raw fault retained')
    rb.require(before==rb.inventory(rb.ROOT),'candidate unchanged')
    record=dict(operation_success=True,scope='PC fixture worker and CANNED parent artifacts; NOT real IPC/device evidence',
        worker_success_calls=12,worker_fault_completed_calls=3,worker_fault_index=90,
        successful_worker_raw_values=96000,successful_worker_INT8_values=96000,
        original_supervisor_normal_path_executed=True,parent_wait_fixture=True,real_parent_child_pair_tested=False,
        real_canonical_lock_tested=False,real_board_access=False,ARM_tested=False,
        board_activation_approved=False,run_ready=False,promotion=False,input_files_unchanged=True)
    ct.write_json(out/'result.json',record);print(record)
if __name__=='__main__':main()
