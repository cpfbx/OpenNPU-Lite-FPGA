"""Operator4 identity gate around the unchanged reviewed real-driver call body.

Library only; constructor does not acquire resources or grant board authority.
"""
from dataclasses import dataclass
import json,os,threading
import numpy as np
from op4_binding import need
import op4_runtime as reference
from pointwise_owner import PointwiseOwner
from pointwise_policy import validate_pointwise_policy
from pointwise_driver_call import PointwiseDriverCall
from batch_policy import BatchStop
from op4_candidate import InputEnvelope
from return_diagnostic import valid

@dataclass(frozen=True)
class DriverFailure:
    stage:str
    error_type:str
    payload:bytes|None
    return_diagnostic_json:bytes|None=None
    accepted:bool=False
    automatic_retry:bool=False

class Op4DriverCall(PointwiseDriverCall):
    def __init__(self,owner,case,*,enabled=False):
        need(enabled is True,'operator4 driver call default-off')
        need(type(owner) is PointwiseOwner,'exact reviewed owner; no software transport')
        validate_pointwise_policy(owner.policy);reference.authorize_owner(owner)
        spec=owner.policy.request(owner._index)
        need(type(case) is dict and type(case.get('cohort_index')) is int and case['cohort_index']==spec.cohort_index,'scheduled operator4 window')
        self.case=reference.sealed_case(case);self.owner,self.spec=owner,spec
        self.pid,self.thread=os.getpid(),threading.get_ident()
        self._guard=threading.Lock();self._envelope_guard=threading.Lock()
        self.used=self.failed=self.accepted=False;self.first_failure=None

    def __call__(self,envelope):
        need((os.getpid(),threading.get_ident())==(self.pid,self.thread),'call process/thread drift')
        need(self._envelope_guard.acquire(blocking=False),'nonreentrant operator4 envelope')
        stage='before_construction'
        try:
            need(not self.used and not self.failed,'one-shot call; no retry/fallback')
            if self.owner.stop_requested() is not False:raise BatchStop('operator4 stop before construction')
            stage='validate_input'
            need(type(envelope) is InputEnvelope,'exact operator4 input envelope')
            need(type(envelope.operator_index) is int and envelope.operator_index==4
                and type(envelope.tensor_index) is int and envelope.tensor_index==25,'input layer identity')
            need(type(envelope.cohort_index) is int and envelope.cohort_index==self.case['cohort_index']
                and type(envelope.source_id) is str and envelope.source_id==self.case['source_id']
                and type(envelope.feature_sha256) is str and envelope.feature_sha256==self.case['feature_sha256'],'input window identity')
            a=envelope.values
            need(type(a) is np.ndarray and a.dtype==np.int8 and a.shape==(125,64) and a.flags.c_contiguous
                and a.flags.owndata and a.base is None and np.array_equal(a,self.case['a']),'exact owning operator4 input bytes')
            stage='reviewed_driver_call'
            # Full work/MMIO/state/record/raw/PS/INT8/stop checks inherited unchanged.
            return super().__call__(a)
        except BaseException as error:
            self.used=True;self.failed=True
            if type(self.first_failure) is dict:
                old=self.first_failure;diagnostic=old.get('return_diagnostic');need(valid(diagnostic),'bounded inherited return diagnostic')
                diagnostic_raw=None if diagnostic is None else json.dumps(diagnostic,sort_keys=True,ensure_ascii=True,separators=(',',':')).encode('ascii')
                self.first_failure=DriverFailure(diagnostic['check'] if diagnostic is not None else stage,
                    old['error_type'],old['payload'],diagnostic_raw)
            elif self.first_failure is None:
                self.first_failure=DriverFailure(stage,type(error).__name__,None)
            raise
        finally:self._envelope_guard.release()

if __name__=='__main__':raise SystemExit('Library only. No board launcher.')
