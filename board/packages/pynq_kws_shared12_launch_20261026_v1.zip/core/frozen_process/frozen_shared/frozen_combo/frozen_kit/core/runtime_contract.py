"""Strict candidate request, fresh file publication and bounded artifact records."""
import json
import os
from pathlib import Path
import re
import stat
import uuid
import runtime_binding as rb
INDICES=(0,30,60,90,120,150,180,210,240,270,300,400)
LOCK='/tmp/opennpu-kws-chain.lock'
def digest(v):
    rb.require(type(v) is str and re.fullmatch('[0-9a-f]{64}',v) is not None,'lowercase SHA256 required');return v
def canonical(path):
    p=Path(path).absolute();rb.require(p.resolve()==p and not p.is_symlink(),'canonical nonalias path');return p
def strict_json(raw):
    def pairs(rows):
        d={}
        for k,v in rows:
            rb.require(k not in d,'duplicate JSON key');d[k]=v
        return d
    def bad(v):raise ValueError('nonfinite JSON number')
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=bad)
def read(path,limit):
    p=canonical(path);s=p.lstat();rb.require(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_size<=limit,'bounded single-link file')
    with p.open('rb') as f:raw=f.read(limit+1)
    rb.require(len(raw)<=limit,'read bound');return raw
def write_bytes(path,raw):
    p=canonical(path)
    with p.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    return dict(bytes=len(raw),sha256=rb.sha(raw))
def write_json(path,value):
    raw=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode('utf-8')
    pin=write_bytes(path,raw)
    # Marker only after data close/fsync. Readers never parse an in-flight JSON.
    write_bytes(Path(str(path)+'.ready'),b'')
    return pin
def ready_json(path,limit=65536):
    marker=Path(str(path)+'.ready')
    if not os.path.lexists(marker):return None
    rb.require(read(marker,0)==b'','empty complete marker')
    return strict_json(read(path,limit))
def lock_identity(value):
    rb.require(type(value) is dict and set(value)=={'path','device','inode'} and value['path']==LOCK
        and type(value['device']) is int and value['device']>=0 and type(value['inode']) is int and value['inode']>0,'exact canonical inode identity')
    return value
def validate_request(v):
    keys={'schema','run_id','operator','board_declaration','image','scope','candidate_manifest_sha256','expected_boot','expected_lock','declarations'}
    rb.require(type(v) is dict and set(v)==keys,'exact process request fields')
    rb.require(v['schema']=='pointwise-process-request-candidate-v1' and v['operator']=='bx'
        and v['scope']=='fixed-twelve-operator4-correctness-only' and v['image']=='pynq-z2-v3.1.1','fixed scope/operator/image')
    rb.require(type(v['board_declaration']) is str and 0<len(v['board_declaration'])<=128
        and all(ord(c)>=32 for c in v['board_declaration']),'bounded declared board identity')
    for k in ('run_id','expected_boot'):
        rb.require(type(v[k]) is str and str(uuid.UUID(v[k]))==v[k],'canonical UUID '+k)
    digest(v['candidate_manifest_sha256']);lock_identity(v['expected_lock'])
    rb.require(type(v['declarations']) is dict and set(v['declarations'])=={'utc','idle','wiring','separate_scope_approved'}
        and all(x is True for x in v['declarations'].values()),'fresh operator declarations, not authenticated approval')
    return v
def read_request(path,pin):
    path=canonical(path);rb.require(not path.is_relative_to(rb.ROOT),'request outside immutable candidate')
    raw=read(path,30000);rb.require(rb.sha(raw)==digest(pin),'request SHA mismatch');return validate_request(strict_json(raw))
def manifest(folder):
    excluded={'artifact_manifest.json','artifact_manifest.json.ready','terminal.json','terminal.json.ready'}
    return {n:p for n,p in rb.inventory(folder).items() if n not in excluded}
def terminal(folder):
    t=ready_json(folder/'terminal.json',300000);rb.require(type(t) is dict,'completed child terminal required')
    m=ready_json(folder/'artifact_manifest.json',2_000_000);rb.require(type(m) is dict and set(m)=={'files'},'artifact manifest')
    rb.require(rb.sha(read(folder/'artifact_manifest.json',2_000_000))==t['artifact_manifest_sha256'],'terminal manifest pin')
    actual=rb.inventory(folder)
    rb.require(actual.keys()==(m['files'].keys()|{'artifact_manifest.json','artifact_manifest.json.ready','terminal.json','terminal.json.ready'})
        and manifest(folder)==m['files'],'exact final artifact member set')
    return t
