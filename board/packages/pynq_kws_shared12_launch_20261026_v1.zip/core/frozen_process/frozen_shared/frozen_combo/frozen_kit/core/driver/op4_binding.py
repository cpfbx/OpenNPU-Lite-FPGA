"""Pinned cold assembly for offline-reviewed operator4 driver adapter; no launcher."""
import hashlib,importlib.util,json,sys
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parent
PINS={'frozen_driver':'9672bb3ae57082509448a626389fe281167c53c654e33695e4572e408d511fc2','frozen_op4':'422b556a27a512f2b0212b26caba2872313111e8e11315291143860cbcd671b2'}
_configured=None
def need(ok,message):
    if not ok:raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def inventory(root):
    result={}
    for p in root.rglob('*'):
        need(not p.is_symlink() and not getattr(p,'is_junction',lambda:False)(),'plain frozen tree')
        if p.is_file():
            raw=p.read_bytes();result[p.relative_to(root).as_posix()]=dict(bytes=len(raw),sha256=sha(raw))
    return result
def verify_frozen():
    for name,pin in PINS.items():
        root=ROOT/name;raw=(root/'candidate_manifest.json').read_bytes();need(sha(raw)==pin,'reviewed source pin')
        wanted=json.loads(raw)['files'];actual=inventory(root)
        need(set(actual)==set(wanted)|{'candidate_manifest.json'} and all(actual[n]==v for n,v in wanted.items()),'reviewed source exact bytes')
    need(inventory(ROOT/'frozen_op4/frozen_op2')==inventory(ROOT/'frozen_driver/frozen_v2'),'shared frozen op2 ABI/data')
def verify_candidate(pin):
    raw=(ROOT/'candidate_manifest.json').read_bytes();need(type(pin) is str and sha(raw)==pin,'external candidate pin')
    wanted=json.loads(raw)['files'];actual=inventory(ROOT)
    need(set(actual)==set(wanted)|{'candidate_manifest.json'} and all(actual[n]==v for n,v in wanted.items()),'candidate exact bytes')
    verify_frozen();return actual
def load(name,path):
    path=path.resolve()
    if name in sys.modules:
        need(Path(getattr(sys.modules[name],'__file__','')).resolve()==path,'foreign module '+name);return sys.modules[name]
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module;spec.loader.exec_module(module);return module
def configure(*,enabled=False):
    global _configured
    need(enabled is True,'operator4 driver binding default-off')
    need(not any(n==r or n.startswith(r+'.') for n in sys.modules for r in ('pynq','tensorflow','tflite_runtime')),'cold CPU reference binding required')
    verify_frozen()
    if _configured is not None:
        _configured.reference.sources();return _configured
    driver=ROOT/'frozen_driver';ab=load('adapter_binding',driver/'adapter_binding.py');ab.select(enabled=True)
    reference=load('runtime_reference',driver/'runtime_reference.py')
    load('return_diagnostic',driver/'return_diagnostic.py')
    load('pointwise_driver_call',driver/'pointwise_driver_call.py')
    for name in ('source_bindings','layer_case','op4_candidate','independent_math'):
        load(name,ROOT/'frozen_op4'/(name+'.py'))
    runtime=load('op4_runtime',ROOT/'op4_runtime.py');runtime.bind()
    # Original policy is layer-neutral fixed geometry/12-window schedule. Operator
    # identity is mandatory in Op4DriverCall and its sealed InputEnvelope.
    policy=sys.modules['pointwise_policy'];owner=sys.modules['pointwise_owner'];flat=sys.modules['flat_driver_candidate']
    need(flat.FlatPackPynqGemm._submit_chain is sys.modules['pynq_gemm'].PynqGemm._submit_chain,'unchanged submit identity')
    _configured=SimpleNamespace(owner_type=owner.PointwiseOwner,policy_type=policy.PointwisePolicy,reference=runtime,
        runner_type=flat.flat_runner_type(enabled=True),board_activation_approved=False,run_ready=False)
    return _configured
if __name__=='__main__':raise SystemExit('Library only. No board CLI or activation authority.')
