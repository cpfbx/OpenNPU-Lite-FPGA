"""PC FIXTURE evidence over unchanged driver; never a real board entry."""
import argparse
import json
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import adapter_binding as ab
components=ab.configure()
from driver_fixture import Harness,FakeCanonicalEnvironment
from pointwise_driver_call import PointwiseDriverCall
from real_case import APPROVED_INDICES

def save(path,raw):
    with path.open('xb') as f:f.write(raw)
    return dict(bytes=len(raw),sha256=ab.sha(raw))
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();out=args.output.absolute()
    ab.require(out.resolve()==out and not out.exists() and out!=ab.ROOT
        and not out.is_relative_to(ab.ROOT) and not ab.ROOT.is_relative_to(out),'fresh output outside candidate')
    before=ab.inventory(ab.ROOT);out.mkdir()
    case0=components.derive(0);h=Harness(case0);env=FakeCanonicalEnvironment();rows=[]
    with env.install():
        h.start(env)
        try:
            for idx in APPROVED_INDICES:
                case=components.derive(idx);h.set_case(case)
                call=PointwiseDriverCall(h.owner,case,enabled=True);actual,data=call(case['a'])
                expected_raw=case['a'].astype(np.int64)@case['weights'].astype(np.int64)
                ab.require(np.array_equal(data['raw'],expected_raw) and np.array_equal(actual,case['expected']),'fixture raw/golden/output')
                folder=out/('window_%03d'%idx);folder.mkdir()
                artifacts={'feature.i8':(ab.ROOT/'frozen_v2/frozen/data/features.i8').read_bytes()[idx*490:(idx+1)*490],
                    'pointwise_input.i8':case['a'].tobytes(),'weights_kn.i8':case['weights'].tobytes(),
                    'request_chain.bin':data['input_chain'],'reply_tile_order.bin':data['reply_tile_order'],
                    'raw_output.i32':data['raw'].astype('<i4').tobytes(),'raw_oracle.i64':expected_raw.astype('<i8').tobytes(),
                    'corrected.i32':data['corrected'].astype('<i4').tobytes(),
                    'candidate_output.i8':actual.tobytes(),'expected_output.i8':case['expected'].tobytes()}
                row=dict(cohort_index=idx,source_id=case['source_id'],first_job_id=call.spec.first_job_id,
                    exact_raw_values=8000,exact_INT8_values=8000,fixture=True,
                    driver_metrics_from_fake_MMIO=data['driver_metrics'],
                    artifacts={n:save(folder/n,raw) for n,raw in artifacts.items()})
                save(folder/'result.json',(json.dumps(row,indent=2)+'\n').encode())
                rows.append(row)
        finally:h.owner.close()
        ab.require(not env.fd_live and not env.held and h.owner._closed,'synthetic normal cleanup')
        cleanup=h.owner.cleanup_readback
    transfers=[e for e in h.events if e[0]=='transfer']
    ab.require(transfers==[('transfer','recv',32000),('transfer','send',16512)]*12,'all 24 synthetic DMA transfer calls')
    # Separate one-bit negative case, with another purely synthetic lease/runner.
    bad=Harness(case0);badenv=FakeCanonicalEnvironment();failure=None
    with badenv.install():
        bad.start(badenv)
        try:
            call=PointwiseDriverCall(bad.owner,case0,enabled=True)
            payload=bad.engine.payload;bad.engine.payload=bytes([payload[0]^1])+payload[1:]
            try:call(case0['a']);raise AssertionError('raw one-bit fault accepted')
            except ValueError:
                ab.require(call.failed and not call.accepted and type(call.first_failure['payload']) is bytes,'bounded synthetic fault')
                failure=call.first_failure
                first=call.first_failure;count=len(bad.events)
                try:call(case0['a']);raise AssertionError('automatic retry accepted')
                except ValueError:ab.require(call.first_failure is first and len(bad.events)==count,'no fault retry')
        finally:bad.owner.close()
    failure_artifact=save(out/'synthetic_first_failure_tile_order.bin',failure['payload'])
    ab.require(len(rows)==12 and ab.inventory(ab.ROOT)==before,'fixed twelve and unchanged inputs')
    record=dict(operation_success=True,scope='PC synthetic PYNQ/MMIO/DMA/lock/recovery ONLY; NOT board or RTL',
        windows=rows,successful_fixture_calls=12,intentional_failed_fixture_calls=1,total_fixture_submissions=13,
        raw_values_compared=96000,INT8_values_compared=96000,synthetic_transfer_calls=24,
        synthetic_events=h.events,synthetic_cleanup=cleanup,synthetic_failure_artifact=failure_artifact,
        input_files_unchanged=True,unchanged_submit_body_exercised=True,
        real_PYNQ_imported=False,real_board_access=False,real_DMA_executed=False,real_lock_access=False,
        PL_simulated=False,ARM_tested=False,board_activation_approved=False,full_board_runtime_implemented=False,
        performance_evaluated=False,energy_evaluated=False,classification_quality_evaluated=False,run_ready=False,promotion=False)
    save(out/'result.json',(json.dumps(record,indent=2)+'\n').encode())
    print(json.dumps({k:record[k] for k in ('operation_success','successful_fixture_calls','intentional_failed_fixture_calls',
        'raw_values_compared','INT8_values_compared','real_board_access','run_ready','promotion')}))
    return 0

if __name__=='__main__':raise SystemExit(main())
