"""Distinct offline outer tests; fake quarantine is NOT real infinite-hold proof."""
import ast
import copy
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parent))
import runtime_binding as rb
import runtime_contract as ct
rb.configure()
import pointwise_parent as pp
import pointwise_worker as pw
import fpga_evidence as fe
from process_observer import observe_exit
from process_fixture import request,launch_binding,synthetic_worker,synthetic_parent,finite_fixture_supervise

class ProcessTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory(prefix='pointwise_process_unit_')
        cls.root=Path(cls.temp.name).resolve();cls.req=request();cls.pin=ct.write_json(cls.root/'request.json',cls.req)['sha256']
        cls.normal=cls.root/'normal';cls.normal.mkdir();cls.worker=cls.normal/'worker';cls.worker.mkdir()
        cls.result,cls.harness=synthetic_worker(cls.req,cls.pin,cls.worker)
    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()
    def setUp(self):
        self.case=tempfile.TemporaryDirectory(prefix='pointwise_outer_case_');self.folder=Path(self.case.name).resolve()
        self.cfg=self.folder/'request.json';self.pin=ct.write_json(self.cfg,self.req)['sha256']
    def tearDown(self):self.case.cleanup()
    def parent(self,**kw):return synthetic_parent(self.cfg,self.pin,self.folder/'evidence',self.worker,**kw)
    def cloned(self):
        p=self.folder/'copied_worker';shutil.copytree(self.worker,p);return p
    def resign(self,p):
        m=p/'artifact_manifest.json';m.write_text(json.dumps(dict(files=ct.manifest(p)),sort_keys=True,indent=2)+'\n',encoding='utf-8')
        t=json.loads((p/'terminal.json').read_bytes());t['artifact_manifest_sha256']=rb.sha(m.read_bytes())
        (p/'terminal.json').write_text(json.dumps(t,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    def test_01_strict_request_defaults(self):ct.validate_request(self.req)
    def test_02_wrong_operator_rejected(self):
        r=copy.deepcopy(self.req);r['operator']='other'
        with self.assertRaises(ValueError):ct.validate_request(r)
    def test_03_bool_lock_integer_rejected(self):
        r=copy.deepcopy(self.req);r['expected_lock']['inode']=True
        with self.assertRaises(ValueError):ct.validate_request(r)
    def test_04_missing_declaration_rejected(self):
        r=copy.deepcopy(self.req);r['declarations']['idle']=False
        with self.assertRaises(ValueError):ct.validate_request(r)
    def test_05_extra_request_field_rejected(self):
        r=dict(self.req,extra=True)
        with self.assertRaises(ValueError):ct.validate_request(r)
    def test_06_invalid_sha_and_UUID(self):
        for key,value in [('candidate_manifest_sha256','A'*64),('expected_boot','bad')]:
            r=copy.deepcopy(self.req);r[key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):ct.validate_request(r)
    def test_07_duplicate_json_rejected(self):
        with self.assertRaises(ValueError):ct.strict_json(b'{"a":1,"a":2}')
    def test_08_nonfinite_json_rejected(self):
        with self.assertRaises(ValueError):ct.strict_json(b'{"a":NaN}')
    def test_09_request_hash_rejected(self):
        with self.assertRaises(ValueError):ct.read_request(self.cfg,'0'*64)
    def test_10_unpublished_JSON_not_read(self):
        p=self.folder/'partial.json';p.write_bytes(b'{')
        self.assertIsNone(ct.ready_json(p))
    def test_11_published_partial_JSON_rejected(self):
        p=self.folder/'partial.json';p.write_bytes(b'{');Path(str(p)+'.ready').write_bytes(b'')
        with self.assertRaises(ValueError):ct.ready_json(p)
    def test_12_no_overwrite_completed_record(self):
        p=self.folder/'a.json';ct.write_json(p,{'a':1});old=p.read_bytes()
        with self.assertRaises(FileExistsError):ct.write_json(p,{'a':2})
        self.assertEqual(old,p.read_bytes())
    def test_13_worker_default_off(self):
        with self.assertRaises(ValueError):pw.run_worker(self.req,self.pin,self.folder,launch_binding(self.req,self.pin))
    def test_14_real_worker_rejects_injection(self):
        with self.assertRaises(ValueError):pw.run_worker(self.req,self.pin,self.folder,launch_binding(self.req,self.pin),enabled=True,fixture_gate=lambda s:None)
    def test_15_worker_launch_binding_mismatch(self):
        b=launch_binding(self.req,self.pin);b['request_sha256']='0'*64
        with self.assertRaises(ValueError):pw.validate_launch(b,self.req,self.pin)
    def test_16_worker_normal_twelve(self):
        self.assertTrue(self.result['operation_success']);self.assertEqual(self.result['completed_indices'],list(ct.INDICES))
        self.assertEqual(self.result['accepted_calls'],12);self.assertFalse(self.result['outer_process_exit_observed'])
    def test_17_original_supervision_normal_path(self):
        self.assertEqual(self.result['signals'],dict(stop_signals=[],handler_errors=[],handler_restore_errors=[],original_supervisor_unchanged=True))
        self.assertTrue(self.result['cleanup']['owner_closed']);self.assertFalse(self.harness.owner._lease is not None)
    def test_18_parent_lost_before_acquisition(self):
        r=request();p=self.folder/'worker';p.mkdir();d,h=synthetic_worker(r,'a'*64,p,parent_alive=False)
        self.assertFalse(d['operation_success']);self.assertEqual(d['cleanup']['kind'],'no_resources')
        self.assertFalse(any(e[0]=='fake_overlay' for e in h.events))
    def test_19_STOP_before_GO_no_submissions(self):
        def gate(stopped):
            ct.write_bytes(self.folder/'stop.flag',b'')
            from batch_policy import BatchStop
            raise BatchStop('synthetic stop before GO')
        r=request();p=self.folder/'worker';p.mkdir();d,h=synthetic_worker(r,'b'*64,p,gate=gate)
        self.assertEqual(d['accepted_calls'],0);self.assertTrue(d['cleanup']['owner_closed'])
        self.assertFalse(any(e[0]=='transfer' for e in h.events))
    def test_20_parent_success_requires_all_proofs(self):
        d,c,events=self.parent();self.assertTrue(d['operation_success']);self.assertEqual(c.waits,1)
        self.assertTrue(d['cleanup_verified'] and d['lock_released_same_inode'] and d['parent_go_sent'])
        self.assertTrue(d['fixture'] and d['evidence_injected']);self.assertEqual(events,['release','release'])
    def test_21_parent_default_off(self):
        with self.assertRaises(ValueError):pp.launch(self.cfg,self.pin,self.folder/'evidence')
    def test_22_parent_unconfirmed_rejected(self):
        with self.assertRaises(ValueError):pp.launch(self.cfg,self.pin,self.folder/'evidence',enabled=True)
    def test_23_real_parent_rejects_injection(self):
        with self.assertRaises(ValueError):pp.launch(self.cfg,self.pin,self.folder/'evidence',enabled=True,confirmed=True,popen_factory=lambda *a:None)
    def test_24_duplicate_attempt_no_retry(self):
        self.parent()
        # Use another fresh evidence path, so the persistent request-attempt
        # guard is reached rather than the earlier existing-directory guard.
        with self.assertRaises(FileExistsError):synthetic_parent(self.cfg,self.pin,self.folder/'second_evidence',self.worker)
    def test_25_initial_lock_absence_required(self):
        with self.assertRaises(ValueError):self.parent(release_ok=False)
        self.assertFalse((self.folder/'evidence').exists())
    def test_26_group_remaining_retains_fake_child(self):
        with self.assertRaises(ValueError):self.parent(group_absent=False,fixture_supervise=finite_fixture_supervise)
        self.assertTrue((self.folder/'evidence/attention_retained.json').is_file())
        self.assertFalse((self.folder/'evidence/outer_receipt.json').exists())
    def test_27_live_ticket_failure_not_success(self):
        with self.assertRaises(ValueError):self.parent(live_ok=False,fixture_supervise=finite_fixture_supervise)
        self.assertFalse((self.folder/'evidence/outer_receipt.json').exists())
    def test_28_final_release_failure_retains_fake_child(self):
        with self.assertRaises(ValueError):self.parent(final_release_ok=False,fixture_supervise=finite_fixture_supervise)
        self.assertFalse((self.folder/'evidence/outer_receipt.json').exists())
    def test_29_missing_terminal_not_exit_success(self):
        with self.assertRaises(ValueError):self.parent(remove_terminal=True,fixture_supervise=finite_fixture_supervise)
        self.assertFalse((self.folder/'evidence/outer_receipt.json').exists())
    def test_30_nonzero_wait_not_operation_success(self):
        with self.assertRaises(ValueError):self.parent(wait_code=3)
        d=ct.ready_json(self.folder/'evidence/outer_receipt.json');self.assertEqual(d['actual_exit_code'],3)
        self.assertFalse(d['operation_success']);self.assertTrue(d['cleanup_verified'])
    def test_31_terminal_PID_mismatch_rejected(self):
        with self.assertRaises(ValueError):pp.validate_terminal(self.worker,os.getpid()+1,self.req,self.pin,True)
    def test_32_terminal_request_mismatch_rejected(self):
        with self.assertRaises(ValueError):pp.validate_terminal(self.worker,os.getpid(),self.req,'0'*64,True)
    def test_33_tampered_output_manifest_rejected(self):
        p=self.cloned();f=p/'window_000/candidate_output.i8';b=bytearray(f.read_bytes());b[0]^=1;f.write_bytes(b)
        with self.assertRaises(ValueError):pp.validate_terminal(p,os.getpid(),self.req,self.pin,True)
    def test_34_resigned_wrong_output_still_rejected(self):
        p=self.cloned();f=p/'window_000/candidate_output.i8';b=bytearray(f.read_bytes());b[0]^=1;f.write_bytes(b)
        row=ct.ready_json(p/'window_000/result.json');row['artifacts']['candidate_output.i8']=dict(bytes=len(b),sha256=rb.sha(b))
        (p/'window_000/result.json').write_text(json.dumps(row),encoding='utf-8')
        t=ct.ready_json(p/'terminal.json');t['windows'][0]=row;(p/'terminal.json').write_text(json.dumps(t),encoding='utf-8');self.resign(p)
        with self.assertRaises(ValueError):pp.validate_terminal(p,os.getpid(),self.req,self.pin,True)
    def test_35_bad_cleanup_phase_rejected(self):
        p=self.cloned();t=ct.ready_json(p/'terminal.json');t['cleanup']['readback']['terminal']['phase']=2
        (p/'terminal.json').write_text(json.dumps(t),encoding='utf-8')
        with self.assertRaises(ValueError):pp.validate_terminal(p,os.getpid(),self.req,self.pin,True)
    def test_36_parent_guardian_one_shot(self):
        g=pp.Guardian();g.begin();c=object();g.retain(c)
        with self.assertRaises(ValueError):g.begin()
        g.forget(c)
        with self.assertRaises(ValueError):g.begin()
    def test_37_pending_spawn_is_unresolved(self):
        g=pp.Guardian();g.begin();self.assertTrue(g.supervision_status['safety_unresolved'])
    def test_38_guardian_no_forget_quarantine(self):
        g=pp.Guardian();g.begin();c=object();g.retain(c);g._hold(RuntimeError())
        with self.assertRaises(ValueError):g.forget(c)
    def test_39_wait_rejects_bool_exit(self):
        class Child:
            pid=123
            def wait(self,timeout):return True
        g=pp.Guardian()
        with self.assertRaises(ValueError):observe_exit(Child(),g,lambda:False,lambda:None,group_query=lambda pid:True)
        self.assertTrue(g.held)
    def test_40_wait_timeout_requests_stop_no_kill(self):
        import subprocess
        class Child:
            pid=123;n=0
            def wait(self,timeout):
                self.n+=1
                if self.n==1:raise subprocess.TimeoutExpired('fixture',1)
                return 0
        calls=[];r=observe_exit(Child(),pp.Guardian(),lambda:True,lambda:calls.append('stop'),group_query=lambda pid:True)
        self.assertEqual(calls,['stop']);self.assertEqual(r['wait_intervals'],1);self.assertFalse(r['automatic_kill'])
    def test_41_installed_signal_chain_cooperative_stop(self):
        import signal
        number=signal.SIGTERM;previous=signal.getsignal(number)
        def gate(stopped):
            handler=signal.getsignal(number);self.assertTrue(callable(handler))
            handler(number,None)  # Invoke installed handler, NOT an OS signal.
            self.assertTrue(stopped())
        p=self.folder/'worker';p.mkdir();d,h=synthetic_worker(request(),'c'*64,p,gate=gate)
        self.assertFalse(d['operation_success']);self.assertEqual(d['accepted_calls'],0)
        self.assertEqual(d['signals']['stop_signals'],[int(number)])
        self.assertTrue(d['cleanup']['owner_closed']);self.assertIs(signal.getsignal(number),previous)
        self.assertFalse(any(e[0]=='transfer' for e in h.events))
    def test_42_stop_before_fourth_window_no_next_DMA(self):
        p=self.folder/'worker';p.mkdir();d,h=synthetic_worker(request(),'d'*64,p,stop_window=90)
        self.assertEqual(d['completed_indices'],[0,30,60]);self.assertEqual(d['not_completed_indices'],list(ct.INDICES[3:]))
        self.assertEqual(len([e for e in h.events if e[0]=='transfer']),6)
        self.assertTrue(d['cleanup']['owner_closed']);self.assertFalse(d['operation_success'])
    def test_43_started_record_failure_still_waits(self):
        original=ct.write_json
        def write(path,value):
            if Path(path).name=='child_started.json':raise OSError('synthetic record failure')
            return original(path,value)
        with patch.object(ct,'write_json',side_effect=write),self.assertRaises(OSError):self.parent()
        observed=ct.ready_json(self.folder/'evidence/observed_child_exit.json')
        final=ct.ready_json(self.folder/'evidence/outer_receipt.json',400000)
        self.assertTrue(observed['actual_wait_observed']);self.assertTrue(final['cleanup_verified'])
        self.assertFalse(final['operation_success']);self.assertEqual(final['error_type'],'OSError')

if __name__=='__main__':unittest.main(verbosity=2)
