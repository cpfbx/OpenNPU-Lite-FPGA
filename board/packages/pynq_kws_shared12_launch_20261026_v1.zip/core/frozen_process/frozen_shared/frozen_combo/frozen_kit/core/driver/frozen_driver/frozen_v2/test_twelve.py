"""New distinct methods; subcases are NOT counted as extra test methods."""
from dataclasses import replace
import json
from pathlib import Path
import sys
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from binding import ROOT, sources, sha
from real_case import APPROVED_INDICES, APPROVED_LABELS, selected_items, derive
from pointwise_candidate import PointwiseCall, SoftwareTransport, Stopped


class TwelveTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cases=[derive(i) for i in APPROVED_INDICES]

    def test_01_exact_preselected_indices(self):
        self.assertEqual(APPROVED_INDICES,(0,30,60,90,120,150,180,210,240,270,300,400))
        self.assertEqual(tuple(r['cohort_index'] for r in selected_items()),APPROVED_INDICES)

    def test_02_first_occurrence_per_label(self):
        first={}
        for i,row in enumerate(json.loads((ROOT/'frozen/data/cohort.json').read_bytes())):
            first.setdefault(row['label'],i)
        self.assertEqual(tuple(first),APPROVED_LABELS)
        self.assertEqual(tuple(first.values()),APPROVED_INDICES)

    def test_03_reject_bool_index(self):
        for i in (True,False):
            with self.subTest(index=i),self.assertRaises(ValueError):derive(i)

    def test_04_reject_float_index(self):
        for i in (0.0,30.0):
            with self.subTest(index=i),self.assertRaises(ValueError):derive(i)

    def test_05_reject_unapproved_integer(self):
        for i in (-1,1,29,31,399,419,420):
            with self.subTest(index=i),self.assertRaises(ValueError):derive(i)

    def test_06_reject_noninteger(self):
        for i in ('0',None,np.int64(0)):
            with self.subTest(index=str(i)),self.assertRaises(ValueError):derive(i)

    def test_07_window_identity_and_feature_slices(self):
        features=(ROOT/'frozen/data/features.i8').read_bytes()
        for i,c in zip(APPROVED_INDICES,self.cases):
            with self.subTest(index=i):
                self.assertEqual(c['cohort_index'],i)
                self.assertEqual(c['feature_sha256'],sha(features[i*490:(i+1)*490]))
                self.assertEqual(c['source_id'],next(r['source_id'] for r in selected_items() if r['cohort_index']==i))

    def test_08_original_prefix_and_logits_all_windows(self):
        for c in self.cases:
            with self.subTest(index=c['cohort_index']):
                self.assertEqual(c['original_prefix_tensors_checked'],[22,23,24])
                self.assertIs(c['full_CPU_reference_logits_checked'],True)

    def test_09_all_windows_exact_software_call(self):
        for c in self.cases:
            with self.subTest(index=c['cohort_index']):
                call=PointwiseCall(c,SoftwareTransport(),enabled=True)
                out,m=call(c['a'])
                self.assertTrue(np.array_equal(out,c['expected']))
                self.assertEqual(m['exact_values'],8000)
                self.assertIs(m['fixture'],True)
                self.assertIs(m['board_access'],False)

    def test_10_cross_window_input_rejected_before_submission(self):
        for current,other in zip(self.cases,self.cases[1:]+self.cases[:1]):
            with self.subTest(index=current['cohort_index']):
                self.assertFalse(np.array_equal(current['a'],other['a']))
                t=SoftwareTransport();call=PointwiseCall(current,t,enabled=True)
                with self.assertRaises(ValueError):call(other['a'])
                self.assertTrue(call.failed);self.assertEqual(t.submissions,0)

    def test_11_fault_and_no_retry_each_window(self):
        def corrupt(reply):return replace(reply,payload=bytes([reply.payload[0]^1])+reply.payload[1:])
        for c in self.cases:
            with self.subTest(index=c['cohort_index']):
                t=SoftwareTransport(corrupt);call=PointwiseCall(c,t,enabled=True)
                with self.assertRaises(ValueError):call(c['a'])
                first=call.first_failure
                self.assertIs(type(first['payload']),bytes);self.assertEqual(len(first['payload']),32000)
                with self.assertRaises(ValueError):call(c['a'])
                self.assertIs(call.first_failure,first);self.assertEqual(t.submissions,1)

    def test_12_stop_before_construction_each_window(self):
        for c in self.cases:
            with self.subTest(index=c['cohort_index']):
                t=SoftwareTransport();call=PointwiseCall(c,t,enabled=True)
                with self.assertRaises(Stopped):call(c['a'],stopped=lambda:True)
                self.assertTrue(call.failed);self.assertEqual(t.submissions,0)

    def test_13_stop_after_exact_reply_each_window(self):
        for c in self.cases:
            with self.subTest(index=c['cohort_index']):
                t=SoftwareTransport();call=PointwiseCall(c,t,enabled=True)
                checks=iter([False,False,True])
                with self.assertRaises(Stopped):call(c['a'],stopped=lambda:next(checks))
                self.assertFalse(call.accepted);self.assertTrue(call.failed);self.assertEqual(t.submissions,1)

    def test_14_model_parameters_equal_but_cases_not_shared(self):
        first=self.cases[0]
        for c in self.cases[1:]:
            with self.subTest(index=c['cohort_index']):
                for key in ('weights','bias','scales'):
                    self.assertTrue(np.array_equal(c[key],first[key]))
                    self.assertFalse(np.shares_memory(c[key],first[key]))

    def test_15_no_hardware_transport_for_any_window(self):
        for c in self.cases:
            with self.subTest(index=c['cohort_index']),self.assertRaises(ValueError):
                PointwiseCall(c,object(),enabled=True)

    def test_16_default_remains_off_for_any_window(self):
        for c in self.cases:
            with self.subTest(index=c['cohort_index']),self.assertRaises(ValueError):
                PointwiseCall(c,SoftwareTransport())

if __name__=='__main__':unittest.main(verbosity=2)
