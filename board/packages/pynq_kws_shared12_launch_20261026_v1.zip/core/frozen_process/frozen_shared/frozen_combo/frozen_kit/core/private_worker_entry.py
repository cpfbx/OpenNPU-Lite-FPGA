"""Private ARM child: fixed request/pin binding, no upload or public activation UI."""
import argparse
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import runtime_binding as rb
import runtime_contract as ct

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('request','request-sha','launch','launch-sha','folder'):p.add_argument('--'+n,required=True)
    p.add_argument('--enabled-private-child',action='store_true');a=p.parse_args()
    rb.require(a.enabled_private_child is True,'private child default-off')
    rb.require_arm()
    request=ct.read_request(a.request,a.request_sha);rb.verify_candidate(request['candidate_manifest_sha256'])
    raw=ct.read(a.launch,30000);rb.require(rb.sha(raw)==ct.digest(a.launch_sha),'launch binding SHA')
    rb.require(ct.canonical(a.launch)==ct.canonical(a.folder).parent/'launch.json','fixed parent launch path')
    from pointwise_worker import run_worker
    result=run_worker(request,a.request_sha,a.folder,ct.strict_json(raw),enabled=True)
    print({'operation_success':result['operation_success'],'run_ready':False,'promotion':False})
    return 0 if result['operation_success'] is True else 1
if __name__=='__main__':
    try:raise SystemExit(main())
    except (OSError,ValueError,RuntimeError,ImportError) as error:
        print({'error_type':type(error).__name__,'promotion':False},file=sys.stderr);raise SystemExit(2)
