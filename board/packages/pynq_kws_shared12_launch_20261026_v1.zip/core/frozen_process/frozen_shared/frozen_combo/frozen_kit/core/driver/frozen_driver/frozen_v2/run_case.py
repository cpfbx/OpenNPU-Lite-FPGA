"""Pure offline numerical evidence. No PYNQ, DMA, RTL simulator or device IO."""
import argparse
from dataclasses import replace
import json
from pathlib import Path
import sys
import tarfile
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from binding import ROOT, sources, verify, require, sha
from real_case import derive
from pointwise_candidate import PointwiseCall, SoftwareTransport, make_jobs, validate_reply, scalar_quantized


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    output=args.output.absolute()
    require(output.resolve()==output and not output.exists() and output!=ROOT
        and not output.is_relative_to(ROOT) and not ROOT.is_relative_to(output),'fresh output outside candidate')
    verify()
    before={p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in ROOT.rglob('*') if p.is_file()}
    # Read exact named original artifacts without extracting or executing tar.
    with tarfile.open(ROOT/'cpu420_original.tar.gz','r:gz') as t:
        for name,nbytes in [('features.i8',205800),('logits.i8',5040)]:
            target='metrics_kws_prepare_0ROstCki/work/evidence/worker/numerical/'+name
            members=[m for m in t.getmembers() if m.name==target]
            require(len(members)==1 and members[0].isfile() and members[0].size==nbytes,'CPU420 original raw extent')
            b=t.extractfile(members[0]).read(nbytes+1)
            require(b==(ROOT/'frozen/data'/name).read_bytes(),'CPU420 board bytes equal fixed reference')
    case=derive()
    expected=case['expected']
    a,b=case['a'],case['weights']
    jobs,records=make_jobs(a,b)
    transport=SoftwareTransport()
    call=PointwiseCall(case,transport,enabled=True)
    actual,metrics=call(a)
    # Separate scalar centered dot product: not tile emulator, not raw+correction.
    centered=np.empty((125,64),np.int64)
    scalar_out=np.empty((125,64),np.int8)
    _,_,_,ref=sources()
    for y in range(125):
        for c in range(64):
            value=sum((int(a[y,k])-case['input_zp'])*int(b[k,c]) for k in range(64))+int(case['bias'][c])
            centered[y,c]=value
            multiplier,shift=ref.quant_multiplier(float(case['scales'][c]))
            quant=scalar_quantized(value,multiplier,shift)+case['output_zp']
            scalar_out[y,c]=min(127,max(case['output_zp'],quant))
    raw64=a.astype(np.int64)@b.astype(np.int64)
    corrected=raw64+case['bias'].astype(np.int64)-case['input_zp']*b.astype(np.int64).sum(axis=0)
    require(np.array_equal(centered,corrected),'centered scalar versus raw+correction INT64')
    require(np.array_equal(scalar_out,actual) and np.array_equal(actual,expected),'all 8000 scalar/frozen/candidate outputs')
    # One intentional SOFTWARE fault, isolated from the successful numerical run.
    faulty=PointwiseCall(case,SoftwareTransport(lambda r:replace(r,payload=bytes([r.payload[0]^1])+r.payload[1:])),enabled=True)
    try:
        faulty(a)
        raise AssertionError('one-bit raw-output fault accepted')
    except ValueError:
        require(faulty.failed and not faulty.accepted and faulty.first_failure is not None,'software first failure recorded')
    first=faulty.first_failure
    try:
        faulty(a)
        raise AssertionError('failed software call retried')
    except ValueError:
        require(faulty.first_failure is first and faulty.transport.submissions==1,'first failure preserved without retry')
    # Distinct synthetic geometry cases, not extra real-WAV observations.
    geometries=[]
    rng=np.random.default_rng(20261024)
    for m,n,k in [(1,1,1),(7,9,63),(9,7,65),(65,3,9),(3,65,40)]:
        aa=rng.integers(-128,128,size=(m,k),dtype=np.int8)
        bb=rng.integers(-128,128,size=(k,n),dtype=np.int8)
        jj,rr=make_jobs(aa,bb)
        response=SoftwareTransport()(jj,rr)
        result=validate_reply(jj,rr,response)
        require(np.array_equal(result,aa.astype(np.int64)@bb.astype(np.int64)),'synthetic tail dot product')
        geometries.append(dict(mnk=[m,n,k],jobs=len(jj),input_bytes=sum(len(r.bytes) for r in rr),
            output_valid_bytes=sum(r.header.output_valid_bytes for r in rr),
            output_transport_bytes=len(response.payload),synthetic=True))
    artifacts={'feature_0.i8':(ROOT/'frozen/data/features.i8').read_bytes()[:490],
        'pointwise_input.i8':a.tobytes(),'weights_kn.i8':b.tobytes(),
        'request_chain.bin':b''.join(r.bytes for r in records),
        'raw_output.i32':raw64.astype('<i4').tobytes(),'corrected.i32':corrected.astype('<i4').tobytes(),
        'expected_output.i8':expected.tobytes(),'candidate_output.i8':actual.tobytes(),'scalar_output.i8':scalar_out.tobytes(),
        'synthetic_first_failure_payload.bin':first['payload']}
    require(before=={p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in ROOT.rglob('*') if p.is_file()},'candidate inputs unchanged')
    verify()
    output.mkdir()
    for n,raw in artifacts.items():
        with (output/n).open('xb') as f:f.write(raw)
    record=dict(operation_success=True,source_manifest_sha256=sha((ROOT/'source_manifest.json').read_bytes()),
        cohort_index=0,source_id=case['source_id'],feature_sha256=case['feature_sha256'],
        source='CPU420 verified real feature window; prefix intermediates generated on PC, not retained board activations',
        operator_index=2,input_tensor=23,output_tensor=24,mnk=[125,64,64],logical_macs=512000,
        jobs=[dict(m_offset=j.m_offset,n_offset=j.n_offset,block_m=j.actual_bm,block_n=j.actual_bn,
            block_k=j.config.bk,input_bytes=len(r.bytes),output_valid_bytes=r.header.output_valid_bytes) for j,r in zip(jobs,records)],
        mm2s_chain_bytes=16512,s2mm_chain_bytes=32000,INT8_values_compared=8000,raw_I32_values_compared=8000,
        prefix_original_API_compared=case['original_prefix_tensors_checked'],original_CPU_window0_logits_exact=True,
        scalar_centered_dot_and_double_rounding_exact=True,synthetic_tail_geometries=geometries,
        synthetic_first_failure=dict(error_type=first['error_type'],accepted=False,fixture=True,
            payload_file='synthetic_first_failure_payload.bin',retry_refused=True,software_submissions=1),
        metadata=metrics,artifacts={n:dict(bytes=len(v),sha256=sha(v)) for n,v in artifacts.items()},
        input_files_unchanged=True,board_access=False,PL_simulated=False,DMA_executed=False,
        stop_or_cleanup_on_board_tested=False,hardware_runtime_implemented=False,
        full_model_PS_PL_executed=False,classification_quality_accepted=False,
        performance_evaluated=False,energy_evaluated=False,deployable=False,promotion=False,
        environment=dict(python=sys.version,numpy=np.__version__))
    (output/'result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:record[k] for k in ('operation_success','operator_index','mnk','INT8_values_compared',
        'raw_I32_values_compared','mm2s_chain_bytes','s2mm_chain_bytes','board_access','hardware_runtime_implemented','promotion')}))


if __name__=='__main__':main()
