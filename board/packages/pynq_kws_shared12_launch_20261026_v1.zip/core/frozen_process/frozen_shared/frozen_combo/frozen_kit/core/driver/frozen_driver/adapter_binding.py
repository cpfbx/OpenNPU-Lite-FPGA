"""Read-only pin/import selection. No board CLI, lock access or construction."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parent
HW_SHA='eef6f6f399a9d7579d98d3acd6730753d3cf1c66081ae396295a7eac8622c289'
V2_SHA='1fb87ca56ffb8f60b08d6427438cce0f1b69184d326865059957b2bfd95a6d5b'
def require(ok,message):
    if not ok:raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def inventory(root):
    result={}
    for p in sorted(root.rglob('*')):
        require(not p.is_symlink() and not getattr(p,'is_junction',lambda:False)(),'plain frozen tree')
        if p.is_file():
            b=p.read_bytes();result[p.relative_to(root).as_posix()]=dict(bytes=len(b),sha256=sha(b))
    return result

def verify_sources():
    require(sha((ROOT/'hardware_sources.json').read_bytes())==HW_SHA,'external hardware source pin')
    h=json.loads((ROOT/'hardware_sources.json').read_bytes())
    require(inventory(ROOT/'frozen_hw')=={n:{k:s[k] for k in ('bytes','sha256')} for n,s in h['files'].items()},'hardware source bytes')
    raw=(ROOT/'frozen_v2/candidate_manifest.json').read_bytes()
    require(sha(raw)==V2_SHA,'reviewed v2 pin')
    m=json.loads(raw)['files'];actual=inventory(ROOT/'frozen_v2')
    require(set(actual)==set(m)|{'candidate_manifest.json'} and all(actual[n]==v for n,v in m.items()),'reviewed v2 unchanged')
    # Same bytes, one exact module object: never silently combine foreign classes.
    for n in ('tiled_gemm','chain_protocol','d007_mode11_contract'):
        require((ROOT/'frozen_v2/frozen'/(n+'.py')).read_bytes()==
            (ROOT/'frozen_hw/legacy/frozen_source'/(n+'.py')).read_bytes(),'shared frozen ABI '+n)
    return h

def load(name,path):
    path=path.resolve()
    if name in sys.modules:
        require(Path(getattr(sys.modules[name],'__file__','')).resolve()==path,'fresh process required: '+name)
        return sys.modules[name]
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    return module

def configure():
    verify_sources()
    require(not any(n=='pynq' or n.startswith('pynq.') for n in sys.modules),'cold binding required')
    b=load('binding',ROOT/'frozen_v2/binding.py');b.sources()
    # v2 uses a private _pointwise_counter name; the unchanged driver requires
    # its original public module name. Bind that name to the SAME pinned bytes.
    load('d007_mode11_contract',ROOT/'frozen_v2/frozen/d007_mode11_contract.py')
    load('real_case',ROOT/'frozen_v2/real_case.py')
    load('pointwise_candidate',ROOT/'frozen_v2/pointwise_candidate.py')
    base=ROOT/'frozen_hw/legacy/frozen_source';legacy=ROOT/'frozen_hw/legacy'
    for n in ('pynq_dma_loopback','pynq_gemm','batch_policy','os_evidence','batch_owner',
        'kws_threeway_entry_support_draft','kws_device_supervision_candidate','matrix_panel_builder_candidate'):
        load(n,base/(n+'.py'))
    for n in ('pack_chain_flat_candidate','flat_driver_candidate','lease_entry_candidate','owner_entry_candidate'):
        load(n,legacy/(n+'.py'))
    load('comparison_policy',ROOT/'frozen_hw/src/comparison_policy.py')
    load('comparison_owner',ROOT/'frozen_hw/src/comparison_owner.py')
    load('supervision_bridge',ROOT/'frozen_hw/src/supervision_bridge.py')
    load('kws_device_recovery_candidate',ROOT/'frozen_hw/runtime_fpga/kws_device_recovery_candidate.py')
    return SimpleNamespace(derive=sys.modules['real_case'].derive,software=sys.modules['pointwise_candidate'])

def select(*,enabled=False):
    require(enabled is True,'driver adapter binding default-off')
    configure()
    policy=load('pointwise_policy',ROOT/'pointwise_policy.py')
    owner=load('pointwise_owner',ROOT/'pointwise_owner.py')
    flat=sys.modules['flat_driver_candidate'];driver=sys.modules['pynq_gemm']
    require(flat.FlatPackPynqGemm._submit_chain is driver.PynqGemm._submit_chain,'unchanged submit body')
    return SimpleNamespace(owner_type=owner.PointwiseOwner,policy_type=policy.PointwisePolicy,
        runner_type=flat.flat_runner_type(enabled=True),
        lease_factory=sys.modules['kws_threeway_entry_support_draft'].existing_shared_lock_draft,
        recovery_factory=sys.modules['kws_device_recovery_candidate']._Recovery,
        supervisor=sys.modules['supervision_bridge'].supervised,
        bit_path=ROOT/'frozen_hw/runtime_fpga/opennpu_gemm_accelerator.bit',
        board_activation_approved=False,run_ready=False)

if __name__=='__main__':
    raise SystemExit('Library only. No board launcher or activation authority.')
