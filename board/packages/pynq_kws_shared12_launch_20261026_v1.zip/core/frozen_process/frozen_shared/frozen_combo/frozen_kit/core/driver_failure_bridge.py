"""Read exact immutable driver failures; never serialize unknown objects/text."""
import json
import runtime_binding as rb

def read_first_failure(active,last_payload):
    from op4_driver_call import Op4DriverCall,DriverFailure
    from return_diagnostic import valid
    rb.require(active is None or type(active) is Op4DriverCall,'exact operator4 active call')
    first=None if active is None else active.first_failure
    if first is None:
        rb.require(last_payload is None or type(last_payload) is bytes and len(last_payload)<=32000,'bounded returned payload')
        return last_payload,None
    rb.require(type(first) is DriverFailure and first.accepted is False and first.automatic_retry is False,'exact immutable driver failure')
    rb.require(first.payload is None or type(first.payload) is bytes and len(first.payload)<=32000,'bounded driver failure payload')
    raw=first.return_diagnostic_json
    if raw is None:return first.payload,None
    rb.require(type(raw) is bytes and len(raw)<=8192 and all(byte<128 for byte in raw),'bounded ASCII driver diagnostic')
    from runtime_contract import strict_json
    value=strict_json(raw);rb.require(valid(value),'whitelisted driver diagnostic')
    return first.payload,value
