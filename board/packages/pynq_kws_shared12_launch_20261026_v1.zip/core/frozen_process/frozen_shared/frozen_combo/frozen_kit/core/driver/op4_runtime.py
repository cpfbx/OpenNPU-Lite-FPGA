"""Unmodified operator4 code objects in private namespaces; frozen globals intact."""
import os,sys
from pathlib import Path
from types import FunctionType
import op4_binding as binding
import runtime_reference as driver_reference
_modules=None
_snapshots=None
_files=None
_clones=None
_pid=os.getpid()
def bind():
    global _modules,_snapshots,_files,_clones
    binding.need(_modules is None,'operator4 reference already bound')
    binding.need(not any(n=='pynq' or n.startswith('pynq.') for n in sys.modules),'operator4 cold binding required')
    driver_reference.sources();modules={n:sys.modules[n] for n in ('source_bindings','layer_case','op4_candidate','independent_math')}
    files={};snapshots={}
    for name,module in modules.items():
        path=(binding.ROOT/'frozen_op4'/(name+'.py')).resolve()
        binding.need(Path(module.__file__).resolve()==path,'exact operator4 reference module')
        files[name]=(path,binding.sha(path.read_bytes()));snapshots[name]=driver_reference._snapshot(module)
    layer=dict(vars(modules['layer_case']));layer['sources']=sources
    clones={}
    for name in ('selection','derive'):
        old=getattr(modules['layer_case'],name);binding.need(type(old) is FunctionType and old.__closure__ is None,'plain operator4 function')
        clone=FunctionType(old.__code__,layer,old.__name__,old.__defaults__);clone.__kwdefaults__=old.__kwdefaults__
        layer[name]=clone;clones[name]=clone
    sealed=dict(vars(modules['op4_candidate']));sealed['derive']=clones['derive'];sealed['sources']=sources
    old=modules['op4_candidate'].sealed_case
    clones['sealed_case']=FunctionType(old.__code__,sealed,old.__name__,old.__defaults__)
    _modules,_snapshots,_files,_clones=modules,snapshots,files,clones;sources()
def sources():
    binding.need(os.getpid()==_pid and _modules is not None,'operator4 bound process required')
    result=driver_reference.sources() # Original authorization, engines, modules and byte checks.
    for name,module in _modules.items():
        path,pin=_files[name]
        binding.need(sys.modules.get(name) is module and Path(module.__file__).resolve()==path
            and binding.sha(path.read_bytes())==pin and driver_reference._same_snapshot(module,_snapshots[name]),'operator4 reference module drift')
    return (*result,sys.modules['pointwise_candidate'])
def authorize_owner(owner):
    driver_reference.authorize_owner(owner);sources()
def derive(index):
    sources();return _clones['derive'](index)
def sealed_case(case):
    sources();return _clones['sealed_case'](case)
def make_jobs(a,b):
    sources();return driver_reference.make_jobs(a,b)
