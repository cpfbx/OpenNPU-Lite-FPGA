"""Offline contract tests. ALL hardware, proc, locks and recovery are fixtures."""
import ast
from contextlib import contextmanager
import inspect
from pathlib import Path
import sys
import textwrap
from types import ModuleType
import unittest
from unittest.mock import patch
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import adapter_binding as ab
components=ab.configure()
from pointwise_policy import PointwisePolicy,validate_pointwise_policy
from pointwise_owner import PointwiseOwner
from pointwise_driver_call import PointwiseDriverCall
from batch_policy import BatchPolicy,BatchStop
import comparison_owner
import owner_entry_candidate
import pynq_gemm as driver
from driver_fixture import Harness,FakeCanonicalEnvironment

class AdapterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.case=components.derive(0)
    @contextmanager
    def started(self,**options):
        h=Harness(self.case,**options);env=FakeCanonicalEnvironment()
        with env.install():
            h.start(env)
            try:yield h,env
            finally:
                if not h.owner.supervision_status['held'] and not h.owner._closed:h.owner.close()
                h.discard_synthetic_hold()
    def call(self,h):return PointwiseDriverCall(h.owner,self.case,enabled=True)
    def test_01_policy_default_off(self):
        for value in (False,1,None,'yes'):
            with self.subTest(value=value),self.assertRaises(ValueError):PointwisePolicy(value)
    def test_02_exact_schedule_geometry_ids(self):
        p=PointwisePolicy(True)
        self.assertEqual([p.request(i).cohort_index for i in range(12)],[0,30,60,90,120,150,180,210,240,270,300,400])
        self.assertEqual([p.request(i).first_job_id for i in range(12)],list(range(1,24,2)))
        self.assertEqual((p.geometry.shape,p.geometry.input_bytes,p.geometry.output_bytes,p.geometry.macs),((125,64,64),16512,32000,512000))
    def test_03_no_extra_requests(self):
        for value in (True,0.,-1,12,'0'):
            with self.subTest(value=value),self.assertRaises(ValueError):PointwisePolicy(True).request(value)
    def test_04_old_or_subclass_policy_rejected(self):
        class Derived(PointwisePolicy):pass
        for p in (BatchPolicy('smoke8',True),Derived(True)):
            with self.subTest(policy=type(p).__name__),self.assertRaises(ValueError):validate_pointwise_policy(p)
    def test_05_owner_default_off(self):
        with self.assertRaises(ValueError):PointwiseOwner(PointwisePolicy(True),lambda:False)
    def test_06_binding_default_off(self):
        with self.assertRaises(ValueError):ab.select()
    def test_07_cold_binding_refuses_preimported_pynq(self):
        with patch.dict(sys.modules,{'pynq':ModuleType('pynq')}),self.assertRaises(ValueError):ab.configure()
    def test_08_actual_submit_identity_unchanged(self):
        deps=ab.select(enabled=True)
        self.assertIs(deps.runner_type._submit_chain,driver.PynqGemm._submit_chain)
    def test_09_owner_AST_only_validator_changes(self):
        for name in ('__init__','start','execute_chain'):
            old=textwrap.dedent(inspect.getsource(getattr(comparison_owner.ComparisonOwner,name)))
            new=textwrap.dedent(inspect.getsource(getattr(PointwiseOwner,name)))
            self.assertEqual(ast.dump(ast.parse(old.replace('validate_fpga_policy','validate_pointwise_policy'))),ast.dump(ast.parse(new)))
    def test_10_safety_methods_inherited(self):
        for name in ('_owned','_hold','_identity','_buffers_valid','pre_submit','close'):
            self.assertIs(getattr(PointwiseOwner,name),getattr(owner_entry_candidate.EntrySafeBatchOwner,name))
    def test_11_exact_start_extents_and_safe_close(self):
        with self.started() as (h,env):
            self.assertEqual([b.nbytes for b in h.buffers],[16512,32000]);self.assertTrue(env.held)
            h.owner.close();self.assertFalse(env.held)
            self.assertEqual([e for e in h.events if e[0]=='free'],[('free','rx'),('free','tx')])
            self.assertTrue(h.owner._lease is None and h.owner._runner is None)
    def test_12_call_default_off(self):
        with self.started() as (h,env):
            with self.assertRaises(ValueError):PointwiseDriverCall(h.owner,self.case)
    def test_13_no_software_transport_in_real_call(self):
        with self.assertRaises(ValueError):PointwiseDriverCall(components.software.SoftwareTransport(),self.case,enabled=True)
    def test_14_exact_output_and_raw_checks(self):
        with self.started() as (h,env):
            out,data=self.call(h)(self.case['a'])
            self.assertTrue(np.array_equal(out,self.case['expected']))
            self.assertTrue(np.array_equal(data['raw'],self.case['a'].astype(np.int64)@self.case['weights'].astype(np.int64)))
            self.assertEqual(data['driver_metrics']['effective_macs'],512000)
            self.assertFalse(data['physical_identity_authenticated'])
    def test_15_two_DMA_transfers_and_order(self):
        with self.started() as (h,env):
            self.call(h)(self.case['a'])
            transfers=[e for e in h.events if e[0]=='transfer']
            self.assertEqual(transfers,[('transfer','recv',32000),('transfer','send',16512)])
    def test_16_success_cannot_be_reused(self):
        with self.started() as (h,env):
            call=self.call(h);call(self.case['a']);count=len(h.events)
            with self.assertRaises(ValueError):call(self.case['a'])
            self.assertEqual(count,len(h.events))
    def test_17_cross_window_before_submit(self):
        other=components.derive(30)
        with self.started() as (h,env):
            call=self.call(h)
            with self.assertRaises(ValueError):call(other['a'])
            self.assertFalse(any(e[0]=='transfer' for e in h.events))
    def test_18_bad_input_types_and_views(self):
        for a in (self.case['a'].astype(np.int32),self.case['a'].view(),self.case['a'][:124]):
            with self.subTest(dtype=a.dtype,shape=a.shape),self.started() as (h,env):
                with self.assertRaises(ValueError):self.call(h)(a)
                self.assertFalse(any(e[0]=='transfer' for e in h.events))
    def test_19_forged_expected_rejected(self):
        with self.started() as (h,env):
            case=dict(self.case);case['expected']=case['expected'].copy();case['expected'][0,0]^=1
            with self.assertRaises(ValueError):PointwiseDriverCall(h.owner,case,enabled=True)
    def test_20_wrong_window_constructor_rejected(self):
        case=components.derive(30)
        with self.started() as (h,env):
            with self.assertRaises(ValueError):PointwiseDriverCall(h.owner,case,enabled=True)
    def test_21_case_copied_and_sealed(self):
        with self.started() as (h,env):
            call=self.call(h)
            for k in ('a','weights','bias','expected','scales'):
                self.assertFalse(call.case[k].flags.writeable);self.assertFalse(np.shares_memory(call.case[k],self.case[k]))
    def test_22_raw_one_bit_masked_by_relu_still_rejected(self):
        with self.started() as (h,env):
            call=self.call(h);b=h.engine.payload;h.engine.payload=bytes([b[0]^1])+b[1:]
            with self.assertRaisesRegex(ValueError,'all raw INT32'):call(self.case['a'])
            self.assertFalse(call.accepted);self.assertEqual(len(call.first_failure['payload']),32000)
            count=len(h.events);first=call.first_failure
            with self.assertRaises(ValueError):call(self.case['a'])
            self.assertEqual(len(h.events),count);self.assertIs(call.first_failure,first)
    def test_23_swapped_records_rejected_and_payload_retained(self):
        with self.started() as (h,env):
            run=h.owner._runner.run_chain
            def swapped(*a,**k):
                b,r,m=run(*a,**k);return b,list(reversed(r)),m
            h.owner._runner.run_chain=swapped
            call=self.call(h)
            with self.assertRaises(ValueError):call(self.case['a'])
            self.assertEqual(len(call.first_failure['payload']),32000)
    def test_24_wrong_sequence_counter_rejected(self):
        self.metrics_fault('first_job_id',99)
    def test_25_boolean_counter_rejected(self):self.metrics_fault('jobs',True)
    def test_26_missing_counter_rejected(self):self.metrics_fault('pl_no_work_cycles',None)
    def test_27_conservation_rejected(self):self.metrics_fault('pl_work_union_cycles',99)
    def test_28_wait_bound_rejected(self):self.metrics_fault('pl_output_wait_tready_cycles',999)
    def test_29_nonfinite_seconds_rejected(self):self.metrics_fault('seconds',float('nan'))
    def test_30_synthetic_transport_tag_rejected(self):self.metrics_fault('counter_evidence','SYNTHETIC-SOFTWARE-FIXTURE-NOT-PL')
    def test_31_wrong_mode_rejected(self):self.metrics_fault('mode',9)
    def test_32_wrong_output_extent_rejected(self):self.metrics_fault('output_bytes',32008)
    def metrics_fault(self,key,value):
        with self.started() as (h,env):
            run=h.owner._runner.run_chain
            def fault(*a,**k):
                b,r,m=run(*a,**k);m=dict(m);m[key]=value;return b,r,m
            h.owner._runner.run_chain=fault
            call=self.call(h)
            with self.assertRaises(ValueError):call(self.case['a'])
            self.assertFalse(call.accepted)
    def test_33_stop_before_construction(self):
        with self.started() as (h,env):
            call=self.call(h);h.stop=True
            with self.assertRaises(BatchStop):call(self.case['a'])
            self.assertFalse(any(e[0]=='transfer' for e in h.events))
    def test_34_stop_after_exact_return(self):
        with self.started() as (h,env):
            h.after_submit=lambda h:setattr(h,'stop',True);call=self.call(h)
            with self.assertRaises(BatchStop):call(self.case['a'])
            self.assertFalse(call.accepted);self.assertTrue(call.failed)
    def test_35_call_process_drift(self):
        with self.started() as (h,env):
            call=self.call(h);call.pid=-1
            with self.assertRaises(ValueError):call(self.case['a'])
            self.assertFalse(any(e[0]=='transfer' for e in h.events))
    def test_36_call_reentrant(self):
        with self.started() as (h,env):
            call=self.call(h);call._guard.acquire()
            try:
                with self.assertRaises(ValueError):call(self.case['a'])
            finally:call._guard.release()
    def test_37_missing_lock_no_acquisition_no_runner(self):
        h=Harness(self.case);env=FakeCanonicalEnvironment(missing=True)
        with env.install(),self.assertRaises(FileNotFoundError):h.start(env)
        self.assertIsNone(h.owner._lease);self.assertIsNone(h.owner._runner);self.assertFalse(h.owner._held)
    def test_38_busy_lock_uncertain_entry_held(self):
        self.entry_failure(busy=True)
    def test_39_opaque_factory_failure_held(self):self.entry_failure(factory_error=True)
    def test_40_inode_drift_held(self):self.entry_failure(drift=True)
    def entry_failure(self,**options):
        h=Harness(self.case);env=FakeCanonicalEnvironment(**options)
        with env.install():
            with self.assertRaises(Exception):h.start(env)
            self.assertTrue(h.owner._held and h.owner._unsafe)
            with self.assertRaises(RuntimeError):h.owner.close()
            self.assertFalse(any(e[0]=='free' for e in h.events));h.discard_synthetic_hold()
    def test_41_partial_allocation_held_not_freed(self):
        h=Harness(self.case,allocation_failure=1);env=FakeCanonicalEnvironment()
        with env.install():
            with self.assertRaises(RuntimeError):h.start(env)
            self.assertEqual(len(h.owner._buffers),1);self.assertTrue(h.owner._held)
            with self.assertRaises(RuntimeError):h.owner.close()
            self.assertFalse(any(e[0]=='free' for e in h.events));h.discard_synthetic_hold()
    def test_42_wrong_clock_held(self):
        h=Harness(self.case,clock=99.);env=FakeCanonicalEnvironment()
        with env.install():
            with self.assertRaises(RuntimeError):h.start(env)
            self.assertTrue(h.owner._held);h.discard_synthetic_hold()
    def test_43_driver_counter_error_holds_resources(self):
        with self.started() as (h,env):
            h.engine.set_u64(driver.REG_D7_WORK_UNION_LO,driver.REG_D7_WORK_UNION_HI,999)
            with self.assertRaises(Exception):self.call(h)(self.case['a'])
            self.assertTrue(h.owner._held and h.owner._unsafe)
            with self.assertRaises(RuntimeError):h.owner.close()
            self.assertFalse(any(e[0]=='free' for e in h.events))
    def test_44_cleanup_recovery_uncertain_held(self):
        with self.started() as (h,env):
            h.recovery_ok=False
            with self.assertRaises(RuntimeError):h.owner.close()
            self.assertTrue(h.owner._held);self.assertTrue(env.held)
            self.assertFalse(any(e[0]=='free' for e in h.events))
    def test_45_fresh_identity_drift_prevents_submit(self):
        with self.started() as (h,env):
            h.engine.values[driver.REG_BUILD_ID]=0
            with self.assertRaises(RuntimeError):self.call(h)(self.case['a'])
            self.assertFalse(any(e[0]=='transfer' for e in h.events))
            # Restore fixture only so normal inherited cleanup can be exercised.
            h.engine.values[driver.REG_BUILD_ID]=0x2026D075
    def test_46_buffer_alias_prevents_submit(self):
        with self.started() as (h,env):
            h.buffers[1].physical_address=h.buffers[0].physical_address
            with self.assertRaises(RuntimeError):self.call(h)(self.case['a'])
            self.assertFalse(any(e[0]=='transfer' for e in h.events))
            h.buffers[1].physical_address=0x20000000
    def test_47_schedule_drift_rejected(self):
        with self.started() as (h,env):
            call=self.call(h);h.owner._index=1
            with self.assertRaises(ValueError):call(self.case['a'])
            self.assertFalse(any(e[0]=='transfer' for e in h.events))
    def test_48_select_is_not_activation(self):
        d=ab.select(enabled=True)
        self.assertFalse(d.board_activation_approved);self.assertFalse(d.run_ready)
        self.assertNotIn('pynq',sys.modules)

if __name__=='__main__':unittest.main(verbosity=2)
