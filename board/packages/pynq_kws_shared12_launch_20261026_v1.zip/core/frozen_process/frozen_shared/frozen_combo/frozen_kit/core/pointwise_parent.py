"""Fixed private child + original wait/group/lock observers, no timeout kill."""
import os
from pathlib import Path
import struct
import subprocess
import sys
import threading
import runtime_binding as rb
import runtime_contract as ct

class Guardian:
    def __init__(self):
        self.pid=os.getpid();self.thread=threading.get_ident();self.child=None;self.pending=False;self.used=False;self.held=False
    @property
    def supervision_status(self):
        return dict(pid=self.pid,held=self.held,safety_unresolved=self.held or self.pending,
            lease_retained=False,runner_retained=self.child is not None,root_buffers_retained=0)
    def owned(self):rb.require((os.getpid(),threading.get_ident())==(self.pid,self.thread),'parent ownership drift')
    def begin(self):
        self.owned();rb.require(not self.used and not self.held and self.child is None,'single child; no retry')
        self.used=True;self.pending=True
    def retain(self,child):
        self.owned();rb.require(self.pending and self.child is None and not self.held,'exact pending spawn')
        self.child=child;self.pending=False
    def forget(self,child):
        self.owned();rb.require(not self.held and not self.pending and self.child is child,'unresolved/wrong child')
        self.child=None
    def _hold(self,error):self.held=True

def validate_terminal(folder,child_pid,request,request_sha,fixture):
    t=ct.terminal(folder)
    from failure_diagnostic import valid
    rb.require(valid(t.get('failure_stage'),t.get('diagnostic_summary'),t['operation_success']), 'bounded failure diagnostic')
    from return_diagnostic import SUCCESS_NO_FAILED_TILE, valid as valid_return
    rb.require(valid_return(t.get('return_diagnostic')) and
        (not t['operation_success'] or t.get('return_diagnostic') is None),'bounded return diagnostic')
    rb.require(type(t['pid']) is int and t['pid']==child_pid and t['run_id']==request['run_id']
        and t['request_sha256']==request_sha and t['fixture'] is fixture,'terminal process/request identity')
    rb.require(all(type(t.get(k)) is int and t[k]==v for k,v in {'operator_index':4,'input_tensor':25,'output_tensor':26}.items()),'terminal operator4 identity')
    n=t['accepted_calls'];rb.require(type(n) is int and 0<=n<=12 and t['completed_indices']==list(ct.INDICES[:n])
        and t['not_completed_indices']==list(ct.INDICES[n:]) and len(t['windows'])==n,'exact completion prefix; no skipped windows')
    rb.require(type(t['operation_success']) is bool and t['outer_process_exit_observed'] is False
        and t['automatic_retry'] is False and t['run_ready'] is False and t['promotion'] is False,'receipt scope')
    cleanup=t['cleanup'];ticket=t['ticket']
    import fpga_evidence
    if cleanup.get('kind')=='closed_owner':
        rb.require(type(ticket) is dict and type(ticket.get('pid')) is int and ticket['pid']==child_pid
            and ticket.get('path')==ct.LOCK and (ticket.get('device'),ticket.get('inode'))==
                (request['expected_lock']['device'],request['expected_lock']['inode']),'same canonical acquired ticket')
        fpga_evidence.validate_cleanup({k:cleanup[k] for k in ('owner_closed','readback')},ticket,child_pid)
    elif cleanup.get('kind')=='no_resources':
        rb.require(ticket is None and n==0 and t['operation_success'] is False,'explicit pre-resource failure only')
        status=cleanup.get('resources',{})
        for k,v in dict(pid=child_pid,held=False,safety_unresolved=False,lease_retained=False,runner_retained=False,root_buffers_retained=0).items():
            rb.require(type(status.get(k)) is type(v) and status[k]==v,'no-resource status '+k)
    else:raise ValueError('unknown cleanup; retain child')
    catalog=rb.verify_sources();bank={r['cohort_index']:r for r in catalog['golden_bank']}
    for index,row in enumerate(t['windows']):
        idx=ct.INDICES[index];sub=folder/('window_%03d'%idx)
        rb.require(row==ct.ready_json(sub/'result.json') and row['index']==index and row['cohort_index']==idx
            and row['first_job_id']==1+2*index and row['exact_values']==8000 and row['source_id']==bank[idx]['source_id']
            and all(type(row.get(k)) is int and row[k]==v for k,v in {'operator_index':4,'input_tensor':25,'output_tensor':26}.items()),'fixed per-window operator4 record')
        rb.require(set(row['artifacts'])=={'request_chain.bin','raw_output.i32','corrected.i32','candidate_output.i8'},'four exact outputs')
        for name,pin in row['artifacts'].items():
            raw=ct.read(sub/name,32000);rb.require(dict(bytes=len(raw),sha256=rb.sha(raw))==pin,'output bytes/pin')
            expected=(rb.ROOT/'golden'/('window_%03d'%idx)/name).read_bytes()
            if name=='request_chain.bin':
                expected=bytearray(expected);struct.pack_into('<I',expected,8,1+2*index);struct.pack_into('<I',expected,8264,2+2*index)
            rb.require(raw==expected,'all retained values equal reviewed fixed golden')
        m=row['driver_metrics'];from d007_mode11_contract import validate_summary
        wanted=dict(mode=11,jobs=2,chain_jobs_completed=2,input_bytes=16512,input_payload_bytes=16384,input_header_bytes=128,output_bytes=32000,
            output_valid_bytes=32000,effective_macs=512000,first_job_id=1+2*index,error_code=0,
            failed_tile_index=SUCCESS_NO_FAILED_TILE,counter_contract_version=2)
        rb.require(type(m) is dict and all(type(m.get(k)) is int and m[k]==v for k,v in wanted.items())
            and m.get('counter_contract')=='d007_global_work_v2' and m.get('layout')=='k_major'
            and type(m.get('status')) is int and m['status']&(2|4|8)==4
            and m.get('mode11_counter_read_strategy')=='pynq_mmio_read' and 'counter_evidence' not in m
            and all(validate_summary(m).values()),'parent counter contract')
    if t['operation_success']:
        rb.require(n==12 and cleanup['kind']=='closed_owner' and t['error_type'] is None and t['secondary_error_types']==[]
            and t['signals']=={'stop_signals':[],'handler_errors':[],'handler_restore_errors':[],'original_supervisor_unchanged':True},'clean complete success only')
    return t

def launch(config,config_sha,folder,*,enabled=False,confirmed=False,fixture=False,popen_factory=None,
           group_query=None,snapshot=None,live_query=None,release_query=None,fixture_supervise=None,fixture_parent_start=None):
    rb.require(enabled is True and confirmed is True,'private parent default-off; separate approval required')
    injected=any(q is not None for q in (popen_factory,group_query,snapshot,live_query,release_query,fixture_supervise,fixture_parent_start))
    rb.require(type(fixture) is bool and (fixture or not injected),'real parent rejects injected evidence')
    request=ct.read_request(config,config_sha)
    if not fixture:rb.require_arm();rb.require_boot(request['expected_boot']);rb.verify_candidate(request['candidate_manifest_sha256'])
    rb.configure()
    from process_observer import observe_exit
    from supervision_bridge import supervised
    from os_evidence import process_start,read_text
    from batch_policy import BatchStop
    import fpga_evidence
    evidence=ct.canonical(folder)
    rb.require(not os.path.lexists(evidence) and not evidence.is_relative_to(rb.ROOT),'fresh external parent evidence')
    ct.write_json(ct.canonical(config).parent/('attempt_'+request['run_id']+'.json'),dict(request_sha256=config_sha,run_id=request['run_id']))
    identity=(snapshot or fpga_evidence.snapshot)();rb.require(identity==request['expected_lock'],'predeclared same inode')
    # Initial absence is not a reservation/board-idle certificate.
    initial_release=(release_query or fpga_evidence.released)(identity)
    rb.require(type(initial_release) is dict and initial_release.get('lock_released_same_inode') is True,
        'initial read-only absence check failed; not a reservation')
    evidence.mkdir(mode=0o700);worker=evidence/'worker';worker.mkdir(mode=0o700)
    guardian=Guardian();primary=None;secondary=[];child_terminal=None;ready=None;go_sent=False
    record=dict(operation_success=False,request_sha256=config_sha,run_id=request['run_id'],fixture=fixture,
        evidence_injected=injected,actual_exit_code=None,actual_wait_observed=False,process_group_absent=None,
        cleanup_verified=False,lock_released_same_inode=False,automatic_kill=False,automatic_retry=False,
        board_activation_approved=False,run_ready=False,promotion=False)
    def remember(error):
        nonlocal primary
        if primary is None:primary=error
        elif error is not primary:secondary.append(type(error).__name__)
    parent_start=(fixture_parent_start or (lambda:process_start(read_text('/proc/self/stat',8192))))()
    binding=dict(request_sha256=config_sha,expected_lock=identity,parent_pid=os.getpid(),parent_start_ticks=parent_start,run_id=request['run_id'])
    launch_pin=ct.write_json(evidence/'launch.json',binding)['sha256']
    def cancel():
        if not os.path.lexists(evidence/'stop.flag'):ct.write_bytes(evidence/'stop.flag',b'')
    def publish(value):ct.write_json(evidence/'attention_retained.json',dict(value,request_sha256=config_sha,fixture=fixture))
    def operation(stopped):
        nonlocal ready,go_sent,child_terminal
        child=None
        def monitor():
            nonlocal ready,go_sent
            if primary is not None or ct.ready_json(worker/'fault.json') is not None:return True
            value=ct.ready_json(worker/'ready.json')
            if value is not None and not go_sent:
                rb.require(type(value['pid']) is int and value['pid']==child.pid and value['run_id']==request['run_id']
                    and value['request_sha256']==config_sha and value['identity']==identity and value['fixture'] is fixture,'worker readiness binding')
                rb.require((live_query or fpga_evidence.verify_live)(value['ticket'],child.pid,identity) is True,'live child lease proof')
                ready=value
                ct.write_json(evidence/'go.json',dict(kind='go',pid=child.pid,parent_pid=os.getpid(),run_id=request['run_id'],
                    request_sha256=config_sha,ready_sha256=rb.sha(ct.read(worker/'ready.json',65536))))
                go_sent=True
            return stopped()
        try:
            if stopped() is not False:raise BatchStop('stop before child creation')
            command=[sys.executable,'-I','-B',str(rb.ROOT/'private_worker_entry.py'),
                '--request',str(ct.canonical(config)),'--request-sha',config_sha,'--launch',str(evidence/'launch.json'),
                '--launch-sha',launch_pin,'--folder',str(worker),'--enabled-private-child']
            with (evidence/'child.stdout').open('xb') as out,(evidence/'child.stderr').open('xb') as err:
                options=dict(stdin=subprocess.DEVNULL,stdout=out,stderr=err,close_fds=True,shell=False)
                if os.name=='posix':options['start_new_session']=True
                else:options['creationflags']=subprocess.CREATE_NO_WINDOW
                guardian.begin()
                try:child=(popen_factory or subprocess.Popen)(command,**options);guardian.retain(child)
                except BaseException as error:guardian._hold(error);raise
                try:ct.write_json(evidence/'child_started.json',dict(pid=child.pid,request_sha256=config_sha))
                except BaseException as error:remember(error);cancel()
                try:record.update(observe_exit(child,guardian,monitor,cancel,group_query=group_query))
                except BaseException as error:
                    partial=getattr(error,'comparison_exit_observation',None)
                    if partial is not None:record.update(partial)
                    remember(error)
            try:ct.write_json(evidence/'observed_child_exit.json',record)
            except BaseException as error:remember(error)
            rb.require(record['actual_wait_observed'] is True and record['process_group_absent'] is True,'actual wait/group proof')
            child_terminal=validate_terminal(worker,child.pid,request,config_sha,fixture)
            if ready is not None:rb.require(child_terminal['ticket']==ready['ticket'],'same acquired live ticket at cleanup')
            release=(release_query or fpga_evidence.released)(identity)
            rb.require(type(release) is dict and release.get('lock_released_same_inode') is True
                and all(release.get(k)==v for k,v in identity.items()),'same-inode release readback')
            record.update(cleanup_verified=True,lock_released_same_inode=True,release_readback=release,
                child_terminal=child_terminal,live_ticket_observed=ready is not None,parent_go_sent=go_sent)
            guardian.forget(child)
            if primary is not None:raise primary
            rb.require(record['actual_exit_code']==0 and child_terminal['operation_success'] is True and ready is not None and go_sent
                and record['stop_seen'] is False,'complete normal operation only')
            record['operation_success']=True;return record
        except BaseException as error:
            remember(error)
            if guardian.child is not None or guardian.pending:guardian._hold(error)
            raise primary
    try:
        result=(fixture_supervise or supervised)(guardian,operation,publish,
            lambda:os.path.lexists(evidence/'stop.flag'),enabled=True);record['signals']=result['signals']
    except BaseException as error:
        remember(error);record['signals']=getattr(error,'supervision_bridge_observation',None)
    # Original unresolved supervisor cannot reach here with a live/unknown child.
    rb.require(not guardian.held and not guardian.pending and guardian.child is None,'supervisor returned unresolved parent')
    record.update(operation_success=record['operation_success'] and primary is None,error_type=None if primary is None else type(primary).__name__,secondary_error_types=secondary)
    ct.write_json(evidence/'outer_receipt.json',record)
    if primary is not None:raise primary
    return record

if __name__=='__main__':raise SystemExit('Private parent library; no public board activation command.')
