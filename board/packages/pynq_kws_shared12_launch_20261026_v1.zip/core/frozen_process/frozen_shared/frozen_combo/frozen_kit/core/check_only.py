"""Read-only identity check. Not a board launcher."""
import argparse
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import runtime_binding as rb
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--manifest-sha',required=True);a=p.parse_args()
    rb.verify_candidate(a.manifest_sha)
    print(dict(check_pass=True,board_access=False,activation_approved=False,run_ready=False,promotion=False))
