"""Private candidate worker. Hardware acquisition ONLY inside frozen supervision."""
import os
from pathlib import Path
import sys
import time
import runtime_binding as rb
import runtime_contract as ct
from failure_diagnostic import diagnostic

def validate_launch(value,request,request_sha):
    rb.require(type(value) is dict and set(value)=={'request_sha256','expected_lock','parent_pid','parent_start_ticks','run_id'},'exact launch binding')
    rb.require(value['request_sha256']==request_sha and value['expected_lock']==request['expected_lock']
        and value['run_id']==request['run_id'] and type(value['parent_pid']) is int and value['parent_pid']>1
        and type(value['parent_start_ticks']) is int and value['parent_start_ticks']>0,'launch request/parent identity')
    return value

def run_worker(request,request_sha,folder,launch,*,enabled=False,fixture=False,fixture_owner=None,
               fixture_start=None,fixture_gate=None,fixture_parent_alive=None,fixture_supervise=None,fixture_before_case=None):
    rb.require(enabled is True,'worker default-off');ct.validate_request(request);ct.digest(request_sha)
    validate_launch(launch,request,request_sha)
    injected=any(x is not None for x in (fixture_owner,fixture_start,fixture_gate,fixture_parent_alive,fixture_supervise,fixture_before_case))
    rb.require(type(fixture) is bool and (fixture or not injected),'real worker rejects injected dependencies')
    if not fixture:rb.require_arm();rb.require_boot(request['expected_boot']);rb.verify_candidate(request['candidate_manifest_sha256'])
    a=rb.configure();deps=a.select(enabled=True)
    from op4_driver_call import Op4DriverCall
    from op4_runtime import derive, authorize_owner
    from op4_candidate import input_for
    from driver_failure_bridge import read_first_failure
    from batch_policy import BatchStop
    from os_evidence import process_start,read_text
    folder=ct.canonical(folder);rb.require(folder.is_dir() and not any(folder.iterdir()) and not folder.is_relative_to(rb.ROOT),'fresh external worker directory')
    outer=folder.parent;holder={};primary=None;secondary=[];ticket=None;rows=[];active=None;signals=None;last_payload=None
    pid=os.getpid()
    stage='before_owner_start';failure=None;return_diagnostic=None
    def parent_alive():
        try:return os.getppid()==launch['parent_pid'] and process_start(read_text('/proc/%d/stat'%launch['parent_pid'],8192))==launch['parent_start_ticks']
        except (OSError,ValueError):return False
    def external_stopped():
        return os.path.lexists(outer/'stop.flag') or (fixture_parent_alive or parent_alive)() is not True
    holder['stop']=external_stopped
    owner=fixture_owner or deps.owner_type(deps.policy_type(enabled=True),lambda:holder['stop'](),enabled=True)
    rb.require(type(owner) is deps.owner_type,'exact reviewed owner')
    if fixture_owner is not None:owner.stop_requested=lambda:holder['stop']()
    def remember(error):
        nonlocal primary,failure
        if primary is None:primary=error;failure=diagnostic(stage,error)
        elif error is not primary:secondary.append(type(error).__name__)
    def publish(value):
        ct.write_json(folder/'attention_retained.json',dict(value,request_sha256=request_sha,
            primary_error_type=None if primary is None else type(primary).__name__,secondary_error_types=list(secondary),fixture=fixture))
    def gate(stopped):
        while True:
            if stopped() is not False:raise BatchStop('stop while waiting for parent GO')
            value=ct.ready_json(outer/'go.json')
            if value is not None:
                rb.require(value==dict(kind='go',pid=pid,parent_pid=launch['parent_pid'],run_id=request['run_id'],
                    request_sha256=request_sha,ready_sha256=rb.sha(ct.read(folder/'ready.json',65536))),'bound parent GO')
                return
            time.sleep(.05)
    def operation(stopped):
        nonlocal ticket,active,last_payload,stage,return_diagnostic
        holder['stop']=stopped
        try:
            if stopped() is not False:raise BatchStop('stop before owner start')
            stage='owner_start'
            if fixture_start is None:owner.start(deps.runner_type,deps.bit_path,deps.lease_factory,deps.recovery_factory)
            else:fixture_start()
            ticket=owner._lease.audit()
            stage='bind_owner_reference';authorize_owner(owner)
            ct.write_json(folder/'ready.json',dict(kind='ready',pid=pid,run_id=request['run_id'],request_sha256=request_sha,
                ticket=ticket,identity=request['expected_lock'],fixture=fixture))
            stage='wait_parent_go';(fixture_gate or gate)(stopped)
            for index,cohort_index in enumerate(ct.INDICES):
                if stopped() is not False:raise BatchStop('stop before next fixed request')
                active=None;last_payload=None;stage='derive_window';case=derive(cohort_index)
                if fixture_before_case is not None:fixture_before_case(case)
                stage='driver_call_init'
                active=Op4DriverCall(owner,case,enabled=True)
                ct.write_json(folder/('entered_%02d.json'%index),dict(index=index,cohort_index=cohort_index,pid=pid,request_sha256=request_sha))
                stage='driver_call_exec';result,data=active(input_for(case))
                last_payload=data['reply_tile_order']
                stage='write_window_artifacts'
                window=folder/('window_%03d'%cohort_index);window.mkdir(mode=0o700)
                artifacts={}
                for name,b in {'request_chain.bin':data['input_chain'],'raw_output.i32':data['raw'].astype('<i4').tobytes(),
                        'corrected.i32':data['corrected'].astype('<i4').tobytes(),'candidate_output.i8':result.tobytes()}.items():
                    artifacts[name]=ct.write_bytes(window/name,b)
                row=dict(index=index,cohort_index=cohort_index,first_job_id=1+2*index,source_id=case['source_id'],
                    operator_index=4,input_tensor=25,output_tensor=26,
                    driver_metrics=data['driver_metrics'],artifacts=artifacts,exact_values=8000)
                ct.write_json(window/'result.json',row);rows.append(row)
        except BaseException as error:
            remember(error)
            try:
                try:payload,return_diagnostic=read_first_failure(active,last_payload)
                except BaseException as diagnostic_error:
                    remember(diagnostic_error);payload=None;return_diagnostic=None
                fault=dict(request_sha256=request_sha,pid=pid,error_type=type(primary).__name__,
                    completed_indices=[r['cohort_index'] for r in rows],payload=None,fixture=fixture,
                    return_diagnostic=return_diagnostic,**failure)
                if type(payload) is bytes and len(payload)<=32000:
                    fault['payload']=dict(path='first_failure_tile_order.bin',**ct.write_bytes(folder/'first_failure_tile_order.bin',payload))
                ct.write_json(folder/'fault.json',fault)
            except BaseException as secondary_error:remember(secondary_error)
        finally:
            stage='cleanup'
            try:owner.close()
            except BaseException as cleanup_error:remember(cleanup_error)
        if primary is not None:raise primary
        return True
    supervise=fixture_supervise or deps.supervisor
    try:
        observed=supervise(owner,operation,publish,external_stopped,enabled=True);signals=observed['signals']
    except BaseException as error:
        remember(error);signals=getattr(error,'supervision_bridge_observation',None)
    # The unchanged supervisor NEVER reaches here with unresolved real resources.
    status=owner.supervision_status
    rb.require(not any(status[k] for k in ('held','safety_unresolved','lease_retained','runner_retained','root_buffers_retained')),
        'supervisor returned with unresolved resources')
    cleanup=(dict(kind='closed_owner',owner_closed=True,readback=owner.cleanup_readback)
        if ticket is not None else dict(kind='no_resources',resources=status))
    success=primary is None and len(rows)==12
    result=dict(operation_success=success,pid=pid,run_id=request['run_id'],request_sha256=request_sha,fixture=fixture,
        operator_index=4,input_tensor=25,output_tensor=26,
        completed_indices=[r['cohort_index'] for r in rows],not_completed_indices=list(ct.INDICES[len(rows):]),
        accepted_calls=len(rows),ticket=ticket,cleanup=cleanup,windows=rows,signals=signals,
        error_type=None if primary is None else type(primary).__name__,secondary_error_types=secondary,
        **(dict(failure_stage=None,diagnostic_summary=None) if primary is None else failure),
        return_diagnostic=return_diagnostic,
        outer_process_exit_observed=False,automatic_retry=False,board_activation_approved=False,run_ready=False,promotion=False)
    pin=ct.write_json(folder/'artifact_manifest.json',dict(files=ct.manifest(folder)))
    result['artifact_manifest_sha256']=pin['sha256'];ct.write_json(folder/'terminal.json',result)
    return result

if __name__=='__main__':
    raise SystemExit('Private worker library; use separately reviewed/approved entry, not this file directly.')
