"""Offline pinned byte check only; no model inference."""
import argparse,sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from source_bindings import verify_candidate
def main():
    p=argparse.ArgumentParser();p.add_argument('--candidate-sha',required=True);args=p.parse_args();actual=verify_candidate(args.candidate_sha)
    print(json.dumps(dict(check_pass=True,files=len(actual),board_access=False,activation_approved=False,promotion=False)))
if __name__=='__main__':
    try:main()
    except (ValueError,OSError) as error:print(type(error).__name__+': '+str(error),file=sys.stderr);raise SystemExit(2)
