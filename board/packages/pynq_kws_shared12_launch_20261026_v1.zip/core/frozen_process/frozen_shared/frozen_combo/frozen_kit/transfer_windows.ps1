[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][ValidateSet('Upload','Download')][string]$Mode,
    [Parameter(Mandatory=$true)][ValidatePattern('^[a-fA-F0-9]{64}$')][string]$ExpectedSha256,
    [string]$Package,
    [string]$BoardArchive,
    [string]$DestinationParent
)
$ErrorActionPreference = 'Stop'
$sshOptions = @('-o','PreferredAuthentications=password','-o','PubkeyAuthentication=no','-o','NumberOfPasswordPrompts=1')
if ($Mode -eq 'Upload') {
    if (-not (Test-Path -LiteralPath $Package -PathType Leaf)) { throw 'Package is missing.' }
    $localItem = Get-Item -LiteralPath $Package
    if (($localItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Aliased package refused.' }
    $Package = $localItem.FullName
    if ((Get-FileHash -LiteralPath $Package -Algorithm SHA256).Hash.ToLowerInvariant() -ne $ExpectedSha256.ToLowerInvariant()) { throw 'Local ZIP hash mismatch.' }
    if ((Read-Host 'Upload only; no remote execution or test. Type UPLOADONLY') -ne 'UPLOADONLY') { throw 'Declined.' }
    $remoteZip = '/home/xilinx/pointwise_upload_' + [guid]::NewGuid().ToString('N') + '.zip'
    # Generated path is restricted to a fixed literal directory and hex suffix.
    & ssh @sshOptions 'xilinx@192.168.2.99' ('test ! -e ' + $remoteZip + ' && test ! -L ' + $remoteZip)
    if ($LASTEXITCODE -ne 0) { throw 'Absence check failed; no upload.' }
    & scp @sshOptions $Package ('xilinx@192.168.2.99:' + $remoteZip)
    if ($LASTEXITCODE -ne 0) { throw 'Upload failed; retain partial remote file, no retry.' }
    Write-Output "REMOTE_ZIP=$remoteZip"
    Write-Output ('EXPECTED_SHA256=' + $ExpectedSha256.ToLowerInvariant())
    Write-Output 'UPLOAD ONLY COMPLETE. Return output before any board preparation.'
} else {
    if ($BoardArchive -cnotmatch '^/home/xilinx/op4pointwise_return_[a-f0-9]{32}/op4pointwise12_evidence_v1[.]tar[.]gz$') { throw 'Unexpected archive path.' }
    if (-not (Test-Path -LiteralPath $DestinationParent -PathType Container)) { throw 'Existing destination parent required.' }
    if ((Read-Host 'Download existing archive only, no workload. Type DOWNLOADONLY') -ne 'DOWNLOADONLY') { throw 'Declined.' }
    $receiveDir = Join-Path $DestinationParent ('board_return_' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $receiveDir -ErrorAction Stop | Out-Null
    $receivedFile = Join-Path $receiveDir 'op4pointwise12_evidence_v1.tar.gz'
    & scp @sshOptions ('xilinx@192.168.2.99:' + $BoardArchive) $receivedFile
    if ($LASTEXITCODE -ne 0) { throw 'Download failed; retain partial directory, no retry.' }
    $actualSha = (Get-FileHash -LiteralPath $receivedFile -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualSha -ne $ExpectedSha256.ToLowerInvariant()) { throw 'Transport hash mismatch; retain received original.' }
    Write-Output "ORIGINAL=$receivedFile"
    Write-Output "SHA256=$actualSha"
}
