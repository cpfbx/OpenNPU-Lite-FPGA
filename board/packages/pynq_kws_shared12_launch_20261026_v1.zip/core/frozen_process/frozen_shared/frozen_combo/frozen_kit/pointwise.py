"""Explicit user-operated Pointwise12 candidate. No implicit board activation."""
import argparse
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import site_support as s
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--kit-manifest-sha',required=True)
    sub=p.add_subparsers(dest='mode',required=True)
    sub.add_parser('check')
    probe=sub.add_parser('preflight');probe.add_argument('--output',required=True);probe.add_argument('--enable-readonly-probe',action='store_true')
    prepare=sub.add_parser('prepare');prepare.add_argument('--preflight',required=True);prepare.add_argument('--preflight-sha',required=True)
    prepare.add_argument('--evidence-parent',required=True);prepare.add_argument('--board-declaration',required=True);prepare.add_argument('--prepare-data-only',action='store_true')
    for name in ('inspect-plan','run','stop','readback','archive'):
        q=sub.add_parser(name);q.add_argument('--work',required=True);q.add_argument('--plan-sha',required=True)
        if name=='run':q.add_argument('--enable-board-candidate',action='store_true')
        elif name=='stop':q.add_argument('--cooperative-only',action='store_true')
        elif name=='readback':q.add_argument('--output',required=True)
        elif name=='archive':q.add_argument('--export-parent',required=True);q.add_argument('--preserve-only',action='store_true')
    a=p.parse_args();s.verify_kit(a.kit_manifest_sha)
    if a.mode=='check':result=dict(check_pass=True,scope='local pinned bytes only',board_activation_approved=False,hardware_access=False,lock_acquired=False,run_ready=False,promotion=False)
    elif a.mode=='inspect-plan':
        import os
        plan,_,_=s.validate_plan(a.work,a.plan_sha,a.kit_manifest_sha);work=s.outside(a.work)
        s.require(not any(os.path.lexists(work/n) for n in ('invocation.json','evidence','shell_attempt.txt','launcher_exit.txt','attempt_'+plan['run_id']+'.json')),'fresh prepared session only')
        result=dict(plan_pass=True,scope='prepared bytes only; no live observations',hardware_access=False,run_ready=False,promotion=False)
    elif a.mode in ('preflight','prepare','run','stop'):
        import site_actions as x
        if a.mode=='preflight':result=x.preflight(a.output,a.kit_manifest_sha,enabled=a.enable_readonly_probe)
        elif a.mode=='prepare':result=x.prepare(a.preflight,a.preflight_sha,a.evidence_parent,a.board_declaration,a.kit_manifest_sha,enabled=a.prepare_data_only)
        elif a.mode=='run':result=x.run(a.work,a.plan_sha,a.kit_manifest_sha,enabled=a.enable_board_candidate)
        else:result=x.stop(a.work,a.plan_sha,a.kit_manifest_sha,enabled=a.cooperative_only)
    else:
        import site_readback as r
        if a.mode=='readback':
            out=s.outside(a.output);s.require(not out.exists(),'fresh readback result');result=r.verify(a.work,a.plan_sha,a.kit_manifest_sha)
            s.write_json(out,result)
        else:result=r.archive(a.work,a.plan_sha,a.kit_manifest_sha,a.export_parent,preserve_only=a.preserve_only)
    print(json.dumps(result,sort_keys=True));return 0
if __name__=='__main__':
    try:raise SystemExit(main())
    except (OSError,ValueError,RuntimeError,ImportError,KeyError,TypeError) as error:
        print(json.dumps(dict(operation_success=False,error_type=type(error).__name__,error=str(error),automatic_retry=False,
            automatic_kill=False,run_ready=False,promotion=False)),file=sys.stderr);raise SystemExit(2)
