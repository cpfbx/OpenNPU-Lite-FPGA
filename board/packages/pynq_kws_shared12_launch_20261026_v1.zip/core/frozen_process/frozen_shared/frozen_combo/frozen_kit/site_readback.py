"""Read existing evidence only. No live lock probe, inference, or resource cleanup."""
import io
import os
from pathlib import Path
import tarfile
import uuid
import site_support as s
def shell_exit(work):
    raw=s.read(work/'launcher_exit.txt',16);s.require(raw.endswith(b'\n') and raw[:-1].isdigit(),'shell-observed numeric exit')
    code=int(raw);s.require(0<=code<=255,'shell exit range');return code
def verify(work,plan_pin,kit_pin):
    s.verify_kit(kit_pin);work=s.outside(work);plan,_,req=s.validate_plan(work,plan_pin,kit_pin,relocated=True)
    s.require(shell_exit(work)==0,'actual shell wait was not zero')
    inv=s.parse(s.read(work/'invocation.json'))
    s.require(inv==dict(schema='pointwise-launch-invocation-candidate-v1',operator='bx',confirmation='OP4POINTWISE12',plan_sha256=plan_pin,
        request_sha256=plan['request_sha256'],kit_manifest_sha256=kit_pin,run_id=plan['run_id'],fixture=False,
        approval_is_operator_declaration=True,physical_identity_authenticated=False),'exact invocation binding')
    rb=s.load_core('runtime_binding');rb.configure();ct=s.load_core('runtime_contract');parent=s.load_core('pointwise_parent')
    evidence=work/'evidence';out=ct.ready_json(evidence/'outer_receipt.json',400000)
    s.require(type(out) is dict,'completed outer receipt')
    for k,v in dict(operation_success=True,actual_exit_code=0,actual_wait_observed=True,process_group_absent=True,group_query_injected=False,
            cleanup_verified=True,lock_released_same_inode=True,fixture=False,evidence_injected=False,automatic_kill=False,automatic_retry=False,
            board_activation_approved=False,run_ready=False,promotion=False,stop_seen=False,live_ticket_observed=True,parent_go_sent=True,error_type=None).items():
        s.require(type(out.get(k)) is type(v) and out[k]==v,'outer check '+k)
    s.require(out.get('secondary_error_types')==[] and out.get('signals')==dict(stop_signals=[],handler_errors=[],handler_restore_errors=[],original_supervisor_unchanged=True),'clean outer signals')
    s.require(out['run_id']==req['run_id'] and out['request_sha256']==plan['request_sha256'],'outer request/run binding')
    started=ct.ready_json(evidence/'child_started.json');s.require(type(started) is dict and set(started)=={'pid','request_sha256'}
        and type(started['pid']) is int and started['pid']>1 and started['request_sha256']==plan['request_sha256'],'started child binding')
    t=parent.validate_terminal(evidence/'worker',started['pid'],req,plan['request_sha256'],False)
    s.require(t==out['child_terminal'] and t['operation_success'] is True and t['accepted_calls']==12,'complete identical child terminal')
    ready=ct.ready_json(evidence/'worker/ready.json');launch=ct.ready_json(evidence/'launch.json')
    s.require(type(launch) is dict and set(launch)=={'request_sha256','expected_lock','parent_pid','parent_start_ticks','run_id'}
        and launch['request_sha256']==plan['request_sha256'] and launch['run_id']==req['run_id'] and launch['expected_lock']==req['expected_lock']
        and type(launch['parent_pid']) is int and launch['parent_pid']>1 and type(launch['parent_start_ticks']) is int and launch['parent_start_ticks']>0,'parent launch binding')
    s.require(ready==dict(kind='ready',pid=started['pid'],run_id=req['run_id'],request_sha256=plan['request_sha256'],ticket=t['ticket'],
        identity=req['expected_lock'],fixture=False),'live readiness record')
    go=ct.ready_json(evidence/'go.json')
    s.require(go==dict(kind='go',pid=started['pid'],parent_pid=launch['parent_pid'],run_id=req['run_id'],request_sha256=plan['request_sha256'],
        ready_sha256=s.sha(s.read(evidence/'worker/ready.json'))),'bound GO')
    observed=ct.ready_json(evidence/'observed_child_exit.json',400000)
    for k in ('actual_exit_code','actual_wait_observed','process_group_absent','group_query_injected','request_sha256','run_id','fixture','evidence_injected'):
        s.require(type(observed.get(k)) is type(out[k]) and observed[k]==out[k],'observed wait '+k)
    s.require(out['release_readback']==dict(req['expected_lock'],lock_released_same_inode=True,
        source='lstat same inode + no matching FLOCK in proc/locks; no acquisition probe'),'same-inode release record')
    return dict(operation_success=True,operator_index=4,input_tensor=25,output_tensor=26,samples=12,jobs=24,effective_macs=6144000,raw_values=96000,corrected_values=96000,INT8_values=96000,
        plan_sha256=plan_pin,request_sha256=plan['request_sha256'],kit_manifest_sha256=kit_pin,core_manifest_sha256=s.CORE_SHA,
        inference_reexecuted=False,live_lock_access=False,hardware_access=False,source_origin_authenticated=False,
        operator_exit_record_authenticated=False,performance_evaluated=False,energy_evaluated=False,run_ready=False,promotion=False)
def archive(work,plan_pin,kit_pin,parent,*,preserve_only=False):
    work=s.outside(work);s.verify_kit(kit_pin);s.validate_plan(work,plan_pin,kit_pin,relocated=True)
    if preserve_only:
        result=dict(operation_success=False,scope='preserve existing ended attempt only; no numerical acceptance',shell_reported_exit=shell_exit(work),
            hardware_access=False,live_lock_access=False,run_ready=False,promotion=False)
    else:result=verify(work,plan_pin,kit_pin)
    parent=s.outside(parent);s.require(parent.is_dir() and not parent.is_relative_to(work),'export parent outside original work');before=s.inventory(work)
    target=parent/('op4pointwise_return_'+uuid.uuid4().hex);target.mkdir(mode=0o755)
    s.require(target.stat().st_mode&0o005==0o005,'export directory not traversable/readable; retain, no chmod')
    report_bytes=(s.json.dumps(result,sort_keys=True,indent=2)+'\n').encode()
    path=target/'op4pointwise12_evidence_v1.tar.gz'
    with tarfile.open(path,'x:gz') as tar:
        for name,pin in before.items():
            raw=s.read(work/name);s.require(dict(bytes=len(raw),sha256=s.sha(raw))==pin,'archive input changed')
            info=tarfile.TarInfo('work/'+name);info.size=len(raw);info.mode=0o644;tar.addfile(info,io.BytesIO(raw))
        info=tarfile.TarInfo('readback.json');info.size=len(report_bytes);info.mode=0o644;tar.addfile(info,io.BytesIO(report_bytes))
    s.require(before==s.inventory(work),'work changed during archive; retain candidate archive, not accepted')
    s.require(path.stat().st_mode&0o004,'archive not readable by transfer account; no chmod')
    b=s.read(path);return dict(archive=str(path),bytes=len(b),sha256=s.sha(b),numerical_acceptance=result['operation_success'],
        preserve_only=preserve_only,hardware_access=False,automatic_retry=False,promotion=False)
