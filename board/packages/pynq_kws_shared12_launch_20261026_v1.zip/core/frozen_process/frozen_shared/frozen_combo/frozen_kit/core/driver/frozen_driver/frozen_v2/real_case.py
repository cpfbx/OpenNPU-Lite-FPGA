"""Approved fixed twelve windows; original prefix verified without source edits."""
import json
import numpy as np
from binding import ROOT, sources, require, sha


APPROVED_INDICES=(0,30,60,90,120,150,180,210,240,270,300,400)
APPROVED_LABELS=('down','go','left','no','off','on','right','stop','up','yes','_unknown_','_silence_')


def selected_items():
    # Selection is based ONLY on the frozen metadata, never inference outcomes.
    sources()
    cohort=json.loads((ROOT/'frozen/data/cohort.json').read_bytes())
    require(type(cohort) is list and len(cohort)==420,'fixed 420-window cohort')
    first={}
    for index,item in enumerate(cohort):
        first.setdefault(item['label'],index)
    require(tuple(first)==APPROVED_LABELS and tuple(first.values())==APPROVED_INDICES,
        'approved first-per-label selection differs')
    return tuple(dict(cohort_index=i,**cohort[i]) for i in APPROVED_INDICES)


def derive(index=0):
    require(type(index) is int and index in APPROVED_INDICES,'exact approved integer window index')
    item=next(row for row in selected_items() if row['cohort_index']==index)
    tile,chain,counter,ref=sources()
    model=ref.IntegerReference(ROOT/'frozen/model',enabled=True)
    feature=(ROOT/'frozen/data/features.i8').read_bytes()[index*490:(index+1)*490]
    require(len(feature)==490,'fixed feature extent')
    x=np.frombuffer(feature,np.int8).reshape(1,49,10,1)
    values={0:x}; baseline={}
    for op in model.info['operators'][:3]:
        src,wi,bi=op['inputs']; dst=op['outputs'][0]
        it,wt,ot=[model.info['tensors'][i] for i in (src,wi,dst)]
        a,b,bias=values[src],model.constants[wi],model.constants[bi]
        zp=it['zero_points'][0]
        if op['name']=='CONV_2D':
            patches=ref.conv_patches(a,b.shape,ot['shape'],op['stride'],op['padding'],op['dilation'],zp)
            weight=b.reshape(b.shape[0],-1)
            acc=(patches.astype(np.int32)@weight.astype(np.int32).T).astype(np.int64)
            acc+=bias.astype(np.int64)-zp*weight.astype(np.int64).sum(axis=1)
        else:
            _,kh,kw,c=b.shape
            patches=ref.conv_patches(a,(c,kh,kw,c),ot['shape'],op['stride'],op['padding'],op['dilation'],zp)
            acc=((patches.reshape(-1,kh*kw,c).astype(np.int64)-zp)*b.reshape(kh*kw,c).astype(np.int64)).sum(axis=1)+bias
        ref.checked_i32(acc)
        scales=np.array(wt['scales'],np.float64)*float(it['scales'][0])/float(ot['scales'][0])
        result=ref.requantize(acc,scales,ot['zero_points'][0],op['activation']).reshape(ot['shape'])
        values[dst]=result
        baseline[dst]=result.copy()
    # compare() is an existing frozen API. Stop AFTER the first 3 comparisons
    # succeeded, at tensor25. No source rewrite, tracing or helper replacement.
    class PrefixComplete(Exception): pass
    seen=[]
    def compare(index):
        if index not in baseline: raise PrefixComplete()
        seen.append(index)
        return baseline[index]
    try:
        model.infer(x,compare=compare)
        raise ValueError('prefix boundary was not reached')
    except PrefixComplete:
        require(seen==[22,23,24],'original prefix tensor comparisons')
    logits,checks=model.infer(x)
    require(not checks and logits.tobytes()==(ROOT/'frozen/data/logits.i8').read_bytes()[index*12:(index+1)*12],
        'unchanged full CPU reference selected-window logits')
    op=model.info['operators'][2]
    require(op['index']==2 and op['mnk']==[125,64,64] and op['inputs']==[23,18,6] and op['outputs']==[24]
        and op['stride']==[1,1] and op['dilation']==[1,1] and op['activation']==1,'fixed pointwise operator')
    it,wt,ot=[model.info['tensors'][i] for i in (23,18,24)]
    require(wt['shape']==[64,1,1,64] and wt['zero_points']==[0]*64 and it['zero_points']==[-128],'fixed symmetric pointwise domain')
    return dict(a=values[23].reshape(125,64).copy(),weights=model.constants[18].reshape(64,64).T.copy(),
        bias=model.constants[6].copy(),input_zp=-128,output_zp=ot['zero_points'][0],activation=1,
        scales=np.array(wt['scales'],np.float64)*float(it['scales'][0])/float(ot['scales'][0]),
        expected=values[24].reshape(125,64).copy(),source_id=item['source_id'],feature_sha256=sha(feature),
        cohort_index=index,label=item['label'],
        original_prefix_tensors_checked=seen,full_CPU_reference_logits_checked=True)
