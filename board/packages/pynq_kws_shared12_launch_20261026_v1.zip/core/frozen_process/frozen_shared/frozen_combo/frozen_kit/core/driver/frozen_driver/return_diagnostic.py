"""D075 no-failure sentinel and bounded CPU-return diagnostics; no device access."""
import json

SUCCESS_NO_FAILED_TILE = 0xFFFF
MAX_BYTES = 8192
CHECKS = ('not_returned', 'driver_tuple', 'return_records', 'work_counters', 'mode11_state',
    'mmio_timing', 'synthetic_evidence', 'raw_int32', 'requantized_int8', 'stop_pending')
FIELDS = ('first_job_id', 'jobs', 'mode', 'input_bytes', 'input_payload_bytes', 'input_header_bytes',
    'output_bytes', 'output_valid_bytes', 'effective_macs', 'error_code', 'chain_jobs_completed',
    'failed_tile_index', 'counter_contract_version', 'status', 'pl_total_cycles',
    'pl_compute_accounted_cycles', 'pl_load_work_cycles', 'pl_array_work_cycles', 'pl_store_work_cycles',
    'pl_output_work_cycles', 'pl_work_union_cycles', 'pl_overlap_credit_cycles', 'pl_no_work_cycles',
    'pl_array_output_work_overlap_cycles', 'pl_compute_wait_bank_cycles', 'pl_output_wait_tready_cycles')
KINDS = ('missing', 'int', 'int_out_of_range', 'bool', 'float', 'str', 'other', 'none')
LIMIT = (1 << 64) - 1

def _kind(value):
    if type(value) is int:
        return 'int' if 0 <= value <= LIMIT else 'int_out_of_range'
    if value is None:return 'none'
    if type(value) is bool:return 'bool'
    if type(value) is float:return 'float'
    if type(value) is str:return 'str'
    return 'other'

def capture(metrics, expected, check):
    """Never formats unknown objects or strings; reads already returned dict only."""
    check = check if type(check) is str and check in CHECKS else 'not_returned'
    if type(metrics) is not dict:
        return dict(check=check, container_type='missing' if metrics is None else 'other', fields={})
    rows = {}
    for name in FIELDS:
        present = name in metrics
        value = metrics.get(name)
        kind = _kind(value) if present else 'missing'
        item = dict(type=kind)
        if kind == 'int':item['value'] = value
        if type(expected) is dict and name in expected:
            wanted = expected[name]
            if type(wanted) is int and 0 <= wanted <= LIMIT:
                item['expected'] = wanted
                item['mismatch'] = kind != 'int' or value != wanted
        rows[name] = item
    return dict(check=check, container_type='dict', fields=rows)

def valid(value):
    if value is None:return True
    if type(value) is not dict or set(value) != {'check', 'container_type', 'fields'}:return False
    if type(value['check']) is not str or value['check'] not in CHECKS:return False
    if type(value['container_type']) is not str or value['container_type'] not in ('dict','other','missing'):return False
    fields=value['fields']
    if type(fields) is not dict or len(fields)>len(FIELDS):return False
    if value['container_type'] != 'dict' and fields:return False
    if value['container_type'] == 'dict' and set(fields) != set(FIELDS):return False
    for name,item in fields.items():
        if type(name) is not str or name not in FIELDS or type(item) is not dict:return False
        if not set(item)<= {'type','value','expected','mismatch'} or 'type' not in item:return False
        kind=item['type']
        if type(kind) is not str or kind not in KINDS:return False
        if kind=='int':
            if type(item.get('value')) is not int or not 0<=item['value']<=LIMIT:return False
        elif 'value' in item:return False
        if 'expected' in item:
            if type(item['expected']) is not int or not 0<=item['expected']<=LIMIT:return False
            if type(item.get('mismatch')) is not bool:return False
            if item['mismatch'] != (kind!='int' or item['value']!=item['expected']):return False
        elif 'mismatch' in item:return False
    return len(json.dumps(value,sort_keys=True,ensure_ascii=True).encode('ascii'))<=MAX_BYTES
