"""Explicitly enabled fixed twelve-window operator4 SOFTWARE batch only."""
import argparse,json,os,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from source_bindings import ROOT,need,sha,inventory,verify_candidate,sources
from layer_case import INDICES,selection,derive
from op4_candidate import Op4Call,SyntheticTransport,input_for
from independent_math import check
def save(path,raw):
    with path.open('xb') as f:f.write(raw)
    return dict(bytes=len(raw),sha256=sha(raw))
def evaluate(case,mutate=None):
    t=SyntheticTransport(mutate);call=Op4Call(case,t,enabled=True)
    try:out,reply=call(input_for(case))
    except BaseException as error:error.offline_first_failure=call.first_failure;raise
    need(t.submissions==1 and call.accepted,'one software submission')
    raw64,centered,scalar=check(case,reply['wire'],reply['raw'],reply['corrected'],out)
    artifacts={
        'pointwise_input.i8':case['a'].tobytes(),'weights_kn.i8':case['weights'].tobytes(),'bias.i32':case['bias'].astype('<i4').tobytes(),
        'scales.f64':case['scales'].astype('<f8').tobytes(),'request_chain.bin':reply['wire'],'reply_tile_order.bin':reply['reply'],
        'raw_output.i32':reply['raw'].astype('<i4').tobytes(),'raw_oracle.i64':raw64.astype('<i8').tobytes(),
        'corrected.i32':reply['corrected'].astype('<i4').tobytes(),'centered_oracle.i64':centered.astype('<i8').tobytes(),
        'candidate_output.i8':out.tobytes(),'expected_output.i8':case['expected'].tobytes(),'scalar_output.i8':scalar.tobytes()}
    row=dict(operator_index=4,input_tensor=25,weight_tensor=19,bias_tensor=9,output_tensor=26,cohort_index=case['cohort_index'],label=case['label'],source_id=case['source_id'],feature_sha256=case['feature_sha256'],prefix_tensors_checked=case['prefix_tensors_checked'],selected_CPU_logits_checked=case['selected_CPU_logits_checked'],mnk=[125,64,64],jobs=2,logical_macs=512000,input_bytes=16512,output_bytes=32000,raw_values=8000,corrected_values=8000,INT8_values=8000,INT8_min=int(out.min()),INT8_max=int(out.max()),nonnegative_INT8_values=int((out>=0).sum()),software_submissions=t.submissions,counter_evidence=reply['metrics'],fixture=True,counters_synthetic=True,board_access=False,PL_simulated=False,DMA_executed=False,promotion=False)
    return row,artifacts
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--candidate-sha',required=True);p.add_argument('--output',required=True);p.add_argument('--enable-offline-candidate',action='store_true');p.add_argument('--inject-raw-bit-window',type=int)
    args=p.parse_args();need(args.enable_offline_candidate is True,'offline candidate default-off');verify_candidate(args.candidate_sha)
    output=Path(args.output).absolute();need(output.resolve()==output and not os.path.lexists(output) and not output.is_relative_to(ROOT) and not ROOT.is_relative_to(output),'fresh canonical output outside immutable candidate')
    need(args.inject_raw_bit_window is None or args.inject_raw_bit_window in INDICES,'approved software fault window')
    before=inventory(ROOT);items=selection();output.mkdir(parents=True);rows=[];active=None;failure=None
    try:
        for item in items:
            active=item['cohort_index'];case=derive(active);mutate=None
            if active==args.inject_raw_bit_window:
                from dataclasses import replace
                mutate=lambda r:replace(r,payload=bytes([r.payload[0]^1])+r.payload[1:])
            row,artifacts=evaluate(case,mutate);folder=output/('window_%03d'%active);folder.mkdir()
            row['artifacts']={n:save(folder/n,b) for n,b in artifacts.items()};save(folder/'result.json',(json.dumps(row,sort_keys=True,indent=2)+'\n').encode());rows.append(row)
            print('WINDOW',active,'8000 raw/PS/scalar INT8 OK',flush=True)
    except Exception as error:
        first=getattr(error,'offline_first_failure',None);failure=dict(cohort_index=active,error_type=type(error).__name__,stage=None if first is None else first.stage,automatic_retry=False)
        if first is not None and type(first.payload) is bytes and len(first.payload)<=32000:failure['payload']=save(output/'first_failure_tile_order.bin',first.payload)
    unchanged=inventory(ROOT)==before;ok=failure is None and len(rows)==12 and unchanged
    result=dict(operation_success=ok,operator_index=4,selected_indices=list(INDICES),completed_indices=[r['cohort_index'] for r in rows],not_completed_indices=list(INDICES[len(rows):]),windows=rows,failure=failure,raw_values=8000*len(rows),corrected_values=8000*len(rows),INT8_values=8000*len(rows),candidate_sha256=args.candidate_sha,input_files_unchanged=unchanged,automatic_retry=False,counters_synthetic=True,scope='PC fixed-twelve SINGLE-operator4 only, CPU prefix includes depthwise3',board_access=False,PL_simulated=False,DMA_executed=False,hardware_adapter_implemented=False,board_stop_or_cleanup_tested=False,full_model_PS_PL_executed=False,classification_quality_accepted=False,performance_evaluated=False,energy_evaluated=False,promotion=False)
    save(output/'result.json',(json.dumps(result,sort_keys=True,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in result.items() if k not in ('windows',)}));return 0 if ok else 1
if __name__=='__main__':
    try:raise SystemExit(main())
    except (ValueError,OSError) as error:print(type(error).__name__+': '+str(error),file=sys.stderr);raise SystemExit(2)
