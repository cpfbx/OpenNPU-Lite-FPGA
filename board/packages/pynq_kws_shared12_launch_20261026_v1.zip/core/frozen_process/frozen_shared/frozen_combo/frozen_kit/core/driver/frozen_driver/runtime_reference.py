"""Cold-pinned CPU reference functions in private namespaces; no device imports.

The original offline modules keep their original globals and PYNQ refusal.
Only an initialized exact PointwiseOwner can authorize its runner's PYNQ object.
This is internal binding/lifecycle validation, not a security sandbox.
"""
import hashlib
import os
from pathlib import Path
import sys
from types import FunctionType, ModuleType
import weakref
import adapter_binding as ab

_modules = None
_namespaces = None
_files = None
_clones = None
_owner = None
_pynq = None
_pid = os.getpid()

def _require(ok, message):
    if not ok:
        raise ValueError(message)

def _forbidden():
    _require(not any(n == root or n.startswith(root + '.') for n in sys.modules
        for root in ('tensorflow', 'tflite_runtime')), 'runtime reference forbidden engine')

def _snapshot(module):
    # Original functions/classes and every original global binding stay identical.
    result = {}
    for key, value in vars(module).items():
        if key == '__warningregistry__':
            continue
        if isinstance(value, FunctionType):
            result[key] = (value, value.__code__, value.__defaults__, value.__kwdefaults__)
        elif isinstance(value, type) and value.__module__ == module.__name__:
            result[key] = (value, {n: (f, f.__code__, f.__defaults__, f.__kwdefaults__)
                for n, f in vars(value).items() if isinstance(f, FunctionType)})
        else:
            result[key] = (value,)
    return result

def _same_snapshot(module, wanted):
    actual = _snapshot(module)
    if actual.keys() != wanted.keys():
        return False
    for key, old in wanted.items():
        new = actual[key]
        if len(new) != len(old) or new[0] is not old[0]:
            return False
        if len(old) == 4 and any(a is not b for a, b in zip(new[1:], old[1:])):
            return False
        if len(old) == 2:
            if new[1].keys() != old[1].keys():
                return False
            if any(any(a is not b for a, b in zip(new[1][n], old[1][n])) for n in old[1]):
                return False
    return True

def bind():
    """Must complete before importing PYNQ, including on repeated configure calls."""
    global _modules, _namespaces, _files, _clones
    _forbidden()
    _require(not any(n == 'pynq' or n.startswith('pynq.') for n in sys.modules), 'runtime reference cold binding required')
    if _modules is not None:
        sources()
        return
    ab.verify_sources()
    names = ('binding', 'real_case', 'pointwise_candidate', 'tiled_gemm',
        'chain_protocol', '_pointwise_counter', '_pointwise_reference')
    expected = ('binding.py', 'real_case.py', 'pointwise_candidate.py', 'frozen/tiled_gemm.py',
        'frozen/chain_protocol.py', 'frozen/d007_mode11_contract.py', 'frozen/reference.py')
    modules = {}
    files = {}
    for name, rel in zip(names, expected):
        module = sys.modules.get(name)
        path = (ab.ROOT/'frozen_v2'/rel).resolve()
        _require(type(module) is ModuleType and Path(getattr(module, '__file__', '')).resolve() == path,
            'runtime reference module identity')
        modules[name] = module
        files[name] = (path, hashlib.sha256(path.read_bytes()).hexdigest())
    modules['binding'].sources()  # Original source/ABI verification while cold.
    snapshots = {name: _snapshot(module) for name, module in modules.items()}
    clones = {}
    for module_name, functions in (('real_case', ('selected_items', 'derive')),
            ('pointwise_candidate', ('inspect_wire', 'make_jobs'))):
        namespace = dict(vars(modules[module_name]))
        namespace['sources'] = sources
        for name in functions:
            original = getattr(modules[module_name], name)
            _require(type(original) is FunctionType and original.__closure__ is None, 'runtime reference plain frozen function')
            clone = FunctionType(original.__code__, namespace, original.__name__, original.__defaults__)
            clone.__kwdefaults__ = original.__kwdefaults__
            namespace[name] = clone
            clones[name] = clone
    _modules, _namespaces, _files, _clones = modules, snapshots, files, clones
    sources()

def authorize_owner(owner):
    """Bind to already initialized owner. Never acquires or changes resources."""
    global _owner, _pynq
    from pointwise_owner import PointwiseOwner
    _require(os.getpid() == _pid and type(owner) is PointwiseOwner, 'runtime reference exact owner')
    _forbidden()
    if 'pynq' not in sys.modules:
        # Existing offline fixtures remove their temporary PYNQ module at start
        # return; no PYNQ permission is granted or needed in that cold state.
        sources()
        return
    module = sys.modules['pynq']
    _require(type(module) is ModuleType and owner._used and not owner._closed and not owner._held
        and not owner._unsafe and owner._lease is not None and owner._lease.entered is True
        and owner._runner is not None and owner._runner._pynq is module,
        'runtime reference initialized owner required')
    old = None if _owner is None else _owner()
    _require(old is None or old is owner or old._closed, 'runtime reference owner already active')
    _owner, _pynq = weakref.ref(owner), weakref.ref(module)
    sources()

def sources():
    _require(os.getpid() == _pid and _modules is not None, 'runtime reference unbound process')
    _forbidden()
    if any(n == 'pynq' or n.startswith('pynq.') for n in sys.modules):
        owner = None if _owner is None else _owner()
        module = None if _pynq is None else _pynq()
        _require(owner is not None and not owner._closed and not owner._held and not owner._unsafe
            and owner._lease is not None and owner._lease.entered is True and owner._runner is not None
            and module is not None and sys.modules.get('pynq') is module and owner._runner._pynq is module,
            'runtime reference unauthorized PYNQ state')
    for name, module in _modules.items():
        path, digest = _files[name]
        _require(sys.modules.get(name) is module and Path(getattr(module, '__file__', '')).resolve() == path
            and hashlib.sha256(path.read_bytes()).hexdigest() == digest
            and _same_snapshot(module, _namespaces[name]), 'runtime reference module drift')
    # This routine verifies model/constants/bank source bytes without the offline
    # sources() policy guard or importing/rebinding any module after owner start.
    _modules['binding'].verify()
    return tuple(_modules[n] for n in ('tiled_gemm', 'chain_protocol', '_pointwise_counter', '_pointwise_reference'))

def derive(index=0):
    sources()
    return _clones['derive'](index)

def make_jobs(a, b):
    sources()
    return _clones['make_jobs'](a, b)

bind()
