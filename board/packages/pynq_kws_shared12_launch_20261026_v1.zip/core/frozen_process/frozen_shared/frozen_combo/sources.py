"""Pinned offline dependencies. Import never enables a board or starts a fixture."""
import hashlib,importlib.util,json,sys,tarfile
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parent
KIT_PIN='d2f4340af48673e5aa6f62bba4f225f7071814816446e2e6d53c8db0e8117c4d'
OP2_PIN='fba363e39ac2eed800dfbc2c0159774bc6f00963da90f930b0753a6808211177'
INDICES=(0,30,60,90,120,150,180,210,240,270,300,400)
_deps=None
def need(ok,msg):
    if not ok:raise ValueError(msg)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def inventory(root):
    result={}
    for p in root.rglob('*'):
        need(not p.is_symlink() and not getattr(p,'is_junction',lambda:False)(),'plain source tree')
        if p.is_file():
            b=p.read_bytes();result[p.relative_to(root).as_posix()]=dict(bytes=len(b),sha256=sha(b))
    return result
def verify(pin):
    raw=(ROOT/'candidate_manifest.json').read_bytes();need(type(pin) is str and sha(raw)==pin,'external candidate pin')
    pins=json.loads(raw)['files'];actual=inventory(ROOT)
    need(set(actual)==set(pins)|{'candidate_manifest.json'} and all(actual[n]==v for n,v in pins.items()),'candidate byte drift')
    verify_frozen();return actual
def verify_frozen():
    root=ROOT/'frozen_kit';raw=(root/'kit_manifest.json').read_bytes();need(sha(raw)==KIT_PIN,'frozen kit pin')
    pins=json.loads(raw)['files'];actual=inventory(root)
    need(len(actual)==209 and set(actual)==set(pins)|{'kit_manifest.json'} and all(actual[n]==v for n,v in pins.items()),'209 frozen kit bytes')
    need(sha((ROOT/'inputs/op2_board_original.tar.gz').read_bytes())==OP2_PIN,'Op2 original identity')
def configure(*,enabled=False):
    global _deps
    need(enabled is True,'combination default-off')
    need(not any(n==r or n.startswith(r+'.') for n in sys.modules for r in ('pynq','tensorflow','tflite_runtime')),'cold CPU-only process required')
    verify_frozen()
    if _deps is None:
        p=ROOT/'frozen_kit/core/driver/op4_binding.py'
        need('op4_binding' not in sys.modules,'foreign existing binding')
        spec=importlib.util.spec_from_file_location('op4_binding',p);m=importlib.util.module_from_spec(spec);sys.modules['op4_binding']=m;spec.loader.exec_module(m)
        _deps=m.configure(enabled=True)
        m.load('op4_fixture',p.parent/'op4_fixture.py')
        m.load('op4_driver_call',p.parent/'op4_driver_call.py')
    else:
        need(Path(sys.modules['op4_binding'].__file__).resolve()==(ROOT/'frozen_kit/core/driver/op4_binding.py').resolve(),'binding identity drift')
        _deps.reference.sources()
    return _deps
def replay_bank():
    path=ROOT/'inputs/op2_board_original.tar.gz';need(sha(path.read_bytes())==OP2_PIN,'Op2 original identity')
    bank={};seen=set()
    with tarfile.open(path,'r:gz') as tar:
        ms=tar.getmembers();need(len(ms)==123 and sum(m.size for m in ms)<2*1024*1024,'bounded original tar')
        for m in ms:
            p=PurePosixPath(m.name)
            need(m.isfile() and not p.is_absolute() and p.as_posix()==m.name and '..' not in p.parts and not any(c in m.name for c in '\\:\x00') and m.name.casefold() not in seen,'plain unique original member');seen.add(m.name.casefold())
            if m.name.endswith('/candidate_output.i8'):
                idx=int(p.parent.name.removeprefix('window_'));need(idx in INDICES and idx not in bank and m.size==8000,'exact replay window')
                bank[idx]=tar.extractfile(m).read()
    need(set(bank)==set(INDICES),'all twelve replay windows');return bank
