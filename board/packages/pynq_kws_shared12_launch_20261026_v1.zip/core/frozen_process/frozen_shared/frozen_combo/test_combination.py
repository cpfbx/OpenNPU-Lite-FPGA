"""Counterexamples for actual offline seams, no real device/lock/board access."""
import copy,json,struct,sys,tempfile,unittest
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import sources as s
import combination as c

class CombinationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        s.configure(enabled=True)
        import runtime_reference as r2,op4_runtime as r4
        cls.case2=r2.derive(0);cls.case4=r4.derive(0);cls.other2=r2.derive(30);cls.other4=r4.derive(30)
        cls.params=c.depthwise_parameters();cls.bank=s.replay_bank()
        cls.up=c.make_upstream(cls.bank[0],cls.case2,'replay')
        cls.dynamic,cls.acc=c.depthwise_kernel(cls.up.values,cls.params)
    def test_01_default_off(self):
        with self.assertRaisesRegex(ValueError,'default-off'):s.configure()
    def test_02_integer_enable_rejected(self):
        with self.assertRaises(ValueError):s.configure(enabled=1)
    def test_03_replay_twelve_exact_bytes(self):
        self.assertEqual(tuple(sorted(self.bank)),s.INDICES);self.assertTrue(all(len(v)==8000 for v in self.bank.values()))
    def test_04_new_source_is_readonly_owning_copy(self):
        self.assertFalse(self.up.values.flags.writeable);self.assertIsNone(self.up.values.base);self.assertTrue(self.up.values.flags.owndata)
    def test_05_wrong_upstream_layer(self):
        with self.assertRaisesRegex(ValueError,'layer'):c.validate_upstream(replace(self.up,operator_index=4),self.case2,'replay')
    def test_06_wrong_upstream_tensor(self):
        with self.assertRaisesRegex(ValueError,'layer'):c.validate_upstream(replace(self.up,tensor_index=25),self.case2,'replay')
    def test_07_bool_index_rejected(self):
        with self.assertRaisesRegex(ValueError,'window'):c.validate_upstream(replace(self.up,cohort_index=False),self.case2,'replay')
    def test_08_cross_window_rejected(self):
        with self.assertRaisesRegex(ValueError,'window'):c.validate_upstream(self.up,self.other2,'replay')
    def test_09_source_id_rejected(self):
        with self.assertRaisesRegex(ValueError,'window'):c.validate_upstream(replace(self.up,source_id='different'),self.case2,'replay')
    def test_10_feature_identity_rejected(self):
        with self.assertRaisesRegex(ValueError,'window'):c.validate_upstream(replace(self.up,feature_sha256='0'*64),self.case2,'replay')
    def test_11_mode_forgery_rejected(self):
        with self.assertRaisesRegex(ValueError,'source mode'):c.validate_upstream(self.up,self.case2,'fixture')
    def test_12_mode_unknown_rejected(self):
        with self.assertRaises(ValueError):c.validate_upstream(self.up,self.case2,'hardware')
    def test_13_stale_bytes_hash_rejected(self):
        a=self.up.values.copy();a[0,0]^=1
        with self.assertRaisesRegex(ValueError,'digest'):c.validate_upstream(replace(self.up,values=a),self.case2,'replay')
    def test_14_resigned_wrong_bytes_oracle_rejected(self):
        a=self.up.values.copy();a[0,0]^=1
        with self.assertRaisesRegex(ValueError,'oracle'):c.validate_upstream(replace(self.up,values=a,output_sha256=s.sha(a.tobytes())),self.case2,'replay')
    def test_15_view_rejected(self):
        with self.assertRaisesRegex(ValueError,'owning'):c.checked_array(self.up.values[:])
    def test_16_fortran_rejected(self):
        with self.assertRaises(ValueError):c.checked_array(np.asfortranarray(self.up.values))
    def test_17_wrong_dtype_rejected(self):
        with self.assertRaises(ValueError):c.checked_array(self.up.values.astype(np.int16))
    def test_18_wrong_shape_rejected(self):
        with self.assertRaises(ValueError):c.checked_array(np.zeros((64,125),np.int8))
    def test_19_exact_depthwise_output_and_new_ownership(self):
        self.assertTrue(np.array_equal(self.dynamic,self.case4['a']));self.assertIsNone(self.dynamic.base);self.assertFalse(np.shares_memory(self.dynamic,self.up.values))
    def test_20_envelope_preserves_dynamic_object(self):
        e=c.dynamic_envelope(self.up,self.dynamic,self.case4);self.assertIs(e.values,self.dynamic)
    def test_21_skip_depthwise_rejected(self):
        self.assertFalse(np.array_equal(self.up.values,self.dynamic))
        with self.assertRaisesRegex(ValueError,'DW3 result'):c.dynamic_envelope(self.up,self.up.values.copy(),self.case4)
    def test_22_cross_window_envelope_rejected(self):
        with self.assertRaisesRegex(ValueError,'window'):c.dynamic_envelope(self.up,self.dynamic,self.other4)
    def test_23_dynamic_bit_rejected(self):
        a=self.dynamic.copy();a[0,0]^=1
        with self.assertRaisesRegex(ValueError,'DW3 result'):c.dynamic_envelope(self.up,a,self.case4)
    def test_24_wrong_depthwise_weight_shape(self):
        p=dict(self.params,weights=np.zeros((1,1,1,64),np.int8))
        with self.assertRaisesRegex(ValueError,'parameter'):c.depthwise_kernel(self.up.values,p)
    def test_25_wrong_bias_changes_accumulator(self):
        p=dict(self.params,bias=self.params['bias'].copy());p['bias'][7]+=1
        out,acc=c.depthwise_kernel(self.up.values,p);self.assertTrue(np.all(acc[:,7]==self.acc[:,7]+1))
        self.assertTrue(np.array_equal(acc[:,:7],self.acc[:,:7]))
    def test_26_kernel_independent_of_op4_oracle_reads(self):
        import op4_runtime
        with patch.object(op4_runtime,'derive',side_effect=AssertionError('oracle read')):
            out,acc=c.depthwise_kernel(self.up.values,self.params)
        self.assertTrue(np.array_equal(out,self.dynamic))
    def test_27_actual_dynamic_op4_call_and_wire(self):
        from op4_fixture import Op4Harness,FakeCanonicalEnvironment
        from op4_driver_call import Op4DriverCall
        h=Op4Harness(self.case4);env=FakeCanonicalEnvironment()
        with env.install(),h.resident(env):
            h.set_case(dict(self.case4,a=self.dynamic));call=Op4DriverCall(h.owner,self.case4,enabled=True)
            e=c.dynamic_envelope(self.up,self.dynamic,self.case4);out,data=call(e)
            self.assertTrue(np.array_equal(c.wire_input(data['input_chain'],1),self.dynamic));self.assertTrue(np.array_equal(out,self.case4['expected']))
        self.assertTrue(h.owner._closed);self.assertFalse(env.held)
    def test_28_op4_exact_owning_gate_unchanged(self):
        from op4_fixture import Op4Harness,FakeCanonicalEnvironment
        from op4_driver_call import Op4DriverCall
        from op4_candidate import InputEnvelope
        h=Op4Harness(self.case4);env=FakeCanonicalEnvironment()
        with env.install(),h.resident(env):
            call=Op4DriverCall(h.owner,self.case4,enabled=True);e=InputEnvelope(4,25,0,self.up.source_id,self.up.feature_sha256,self.dynamic[:])
            with self.assertRaisesRegex(ValueError,'owning'):call(e)
            self.assertFalse(any(e[0]=='transfer' for e in h.events))
    def test_29_first_job_policy_unchanged(self):
        from pointwise_policy import PointwisePolicy
        p=PointwisePolicy(enabled=True);self.assertEqual([p.request(i).first_job_id for i in range(12)],list(range(1,24,2)))
        with self.assertRaises(ValueError):p.request(12)
    def test_30_stop_exact_false_only(self):
        for value in (True,None,0,1):
            with self.subTest(value=value),self.assertRaises(c.ChainStop):c.checkpoint(lambda stage,index:value,'before_depthwise',0)
    def test_31_stop_stage_identity(self):
        seen=[];c.checkpoint(lambda stage,index:seen.append((stage,index)) or False,'op4_before_submit',90);self.assertEqual(seen,[('op4_before_submit',90)])
    def test_32_mode_and_output_default_off_before_configure(self):
        with self.assertRaisesRegex(ValueError,'default-off'):c.run('replay','unused')
    def test_33_existing_output_rejected(self):
        with tempfile.TemporaryDirectory() as t,self.assertRaisesRegex(ValueError,'fresh output'):c.run('replay',t,enabled=True)
    def test_34_inside_candidate_rejected(self):
        with self.assertRaisesRegex(ValueError,'fresh output'):c.run('replay',s.ROOT/'not_created',enabled=True)
    def test_35_only_planned_fault_window(self):
        with self.assertRaisesRegex(ValueError,'planned raw fault'):c.run('replay','unused',enabled=True,inject_raw_window=0)
    def test_36_no_real_pynq_left(self):
        self.assertNotIn('pynq',sys.modules)
    def test_37_observable_LSB_reaches_frozen_op4_gate(self):
        from propagation import witnesses
        from op4_fixture import Op4Harness,FakeCanonicalEnvironment
        from op4_driver_call import Op4DriverCall
        from op4_candidate import InputEnvelope
        witness=witnesses(self.up.values,self.params)['observable']
        self.assertGreater(witness['accumulator_changed_values'],0);self.assertGreater(witness['INT8_changed_values'],0)
        h=Op4Harness(self.case4);env=FakeCanonicalEnvironment()
        with env.install(),h.resident(env):
            call=Op4DriverCall(h.owner,self.case4,enabled=True)
            e=InputEnvelope(4,25,0,self.up.source_id,self.up.feature_sha256,witness['output'])
            with self.assertRaisesRegex(ValueError,'input bytes'):call(e)
            self.assertFalse(any(e[0]=='transfer' for e in h.events))
    def test_38_masked_LSB_kept_and_upstream_rejected(self):
        from propagation import witnesses
        witness=witnesses(self.up.values,self.params)['masked']
        self.assertGreater(witness['accumulator_changed_values'],0);self.assertEqual(witness['INT8_changed_values'],0)
        self.assertTrue(np.array_equal(witness['output'],self.dynamic))
        with self.assertRaisesRegex(ValueError,'digest'):c.validate_upstream(replace(self.up,values=witness['mutated']),self.case2,'replay')
    def test_39_masked_bias_perturbation_not_claimed_output_change(self):
        p=dict(self.params,bias=self.params['bias'].copy());p['bias'][7]+=1
        out,acc=c.depthwise_kernel(self.up.values,p)
        self.assertGreater(np.count_nonzero(acc!=self.acc),0)
        # No requirement that a one-unit accumulator change survives rounding.
        self.assertEqual(out.shape,self.dynamic.shape)
    def test_40_wire_tail_negative_control(self):
        from op4_fixture import Op4Harness,FakeCanonicalEnvironment
        from op4_driver_call import Op4DriverCall
        h=Op4Harness(self.case4);env=FakeCanonicalEnvironment()
        with env.install(),h.resident(env):
            _,d=Op4DriverCall(h.owner,self.case4,enabled=True)(c.dynamic_envelope(self.up,self.dynamic,self.case4))
        raw=bytearray(d['input_chain']);raw[8256+64+7*512+5]^=1
        with self.assertRaisesRegex(ValueError,'tail'):c.wire_input(bytes(raw),1)

if __name__=='__main__':unittest.main(verbosity=2)
