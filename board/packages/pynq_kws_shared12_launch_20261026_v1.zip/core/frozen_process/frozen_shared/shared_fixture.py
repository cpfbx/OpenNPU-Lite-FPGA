"""TEST ONLY one fake Overlay, owner, lock and buffer pair. Not real PYNQ/RTL."""
from contextlib import contextmanager
import gc,sys
from unittest.mock import patch
import shared_binding as b
from shared_policy import SharedPolicy
from shared_owner import SharedOwner
from shared_reference import REFERENCE as ref
OriginalHarness=b.old('driver_fixture').Harness
FakeCanonicalEnvironment=b.old('driver_fixture').FakeCanonicalEnvironment
_g=dict(OriginalHarness.__init__.__globals__);_g.update(PointwiseOwner=SharedOwner,PointwisePolicy=SharedPolicy)
_init=b.clone(OriginalHarness.__init__,_g)
class SharedHarness(OriginalHarness):
    def __init__(self,case,**options):
        gc.collect();_init(self,case,**options)
        self.close_attempts=0;self.before_teardown=None;self.fail_before_return=False
        self._initial=None;self.resource_checks=0
    def set_case(self,case):
        tile=ref.sources2()[0];jobs,_=ref.make_jobs(case['a'],case['weights'])
        self.engine.payload=b''.join(tile.emulate_transaction(j) for j in jobs)
    def check_reuse(self):
        current=(id(self.owner._lease),id(self.owner._runner),tuple(map(id,self.owner._buffers)))
        if self._initial is None:self._initial=current
        b.need(current==self._initial and len(self.buffers)==2 and len(self.owner._buffers)==2,'same lease runner buffer objects')
        b.need([buf.physical_address for buf in self.owner._buffers]==[0x10000000,0x20000000],'same fake buffer addresses')
        self.resource_checks+=1
    @contextmanager
    def resident(self,env):
        try:
            self.start(env)
            original=self.owner._runner.run_chain
            def returned(*args,**kwargs):
                if self.fail_before_return:raise RuntimeError('TEST_ONLY opaque driver failure before return')
                return original(*args,**kwargs)
            self.owner._runner.run_chain=returned
            with patch.dict(sys.modules,{'pynq':self.fake}):
                ref.authorize(self.owner);self.check_reuse()
                yield self
        finally:
            if not self.owner._closed and not self.owner._held and not self.owner._unsafe:
                self.close_attempts+=1;self.owner.close()
            self.before_teardown=dict(resources=self.owner.supervision_status,closed=self.owner._closed,
                session_failed=self.owner._session_failed,admission_cleared=self.owner._admission is None,
                fake_fd_live=env.fd_live,fake_lock_held=env.held,
                close_attempts=self.close_attempts,free_events=len([e for e in self.events if e[0]=='free']))
            self.before_teardown['software_admission']=dict(active_call_cleared=self.owner._active_call is None,
                producer_cleared=self.owner._active_producer is None,
                call_guard_released=not self.owner._call_guard.locked(),issued=self.owner._permits_issued,
                consumed=self.owner._permits_consumed,revoked=self.owner._permits_revoked)
            # Only fake test-retention bookkeeping. No owner.close/free/real lock
            # release is performed here for unresolved/held owners.
            self.discard_synthetic_hold()
    def report(self,env):
        transfers=[e for e in self.events if e[0]=='transfer'];b.need(transfers==[('transfer','recv',32000),('transfer','send',16512)]*(len(transfers)//2),'paired fake transfers')
        return dict(fixture=True,overlay_initializations=len([e for e in self.events if e[0]=='fake_overlay']),
            allocations=len(self.buffers),fake_open_calls=env.events.count('fake_open'),fake_flock_calls=env.events.count('fake_flock'),
            fake_close_calls_after_test_teardown=env.events.count('fake_close'),close_attempts=self.close_attempts,
            free_events=len([e for e in self.events if e[0]=='free']),fixture_submissions=len(transfers)//2,
            owner_completed_driver_returns=self.owner._index,resource_identity_checks=self.resource_checks,
            before_test_teardown=self.before_teardown,synthetic_context_teardown=True,
            actual_lock_access=False,real_DMA_executed=False,real_infinite_hold_executed=False)
