"""Single shared FAKE resource session, alternating exact12 Op2/DW3/Op4."""
import json
from pathlib import Path
import numpy as np
import shared_binding as b
from shared_policy import SharedPolicy,INDICES

def depthwise(a,parameters):
    """Frozen arithmetic expression; only CPU provider changes to private state."""
    from shared_reference import REFERENCE as ref
    combo=b.old('combination');combo.checked_array(a);reference=ref.sources2()[3]
    weights=parameters['weights'];bias=parameters['bias'];scales=parameters['scales']
    b.need(type(weights) is np.ndarray and weights.dtype==np.int8 and weights.shape==(1,3,3,64)
        and type(bias) is np.ndarray and bias.dtype==np.int32 and bias.shape==(64,)
        and type(scales) is np.ndarray and scales.dtype==np.float64 and scales.shape==(64,),'DW3 parameter shapes')
    patches=reference.conv_patches(a.reshape(1,25,5,64),(64,3,3,64),(1,25,5,64),[1,1],0,[1,1],-128)
    acc=((patches.reshape(125,9,64).astype(np.int64)+128)*weights.reshape(9,64).astype(np.int64)).sum(axis=1)+bias.astype(np.int64)
    reference.checked_i32(acc)
    result=reference.requantize(acc,scales,-128,1).reshape(125,64).copy(order='C');combo.checked_array(result)
    return result,acc.astype('<i4')

def run(output,*,enabled=False,scenario='normal',stopped=lambda stage,index:False):
    b.need(enabled is True,'shared run default-off');b.need(type(scenario) is str and scenario in ['normal','raw_fault','stop','unsafe'],'planned scenario only')
    output=Path(output).absolute();b.need(output.resolve()==output and not output.exists() and not output.is_relative_to(b.ROOT) and not b.ROOT.is_relative_to(output),'fresh output outside shared candidate')
    b.need(callable(stopped),'explicit stop callback');b.configure(enabled=True)
    from shared_reference import REFERENCE as ref
    from shared_fixture import SharedHarness,FakeCanonicalEnvironment
    from shared_call import SharedCall
    from op4_candidate import InputEnvelope
    combo=b.old('combination');cases2={i:ref.derive(2,i) for i in INDICES};cases4={i:ref.derive(4,i) for i in INDICES}
    parameters=combo.depthwise_parameters();h=SharedHarness(cases2[0]);env=FakeCanonicalEnvironment();output.mkdir(parents=True)
    rows=[];calls=[];failure=None;stage='before_session';index=None;call=None;dw_calls=0;accepted2=accepted4=0
    def check(where):
        nonlocal stage
        stage=where
        requested=(scenario=='stop' and where=='before_depthwise' and index==90)
        if requested or stopped(where,index) is not False:raise combo.ChainStop('shared offline stop boundary')
    def save(folder,name,raw):
        with (folder/name).open('xb') as f:f.write(raw)
        return dict(bytes=len(raw),sha256=b.sha(raw))
    try:
        with env.install(),h.resident(env):
            for index in INDICES:
                check('op2_before_submit');c2=cases2[index];h.set_case(c2);h.check_reuse()
                call=SharedCall(h.owner,c2,enabled=True);spec2=call.spec;stage='op2_call'
                e2=InputEnvelope(2,23,index,c2['source_id'],c2['feature_sha256'],c2['a'].copy(order='C'))
                out2,d2=call(e2);accepted2+=1;h.check_reuse();calls.append(dict(request_index=spec2.index,cohort_index=index,operator_index=2,first_job_id=spec2.first_job_id,accepted=True))
                upstream=combo.make_upstream(out2.tobytes(),c2,'fixture');a=combo.validate_upstream(upstream,c2,'fixture')
                check('before_depthwise');dynamic,acc=depthwise(a,parameters);dw_calls+=1
                env4=combo.dynamic_envelope(upstream,dynamic,cases4[index]);b.need(env4.values is dynamic,'actual dynamic object')
                check('op4_before_submit');h.set_case(dict(cases4[index],a=dynamic));h.check_reuse()
                call=SharedCall(h.owner,cases4[index],enabled=True);spec4=call.spec
                if index==90 and scenario=='raw_fault':
                    raw=h.engine.payload;h.engine.payload=bytes([raw[0]^1])+raw[1:]
                if index==90 and scenario=='unsafe':h.fail_before_return=True
                stage='op4_call';out4,d4=call(env4);accepted4+=1;h.check_reuse()
                b.need(np.array_equal(combo.wire_input(d4['input_chain'],spec4.first_job_id),dynamic),'submitted shared wire consumes dynamic output')
                calls.append(dict(request_index=spec4.index,cohort_index=index,operator_index=4,first_job_id=spec4.first_job_id,accepted=True))
                check('after_op4')
                folder=output/('window_%03d'%index);folder.mkdir()
                artifacts={
                    'op2_input.i8':c2['a'].tobytes(),'op2_weights.i8':c2['weights'].tobytes(),'op2_bias.i32':c2['bias'].astype('<i4').tobytes(),'op2_scales.f64':c2['scales'].astype('<f8').tobytes(),
                    'op2_output.i8':out2.tobytes(),'op2_wire.bin':d2['input_chain'],'op2_raw.i32':d2['raw'].astype('<i4').tobytes(),'op2_corrected.i32':d2['corrected'].astype('<i4').tobytes(),
                    'dw3_input.i8':a.tobytes(),'dw3_weights.i8':parameters['weights'].tobytes(),'dw3_bias.i32':parameters['bias'].astype('<i4').tobytes(),'dw3_scales.f64':parameters['scales'].astype('<f8').tobytes(),
                    'dw3_acc.i32':acc.tobytes(),'dw3_output.i8':dynamic.tobytes(),'op4_input.i8':dynamic.tobytes(),
                    'op4_weights.i8':cases4[index]['weights'].tobytes(),'op4_bias.i32':cases4[index]['bias'].astype('<i4').tobytes(),'op4_scales.f64':cases4[index]['scales'].astype('<f8').tobytes(),
                    'op4_wire.bin':d4['input_chain'],'op4_raw.i32':d4['raw'].astype('<i4').tobytes(),'op4_corrected.i32':d4['corrected'].astype('<i4').tobytes(),'op4_output.i8':out4.tobytes()}
                row=dict(cohort_index=index,source_id=c2['source_id'],feature_sha256=c2['feature_sha256'],op2_request_index=spec2.index,op4_request_index=spec4.index,
                    op2_first_job_id=spec2.first_job_id,op4_first_job_id=spec4.first_job_id,op2_fake_metrics=d2['driver_metrics'],op4_fake_metrics=d4['driver_metrics'],
                    actual_dynamic_payload_identity=True,same_resource_pair=True,artifacts={n:save(folder,n,raw) for n,raw in artifacts.items()})
                save(folder,'result.json',(json.dumps(row,sort_keys=True,indent=2)+'\n').encode());rows.append(row)
                print('WINDOW',index,'shared alternating dynamic chain verified',flush=True)
    except Exception as error:
        first=None if call is None else call.first_failure
        failure=dict(cohort_index=index,stage=stage,error_type=type(error).__name__,automatic_retry=False)
        if type(first) is dict:
            payload=first.get('payload')
            if type(payload) is bytes and len(payload)<=32000:failure['payload']=save(output,'first_failure.bin',payload)
            diagnostic=first.get('return_diagnostic')
            if diagnostic is not None:save(output,'return_diagnostic.json',(json.dumps(diagnostic,sort_keys=True,ensure_ascii=True)+'\n').encode('ascii'))
    report=h.report(env);ok=failure is None and len(rows)==12
    result=dict(operation_success=ok,scenario=scenario,completed_indices=[r['cohort_index'] for r in rows],not_completed_indices=list(INDICES[len(rows):]),windows=rows,calls=calls,failure=failure,
        accepted_op2_calls=accepted2,accepted_op4_calls=accepted4,depthwise_executed_calls=dw_calls,depthwise_executed_logical_MACs=72000*dw_calls,
        completed_chain_depthwise_logical_MACs=72000*len(rows),fixture_submissions=report['fixture_submissions'],fixture_jobs=2*report['fixture_submissions'],fixture_MACs=512000*report['fixture_submissions'],
        single_session_fixture=report,fixture=True,counters_synthetic=True,normal_cleanup_synthetic=True,board_access=False,real_cross_layer_PL_execution=False,real_lock_access=False,real_DMA_executed=False,real_infinite_hold_executed=False,
        CPU_reference_selected_checks_reexecuted=True,full_model_deployed=False,classification_quality_evaluated=False,performance_evaluated=False,energy_evaluated=False,automatic_retry=False,automatic_kill=False,run_ready=False,promotion=False)
    save(output,'summary.json',(json.dumps(result,sort_keys=True,indent=2)+'\n').encode());return result

if __name__=='__main__':raise SystemExit('Library only. No board activation.')
