"""Private CPU reference namespaces authorized only for initialized SharedOwner.

Frozen modules and their original exact-PointwiseOwner authorization stay intact.
"""
import os,sys,weakref
from pathlib import Path
from types import ModuleType
import shared_binding as b
from shared_owner import SharedOwner
class SharedReference:
    def __init__(self):
        r2=b.old('runtime_reference');r4=b.old('op4_runtime')
        need=b.need;need('pynq' not in sys.modules,'shared reference cold binding')
        self.original=r2;self.original4=r4
        ns=dict(vars(r2));ns.update(_owner=None,_pynq=None,_pid=os.getpid())
        self.namespace=ns;self.sources2=b.clone(r2.sources,ns);ns['sources']=self.sources2
        clones={}
        for name,functions in [('real_case',('selected_items','derive')),('pointwise_candidate',('inspect_wire','make_jobs'))]:
            module=r2._modules[name];g=dict(vars(module));g['sources']=self.sources2
            for f in functions:
                v=b.clone(getattr(module,f),g);g[f]=v;clones[f]=v
        ns['_clones']=clones;self.derive2=clones['derive'];self.make_jobs=clones['make_jobs']
        layer=dict(vars(b.old('layer_case')));layer['sources']=self.sources4
        for name in ['selection','derive']:layer[name]=b.clone(getattr(b.old('layer_case'),name),layer)
        self.derive4=layer['derive'];self.sources2();self.sources4()
    def sources4(self):
        result=self.sources2();r4=self.original4
        for name,module in r4._modules.items():
            path,pin=r4._files[name]
            b.need(sys.modules.get(name) is module and Path(module.__file__).resolve()==path and b.sha(path.read_bytes())==pin
                and self.original._same_snapshot(module,r4._snapshots[name]),'shared Op4 reference drift')
        return (*result,b.old('pointwise_candidate'))
    def authorize(self,owner):
        b.need(type(owner) is SharedOwner and os.getpid()==self.namespace['_pid'],'exact shared owner/process')
        b.need(not any(n==r or n.startswith(r+'.') for n in sys.modules for r in ('tensorflow','tflite_runtime')),'shared reference forbidden engine')
        b.need('pynq' in sys.modules,'initialized fixture module required');m=sys.modules['pynq']
        b.need(type(m) is ModuleType and owner._used and not owner._closed and not owner._held and not owner._unsafe
            and owner._lease is not None and owner._lease.entered is True and owner._runner is not None and owner._runner._pynq is m,'shared reference initialized owner')
        oldref=self.namespace['_owner'];old=None if oldref is None else oldref()
        b.need(old is None or old is owner or old._closed,'another shared owner active')
        self.namespace.update(_owner=weakref.ref(owner),_pynq=weakref.ref(m));self.sources2();self.sources4()
    def derive(self,layer,index):
        b.need(type(layer) is int and layer in (2,4),'exact layer dispatch')
        self.sources4();return (self.derive2 if layer==2 else self.derive4)(index)
REFERENCE=SharedReference()
