"""New exact shared owner with original safety methods and private policy binding."""
import shared_binding as b
import threading
from job_permit import JobPermit,snapshot_job
from shared_policy import SharedPolicy,validate_shared_policy
OriginalOwner=b.old('pointwise_owner').PointwiseOwner
_g=dict(OriginalOwner.__init__.__globals__);_g['validate_pointwise_policy']=validate_shared_policy
_init=b.clone(OriginalOwner.__init__,_g)
_execute=b.clone(OriginalOwner.execute_chain,_g)
class SharedOwner(OriginalOwner):
    def __init__(self,policy,stop_requested,*,enabled=False):
        _init(self,policy,stop_requested,enabled=enabled)
        self._admission=None;self._session_failed=False
        self._active_call=None;self._active_producer=None;self._call_guard=threading.Lock()
        self._permits_issued=self._permits_consumed=self._permits_revoked=0
    def begin_call(self,call,producer_key):
        self._owned()
        from shared_call import SharedCall
        b.need(type(call) is SharedCall and call.owner is self and type(producer_key) is object and producer_key is call._producer_key,'exact private call producer')
        b.need(self._call_guard.acquire(blocking=False),'shared owner call busy/reentrant')
        if self._active_call is not None or self._admission is not None:
            self._call_guard.release();raise ValueError('shared owner stale call state')
        self._active_call=call;self._active_producer=producer_key
    def end_call(self,call):
        self._owned();b.need(self._active_call is call,'shared owner active call identity')
        permit=self._admission;self._admission=None
        if type(permit) is JobPermit and permit.consumed is False:
            permit.revoke();self._permits_revoked+=1
        self._active_call=None;self._active_producer=None;self._call_guard.release()
    def issue_permit(self,call,jobs,producer_key=None):
        self._owned();validate_shared_policy(self.policy)
        b.need(self._session_failed is False and self._active_call is call and self._call_guard.locked(),'active call required for job permit')
        b.need(call.owner is self and call.spec==self.policy.request(self._index) and call.used is True and call.failed is False,'job permit current call/slot')
        b.need(producer_key is self._active_producer and producer_key is call._producer_key,'private job producer token required')
        b.need(self._admission is None and type(jobs) is tuple and len(jobs)==2,'one permit after actual job construction')
        from shared_reference import REFERENCE as ref
        tile=ref.sources2()[0]
        self._admission=JobPermit(self,call,call.spec,producer_key,jobs,tuple(snapshot_job(j,tile) for j in jobs));self._permits_issued+=1
    def execute_chain(self,jobs,**options):
        self._owned();validate_shared_policy(self.policy)
        b.need(self._session_failed is False,'failed shared session cannot continue')
        permit=self._admission;self._admission=None
        b.need(type(permit) is JobPermit and self._active_call is not None and self._call_guard.locked(),'exact job-bound admission required')
        from shared_reference import REFERENCE as ref
        try:
            permit.consume(self,self._active_call,self.policy.request(self._index),jobs,options,ref.sources2()[0]);self._permits_consumed+=1
        except BaseException:
            permit.revoke();self._permits_revoked+=1;self._session_failed=True;raise
        return _execute(self,jobs,**options)
if __name__=='__main__':raise SystemExit('Library only; no board activation.')
