"""Pinned CPU-only assembly, no real device or canonical-lock operations."""
import hashlib,importlib.util,json,sys
from pathlib import Path
from types import FunctionType
ROOT=Path(__file__).resolve().parent
FROZEN_PIN='4851b2157712c79ce16d4c267a6c5c1b0365566a2ed080306985690512b1c04d'
_ready=False
def need(ok,msg):
    if not ok:raise ValueError(msg)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def inventory(root):
    result={}
    for p in root.rglob('*'):
        need(not p.is_symlink() and not getattr(p,'is_junction',lambda:False)(),'plain source tree')
        if p.is_file():
            b=p.read_bytes();result[p.relative_to(root).as_posix()]=dict(bytes=len(b),sha256=sha(b))
    return result
def verify(pin):
    raw=(ROOT/'candidate_manifest.json').read_bytes();need(type(pin) is str and sha(raw)==pin,'external shared candidate pin')
    m=json.loads(raw)['files'];actual=inventory(ROOT)
    need(set(actual)==set(m)|{'candidate_manifest.json'} and all(actual[n]==p for n,p in m.items()),'shared candidate byte drift');verify_frozen()
def verify_frozen():
    root=ROOT/'frozen_combo';raw=(root/'candidate_manifest.json').read_bytes();need(sha(raw)==FROZEN_PIN,'frozen combination pin')
    m=json.loads(raw)['files'];actual=inventory(root);need(len(actual)==218 and set(actual)==set(m)|{'candidate_manifest.json'} and all(actual[n]==p for n,p in m.items()),'218 frozen combination bytes')
def load(name,path):
    path=path.resolve()
    if name in sys.modules:
        need(Path(getattr(sys.modules[name],'__file__','')).resolve()==path,'foreign module '+name);return sys.modules[name]
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def clone(function,namespace):
    need(type(function) is FunctionType and function.__closure__ is None,'plain frozen function')
    f=FunctionType(function.__code__,namespace,function.__name__,function.__defaults__);f.__kwdefaults__=function.__kwdefaults__;return f
def configure(*,enabled=False):
    global _ready
    need(enabled is True,'shared candidate default-off')
    need(not any(n==r or n.startswith(r+'.') for n in sys.modules for r in ('pynq','tensorflow','tflite_runtime')),'cold CPU process required')
    verify_frozen();s=load('sources',ROOT/'frozen_combo/sources.py');s.configure(enabled=True)
    load('combination',ROOT/'frozen_combo/combination.py');_ready=True
def old(name):
    need(_ready and name in sys.modules,'shared binding not configured');return sys.modules[name]
