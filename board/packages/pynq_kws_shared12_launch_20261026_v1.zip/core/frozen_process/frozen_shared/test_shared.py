"""New shared-session seams. All devices, MMIO, DMA and locks are software fixtures."""
from contextlib import contextmanager
from dataclasses import FrozenInstanceError,replace
import copy,gc,sys,threading,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import shared_binding as b
b.configure(enabled=True)
from shared_policy import SharedPolicy,validate_shared_policy,INDICES
from shared_owner import SharedOwner,OriginalOwner,_init,_execute
from shared_reference import REFERENCE as ref
from shared_call import SharedCall,_body,OriginalCall
from shared_fixture import SharedHarness,FakeCanonicalEnvironment
from shared_run import depthwise
from op4_candidate import InputEnvelope
from batch_policy import BatchStop
class SharedTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.c2=ref.derive(2,0);cls.c4=ref.derive(4,0);cls.other=ref.derive(2,30)
        cls.parameters=b.old('combination').depthwise_parameters()
        cls.dynamic,cls.acc=depthwise(cls.c2['expected'].copy(),cls.parameters)
    @contextmanager
    def started(self,**options):
        h=SharedHarness(self.c2,**options);env=FakeCanonicalEnvironment()
        with env.install(),h.resident(env):yield h,env
    def envelope(self,case=None,layer=2):
        case=self.c2 if case is None else case
        return InputEnvelope(layer,23 if layer==2 else 25,case['cohort_index'],case['source_id'],case['feature_sha256'],case['a'].copy(order='C'))
    def advance2(self,h):
        h.set_case(self.c2);call=SharedCall(h.owner,self.c2,enabled=True);out,data=call(self.envelope());return call,out,data
    def test_01_policy_default_off(self):
        with self.assertRaises(ValueError):SharedPolicy()
    def test_02_policy_bool_identity(self):
        for x in [1,False,None]:
            with self.subTest(x=x),self.assertRaises(ValueError):SharedPolicy(x)
    def test_03_policy_exact24_layers(self):
        p=SharedPolicy(True);self.assertEqual([p.request(i).operator_index for i in range(24)],[2,4]*12)
        self.assertEqual([p.request(i).cohort_index for i in range(24)],[i for i in INDICES for _ in range(2)])
    def test_04_global_ids_1_to48(self):
        p=SharedPolicy(True);self.assertEqual([j for i in range(24) for j in [p.request(i).first_job_id,p.request(i).first_job_id+1]],list(range(1,49)))
    def test_05_policy_index_types_and_bounds(self):
        for x in [False,True,-1,24,0.0]:
            with self.subTest(x=x),self.assertRaises(ValueError):SharedPolicy(True).request(x)
    def test_06_request_frozen(self):
        with self.assertRaises(FrozenInstanceError):SharedPolicy(True).request(0).operator_index=4
    def test_07_old_policy_not_coerced(self):
        old=b.old('pointwise_policy').PointwisePolicy(True)
        with self.assertRaises(ValueError):validate_shared_policy(old)
        with self.assertRaises(ValueError):b.old('pointwise_policy').validate_pointwise_policy(SharedPolicy(True))
    def test_08_old_owner_rejects_new_policy(self):
        with self.assertRaises(ValueError):OriginalOwner(SharedPolicy(True),lambda:False,enabled=True)
    def test_09_new_owner_default_off(self):
        with self.assertRaises(ValueError):SharedOwner(SharedPolicy(True),lambda:False)
    def test_10_old_safety_methods_same_objects(self):
        for n in ['start','_owned','_hold','_identity','_buffers_valid','pre_submit','close']:
            self.assertIs(getattr(SharedOwner,n),getattr(OriginalOwner,n))
    def test_11_private_init_execute_code_identity(self):
        self.assertIs(_init.__code__,OriginalOwner.__init__.__code__);self.assertIs(_execute.__code__,OriginalOwner.execute_chain.__code__)
        self.assertIsNot(_init.__globals__,OriginalOwner.__init__.__globals__)
    def test_12_driver_body_code_identity(self):
        self.assertIs(_body.__code__,OriginalCall.__call__.__code__)
        self.assertIsNot(_body.__globals__,OriginalCall.__call__.__globals__)
    def test_13_frozen_globals_validation_unchanged(self):
        self.assertIs(OriginalOwner.__init__.__globals__['validate_pointwise_policy'],b.old('pointwise_policy').validate_pointwise_policy)
        self.assertIs(OriginalCall.__call__.__globals__['sources'],b.old('runtime_reference').sources)
    def test_14_old_reference_rejects_shared_owner(self):
        with self.started() as (h,e),self.assertRaisesRegex(ValueError,'exact owner'):b.old('runtime_reference').authorize_owner(h.owner)
    def test_15_new_reference_requires_initialized_owner(self):
        owner=SharedOwner(SharedPolicy(True),lambda:False,enabled=True)
        with self.assertRaises(ValueError):ref.authorize(owner)
    def test_16_reference_owner_subclass_rejected(self):
        class Other(SharedOwner):pass
        with self.assertRaises(ValueError):ref.authorize(Other(SharedPolicy(True),lambda:False,enabled=True))
    def test_17_call_default_off(self):
        with self.started() as (h,e),self.assertRaises(ValueError):SharedCall(h.owner,self.c2)
    def test_18_old_call_stays_exact_owner(self):
        with self.started() as (h,e),self.assertRaisesRegex(ValueError,'exact pointwise owner'):OriginalCall(h.owner,self.c2,enabled=True)
    def test_19_call_wrong_scheduled_layer_case(self):
        with self.started() as (h,e):
            with self.assertRaises(ValueError):SharedCall(h.owner,self.c4,enabled=True)
            self.assertTrue(h.owner._session_failed);self.assertFalse(h.events and any(x[0]=='transfer' for x in h.events))
    def test_20_wrong_window_case_rejected(self):
        with self.started() as (h,e),self.assertRaisesRegex(ValueError,'window'):SharedCall(h.owner,self.other,enabled=True)
    def test_21_forged_oracle_rejected(self):
        case=copy.deepcopy(self.c2);case['expected'][0,0]^=1
        with self.started() as (h,e),self.assertRaisesRegex(ValueError,'expected'):SharedCall(h.owner,case,enabled=True)
    def test_22_case_extra_field_rejected(self):
        with self.started() as (h,e),self.assertRaisesRegex(ValueError,'case fields'):SharedCall(h.owner,dict(self.c2,extra=1),enabled=True)
    def reject(self,edit,pattern):
        with self.started() as (h,e):
            call=SharedCall(h.owner,self.c2,enabled=True)
            with self.assertRaisesRegex(ValueError,pattern):call(edit(self.envelope()))
            self.assertTrue(h.owner._session_failed);self.assertIsNone(h.owner._admission);self.assertFalse(any(x[0]=='transfer' for x in h.events))
    def test_23_cross_layer_envelope(self):self.reject(lambda e:replace(e,operator_index=4),'layer')
    def test_24_cross_tensor_envelope(self):self.reject(lambda e:replace(e,tensor_index=25),'layer')
    def test_25_bool_index_envelope(self):self.reject(lambda e:replace(e,cohort_index=False),'window')
    def test_26_cross_window_envelope(self):self.reject(lambda e:replace(e,cohort_index=30),'window')
    def test_27_wrong_feature(self):self.reject(lambda e:replace(e,feature_sha256='0'*64),'window')
    def test_28_nonowning_input(self):self.reject(lambda e:replace(e,values=e.values[:]),'owning')
    def test_29_changed_input(self):
        def edit(e):
            a=e.values.copy();a[0,0]^=1;return replace(e,values=a)
        self.reject(edit,'owning exact')
    def test_30_no_direct_owner_submission(self):
        with self.started() as (h,e),self.assertRaisesRegex(ValueError,'admission'):h.owner.execute_chain([])
    def test_31_call_one_shot_and_session_poison(self):
        with self.started() as (h,e):
            call,_,_=self.advance2(h)
            with self.assertRaises(ValueError):call(self.envelope())
            self.assertTrue(h.owner._session_failed)
            with self.assertRaisesRegex(ValueError,'failed shared'):SharedCall(h.owner,self.c4,enabled=True)
    def test_32_interleaved_op2_op4_dynamic_and_reused_buffers(self):
        with self.started() as (h,e):
            original=tuple(map(id,h.owner._buffers));_,out2,_=self.advance2(h)
            dynamic,acc=depthwise(out2.copy(),self.parameters);up=b.old('combination').make_upstream(out2.tobytes(),self.c2,'fixture')
            env=b.old('combination').dynamic_envelope(up,dynamic,self.c4);h.set_case(dict(self.c4,a=dynamic))
            call=SharedCall(h.owner,self.c4,enabled=True);out4,data=call(env)
            self.assertEqual(call.spec.first_job_id,3);self.assertTrue(np.array_equal(out4,self.c4['expected']))
            self.assertEqual(tuple(map(id,h.owner._buffers)),original);h.check_reuse()
            self.assertTrue(np.array_equal(b.old('combination').wire_input(data['input_chain'],3),dynamic))
        self.assertEqual(h.report(e)['allocations'],2);self.assertEqual(h.close_attempts,1);self.assertEqual(h.report(e)['free_events'],2)
    def test_33_stale_op2_used_as_op4_rejected(self):
        with self.started() as (h,e):
            _,out2,_=self.advance2(h);call=SharedCall(h.owner,self.c4,enabled=True)
            with self.assertRaisesRegex(ValueError,'owning exact'):call(InputEnvelope(4,25,0,self.c4['source_id'],self.c4['feature_sha256'],out2.copy()))
    def test_34_header_and_counter_fault_keeps_original_gate(self):
        with self.started() as (h,e):
            h.set_case(self.c2);original=h.owner._runner.run_chain
            def changed(*args,**kwargs):
                raw,records,m=original(*args,**kwargs);m=dict(m,failed_tile_index=0);return raw,records,m
            h.owner._runner.run_chain=changed;call=SharedCall(h.owner,self.c2,enabled=True)
            with self.assertRaisesRegex(ValueError,'counters'):call(self.envelope())
            self.assertEqual(len(call.first_failure['payload']),32000);self.assertFalse(h.owner._held)
    def test_35_unsafe_before_return_retains_and_does_not_free(self):
        h=SharedHarness(self.c2);e=FakeCanonicalEnvironment()
        with e.install(),h.resident(e):
            h.fail_before_return=True;call=SharedCall(h.owner,self.c2,enabled=True)
            with self.assertRaises(RuntimeError):call(self.envelope())
            self.assertTrue(h.owner._held and h.owner._unsafe);self.assertIsNone(call.first_failure['payload'])
            with self.assertRaisesRegex(RuntimeError,'quarantined'):h.owner.close()
        r=h.report(e);self.assertEqual(r['free_events'],0);self.assertEqual(r['close_attempts'],0)
        self.assertTrue(r['before_test_teardown']['resources']['lease_retained']);self.assertTrue(r['before_test_teardown']['fake_fd_live'])
    def test_36_partial_allocation_holds_not_closes(self):
        h=SharedHarness(self.c2,allocation_failure=1);e=FakeCanonicalEnvironment()
        with self.assertRaises(RuntimeError):
            with e.install(),h.resident(e):pass
        self.assertTrue(h.owner._held);self.assertEqual(h.close_attempts,0);self.assertEqual(len(h.owner._buffers),1)
    def test_37_missing_lock_is_pre_factory_safe_failure(self):
        h=SharedHarness(self.c2);e=FakeCanonicalEnvironment(missing=True)
        with self.assertRaises(FileNotFoundError):
            with e.install(),h.resident(e):pass
        self.assertFalse(h.owner._held);self.assertTrue(h.owner._closed);self.assertFalse(h.buffers)
    def test_38_busy_factory_is_uncertain_hold(self):
        h=SharedHarness(self.c2);e=FakeCanonicalEnvironment(busy=True)
        with self.assertRaises(BlockingIOError):
            with e.install(),h.resident(e):pass
        self.assertTrue(h.owner._held);self.assertFalse(h.owner._closed);self.assertEqual(h.close_attempts,0)
    def test_39_stop_before_call_no_transfer(self):
        with self.started() as (h,e):
            call=SharedCall(h.owner,self.c2,enabled=True);h.stop=True
            with self.assertRaises(BatchStop):call(self.envelope())
            self.assertFalse(any(x[0]=='transfer' for x in h.events));self.assertFalse(h.owner._held)
    def test_40_buffer_alias_detected(self):
        with self.started() as (h,e):
            before=h.owner._buffers[1];h.owner._buffers[1]=h.owner._buffers[0]
            with self.assertRaises(RuntimeError):h.owner.pre_submit()
            h.owner._buffers[1]=before
    def test_41_changed_job_id_after_call_init_rejected(self):
        with self.started() as (h,e):
            call=SharedCall(h.owner,self.c2,enabled=True);h.owner._index=1
            with self.assertRaisesRegex(ValueError,'schedule'):call(self.envelope())
    def test_42_module_binding_drift_rejected(self):
        old=b.old('real_case');oldfn=old.derive
        with patch.object(old,'derive',lambda:None),self.assertRaisesRegex(ValueError,'module drift'):ref.sources2()
        self.assertIs(old.derive,oldfn)
    def test_43_foreign_pynq_authorization_rejected(self):
        from types import ModuleType
        with self.started() as (h,e),patch.dict(sys.modules,{'pynq':ModuleType('pynq')}),self.assertRaises(ValueError):ref.sources2()
    def test_44_thread_drift_rejected(self):
        with self.started() as (h,e):
            call=SharedCall(h.owner,self.c2,enabled=True);errors=[]
            def other():
                try:call(self.envelope())
                except Exception as x:errors.append(type(x).__name__)
            t=threading.Thread(target=other);t.start();t.join();self.assertEqual(errors,['ValueError']);self.assertFalse(call.used)
    def test_45_reference_frozen_owner_global_unchanged(self):
        self.assertIs(b.old('pointwise_owner').PointwiseOwner,OriginalOwner);self.assertIsNone(b.old('runtime_reference')._owner)
    def test_46_unknown_layer_rejected(self):
        for layer in [True,0,3,6]:
            with self.subTest(layer=layer),self.assertRaises(ValueError):ref.derive(layer,0)
    def test_47_driver_call_body_not_new_math(self):
        self.assertIs(_body.__globals__['make_jobs'],ref.make_jobs);self.assertIs(_body.__globals__['sources'],ref.sources2)
    def test_48_no_real_pynq_module_left(self):self.assertNotIn('pynq',sys.modules)
    def test_49_depthwise_parameter_shape_and_dtype_guard(self):
        for name,value in [('weights',np.zeros((1,1,1,64),np.int8)),('bias',np.zeros(64,np.int16)),('scales',np.zeros(64,np.float32))]:
            with self.subTest(name=name),self.assertRaisesRegex(ValueError,'parameter shapes'):depthwise(self.c2['expected'].copy(),dict(self.parameters,**{name:value}))
if __name__=='__main__':unittest.main(verbosity=2)
