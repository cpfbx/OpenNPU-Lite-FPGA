"""Single fixed PC child + frozen wait/signal observers; no timeout kill/retry."""
import os
import subprocess
import sys
from pathlib import Path
import shared_process_binding as b
import shared_process_contract as ct
from shared_process_fixture import Guardian, finite_supervised


def validate_ready(value, child, req, request_sha):
    b.need(type(value) is dict and value['kind'] == 'ready' and type(value['pid']) is int and value['pid'] == child.pid
           and value['process'] == ct.process_identity(child.pid) and value['run_id'] == req['run_id']
           and value['request_sha256'] == request_sha and value['identity'] == ct.FAKE_IDENTITY
           and value['fake_lock_evidence'] is True and value['fixture'] is True, 'bound worker ready')
    ticket = value['ticket']
    b.need(type(ticket) is dict and type(ticket['pid']) is int and ticket['pid'] == child.pid
           and type(ticket['fd']) is int and ticket['fd'] == 99 and ticket['path'] == ct.FAKE_IDENTITY['path']
           and type(ticket['device']) is int and ticket['device'] == 2048
           and type(ticket['inode']) is int and ticket['inode'] == 11
           and type(ticket['process_start_ticks']) is int and ticket['process_start_ticks'] == 123, 'synthetic owned ticket binding')
    return value


def validate_terminal(folder, pid, req, request_sha):
    value = ct.terminal(folder)
    b.need(type(value['pid']) is int and value['pid'] == pid and value['run_id'] == req['run_id']
           and value['request_sha256'] == request_sha and value['outer_process_exit_observed'] is False, 'terminal process/request binding')
    for key, expected in ct.FLAGS.items():
        b.need(type(value.get(key)) is type(expected) and value[key] == expected, 'terminal fixed scope ' + key)
    b.need(value['automatic_retry'] is False and value['automatic_kill'] is False
           and type(value['operation_success']) is bool and type(value['safety_unresolved']) is bool
           and value['finite_supervisor_fixture'] is (req['scenario'] == 'unsafe'), 'terminal lifecycle scope')
    base_members = {'artifact_manifest.json', 'artifact_manifest.json.ready', 'terminal.json', 'terminal.json.ready'}
    if value['cleanup']['kind'] == 'no_fake_resources':
        status = value['cleanup']['resources']
        b.need(req['scenario'] == 'stop_before_start' and value['ticket'] is None and value['summary_sha256'] is None
               and value['completed_indices'] == [] and value['operation_success'] is False and value['safety_unresolved'] is False
               and type(status['pid']) is int and status['pid'] == pid
               and all(type(status[k]) is type(expected) and status[k] == expected for k, expected in
                       dict(held=False, safety_unresolved=False, lease_retained=False, runner_retained=False, root_buffers_retained=0).items()),
               'explicit stop before any fake resource')
        b.need(set(b.inventory(folder)) == base_members | {'fault.json', 'fault.json.ready'}, 'exact pre-resource artifacts')
        return value
    summary = ct.strict_json(ct.read(folder / 'data/summary.json'))
    b.need(b.sha(ct.read(folder / 'data/summary.json')) == value['summary_sha256'], 'bound chain summary')
    completed = summary['completed_indices']
    b.need(type(completed) is list and all(type(i) is int for i in completed)
           and completed == list(ct.INDICES[:len(completed)]) and len(completed) <= 12
           and summary['not_completed_indices'] == list(ct.INDICES[len(completed):])
           and value['completed_indices'] == completed and len(summary['windows']) == len(completed), 'exact shared completion prefix')
    b.need(summary['fixture'] is True and summary['board_access'] is False and summary['real_lock_access'] is False
           and summary['real_DMA_executed'] is False and summary['real_cross_layer_PL_execution'] is False
           and summary['counters_synthetic'] is True and summary['performance_evaluated'] is False
           and summary['energy_evaluated'] is False and summary['classification_quality_evaluated'] is False
           and summary['promotion'] is False and summary['run_ready'] is False, 'chain evidence remains software fixture')
    expected_counts = {'normal': (12, 12, 12, 24, 24, 12), 'raw_fault': (4, 3, 4, 8, 8, 3),
                       'stop': (4, 3, 3, 7, 7, 3), 'unsafe': (4, 3, 4, 7, 8, 3),
                       'parent_stop': (4, 3, 3, 7, 7, 3), 'no_go': (0, 0, 0, 0, 0, 0)}
    counts = expected_counts[req['scenario']]
    a2, a4, dw, submitted, consumed, complete = counts
    for key, expected in dict(accepted_op2_calls=a2, accepted_op4_calls=a4, depthwise_executed_calls=dw,
                              depthwise_executed_logical_MACs=72000 * dw, fixture_submissions=submitted,
                              fixture_jobs=2 * submitted, fixture_MACs=512000 * submitted,
                              completed_chain_depthwise_logical_MACs=72000 * complete).items():
        b.need(type(summary.get(key)) is int and summary[key] == expected, 'exact scenario accounting ' + key)
    b.need(len(completed) == complete and len(summary['calls']) == a2 + a4, 'scenario complete/call counts')
    for i, call in enumerate(summary['calls']):
        b.need(call == dict(request_index=i, cohort_index=ct.INDICES[i // 2], operator_index=2 if i % 2 == 0 else 4,
                            first_job_id=1 + 2 * i, accepted=True), 'accepted alternating call prefix')
    golden = ct.strict_json(ct.read(b.ROOT / 'golden_index.json'))
    bank = ct.strict_json(ct.read(b.ROOT / 'golden_records.json'))
    counter = b.load('_shared_process_counter', b.HW / 'legacy/frozen_source/d007_mode11_contract.py')
    for index, row in enumerate(summary['windows']):
        cohort = ct.INDICES[index]
        sub = folder / 'data' / ('window_%03d' % cohort)
        b.need(row == ct.strict_json(ct.read(sub / 'result.json')) and row['cohort_index'] == cohort
               and row['source_id'] == bank[str(cohort)]['source_id'] and row['feature_sha256'] == bank[str(cohort)]['feature_sha256']
               and row['actual_dynamic_payload_identity'] is True and row['same_resource_pair'] is True, 'bound shared window source')
        expected_names = {Path(n).name for n in golden if n.startswith('window_%03d/' % cohort)}
        b.need(set(row['artifacts']) == expected_names and len(expected_names) == 22, '22 exact shared outputs')
        for name, expected in row['artifacts'].items():
            raw = ct.read(sub / name, 32000)
            actual = dict(bytes=len(raw), sha256=b.sha(raw))
            b.need(actual == expected == golden['window_%03d/' % cohort + name], 'all shared values equal frozen golden')
        for offset, layer in enumerate(('op2', 'op4')):
            call_index = 2 * index + offset
            first = 1 + 2 * call_index
            b.need(type(row[layer + '_request_index']) is int and row[layer + '_request_index'] == call_index
                   and type(row[layer + '_first_job_id']) is int and row[layer + '_first_job_id'] == first, 'shared alternating request/job IDs')
            metrics = row[layer + '_fake_metrics']
            wanted = dict(mode=11, jobs=2, chain_jobs_completed=2, input_bytes=16512, input_payload_bytes=16384,
                          input_header_bytes=128, output_bytes=32000, output_valid_bytes=32000, effective_macs=512000,
                          first_job_id=first, error_code=0, failed_tile_index=65535, counter_contract_version=2)
            b.need(all(type(metrics.get(k)) is int and metrics[k] == expected for k, expected in wanted.items())
                   and metrics.get('counter_contract') == 'd007_global_work_v2' and metrics.get('layout') == 'k_major'
                   and type(metrics.get('status')) is int and metrics['status'] & (2 | 4 | 8) == 4
                   and metrics.get('mode11_counter_read_strategy') == 'pynq_mmio_read'
                   and 'counter_evidence' not in metrics and all(counter.validate_summary(metrics).values()), 'shared parent counter gate')
    if 'payload' in (summary.get('failure') or {}):
        raw = ct.read(folder / 'data/first_failure.bin', 32000)
        b.need(dict(bytes=len(raw), sha256=b.sha(raw)) == summary['failure']['payload'] == golden['first_failure.bin'], 'bounded first-failure bytes')
    report = summary['single_session_fixture']
    state = report['before_test_teardown']
    b.need(value['cleanup']['resources'] == state['resources'], 'same retained/closed resource snapshot')
    b.need(value['cleanup']['before_test_teardown'] == state and value['cleanup']['fake_lock_evidence'] is True
           and value['ticket']['pid'] == pid and value['ticket']['inode'] == 11 and value['ticket']['device'] == 2048
           and value['ticket']['path'] == ct.FAKE_IDENTITY['path'], 'same synthetic ticket/cleanup')
    sw = state['software_admission']
    b.need(all(sw.get(k) is True for k in ('active_call_cleared', 'producer_cleared', 'call_guard_released')), 'software call state cleared')
    b.need(report['overlay_initializations'] == 1 and report['allocations'] == 2
           and report['fake_open_calls'] == report['fake_flock_calls'] == 1, 'single fake resource session')
    b.need(all(type(sw.get(k)) is int and sw[k] == expected for k, expected in dict(issued=consumed, consumed=consumed, revoked=0).items())
           and type(report['fixture_submissions']) is int and report['fixture_submissions'] == submitted
           and type(report['owner_completed_driver_returns']) is int and report['owner_completed_driver_returns'] == submitted,
           'permit consumption versus driver return accounting')
    if value['safety_unresolved']:
        b.need(req['scenario'] == 'unsafe' and value['cleanup']['kind'] == 'TEST_ONLY_retained'
               and state['resources']['held'] is True and state['resources']['safety_unresolved'] is True
               and state['fake_fd_live'] is True and state['fake_lock_held'] is True and state['closed'] is False
               and (state['close_attempts'], state['free_events'], state['resources']['root_buffers_retained']) == (0, 0, 2)
               and value['operation_success'] is False, 'explicit unresolved fake resources retained')
    else:
        b.need(value['cleanup']['kind'] == 'closed_fake_owner' and state['closed'] is True
               and state['fake_fd_live'] is False and state['fake_lock_held'] is False
               and (state['close_attempts'], state['free_events']) == (1, 2)
               and all(state['resources'][k] in (False, 0) for k in ('held', 'safety_unresolved', 'lease_retained', 'runner_retained', 'root_buffers_retained')), 'closed fake owner evidence')
    if value['operation_success']:
        b.need(req['scenario'] == 'normal' and summary['operation_success'] is True and completed == list(ct.INDICES)
               and summary['accepted_op2_calls'] == summary['accepted_op4_calls'] == 12
               and (sw['issued'], sw['consumed'], sw['revoked']) == (24, 24, 0)
               and report['fixture_submissions'] == report['owner_completed_driver_returns'] == 24
               and value['signals'] == dict(stop_signals=[], handler_errors=[], handler_restore_errors=[], original_supervisor_unchanged=True), 'complete clean shared success')
    else:
        b.need(summary['operation_success'] is False, 'failed terminal cannot mask chain success')
    expected_members = base_members | {'ready.json', 'ready.json.ready', 'data/summary.json'}
    for cohort in ct.INDICES[:a2]:
        expected_members.update({'entered_%03d.json' % cohort, 'entered_%03d.json.ready' % cohort})
    for cohort in completed:
        expected_members.add('data/window_%03d/result.json' % cohort)
        expected_members.update('data/' + name for name in golden if name.startswith('window_%03d/' % cohort))
    if req['scenario'] != 'normal':
        expected_members.update({'fault.json', 'fault.json.ready'})
    if req['scenario'] == 'raw_fault':
        expected_members.update({'data/first_failure.bin', 'data/return_diagnostic.json'})
    if req['scenario'] == 'unsafe':
        expected_members.update({'data/return_diagnostic.json', 'attention_retained.json', 'attention_retained.json.ready'})
    if req['scenario'] == 'parent_stop':
        expected_members.update({'await_parent_stop.json', 'await_parent_stop.json.ready'})
    b.need(set(b.inventory(folder)) == expected_members, 'exact scenario worker member set')
    # Re-signed publication markers or foreign progress records are not evidence.
    for name in expected_members:
        if name.endswith('.json.ready'):
            b.need(ct.read(folder / name, 0) == b'', 'empty final publication marker')
    ready_record = ct.ready(folder / 'ready.json')
    b.need(ready_record['ticket'] == value['ticket'] and ready_record['process'] == value['process']
           and ready_record['pid'] == pid and ready_record['run_id'] == req['run_id']
           and ready_record['request_sha256'] == request_sha and ready_record['fake_lock_evidence'] is True,
           'final ready matches terminal')
    for cohort in ct.INDICES[:a2]:
        entered = ct.ready(folder / ('entered_%03d.json' % cohort))
        b.need(type(entered['cohort_index']) is int and type(entered['pid']) is int and entered ==
               dict(stage='op2_before_submit', cohort_index=cohort, pid=pid, run_id=req['run_id'], request_sha256=request_sha),
               'bound entered window record')
    if req['scenario'] != 'normal':
        fault = ct.ready(folder / 'fault.json')
        b.need(type(fault['pid']) is int and fault['pid'] == pid and fault['request_sha256'] == request_sha
               and fault['run_id'] == req['run_id'] and fault['safety_unresolved'] is value['safety_unresolved'],
               'bound fault record')
    if req['scenario'] == 'parent_stop':
        waiting = ct.ready(folder / 'await_parent_stop.json')
        b.need(type(waiting['cohort_index']) is int and type(waiting['pid']) is int and waiting ==
               dict(stage='before_depthwise', cohort_index=90, pid=pid, run_id=req['run_id']), 'bound parent-stop marker')
    return value


def launch(config, config_sha, folder, *, enabled=False):
    b.need(enabled is True, 'shared process parent default-off')
    b.pc_only()
    req = ct.read_request(config, config_sha)
    b.verify(req['candidate_manifest_sha256'])
    before = b.inventory(b.ROOT)
    bridge, observer = b.controls()
    folder = ct.outside(folder)
    b.need(not os.path.lexists(folder), 'fresh external parent evidence')
    ct.write_json(ct.canonical(config).parent / ('attempt_' + req['run_id'] + '.json'),
                  dict(request_sha256=config_sha, run_id=req['run_id']))
    folder.mkdir()
    worker = folder / 'worker'
    worker.mkdir()
    guardian = Guardian()
    binding = ct.launch_binding(req, config_sha)
    launch_sha = ct.write_json(folder / 'launch.json', binding)['sha256']
    finite = req['scenario'] == 'unsafe'
    record = dict(operation_success=False, run_id=req['run_id'], request_sha256=config_sha,
                  actual_wait_observed=False, actual_exit_code=None, process_group_absent=None,
                  cleanup_verified=False, fake_lock_release_verified=False, live_fake_ticket_observed=False,
                  parent_go_sent=False, automatic_retry=False, automatic_kill=False,
                  finite_supervisor_fixture=finite, original_infinite_hold_executed=False,
                  process_group_proof_real=os.name == 'posix', **ct.FLAGS)
    child_terminal = None
    ready_value = None
    go_sent = False
    primary = None

    def cancel():
        if not os.path.lexists(folder / 'stop.flag'):
            ct.write(folder / 'stop.flag', b'')

    def publish(value):
        ct.write_json(folder / 'attention_retained.json', dict(value, request_sha256=config_sha, **ct.FLAGS))

    def operation(stopped):
        nonlocal child_terminal, ready_value, go_sent
        try:
            b.need(stopped() is False, 'stop before fixed child')
            command = [sys.executable, '-I', '-B', str(b.ROOT / 'shared_pc_entry.py'), '--request', str(ct.canonical(config)),
                       '--request-sha', config_sha, '--launch', str(folder / 'launch.json'), '--launch-sha', launch_sha,
                       '--folder', str(worker), '--enable-PC-fixture']
            options = dict(stdin=subprocess.DEVNULL, close_fds=True, shell=False)
            if os.name == 'posix':
                options['start_new_session'] = True
            else:
                options['creationflags'] = subprocess.CREATE_NO_WINDOW
            with (folder / 'child.stdout.txt').open('xb') as out, (folder / 'child.stderr.txt').open('xb') as err:
                guardian.begin()
                child = subprocess.Popen(command, stdout=out, stderr=err, **options)
                guardian.retain(child)
                ct.write_json(folder / 'child_started.json', dict(pid=child.pid, process=ct.process_identity(child.pid),
                                                                 run_id=req['run_id'], request_sha256=config_sha))

                def monitor():
                    nonlocal ready_value, go_sent
                    value = ct.ready(worker / 'ready.json')
                    if value is not None and not go_sent:
                        validate_ready(value, child, req, config_sha)
                        ready_value = value
                        record['live_fake_ticket_observed'] = True
                        if req['scenario'] == 'no_go':
                            cancel()
                            return True
                        ct.write_json(folder / 'go.json', dict(kind='go', pid=child.pid, parent=binding['parent'],
                                                               run_id=req['run_id'], request_sha256=config_sha,
                                                               ready_sha256=b.sha(ct.read(worker / 'ready.json')), fixture=True))
                        go_sent = True
                    if req['scenario'] == 'parent_stop' and ct.ready(worker / 'await_parent_stop.json') is not None:
                        cancel()
                        return True
                    return stopped()

                query = None if os.name == 'posix' else (lambda pid: True)
                observed = observer.observe_exit(child, guardian, monitor, cancel, group_query=query)
                record.update(observed)
            ct.write_json(folder / 'observed_child_exit.json', record)
            b.need(record['actual_wait_observed'] is True and record['process_group_absent'] is True, 'wait/group observation')
            child_terminal = validate_terminal(worker, child.pid, req, config_sha)
            if child_terminal['cleanup']['kind'] == 'no_fake_resources':
                b.need(req['scenario'] == 'stop_before_start' and ready_value is None and go_sent is False, 'no false lease/GO before resources')
            else:
                b.need(ready_value is not None and child_terminal['ticket'] == ready_value['ticket']
                       and child_terminal['process'] == ready_value['process'], 'same synthetic acquired ticket/process')
            record['parent_go_sent'] = go_sent
            record['child_terminal'] = child_terminal
            if child_terminal['safety_unresolved']:
                guardian._hold(RuntimeError('unresolved fake worker resources'))
                raise RuntimeError('TEST_ONLY retain unresolved resources')
            record['cleanup_verified'] = True
            record['fake_lock_release_verified'] = child_terminal['ticket'] is not None
            guardian.forget(child)
            b.need(record['actual_exit_code'] == (0 if child_terminal['operation_success'] else 1), 'actual exit/terminal agreement')
            b.need(record['actual_exit_code'] == 0 and go_sent and child_terminal['operation_success'] is True
                   and record['stop_seen'] is False, 'complete normal operation only')
            record['operation_success'] = True
            return record
        except BaseException as error:
            partial = getattr(error, 'comparison_exit_observation', None)
            if partial is not None:
                record.update(partial)
            if guardian.child is not None or guardian.pending:
                guardian._hold(error)
            raise

    try:
        result = (finite_supervised if finite else bridge.supervised)(guardian, operation, publish,
                                                                     lambda: os.path.lexists(folder / 'stop.flag'), enabled=True)
        record['signals'] = result['signals']
    except BaseException as error:
        primary = error
        record['signals'] = getattr(error, 'supervision_bridge_observation', None)
    b.need(not (guardian.held or guardian.pending or guardian.child is not None) or finite, 'supervisor returned unresolved parent')
    record['parent_guardian'] = guardian.supervision_status
    record['error_type'] = None if primary is None else type(primary).__name__
    record['operation_success'] = record['operation_success'] and primary is None
    record['sources_unchanged'] = before == b.inventory(b.ROOT)
    b.need(record['sources_unchanged'], 'immutable process candidate changed')
    ct.write_json(folder / 'outer_receipt.json', record)
    return record


if __name__ == '__main__':
    raise SystemExit('Library only; no board launch authority.')
