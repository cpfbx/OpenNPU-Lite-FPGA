"""Explicit finite PC-only retention observation; no real resource or hold escape."""
import os


def finite_supervised(factory, operation, publish, external_stopped, *, enabled=False):
    if enabled is not True:
        raise ValueError('finite fixture default-off')
    try:
        result = operation(external_stopped)
    except BaseException:
        status = factory.supervision_status
        if any(status[k] for k in ('held', 'safety_unresolved', 'lease_retained', 'runner_retained', 'root_buffers_retained')):
            publish(dict(status, TEST_ONLY_finite_retention=True, original_infinite_hold_executed=False))
        raise
    status = factory.supervision_status
    if any(status[k] for k in ('held', 'safety_unresolved', 'lease_retained', 'runner_retained', 'root_buffers_retained')):
        publish(dict(status, TEST_ONLY_finite_retention=True, original_infinite_hold_executed=False))
        raise RuntimeError('TEST_ONLY unresolved fixture retained')
    return dict(result=result, signals=dict(stop_signals=[], handler_errors=[], handler_restore_errors=[],
                                           original_supervisor_unchanged=False, TEST_ONLY_finite_retention=True))


class Guardian:
    def __init__(self):
        import threading
        self.pid = os.getpid()
        self.thread = threading.get_ident()
        self.child = None
        self.pending = self.used = self.held = False

    @property
    def supervision_status(self):
        return dict(pid=self.pid, held=self.held, safety_unresolved=self.held or self.pending,
                    lease_retained=False, runner_retained=self.child is not None, root_buffers_retained=0)

    def owned(self):
        import threading
        if (os.getpid(), threading.get_ident()) != (self.pid, self.thread):
            raise ValueError('parent ownership drift')

    def begin(self):
        self.owned()
        if self.used or self.held or self.child is not None:
            raise ValueError('one child only; no retry')
        self.used = self.pending = True

    def retain(self, child):
        self.owned()
        if not self.pending or self.child is not None or self.held:
            raise ValueError('exact pending child')
        self.child = child
        self.pending = False

    def forget(self, child):
        self.owned()
        if self.pending or self.held or self.child is not child:
            raise ValueError('cannot forget unresolved child')
        self.child = None

    def _hold(self, error):
        self.held = True
