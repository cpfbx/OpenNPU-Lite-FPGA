"""Fixed x86 PC-fixture child. Never an ARM/board entry."""
import argparse
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import shared_process_binding as b
import shared_process_contract as ct


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('request', 'request-sha', 'launch', 'launch-sha', 'folder'):
        parser.add_argument('--' + name, required=True)
    parser.add_argument('--enable-PC-fixture', action='store_true')
    args = parser.parse_args()
    b.need(args.enable_PC_fixture is True, 'PC child default-off')
    b.pc_only()
    req = ct.read_request(args.request, args.request_sha)
    b.verify(req['candidate_manifest_sha256'])
    folder = ct.outside(args.folder)
    b.need(ct.canonical(args.launch) == folder.parent / 'launch.json', 'fixed parent launch location')
    raw = ct.read(args.launch, 30000)
    b.need(b.sha(raw) == ct.digest(args.launch_sha), 'launch pin')
    from shared_process_worker import run_worker
    result = run_worker(req, args.request_sha, folder, ct.strict_json(raw), enabled=True)
    return 0 if result['operation_success'] else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (ValueError, OSError, RuntimeError, ImportError) as error:
        print({'error_type': type(error).__name__, 'fixture': True, 'board_access': False, 'promotion': False}, file=sys.stderr)
        raise SystemExit(2)
