"""Device boundary/gate counterexamples. All resources in these tests are fake."""
import ast
from contextlib import contextmanager
import gc
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import Mock,patch
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import device_binding as b
import device_contract as ct
from device_session import SharedDeviceSession,LiveEvidence
from device_parent import ParentEvidenceChecks,validate_ready,validate_terminal,validate_metrics,launch_pc
from device_fixture import WireEnvironment,FixtureParentEvidence
TEMPLATE=Path(sys.argv.pop()).resolve();OUTPUT=Path(sys.argv.pop()).resolve();OUTPUT.mkdir(parents=True)

class DeviceAdapterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.c=b.configure(enabled=True);cls.req=ct.strict_json((TEMPLATE/'request.json').read_bytes());cls.sha=b.sha((TEMPLATE/'request.json').read_bytes())
        cls.worker=TEMPLATE/'evidence/worker';cls.term=ct.terminal(cls.worker)
        cls.case=cls.c.reference.derive(2,0)
    def setUp(self):gc.collect()
    def fresh(self):return Path(tempfile.mkdtemp(prefix=self._testMethodName+'_',dir=OUTPUT))
    def real(self):
        r=dict(self.req);r.pop('fixture_profile');r.update(schema=ct.REAL_SCHEMA,fixture=False);return r
    def worker_copy(self):
        target=self.fresh()/'worker';shutil.copytree(self.worker,target);return target
    def overwrite(self,path,value):path.write_bytes((json.dumps(value,sort_keys=True,indent=2)+'\n').encode())
    def reseal(self,folder):
        t=ct.strict_json((folder/'terminal.json').read_bytes());t['summary_sha256']=b.sha((folder/'data/summary.json').read_bytes())
        excluded={'artifact_manifest.json','artifact_manifest.json.ready','terminal.json','terminal.json.ready'}
        self.overwrite(folder/'artifact_manifest.json',dict(files={n:p for n,p in b.inventory(folder).items() if n not in excluded}))
        t['artifact_manifest_sha256']=b.sha((folder/'artifact_manifest.json').read_bytes());self.overwrite(folder/'terminal.json',t)
    def mutate_summary(self,change):
        target=self.worker_copy();v=ct.strict_json((target/'data/summary.json').read_bytes());change(v)
        for row in v['windows']:self.overwrite(target/'data'/('window_%03d'%row['cohort_index'])/'result.json',row)
        self.overwrite(target/'data/summary.json',v);self.reseal(target);return target
    def validate(self,folder):return validate_terminal(folder,self.term['pid'],self.req,self.sha,fixture=True)
    @contextmanager
    def session(self,env,*,overrides=None):
        options=dict(env.overrides);options.update(overrides or {})
        s=SharedDeviceSession(self.req,lambda:env.stop,enabled=True,fixture=True,components=self.c,evidence=env.evidence,overrides=options)
        with env.install():
            try:yield s
            finally:
                if not s.owner._held and not s.owner._unsafe:s.close()
                env.capture(s,{})

    def test_01_real_request_schema_is_independent(self):
        self.assertEqual(ct.validate_request(self.real()),self.real())
    def test_02_pc_request_rejected_as_real(self):
        with self.assertRaises(ValueError):ct.validate_request(self.req)
    def test_03_real_request_rejected_as_pc(self):
        with self.assertRaises(ValueError):ct.validate_request(self.real(),fixture=True)
    def test_04_old_pc_process_schema_rejected(self):
        r=dict(self.req,schema='shared-session-PC-process-fixture-v1')
        with self.assertRaises(ValueError):ct.validate_request(r,fixture=True)
    def test_05_boolean_fixture_and_counters_required(self):
        with self.assertRaises(ValueError):ct.validate_request(dict(self.req,fixture=1),fixture=True)
        with self.assertRaises(ValueError):ct.flags(True,driver_returns=True)
    def test_06_unknown_request_fields_rejected(self):
        with self.assertRaises(ValueError):ct.validate_request(dict(self.req,extra='x'),fixture=True)
    def test_07_lock_identity_boolean_inode_rejected(self):
        r=dict(self.req,expected_lock=dict(self.req['expected_lock'],inode=True))
        with self.assertRaises(ValueError):ct.validate_request(r,fixture=True)
    def test_08_unknown_profile_not_a_device_option(self):
        with self.assertRaises(ValueError):ct.validate_request(dict(self.req,fixture_profile='board'),fixture=True)
        r=self.real();r['fixture_profile']='normal'
        with self.assertRaises(ValueError):ct.validate_request(r)
    def test_09_declaration_integer_rejected(self):
        r=dict(self.req,declarations=dict(self.req['declarations'],idle=1))
        with self.assertRaises(ValueError):ct.validate_request(r,fixture=True)
    def test_10_fixture_flags_cannot_claim_actual_hardware(self):
        v=ct.flags(True,lock_access=True,board_access=True,driver_returns=24)
        for key in ('board_access','real_DMA_executed','real_lock_access','real_cross_layer_PL_execution'):self.assertIs(v[key],False)
    def test_11_binding_default_off(self):
        with self.assertRaisesRegex(ValueError,'default-off'):b.configure()
    def test_12_session_default_off_no_factory(self):
        with patch.object(b,'configure') as select,self.assertRaisesRegex(ValueError,'default-off'):SharedDeviceSession({},lambda:False)
        select.assert_not_called()
    def test_13_real_session_rejects_injected_provider_before_arm(self):
        with patch.object(b,'require_arm') as guard,self.assertRaisesRegex(ValueError,'injected'):SharedDeviceSession(self.real(),lambda:False,enabled=True,evidence=object())
        guard.assert_not_called()
    def test_14_real_session_rejects_injected_factory(self):
        fake=Mock()
        with self.assertRaisesRegex(ValueError,'injected'):SharedDeviceSession(self.real(),lambda:False,enabled=True,overrides={'lease_factory':fake})
        fake.assert_not_called()
    def test_15_real_session_pc_guard_before_factories(self):
        with patch.object(b,'configure') as select,self.assertRaises(ValueError):SharedDeviceSession(self.real(),lambda:False,enabled=True)
        select.assert_not_called()
    def test_16_parent_real_rejects_fake_evidence_provider(self):
        with patch.object(b,'require_arm') as guard,self.assertRaisesRegex(ValueError,'injected'):ParentEvidenceChecks(self.real(),self.sha,enabled=True,provider=FixtureParentEvidence(self.c.fpga_evidence))
        guard.assert_not_called()
    def test_17_worker_default_off(self):
        from device_worker import run_worker
        with self.assertRaisesRegex(ValueError,'default-off'):run_worker({},'',None,{})
    def test_18_worker_real_rejects_fixture_gate(self):
        from device_worker import run_worker
        with self.assertRaisesRegex(ValueError,'injected'):run_worker(self.real(),self.sha,None,{},enabled=True,fixture_gate=lambda stopped:None)
    def test_19_pc_parent_default_off(self):
        with patch('subprocess.Popen') as spawn,self.assertRaisesRegex(ValueError,'default-off'):launch_pc('','',self.fresh()/'e')
        spawn.assert_not_called()
    def test_20_source_pin_drift_rejected(self):
        with self.assertRaisesRegex(ValueError,'candidate pin'):b.verify('0'*64)
    def test_21_original_runner_lease_recovery_submit_identity(self):
        self.assertIs(self.c.lease_factory,sys.modules['kws_threeway_entry_support_draft'].existing_shared_lock_draft)
        self.assertIs(self.c.recovery_factory,sys.modules['kws_device_recovery_candidate']._Recovery)
        self.assertIs(self.c.supervisor,sys.modules['supervision_bridge'].supervised)
        self.assertIs(self.c.runner_type._submit_chain,sys.modules['pynq_gemm'].PynqGemm._submit_chain)
    def test_22_original_owner_safety_and_call_body_preserved(self):
        owner=sys.modules['pointwise_owner'].PointwiseOwner
        for name in ('start','pre_submit','close','_hold','_identity','_buffers_valid'):self.assertIs(getattr(self.c.owner_type,name),getattr(owner,name))
        self.assertIs(sys.modules['shared_owner']._execute.__code__,owner.execute_chain.__code__)
        self.assertIs(self.c.call_type,sys.modules['shared_call'].SharedCall)
    def test_23_depthwise_same_function_object(self):
        self.assertIs(self.c.depthwise,sys.modules['_device_frozen_loop'].depthwise)
    def test_24_production_loop_has_no_case_reply_emulator(self):
        for name in ('device_loop.py','device_session.py'):
            tree=ast.parse((b.ROOT/name).read_bytes())
            forbidden=[n for n in ast.walk(tree) if isinstance(n,ast.Attribute) and n.attr in ('engine','set_case','payload','frames')]
            self.assertEqual(forbidden,[])
            self.assertNotIn('SoftwareTransport',{n.id for n in ast.walk(tree) if isinstance(n,ast.Name)})
    def test_25_frozen242_manifest_exact(self):
        f=ct.strict_json((b.FROZEN/'candidate_manifest.json').read_bytes())['files'];actual=b.inventory(b.FROZEN)
        self.assertEqual(len(actual),242);self.assertEqual({n:p for n,p in actual.items() if n!='candidate_manifest.json'},f)
    def test_26_wire_model_uses_actual_input_bytes(self):
        p=self.worker/'data/window_000/op2_wire.bin';raw=p.read_bytes();expected=(p.parent/'op2_raw.i32').read_bytes()
        self.assertEqual(WireEnvironment.compute_wire(raw),expected)
        k=int(np.flatnonzero(np.any(self.case['weights']!=0,axis=1))[0]);changed=bytearray(raw);changed[64+k*8]^=1
        self.assertNotEqual(WireEnvironment.compute_wire(bytes(changed)),expected)
    def test_27_wire_tail_nonzero_rejected(self):
        raw=bytearray((self.worker/'data/window_000/op2_wire.bin').read_bytes());raw[8256+64+7*512+5]=1
        with self.assertRaisesRegex(ValueError,'tail padding'):WireEnvironment.compute_wire(bytes(raw))
    def test_28_wire_second_weight_panel_corruption_rejected(self):
        raw=bytearray((self.worker/'data/window_000/op2_wire.bin').read_bytes());raw[8256+64+4096]^=1
        with self.assertRaisesRegex(ValueError,'same actual weights'):WireEnvironment.compute_wire(bytes(raw))
    def test_29_original_recovery_executes_over_fake_dma_registers(self):
        env=WireEnvironment(self.c)
        with self.session(env) as s:
            s.start();self.assertIs(type(s.owner._recovery),self.c.recovery_factory)
            self.assertIs(s.owner._recovery.last_diagnostics['confirmed'],True)
        resets=[e for e in env.events if e[0]=='dma_write' and e[2]==4]
        self.assertEqual(len(resets),2)
    def test_30_arbitrary_valid_root_addresses_supported(self):
        env=WireEnvironment(self.c,addresses=(0x52000000,0x53000000))
        with self.session(env) as s:
            s.start();s.check_reuse();self.assertEqual([x.physical_address for x in s.owner._buffers],[0x52000000,0x53000000])
        self.assertEqual(env.before_teardown['free_events'],2)
    def test_31_missing_lock_stops_before_original_factory(self):
        env=WireEnvironment(self.c);env.env.missing=True
        with self.session(env) as s:
            with self.assertRaises(FileNotFoundError):s.start()
            self.assertIs(s.owner._lease,None);self.assertEqual(env.env.events,[])
    def test_32_factory_failure_keeps_uncertain_owner(self):
        env=WireEnvironment(self.c,'factory_error')
        with self.session(env) as s:
            with self.assertRaises(RuntimeError):s.start()
            self.assertTrue(s.owner._held and s.owner._unsafe);self.assertEqual(s.close_attempts,0)
        self.assertEqual(env.before_teardown['free_events'],0)
    def test_33_busy_enter_does_not_imply_safe_owner(self):
        env=WireEnvironment(self.c,'lock_busy')
        with self.session(env) as s:
            with self.assertRaises(BlockingIOError):s.start()
            self.assertTrue(s.owner._held);self.assertTrue(s.owner._lease.acquisition_attempted)
    def test_34_factory_batchstop_is_uncertain(self):
        from batch_policy import BatchStop
        def fail():raise BatchStop('TEST_ONLY opaque factory stop')
        env=WireEnvironment(self.c)
        with self.session(env,overrides={'lease_factory':fail}) as s:
            with self.assertRaises(BatchStop):s.start()
            self.assertTrue(s.owner._held and s.owner._unsafe)
    def test_35_partial_allocation_retains_one_root(self):
        env=WireEnvironment(self.c,'allocation_error')
        with self.session(env) as s:
            with self.assertRaises(RuntimeError):s.start()
            self.assertEqual(len(s.owner._buffers),1);self.assertTrue(s.owner._held)
        self.assertTrue(env.before_teardown['fake_fd_live']);self.assertEqual(env.before_teardown['free_events'],0)
    def test_36_clock_mismatch_keeps_acquired_lease(self):
        env=WireEnvironment(self.c,clock=99.)
        with self.session(env) as s:
            with self.assertRaisesRegex(RuntimeError,'100MHz'):s.start()
            self.assertTrue(s.owner._held);self.assertIsNotNone(s.owner._runner)
    def test_37_root_physical_alias_rejected_and_retained(self):
        env=WireEnvironment(self.c,addresses=(0x31000000,0x31000008))
        with self.session(env) as s:
            with self.assertRaisesRegex(RuntimeError,'alias'):s.start()
            self.assertTrue(s.owner._held);self.assertEqual(len(s.owner._buffers),2)
    def test_38_inode_drift_keeps_uncertain_lease(self):
        env=WireEnvironment(self.c);env.env.drift=True
        with self.session(env) as s:
            with self.assertRaisesRegex(ValueError,'inode changed'):s.start()
            self.assertTrue(s.owner._held);self.assertIsNone(s.owner._runner)
    def test_39_recovery_truthy_is_not_confirmation(self):
        env=WireEnvironment(self.c)
        factory=lambda *a,**kw: type('FakeRecovery',(),{'recover_and_confirm':lambda self,runner:1})()
        with self.session(env,overrides={'recovery_factory':factory}) as s:
            with self.assertRaisesRegex(RuntimeError,'not confirmed'):s.start()
            self.assertTrue(s.owner._held)
    def test_40_live_provider_rejection_after_start_retains(self):
        env=WireEnvironment(self.c)
        with patch.object(env.evidence,'live',return_value=False),self.session(env) as s:
            with self.assertRaisesRegex(ValueError,'active acquired'):s.start()
            self.assertTrue(s.owner._held);self.assertIsNotNone(s.ticket)
    def test_41_safe_stop_after_initialization_preserves_ticket_on_close(self):
        from batch_policy import BatchStop
        env=WireEnvironment(self.c)
        with self.session(env) as s:
            with patch.object(s.owner,'pre_submit',side_effect=BatchStop('TEST_ONLY initialized stop')):
                with self.assertRaises(BatchStop):s.start()
            self.assertFalse(s.owner._held or s.owner._unsafe);self.assertIsNone(s.ticket)
        self.assertIsNotNone(s.ticket);self.assertTrue(s.owner._closed)
        self.assertTrue(s.release_readback['lock_released_same_inode'])
    def test_42_buffer_object_replacement_rejected(self):
        env=WireEnvironment(self.c)
        with self.session(env) as s:
            s.start();old=s.owner._buffers[0]
            try:
                replacement=old.copy();replacement.physical_address=old.physical_address;s.owner._buffers[0]=replacement
                with self.assertRaisesRegex(ValueError,'same lease runner'):s.check_reuse()
            finally:s.owner._buffers[0]=old
    def test_43_second_start_does_not_reenter_factory(self):
        env=WireEnvironment(self.c)
        with self.session(env) as s:
            s.start();before=list(env.env.events)
            with self.assertRaisesRegex(ValueError,'one device'):s.start()
            self.assertEqual(env.env.events,before)
    def test_44_counter_sentinel_zero_rejected(self):
        m=dict(ct.strict_json((self.worker/'data/window_000/result.json').read_bytes())['op4_driver_metrics'],failed_tile_index=0)
        with self.assertRaisesRegex(ValueError,'counter gate'):validate_metrics(m,3)
    def test_45_counter_boolean_job_rejected(self):
        m=dict(ct.strict_json((self.worker/'data/window_000/result.json').read_bytes())['op2_driver_metrics'],first_job_id=True)
        with self.assertRaises(ValueError):validate_metrics(m,1)
    def test_46_counter_fixture_tags_rejected(self):
        m=dict(ct.strict_json((self.worker/'data/window_000/result.json').read_bytes())['op4_driver_metrics'],fixture=True)
        with self.assertRaises(ValueError):validate_metrics(m,3)
    def test_47_counter_version1_is_only_cleanup_identity(self):
        m=dict(ct.strict_json((self.worker/'data/window_000/result.json').read_bytes())['op4_driver_metrics'],counter_contract_version=1)
        with self.assertRaises(ValueError):validate_metrics(m,3)
        identity=self.term['session']['cleanup_readback']['terminal']['recovery']['fresh_accelerator_identity']
        self.assertEqual(identity['counter_contract_version'],1);self.assertEqual(identity['phase'],'post-soft-reset-before-start')
    def test_48_parent_real_ready_rejects_fixture_record(self):
        value=ct.ready(self.worker/'ready.json')
        with self.assertRaisesRegex(ValueError,'ready mode'):validate_ready(value,self.term['pid'],self.real(),self.sha)
    def test_49_parent_ready_rejects_boolean_pid(self):
        value=ct.ready(self.worker/'ready.json');value['pid']=True
        with self.assertRaises(ValueError):validate_ready(value,self.term['pid'],self.req,self.sha,fixture=True)
    def test_50_parent_ready_requires_original_flock_fields(self):
        value=ct.ready(self.worker/'ready.json');value['ticket']['exclusive_flock']=False
        with self.assertRaisesRegex(ValueError,'acquired lease'):validate_ready(value,self.term['pid'],self.req,self.sha,fixture=True)
    def test_51_raw_resign_cannot_hide_behind_relu_output(self):
        target=self.worker_copy();path=target/'data/window_000/op2_raw.i32';raw=path.read_bytes();path.write_bytes(bytes([raw[0]^1])+raw[1:])
        v=ct.strict_json((target/'data/summary.json').read_bytes());v['windows'][0]['artifacts']['op2_raw.i32']=dict(bytes=len(raw),sha256=b.sha(path.read_bytes()))
        self.overwrite(path.parent/'result.json',v['windows'][0]);self.overwrite(target/'data/summary.json',v);self.reseal(target)
        with self.assertRaisesRegex(ValueError,'frozen golden'):self.validate(target)
    def test_52_dynamic_output_resign_rejected(self):
        target=self.worker_copy();path=target/'data/window_000/dw3_output.i8';raw=path.read_bytes();path.write_bytes(bytes([raw[0]^1])+raw[1:])
        v=ct.strict_json((target/'data/summary.json').read_bytes());v['windows'][0]['artifacts']['dw3_output.i8']=dict(bytes=len(raw),sha256=b.sha(path.read_bytes()))
        self.overwrite(path.parent/'result.json',v['windows'][0]);self.overwrite(target/'data/summary.json',v);self.reseal(target)
        with self.assertRaisesRegex(ValueError,'frozen golden'):self.validate(target)
    def test_53_resigned_extra_member_rejected(self):
        target=self.worker_copy();(target/'extra.txt').write_bytes(b'x');self.reseal(target)
        with self.assertRaisesRegex(ValueError,'allowed device worker'):self.validate(target)
    def test_54_resigned_cross_window_progress_rejected(self):
        target=self.worker_copy();p=target/'entered_000.json';v=ct.strict_json(p.read_bytes());v['cohort_index']=30;self.overwrite(p,v);self.reseal(target)
        with self.assertRaisesRegex(ValueError,'window entry'):self.validate(target)
    def test_55_resigned_nonempty_marker_rejected(self):
        target=self.worker_copy();(target/'entered_000.json.ready').write_bytes(b'x');self.reseal(target)
        with self.assertRaisesRegex(ValueError,'bounded single-link|publication'):self.validate(target)
    def test_56_cleanup_ticket_drift_rejected(self):
        target=self.worker_copy();p=target/'terminal.json';v=ct.strict_json(p.read_bytes());v['session']['cleanup_readback']['last_lock_proof']['inode']+=1;self.overwrite(p,v)
        with self.assertRaisesRegex(ValueError,'acquired lock ticket'):self.validate(target)
    def test_57_ready_and_terminal_creation_identity_bound(self):
        target=self.worker_copy();p=target/'ready.json';v=ct.strict_json(p.read_bytes());v['process']['start']+=1;self.overwrite(p,v);self.reseal(target)
        with self.assertRaisesRegex(ValueError,'ready/terminal process'):self.validate(target)
    def test_58_fixture_terminal_cannot_claim_real_execution(self):
        target=self.worker_copy();p=target/'terminal.json';v=ct.strict_json(p.read_bytes());v['real_DMA_executed']=True;self.overwrite(p,v)
        with self.assertRaisesRegex(ValueError,'PC-only scope'):self.validate(target)
    def test_59_finite_hook_cannot_replace_normal_supervisor(self):
        target=self.worker_copy();p=target/'terminal.json';v=ct.strict_json(p.read_bytes());v['finite_supervisor_fixture']=True;self.overwrite(p,v)
        with self.assertRaisesRegex(ValueError,'finite profile'):self.validate(target)
    def test_60_original_good_terminal_accepted(self):self.assertTrue(self.validate(self.worker)['operation_success'])

    def test_61_first_numerical_error_survives_failure_journal_error(self):
        from types import SimpleNamespace
        from device_loop import execute
        class FaultCall:
            def __init__(self,*a,**kw):
                self.spec=SimpleNamespace(index=0,first_job_id=1);self.first_failure=dict(payload=b'A'*16,return_diagnostic=None)
            def __call__(self,envelope):raise ValueError('TEST_ONLY original raw mismatch')
        c=SimpleNamespace(call_type=FaultCall,envelope_type=self.c.envelope_type)
        session=SimpleNamespace(components=c,owner=SimpleNamespace(_index=0),check_reuse=lambda:None,fixture=True,lock_observation_attempted=False,hardware_constructor_attempted=False)
        original=ct.write
        def write(path,raw):
            if path.name=='first_failure.bin':raise OSError('TEST_ONLY journal failure')
            return original(path,raw)
        bank={i:self.case for i in ct.INDICES}
        with patch.object(ct,'write',side_effect=write),self.assertRaisesRegex(ValueError,'original raw mismatch') as error:
            execute(session,bank,bank,{},self.fresh()/'loop',lambda:False,lambda stage,index:None)
        result=error.exception.device_chain_summary
        self.assertEqual(result['failure']['error_type'],'ValueError')
        self.assertEqual(result['secondary_diagnostic_error_types'],['OSError'])

    def test_62_terminal_success_cannot_mask_summary_failure(self):
        target=self.mutate_summary(lambda v:v.update(operation_success=False))
        with self.assertRaisesRegex(ValueError,'complete clean'):self.validate(target)

    def test_63_returned_workload_resign_rejected(self):
        for key in ('returned_jobs','returned_pointwise_MACs'):
            target=self.mutate_summary(lambda v:v.update({key:v[key]+1}))
            with self.subTest(key=key),self.assertRaisesRegex(ValueError,'workload conservation'):self.validate(target)

    def test_64_op4_attempt_requires_current_DW3(self):
        source=TEMPLATE.parent/'unsafe';target=self.fresh()/'worker';shutil.copytree(source/'evidence/worker',target)
        v=ct.strict_json((target/'data/summary.json').read_bytes());v.update(depthwise_executed_calls=3,depthwise_executed_logical_MACs=216000)
        self.overwrite(target/'data/summary.json',v);self.reseal(target)
        req=ct.strict_json((source/'request.json').read_bytes());sha=b.sha((source/'request.json').read_bytes());pid=ct.terminal(target)['pid']
        with self.assertRaisesRegex(ValueError,'stage-specific work order'):validate_terminal(target,pid,req,sha,fixture=True)

if __name__=='__main__':unittest.main(verbosity=2)
