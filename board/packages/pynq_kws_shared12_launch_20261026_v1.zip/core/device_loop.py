"""Normal fixed12 dynamic chain. No fixture engine or generated device reply."""
import json
import numpy as np
import device_binding as b
import device_contract as ct

def execute(session,cases2,cases4,parameters,output,stopped,publish_stage):
    b.need(type(cases2) is dict and type(cases4) is dict and set(cases2)==set(cases4)==set(ct.INDICES),'exact fixed12 case bank')
    output=ct.outside(output);b.need(not output.exists(),'fresh device chain output');output.mkdir()
    c=session.components;rows=[];calls=[];accepted2=accepted4=dw_calls=0;active=None;index=None;stage='before_loop';primary=None;failure=None;secondary=[]
    def check(where):
        nonlocal stage
        stage=where;publish_stage(where,index)
        if stopped() is not False:raise __import__('batch_policy').BatchStop('stop at device chain boundary')
    def save(folder,name,raw):return ct.write(folder/name,raw)
    try:
        for index in ct.INDICES:
            check('op2_before_submit');case2=cases2[index];session.check_reuse()
            active=c.call_type(session.owner,case2,enabled=True);spec2=active.spec;stage='op2_call'
            env2=c.envelope_type(2,23,index,case2['source_id'],case2['feature_sha256'],case2['a'].copy(order='C'))
            out2,d2=active(env2);accepted2+=1;session.check_reuse()
            calls.append(dict(request_index=spec2.index,cohort_index=index,operator_index=2,first_job_id=spec2.first_job_id,accepted=True))
            upstream=c.combination.make_upstream(out2.tobytes(),case2,'fixture')
            # 'fixture' here is the frozen data provenance enum, not device evidence.
            # This value means current-call output rather than historical replay.
            a=c.combination.validate_upstream(upstream,case2,'fixture')
            check('before_depthwise');dynamic,acc=c.depthwise(a,parameters);dw_calls+=1
            env4=c.combination.dynamic_envelope(upstream,dynamic,cases4[index]);b.need(env4.values is dynamic,'actual dynamic owning payload')
            check('op4_before_submit');session.check_reuse()
            active=c.call_type(session.owner,cases4[index],enabled=True);spec4=active.spec;stage='op4_call'
            out4,d4=active(env4);accepted4+=1;session.check_reuse()
            b.need(np.array_equal(c.combination.wire_input(d4['input_chain'],spec4.first_job_id),dynamic),'actual submitted Op4 wire uses dynamic DW3')
            calls.append(dict(request_index=spec4.index,cohort_index=index,operator_index=4,first_job_id=spec4.first_job_id,accepted=True))
            check('after_op4');folder=output/('window_%03d'%index);folder.mkdir()
            artifacts={
                'op2_input.i8':case2['a'].tobytes(),'op2_weights.i8':case2['weights'].tobytes(),'op2_bias.i32':case2['bias'].astype('<i4').tobytes(),'op2_scales.f64':case2['scales'].astype('<f8').tobytes(),
                'op2_output.i8':out2.tobytes(),'op2_wire.bin':d2['input_chain'],'op2_raw.i32':d2['raw'].astype('<i4').tobytes(),'op2_corrected.i32':d2['corrected'].astype('<i4').tobytes(),
                'dw3_input.i8':a.tobytes(),'dw3_weights.i8':parameters['weights'].tobytes(),'dw3_bias.i32':parameters['bias'].astype('<i4').tobytes(),'dw3_scales.f64':parameters['scales'].astype('<f8').tobytes(),
                'dw3_acc.i32':acc.tobytes(),'dw3_output.i8':dynamic.tobytes(),'op4_input.i8':dynamic.tobytes(),
                'op4_weights.i8':cases4[index]['weights'].tobytes(),'op4_bias.i32':cases4[index]['bias'].astype('<i4').tobytes(),'op4_scales.f64':cases4[index]['scales'].astype('<f8').tobytes(),
                'op4_wire.bin':d4['input_chain'],'op4_raw.i32':d4['raw'].astype('<i4').tobytes(),'op4_corrected.i32':d4['corrected'].astype('<i4').tobytes(),'op4_output.i8':out4.tobytes()}
            row=dict(cohort_index=index,source_id=case2['source_id'],feature_sha256=case2['feature_sha256'],op2_request_index=spec2.index,op4_request_index=spec4.index,
                     op2_first_job_id=spec2.first_job_id,op4_first_job_id=spec4.first_job_id,op2_driver_metrics=d2['driver_metrics'],op4_driver_metrics=d4['driver_metrics'],
                     actual_dynamic_payload_identity=True,same_resource_pair=True,artifacts={n:save(folder,n,v) for n,v in artifacts.items()})
            save(folder,'result.json',(json.dumps(row,sort_keys=True,indent=2)+'\n').encode());rows.append(row)
            print('WINDOW',index,'device-adapter dynamic chain checked',flush=True)
    except BaseException as error:
        primary=error;failure=dict(cohort_index=index,stage=stage,error_type=type(error).__name__,automatic_retry=False)
        try:
            first=None if active is None else active.first_failure
            if type(first) is dict:
                raw=first.get('payload')
                if type(raw) is bytes and len(raw)<=32000:failure['payload']=save(output,'first_failure.bin',raw)
                diag=first.get('return_diagnostic')
                if diag is not None:
                    from return_diagnostic import valid
                    b.need(valid(diag),'bounded original return diagnostic')
                    save(output,'return_diagnostic.json',(json.dumps(diag,sort_keys=True,ensure_ascii=True)+'\n').encode('ascii'))
        except BaseException as diagnostic_error:secondary.append(type(diagnostic_error).__name__)
    result=dict(operation_success=primary is None and len(rows)==12,completed_indices=[r['cohort_index'] for r in rows],not_completed_indices=list(ct.INDICES[len(rows):]),
                windows=rows,calls=calls,failure=failure,accepted_op2_calls=accepted2,accepted_op4_calls=accepted4,depthwise_executed_calls=dw_calls,
                depthwise_executed_logical_MACs=72000*dw_calls,completed_chain_depthwise_logical_MACs=72000*len(rows),
                driver_returns=session.owner._index,returned_jobs=2*session.owner._index,returned_pointwise_MACs=512000*session.owner._index,
                secondary_diagnostic_error_types=secondary,**ct.flags(session.fixture,lock_access=session.lock_observation_attempted,board_access=session.hardware_constructor_attempted,driver_returns=session.owner._index))
    save(output,'summary.json',(json.dumps(result,sort_keys=True,indent=2)+'\n').encode())
    if primary is not None:
        primary.device_chain_summary=result;raise primary
    return result
if __name__=='__main__':raise SystemExit('Private loop library only; no activation entry.')
