"""Fixed internal PC fixture child. Cannot activate ARM or real evidence mode."""
import argparse
import os
import sys
import time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import device_binding as b
import device_contract as ct
def main():
    p=argparse.ArgumentParser();p.add_argument('--request',required=True);p.add_argument('--request-sha',required=True);p.add_argument('--launch',required=True);p.add_argument('--launch-sha',required=True);p.add_argument('--folder',required=True);p.add_argument('--enable-PC-fixture',action='store_true');a=p.parse_args()
    b.need(a.enable_PC_fixture is True,'PC child default-off');b.pc_only()
    request=ct.strict_json(ct.read(a.request));b.need(b.sha(ct.read(a.request))==ct.digest(a.request_sha),'private child request pin');ct.validate_request(request,fixture=True)
    launch=ct.strict_json(ct.read(a.launch));b.need(b.sha(ct.read(a.launch))==ct.digest(a.launch_sha),'private child launch pin')
    folder=ct.outside(a.folder);b.need(ct.canonical(a.launch)==folder.parent/'launch.json','fixed launch location')
    from device_fixture import WireEnvironment
    from device_worker import run_worker
    components=b.configure(enabled=True);environment=WireEnvironment(components,request['fixture_profile'])
    finite=b.previous().load('shared_process_fixture',b.FROZEN/'shared_process_fixture.py').finite_supervised if request['fixture_profile'] in ct.FINITE_PROFILES else None
    def boundary(where,index):
        environment.boundary(where,index)
        if request['fixture_profile']=='parent_stop' and where=='before_depthwise' and index==90:
            ct.write_json(folder/'await_parent_stop.json',dict(stage=where,cohort_index=index,pid=os.getpid(),run_id=request['run_id']))
            deadline=time.monotonic()+30
            while not (folder.parent/'stop.flag').exists():
                if time.monotonic()>=deadline:raise RuntimeError('PC_ONLY cooperative stop handshake expired')
                time.sleep(.025)
    terminal=run_worker(request,a.request_sha,folder,launch,enabled=True,fixture=True,environment=environment,fixture_boundary=boundary,fixture_supervisor=finite)
    ct.write_json(folder.parent/'fixture_boundary.json',environment.before_teardown)
    return 0 if terminal['operation_success'] else 1
if __name__=='__main__':
    try:raise SystemExit(main())
    except (ValueError,OSError,RuntimeError) as error:
        print(dict(error_type=type(error).__name__,board_access=False,promotion=False),file=sys.stderr);raise SystemExit(2)
