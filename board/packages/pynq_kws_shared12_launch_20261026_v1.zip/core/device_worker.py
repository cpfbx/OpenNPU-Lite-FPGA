"""Private supervised shared-device session; fixture injection is mode-isolated."""
from contextlib import nullcontext
import os
import time
import device_binding as b
import device_contract as ct
from device_session import SharedDeviceSession

def run_worker(request,request_sha,folder,launch,*,enabled=False,fixture=False,environment=None,fixture_gate=None,fixture_boundary=None,fixture_supervisor=None):
    b.need(enabled is True,'device worker default-off');ct.validate_request(request,fixture=fixture);ct.digest(request_sha)
    b.need(type(fixture) is bool and (fixture or all(x is None for x in (environment,fixture_gate,fixture_boundary,fixture_supervisor))),'real worker rejects injected hooks')
    if not fixture:b.require_arm(request)
    b.verify(request['candidate_manifest_sha256'])
    b.need(type(launch) is dict and set(launch)=={'run_id','request_sha256','parent','fixture'} and launch['run_id']==request['run_id'] and launch['request_sha256']==request_sha and launch['fixture'] is fixture,'bound new worker launch')
    parent=launch['parent'];b.need(type(parent) is dict and set(parent)=={'pid','start','kind'} and type(parent['pid']) is int and parent['pid']>1 and type(parent['start']) is int and parent['start']>0,'exact parent creation identity')
    folder=ct.outside(folder);b.need(folder.is_dir() and not any(folder.iterdir()),'fresh empty device worker evidence')
    components=b.configure(enabled=True)
    # All reference namespaces and case derivation are prepared while cold.
    cases2={i:components.reference.derive(2,i) for i in ct.INDICES};cases4={i:components.reference.derive(4,i) for i in ct.INDICES}
    parameters=components.combination.depthwise_parameters()
    from device_loop import execute
    primary=None;summary=None;stage='before_owner_start';signals=None;holder={};ticket=None
    def external_stop():
        if environment is not None and environment.stop:return True
        if os.path.lexists(folder.parent/'stop.flag'):return True
        try:return os.getppid()!=parent['pid'] or ct.process_identity(parent['pid'])!=parent
        except (OSError,ValueError):return True
    holder['stop']=external_stop
    session=SharedDeviceSession(request,lambda:holder['stop'](),enabled=True,fixture=fixture,
        components=components if fixture else None,evidence=environment.evidence if environment is not None else None,
        overrides=environment.overrides if environment is not None else None)
    def publish(value):ct.write_json(folder/'attention_retained.json',dict(value,run_id=request['run_id'],request_sha256=request_sha,fixture=fixture,real_infinite_hold_executed=False))
    def gate(stopped):
        while True:
            if stopped() is not False:raise __import__('batch_policy').BatchStop('stop before device GO')
            go=ct.ready(folder.parent/'go.json')
            if go is not None:
                b.need(go==dict(kind='go',pid=os.getpid(),parent=parent,run_id=request['run_id'],request_sha256=request_sha,
                               ready_sha256=b.sha(ct.read(folder/'ready.json')),fixture=fixture),'exact device parent GO');return
            time.sleep(.025)
    def operation(stopped):
        nonlocal summary,stage,ticket,primary
        holder['stop']=stopped
        try:
            stage='owner_start'
            if stopped() is not False:raise __import__('batch_policy').BatchStop('stop before device owner')
            ticket=session.start();stage='ready_wait_go'
            ct.write_json(folder/'ready.json',dict(kind='ready',pid=os.getpid(),process=ct.process_identity(os.getpid()),run_id=request['run_id'],request_sha256=request_sha,
                          ticket=ticket,identity=request['expected_lock'],fixture=fixture,evidence_injected=fixture))
            (fixture_gate or gate)(stopped)
            def boundary(where,index):
                nonlocal stage
                stage=where
                if where=='op2_before_submit':ct.write_json(folder/('entered_%03d.json'%index),dict(stage=where,cohort_index=index,pid=os.getpid(),run_id=request['run_id'],request_sha256=request_sha))
                if fixture_boundary is not None:fixture_boundary(where,index)
            summary=execute(session,cases2,cases4,parameters,folder/'data',stopped,boundary)
        except BaseException as error:
            primary=error;summary=getattr(error,'device_chain_summary',summary)
            ct.write_json(folder/'fault.json',dict(error_type=type(error).__name__,stage=stage,request_sha256=request_sha,pid=os.getpid(),run_id=request['run_id'],fixture=fixture,
                          completed_indices=[] if summary is None else summary['completed_indices']))
        finally:
            if not session.owner._held and not session.owner._unsafe:
                try:session.close()
                except BaseException as error:
                    if primary is None:primary=error
                    session.owner._hold(error)
        if primary is not None:raise primary
        return True
    supervise=fixture_supervisor or components.supervisor
    with environment.install() if environment is not None else nullcontext():
        try:
            value=supervise(session.owner,operation,publish,external_stop,enabled=True);signals=value['signals']
        except BaseException as error:
            if primary is None:primary=error
            signals=getattr(error,'supervision_bridge_observation',None)
        state=session.observation()
        unresolved=any(state['resources'][k] for k in ('held','safety_unresolved','lease_retained','runner_retained','root_buffers_retained'))
        b.need(not unresolved or (fixture and fixture_supervisor is not None),'original supervisor cannot exit unresolved real resources')
        ticket=session.ticket
        if primary is not None and not (folder/'fault.json').exists():
            ct.write_json(folder/'fault.json',dict(error_type=type(primary).__name__,stage=stage,request_sha256=request_sha,pid=os.getpid(),run_id=request['run_id'],fixture=fixture,
                          completed_indices=[] if summary is None else summary['completed_indices']))
        terminal=dict(operation_success=primary is None and summary is not None and summary['operation_success'] is True,
            pid=os.getpid(),process=ct.process_identity(os.getpid()),run_id=request['run_id'],request_sha256=request_sha,
            completed_indices=[] if summary is None else summary['completed_indices'],ticket=ticket,session=state,signals=signals,
            safety_unresolved=unresolved,finite_supervisor_fixture=fixture_supervisor is not None,original_infinite_hold_executed=False,
            error_type=None if primary is None else type(primary).__name__,outer_process_exit_observed=False,
            summary_sha256=None if summary is None else b.sha(ct.read(folder/'data/summary.json')),**ct.flags(fixture,lock_access=session.lock_observation_attempted,board_access=session.hardware_constructor_attempted,driver_returns=session.owner._index))
        files=b.inventory(folder);terminal['artifact_manifest_sha256']=ct.write_json(folder/'artifact_manifest.json',dict(files=files))['sha256']
        ct.write_json(folder/'terminal.json',terminal)
        if environment is not None:environment.capture(session,terminal)
    return terminal
if __name__=='__main__':raise SystemExit('Private library only; no board activation CLI.')
