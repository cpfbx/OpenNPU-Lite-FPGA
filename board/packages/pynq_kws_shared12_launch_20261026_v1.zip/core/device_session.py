"""One exact SharedOwner using original runner/lease/recovery factories.

No fake engine, precomputed reply, emulator, synthetic address or metrics here.
Real use is private/default-off and guarded by the original ARM/boot contract.
"""
from dataclasses import replace
import device_binding as b
import device_contract as ct

class LiveEvidence:
    fixture=False
    def __init__(self,components):self._proof=components.fpga_evidence
    def snapshot(self):return self._proof.snapshot()
    def live(self,ticket,pid,identity):return self._proof.verify_live(ticket,pid,identity)
    def cleanup(self,value,ticket,pid):return self._proof.validate_cleanup(value,ticket,pid)
    def released(self,identity):return self._proof.released(identity)

class SharedDeviceSession:
    def __init__(self,request,stopped,*,enabled=False,fixture=False,components=None,evidence=None,overrides=None):
        b.need(enabled is True and callable(stopped),'device session default-off')
        ct.validate_request(request,fixture=fixture)
        b.need(type(fixture) is bool and (fixture or all(x is None for x in (components,evidence,overrides))),'real session rejects injected dependencies')
        if not fixture:
            b.require_arm(request);b.verify(request['candidate_manifest_sha256'])
        self.components=components or b.configure(enabled=True)
        b.need(type(self.components) is b.Components,'exact component assembly')
        if overrides is not None:
            b.need(fixture and type(overrides) is dict and set(overrides)<={'lease_factory','recovery_factory'},'explicit limited factory fixture')
            self.components=replace(self.components,**overrides)
        self.request=request;self.fixture=fixture;self.evidence=evidence or LiveEvidence(self.components)
        b.need((fixture and getattr(self.evidence,'fixture',None) is True) or (not fixture and type(self.evidence) is LiveEvidence),'evidence provider mode isolation')
        self.owner=self.components.owner_type(self.components.policy_type(enabled=True),stopped,enabled=True)
        self.started=False;self.close_attempts=0;self.ticket=None;self._roots=None;self.reuse_checks=0
        self.release_readback=None;self.lock_observation_attempted=False;self.hardware_constructor_attempted=False
    def start(self):
        b.need(not self.started,'one device session start only')
        self.started=True
        self.lock_observation_attempted=True
        b.need(self.evidence.snapshot()==self.request['expected_lock'],'predeclared lock inode before start')
        c=self.components
        try:self.owner.start(c.runner_type,c.bit_path,c.lease_factory,c.recovery_factory)
        finally:self.hardware_constructor_attempted=self.owner._runner is not None
        self.ticket=self.owner._lease.audit()
        try:b.need(self.evidence.live(self.ticket,self.owner._pid,self.request['expected_lock']) is True,'same active acquired lease')
        except BaseException as error:
            self.owner._hold(error);raise
        c.reference.authorize(self.owner)
        self.check_reuse()
        return self.ticket
    def check_reuse(self):
        self.owner._owned();self.owner._buffers_valid()
        b.need(not self.owner._closed and not self.owner._held and not self.owner._unsafe and self.owner._lease is not None and self.owner._runner is not None,'healthy initialized shared owner')
        roots=(id(self.owner._lease),id(self.owner._runner),id(self.owner._mmio),id(self.owner._dma),
               tuple((id(buf),buf.physical_address,buf.nbytes) for buf in self.owner._buffers))
        b.need(len(self.owner._buffers)==2,'exact two shared DMA roots')
        if self._roots is None:self._roots=roots
        b.need(roots==self._roots,'same lease runner mapping and physical buffer objects')
        self.reuse_checks+=1
    def close(self):
        self.close_attempts+=1
        if self.ticket is None and self.owner._lease is not None and not self.owner._held and not self.owner._unsafe:
            self.ticket=self.owner._lease.audit()  # Safe initialization may stop before start() returns.
        self.owner.close()
        if self.ticket is not None:
            b.need(self.evidence.cleanup(dict(owner_closed=True,readback=self.owner.cleanup_readback),self.ticket,self.owner._pid) is True,'original cleanup evidence')
            proof=self.evidence.released(self.request['expected_lock'])
            b.need(type(proof) is dict and proof.get('lock_released_same_inode') is True and all(proof.get(k)==v for k,v in self.request['expected_lock'].items()),'same-inode release observation')
            self.release_readback=proof
    @property
    def supervision_status(self):return self.owner.supervision_status
    def observation(self):
        return dict(owner_closed=self.owner._closed,resources=self.owner.supervision_status,cleanup_readback=self.owner.cleanup_readback,
                    close_attempts=self.close_attempts,reuse_checks=self.reuse_checks,lease_ticket=self.ticket,
                    release_readback=self.release_readback,completed_driver_returns=self.owner._index,
                    software_admission=dict(issued=self.owner._permits_issued,consumed=self.owner._permits_consumed,revoked=self.owner._permits_revoked,
                        active_call_cleared=self.owner._active_call is None,producer_cleared=self.owner._active_producer is None,
                        call_guard_released=not self.owner._call_guard.locked()),
                    **ct.flags(self.fixture,lock_access=self.lock_observation_attempted,board_access=self.hardware_constructor_attempted,driver_returns=self.owner._index))
if __name__=='__main__':raise SystemExit('Private library only. No board launch entry.')
