"""Evidence gates for future private device binding, plus explicit PC-only pair.

No board launch CLI. Live mode rejects injected providers and uses ARM/boot guard.
PC pair uses original wait/supervisor over fake device boundaries only.
"""
import os
import subprocess
import sys
import device_binding as b
import device_contract as ct
from device_session import LiveEvidence

def validate_ready(value,pid,request,request_sha,*,fixture=False):
    b.need(type(value) is dict and set(value)=={'kind','pid','process','run_id','request_sha256','ticket','identity','fixture','evidence_injected'},'exact device ready record')
    b.need(type(value['pid']) is int and value['pid']==pid and value['kind']=='ready' and value['run_id']==request['run_id'] and value['request_sha256']==request_sha
           and value['fixture'] is fixture and value['evidence_injected'] is fixture and value['identity']==request['expected_lock'],'device ready mode/process/request binding')
    process=value['process'];ticket=value['ticket']
    b.need(type(process) is dict and set(process)=={'pid','start','kind'} and type(process['pid']) is int and process['pid']==pid
           and type(process['start']) is int and process['start']>0 and process['kind'] in ('proc-stat-start-ticks','windows-process-creation-filetime'),'ready creation identity')
    if not fixture:b.need(process['kind']=='proc-stat-start-ticks','live ready requires POSIX creation identity')
    b.need(type(ticket) is dict and all(type(ticket.get(k)) is int and ticket[k]>=(0 if k in ('fd','device') else 1) for k in ('pid','fd','device','inode','process_start_ticks'))
           and ticket['pid']==pid and ticket.get('exclusive_flock') is True and ticket.get('cloexec') is True
           and all(ticket.get(k)==v for k,v in request['expected_lock'].items()),'same original acquired lease ticket')
    b.need(not any(ticket.get(k) is True for k in ('fixture','synthetic','evidence_injected')),'ticket may not disguise fixture tags')
    return value

def validate_metrics(metrics,first):
    from d007_mode11_contract import validate_summary
    exact=dict(mode=11,jobs=2,chain_jobs_completed=2,input_bytes=16512,input_payload_bytes=16384,input_header_bytes=128,
               output_bytes=32000,output_valid_bytes=32000,effective_macs=512000,first_job_id=first,error_code=0,failed_tile_index=65535,counter_contract_version=2)
    b.need(type(metrics) is dict and all(type(metrics.get(k)) is int and metrics[k]==v for k,v in exact.items())
           and metrics.get('counter_contract')=='d007_global_work_v2' and metrics.get('layout')=='k_major'
           and type(metrics.get('status')) is int and metrics['status']&14==4
           and metrics.get('mode11_counter_read_strategy')=='pynq_mmio_read' and 'counter_evidence' not in metrics
           and not any(metrics.get(k) is True for k in ('fixture','synthetic','counters_synthetic')) and all(validate_summary(metrics).values()),'unchanged device MODE11 counter gate')

def validate_terminal(folder,pid,request,request_sha,*,fixture=False):
    ct.validate_request(request,fixture=fixture);t=ct.terminal(folder)
    b.need(type(t['pid']) is int and t['pid']==pid and t['request_sha256']==request_sha and t['run_id']==request['run_id']
           and t['fixture'] is fixture and t['evidence_injected'] is fixture and t['outer_process_exit_observed'] is False,'terminal device/PC process binding')
    for key in ('operation_success','safety_unresolved','finite_supervisor_fixture'):b.need(type(t[key]) is bool,'strict terminal booleans')
    for key in ('promotion','run_ready','automatic_retry','automatic_kill','performance_evaluated','energy_evaluated','classification_quality_evaluated','original_infinite_hold_executed'):b.need(t[key] is False,'unapproved outcome '+key)
    if fixture:
        for key in ('board_access','real_lock_access','real_DMA_executed','real_cross_layer_PL_execution','ARM_tested'):b.need(t[key] is False,'honest PC-only scope '+key)
        b.need(t['finite_supervisor_fixture'] is (request['fixture_profile'] in ct.FINITE_PROFILES),'fixture finite profile isolation')
    else:b.need(t['finite_supervisor_fixture'] is False,'real evidence rejects finite fixture')
    state=t['session'];r=state['resources'];ticket=t['ticket'];n=len(t['completed_indices'])
    b.need(t['completed_indices']==list(ct.INDICES[:n]) and n<=12 and type(r['pid']) is int and r['pid']==pid and state['fixture'] is fixture,'exact completion/resource identity')
    b.need(state['lease_ticket']==ticket and type(state['completed_driver_returns']) is int and 0<=state['completed_driver_returns']<=24,'same session ticket/driver returns')
    sw=state['software_admission']
    b.need(all(type(sw.get(k)) is int and 0<=sw[k]<=24 for k in ('issued','consumed','revoked')) and sw['issued']==sw['consumed']+sw['revoked']
           and all(sw.get(k) is True for k in ('active_call_cleared','producer_cleared','call_guard_released')),'closed software job admission state')
    files={'artifact_manifest.json','artifact_manifest.json.ready','terminal.json','terminal.json.ready'}
    ready_path=folder/'ready.json'
    if ready_path.exists():
        ready=ct.ready(ready_path);validate_ready(ready,pid,request,request_sha,fixture=fixture)
        b.need(ready['process']==t['process'] and ready['ticket']==ticket,'same ready/terminal process and lease');files|={'ready.json','ready.json.ready'}
    if t['safety_unresolved']:
        b.need(fixture and t['finite_supervisor_fixture'] is True and t['operation_success'] is False and state['owner_closed'] is False
               and r['held'] is True and state['close_attempts']==0 and state['cleanup_readback'] is None,'explicit finite-test uncertain resource retention')
        attention=ct.ready(folder/'attention_retained.json');b.need(attention['fixture'] is True and attention['real_infinite_hold_executed'] is False,'finite retention publication')
        files|={'attention_retained.json','attention_retained.json.ready'}
    else:
        b.need(all(type(r[k]) is type(v) and r[k]==v for k,v in dict(held=False,safety_unresolved=False,lease_retained=False,runner_retained=False,root_buffers_retained=0).items()),'fully resolved owner resources')
        if ticket is not None:
            proof=sys.modules['fpga_evidence']
            b.need(state['owner_closed'] is True and state['close_attempts']==1 and proof.validate_cleanup(dict(owner_closed=True,readback=state['cleanup_readback']),ticket,pid) is True,'original cleanup proof')
            b.need(state['release_readback']['lock_released_same_inode'] is True and all(state['release_readback'][k]==v for k,v in request['expected_lock'].items()),'same canonical inode release')
        else:b.need(n==0 and state['completed_driver_returns']==0,'no ticket cannot contain device work')
    if t['summary_sha256'] is not None:
        summary=ct.strict_json(ct.read(folder/'data/summary.json'))
        b.need(b.sha(ct.read(folder/'data/summary.json'))==t['summary_sha256'] and summary['completed_indices']==t['completed_indices']
               and summary['not_completed_indices']==list(ct.INDICES[n:]) and len(summary['windows'])==n and summary['driver_returns']==state['completed_driver_returns'],'bound exact chain summary')
        b.need(summary['fixture'] is fixture and summary['evidence_injected'] is fixture,'chain evidence mode')
        a2,a4,dw=[summary[k] for k in ('accepted_op2_calls','accepted_op4_calls','depthwise_executed_calls')]
        b.need(all(type(v) is int for v in (a2,a4,dw)) and n<=a4<=a2<=min(12,n+1) and a4<=dw<=a2
               and summary['depthwise_executed_logical_MACs']==72000*dw and summary['completed_chain_depthwise_logical_MACs']==72000*n,'partial workload counts')
        returns=state['completed_driver_returns']
        b.need(a2+a4<=returns<=sw['consumed'] and type(summary['returned_jobs']) is int and summary['returned_jobs']==2*returns
               and type(summary['returned_pointwise_MACs']) is int and summary['returned_pointwise_MACs']==512000*returns,'returned device workload conservation')
        failed_stage=None if summary['failure'] is None else summary['failure']['stage']
        if failed_stage in ('op4_before_submit','op4_call'):b.need(dw==a2 and a2==a4+1,'stage-specific work order before Op4 completion')
        if failed_stage=='before_depthwise':b.need(dw==a4 and a2==a4+1,'stage-specific work order before DW3')
        if failed_stage in ('op2_before_submit','op2_call'):b.need(a2==a4==dw,'stage-specific work order before Op2 completion')
        expected_calls=[dict(request_index=i,cohort_index=ct.INDICES[i//2],operator_index=2 if i%2==0 else 4,first_job_id=1+2*i,accepted=True) for i in range(a2+a4)]
        b.need(summary['calls']==expected_calls,'alternating accepted prefix')
        golden=ct.strict_json(ct.read(b.FROZEN/'golden_index.json'));bank=ct.strict_json(ct.read(b.FROZEN/'golden_records.json'))
        files.add('data/summary.json')
        for i,row in enumerate(summary['windows']):
            index=ct.INDICES[i];sub=folder/'data'/('window_%03d'%index)
            b.need(row==ct.strict_json(ct.read(sub/'result.json')) and type(row['cohort_index']) is int and row['cohort_index']==index
                   and row['source_id']==bank[str(index)]['source_id'] and row['feature_sha256']==bank[str(index)]['feature_sha256']
                   and row['actual_dynamic_payload_identity'] is True and row['same_resource_pair'] is True,'bound dynamic source window')
            wanted={name.split('/')[-1] for name in golden if name.startswith(sub.name+'/')}
            b.need(set(row['artifacts'])==wanted and len(wanted)==22,'22 exact layer operands/outputs')
            for name,pin in row['artifacts'].items():
                raw=ct.read(sub/name,32000);b.need(dict(bytes=len(raw),sha256=b.sha(raw))==pin==golden[sub.name+'/'+name],'all layer values equal frozen golden')
                files.add('data/'+sub.name+'/'+name)
            files.add('data/'+sub.name+'/result.json')
            for offset,layer in enumerate(('op2','op4')):
                b.need(type(row[layer+'_request_index']) is int and row[layer+'_request_index']==2*i+offset
                       and type(row[layer+'_first_job_id']) is int and row[layer+'_first_job_id']==4*i+2*offset+1,'exact alternating job IDs')
                validate_metrics(row[layer+'_driver_metrics'],4*i+2*offset+1)
        failure=summary['failure']
        if failure is not None and 'payload' in failure:
            raw=ct.read(folder/'data/first_failure.bin',32000)
            b.need(dict(bytes=len(raw),sha256=b.sha(raw))==failure['payload'],'bounded actual first failure payload');files.add('data/first_failure.bin')
        if (folder/'data/return_diagnostic.json').exists():
            from return_diagnostic import valid
            b.need(valid(ct.strict_json(ct.read(folder/'data/return_diagnostic.json',8192))),'bounded returned metric diagnostic');files.add('data/return_diagnostic.json')
    else:b.need(n==0 and not (folder/'data').exists(),'no unbound numerical output')
    entered=[]
    for p in folder.glob('entered_*.json'):
        v=ct.ready(p);index=v['cohort_index']
        b.need(type(index) is int and index in ct.INDICES and p.name=='entered_%03d.json'%index and type(v['pid']) is int
               and v==dict(stage='op2_before_submit',cohort_index=index,pid=pid,run_id=request['run_id'],request_sha256=request_sha),'exact device window entry')
        entered.append(index);files|={p.name,p.name+'.ready'}
    b.need(sorted(entered)==list(ct.INDICES[:len(entered)]) and n<=len(entered)<=min(12,n+1),'entered window prefix')
    if t['summary_sha256'] is None:b.need(entered==[],'no pre-GO window entry')
    else:
        entry_count=a2+int(summary['failure'] is not None and summary['failure']['stage'] in ('op2_before_submit','op2_call'))
        b.need(len(entered)==entry_count,'entries match actual Op2 attempt boundary')
    if not t['operation_success']:
        fault=ct.ready(folder/'fault.json');b.need(type(fault['pid']) is int and fault['pid']==pid and fault['request_sha256']==request_sha and fault['run_id']==request['run_id'] and fault['fixture'] is fixture,'bound failure record')
        files|={'fault.json','fault.json.ready'}
    if (folder/'await_parent_stop.json').exists():
        a=ct.ready(folder/'await_parent_stop.json');b.need(fixture and request['fixture_profile']=='parent_stop' and a==dict(stage='before_depthwise',cohort_index=90,pid=pid,run_id=request['run_id']),'parent-stop fixture boundary');files|={'await_parent_stop.json','await_parent_stop.json.ready'}
    b.need(set(b.inventory(folder))==files,'exact allowed device worker members')
    if t['operation_success']:
        b.need(n==12 and summary['operation_success'] is True and summary['failure'] is None and summary['secondary_diagnostic_error_types']==[]
               and sw==dict(issued=24,consumed=24,revoked=0,active_call_cleared=True,producer_cleared=True,call_guard_released=True)
               and state['completed_driver_returns']==24 and t['error_type'] is None and t['signals']==dict(stop_signals=[],handler_errors=[],handler_restore_errors=[],original_supervisor_unchanged=True),'complete clean shared device chain')
    return t

class ParentEvidenceChecks:
    def __init__(self,request,request_sha,*,enabled=False,fixture=False,provider=None,components=None):
        b.need(enabled is True,'parent evidence checks default-off');ct.validate_request(request,fixture=fixture)
        b.need(fixture or provider is None and components is None,'real parent rejects injected evidence')
        if not fixture:b.require_arm(request);b.verify(request['candidate_manifest_sha256'])
        self.components=components or b.configure(enabled=True);self.request=request;self.request_sha=request_sha;self.fixture=fixture
        self.provider=provider or LiveEvidence(self.components)
        b.need((fixture and getattr(self.provider,'fixture',None) is True) or (not fixture and type(self.provider) is LiveEvidence),'parent evidence provider mode')
    def initial(self):
        identity=self.provider.snapshot();b.need(identity==self.request['expected_lock'],'predeclared parent inode snapshot')
        return self.release()
    def ready(self,value,pid):
        validate_ready(value,pid,self.request,self.request_sha,fixture=self.fixture)
        b.need(value['process']==ct.process_identity(pid),'live child creation identity')
        b.need(self.provider.live(value['ticket'],pid,self.request['expected_lock']) is True,'live original child lease evidence')
    def release(self):
        r=self.provider.released(self.request['expected_lock'])
        b.need(type(r) is dict and r.get('lock_released_same_inode') is True and all(r.get(k)==v for k,v in self.request['expected_lock'].items()),'parent same-inode release proof')
        if not self.fixture:b.need(r.get('fixture') is not True and r.get('evidence_injected') is not True,'live parent rejects synthetic release')
        return r

def launch_pc(config,config_sha,folder,*,enabled=False,diagnostic_finite=False):
    b.need(enabled is True and type(diagnostic_finite) is bool,'PC adapter parent default-off');b.pc_only()
    request=ct.strict_json(ct.read(config));b.need(b.sha(ct.read(config))==ct.digest(config_sha),'PC request pin');ct.validate_request(request,fixture=True)
    b.verify(request['candidate_manifest_sha256']);components=b.configure(enabled=True)
    from device_fixture import FixtureParentEvidence
    proof=ParentEvidenceChecks(request,config_sha,enabled=True,fixture=True,provider=FixtureParentEvidence(components.fpga_evidence),components=components);proof.initial()
    before=b.inventory(b.ROOT);folder=ct.outside(folder);b.need(not folder.exists(),'fresh PC pair evidence')
    ct.write_json(ct.canonical(config).parent/('attempt_'+request['run_id']+'.json'),dict(run_id=request['run_id'],request_sha256=config_sha))
    folder.mkdir();worker=folder/'worker';worker.mkdir()
    previous=b.previous().load('shared_process_fixture',b.FROZEN/'shared_process_fixture.py');guardian=previous.Guardian()
    launch=dict(run_id=request['run_id'],request_sha256=config_sha,parent=ct.process_identity(os.getpid()),fixture=True)
    launchsha=ct.write_json(folder/'launch.json',launch)['sha256'];go=False;seen=None;terminal=None;primary=None;phase='before_spawn'
    finite=request['fixture_profile'] in ct.FINITE_PROFILES
    record=dict(operation_success=False,request_sha256=config_sha,run_id=request['run_id'],actual_wait_observed=False,actual_exit_code=None,process_group_absent=None,
                cleanup_verified=False,lock_released_same_inode=False,acquired_lease_release_verified=False,process_group_proof_real=os.name=='posix',parent_go_sent=False,live_ticket_observed=False,
                finite_supervisor_fixture=finite,TEST_ONLY_parent_diagnostic=diagnostic_finite,original_infinite_hold_executed=False,**ct.flags(True))
    def cancel():
        if not (folder/'stop.flag').exists():ct.write(folder/'stop.flag',b'')
    def publish(v):ct.write_json(folder/'attention_retained.json',dict(v,fixture=True,request_sha256=config_sha))
    def operation(stopped):
        nonlocal go,seen,terminal,phase
        try:
            b.need(stopped() is False,'stop before fixed device fixture child')
            command=[sys.executable,'-I','-B',str(b.ROOT/'device_pc_entry.py'),'--request',str(ct.canonical(config)),'--request-sha',config_sha,
                     '--launch',str(folder/'launch.json'),'--launch-sha',launchsha,'--folder',str(worker),'--enable-PC-fixture']
            options=dict(stdin=subprocess.DEVNULL,close_fds=True,shell=False)
            if os.name=='posix':options['start_new_session']=True
            else:options['creationflags']=subprocess.CREATE_NO_WINDOW
            with (folder/'child.stdout.txt').open('xb') as out,(folder/'child.stderr.txt').open('xb') as err:
                guardian.begin();phase='spawn_pending';child=subprocess.Popen(command,stdout=out,stderr=err,**options);guardian.retain(child)
                started=dict(pid=child.pid,process=ct.process_identity(child.pid),request_sha256=config_sha,run_id=request['run_id'])
                ct.write_json(folder/'child_started.json',started)
                def monitor():
                    nonlocal seen,go
                    value=ct.ready(worker/'ready.json')
                    if value is not None and not go:
                        proof.ready(value,child.pid);seen=value
                        if request['fixture_profile']=='no_go':cancel();return True
                        ct.write_json(folder/'go.json',dict(kind='go',pid=child.pid,parent=launch['parent'],run_id=request['run_id'],request_sha256=config_sha,
                                      ready_sha256=b.sha(ct.read(worker/'ready.json')),fixture=True));go=True
                    if ct.ready(worker/'await_parent_stop.json') is not None:cancel();return True
                    return stopped()
                phase='actual_wait'
                observation=components.observer.observe_exit(child,guardian,monitor,cancel,group_query=None if os.name=='posix' else (lambda pid:True))
                record.update(observation)
            ct.write_json(folder/'observed_child_exit.json',record);phase='validate_terminal'
            b.need(type(ct.ready(folder/'fixture_boundary.json',2_000_000)) is dict,'published PC boundary observation')
            record['fixture_boundary_sha256']=b.sha(ct.read(folder/'fixture_boundary.json',2_000_000))
            terminal=validate_terminal(worker,child.pid,request,config_sha,fixture=True)
            b.need(terminal['process']==started['process'],'actual child creation identity at terminal')
            record.update(child_terminal=terminal,parent_go_sent=go,live_ticket_observed=seen is not None)
            if seen is not None:b.need(terminal['ticket']==seen['ticket'],'same child ticket after completion')
            if terminal['safety_unresolved']:
                guardian._hold(RuntimeError('TEST_ONLY unresolved device fixture'))
                raise RuntimeError('TEST_ONLY unresolved device fixture retained')
            release=proof.release();record.update(cleanup_verified=True,lock_released_same_inode=True,acquired_lease_release_verified=terminal['ticket'] is not None,release_readback=release)
            guardian.forget(child)
            b.need(record['actual_exit_code']==(0 if terminal['operation_success'] else 1),'observed worker exit agrees terminal')
            b.need(terminal['operation_success'] is True and go and record['stop_seen'] is False,'complete adapter normal operation only')
            record['operation_success']=True;return record
        except BaseException as error:
            partial=getattr(error,'comparison_exit_observation',None)
            if partial is not None:record.update(partial)
            if guardian.child is not None or guardian.pending:guardian._hold(error)
            raise
    try:
        observed=(previous.finite_supervised if finite or diagnostic_finite else components.supervisor)(guardian,operation,publish,lambda:(folder/'stop.flag').exists(),enabled=True)
        record['signals']=observed['signals']
    except BaseException as error:primary=error;record['signals']=getattr(error,'supervision_bridge_observation',None)
    b.need(not (guardian.held or guardian.pending or guardian.child is not None) or finite or diagnostic_finite,'original parent cannot exit unresolved child')
    record.update(error_type=None if primary is None else type(primary).__name__,last_stage=phase,parent_guardian=guardian.supervision_status,sources_unchanged=before==b.inventory(b.ROOT))
    b.need(record['sources_unchanged'],'candidate changed during pair');ct.write_json(folder/'outer_receipt.json',record);return record
if __name__=='__main__':raise SystemExit('Private evidence library. No board parent launch command.')
