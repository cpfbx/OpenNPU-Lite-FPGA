"""Separate candidate device/PC contracts; legacy schemas remain immutable."""
import os
import uuid
from pathlib import Path
import device_binding as b
old=b.previous().load('shared_process_contract',b.FROZEN/'shared_process_contract.py')
read,write,write_json,ready,strict_json=old.read,old.write,old.write_json,old.ready,old.strict_json
digest,canonical,process_identity=old.digest,old.canonical,old.process_identity
INDICES=old.INDICES
LOCK='/tmp/opennpu-kws-chain.lock'
FAKE_LOCK=dict(path=LOCK,device=2048,inode=11)
REAL_SCHEMA='shared-device-request-candidate-v1'
PC_SCHEMA='shared-device-PC-fixture-v1'
SCOPE='fixed12-op2-cpu-dw3-op4-correctness-only'
PROFILES=('normal','raw_fault','stop','unsafe','no_go','parent_stop','stop_before_start','factory_error','allocation_error','lock_busy')
FINITE_PROFILES=('unsafe','factory_error','allocation_error','lock_busy')
def outside(path):
    p=canonical(path);b.need(not p.is_relative_to(b.ROOT) and not b.ROOT.is_relative_to(p),'output outside immutable device candidate');return p
def validate_request(value,*,fixture=False):
    b.need(type(fixture) is bool,'strict fixture selector')
    keys={'schema','scope','run_id','operator','candidate_manifest_sha256','expected_boot','expected_lock','declarations','fixture'}
    if fixture:keys.add('fixture_profile')
    b.need(type(value) is dict and set(value)==keys,'exact new device request fields')
    b.need(value['schema']==(PC_SCHEMA if fixture else REAL_SCHEMA) and value['scope']==SCOPE and value['operator']=='bx'
           and value['fixture'] is fixture,'device/PC request isolation')
    if fixture:b.need(type(value['fixture_profile']) is str and value['fixture_profile'] in PROFILES,'explicit PC profile only')
    for key in ('run_id','expected_boot'):b.need(type(value[key]) is str and str(uuid.UUID(value[key]))==value[key],'canonical request UUID')
    digest(value['candidate_manifest_sha256']);lock=value['expected_lock']
    b.need(type(lock) is dict and set(lock)=={'path','device','inode'} and lock['path']==LOCK and type(lock['device']) is int and lock['device']>=0 and type(lock['inode']) is int and lock['inode']>0,'original canonical lock identity')
    declarations=value['declarations']
    b.need(type(declarations) is dict and set(declarations)=={'utc','idle','wiring','separate_scope_approved'} and all(v is True for v in declarations.values()),'explicit declarations are not authenticated approval')
    return value
def fixture_request(pin,profile='normal'):
    return validate_request(dict(schema=PC_SCHEMA,scope=SCOPE,run_id=str(uuid.uuid4()),operator='bx',candidate_manifest_sha256=digest(pin),expected_boot='00000000-0000-0000-0000-000000000001',expected_lock=dict(FAKE_LOCK),declarations=dict(utc=True,idle=True,wiring=True,separate_scope_approved=True),fixture=True,fixture_profile=profile),fixture=True)
def flags(fixture,*,lock_access=False,board_access=False,driver_returns=0):
    b.need(type(fixture) is bool and type(lock_access) is bool and type(board_access) is bool
           and type(driver_returns) is int and driver_returns>=0,'strict record mode/observations')
    return dict(fixture=fixture,evidence_injected=fixture,real_lock_access=not fixture and lock_access,real_DMA_executed=not fixture and driver_returns>0,
                board_access=not fixture and board_access,real_cross_layer_PL_execution=not fixture and driver_returns>=2,ARM_tested=False,
                performance_evaluated=False,energy_evaluated=False,classification_quality_evaluated=False,
                automatic_retry=False,automatic_kill=False,run_ready=False,promotion=False)
def terminal(folder):
    t=ready(folder/'terminal.json',2_000_000);b.need(type(t) is dict,'published device terminal required')
    m=ready(folder/'artifact_manifest.json',2_000_000);b.need(type(m) is dict and set(m)=={'files'},'device worker manifest')
    b.need(t['artifact_manifest_sha256']==b.sha(read(folder/'artifact_manifest.json',2_000_000)),'device terminal manifest pin')
    excluded={'terminal.json','terminal.json.ready','artifact_manifest.json','artifact_manifest.json.ready'}
    actual=b.inventory(folder)
    b.need(set(actual)==set(m['files'])|excluded and {n:v for n,v in actual.items() if n not in excluded}==m['files'],'exact device worker artifacts')
    for name in actual:
        if name.endswith('.json.ready'):b.need(read(folder/name,0)==b'','empty device publication marker')
    return t
if __name__=='__main__':raise SystemExit('Contract only. No board request generator or activation entry.')
