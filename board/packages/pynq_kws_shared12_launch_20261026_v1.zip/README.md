# Fixed12 shared-session thin-launch candidate

Offline review candidate only. No board activation has been approved by this package. bx is the sole board operator. Default/core contracts, D075, oracle, thresholds, canonical lock and supervision are unchanged.

One SharedOwner, one lease, one runner and two root DMA buffers; 12 fixed windows, alternating Op2 -> CPU depthwise3 -> Op4, 24 Pointwise requests, job IDs 1..48. CPU prefix/reference checking is part of correctness work; no latency or energy claim.

`shared.py check` verifies pinned package bytes only. `preflight` is an explicit read-only ARM environment and existing-lock observation, not idle proof; it never creates/acquires/repairs the lock. `prepare` only writes new data after declarations. `run` requires opt-in and SHARED12 confirmation plus before/after observations, uses the fixed real child and original supervisor/observer. `stop` only publishes a cooperative flag. Unsafe/unresolved original supervision may remain resident indefinitely; no automatic kill, timeout-release, retry or network operation occurs.

Readback verifies stored evidence/golden bytes and metadata only. It neither reruns inference nor proves artifact origin, authenticates a shell exit record, or touches the current board lock. `archive --preserve-only` is for an ended attempt with stored child-exit/group absence; it is never numerical acceptance.

Use `run_board.sh` only after separate bx authorization for the exact reviewed package and current site. It retains a single shell attempt and actual Python exit code. Commands and placeholders are in the review bundle's operator_guide.md; no historical boot/inode is prefilled. Do not execute PowerShell in Bash or explanatory prose as shell commands. Board reboot requires a new preflight and fresh work. Missing canonical lock: stop; only a separately authorized frozen bootstrap may prepare it.

The core directory is 253 exact reviewed files. All PC fixture entry points retain x86/default-off restrictions. New real entry accepts no fixture profiles, providers, fake metrics, or finite supervisor arguments. Offline mock tests do not authorize real ARM execution. No 420-window quality, full-model deployment, performance, energy, recovery certification, long-run stability or promotion is claimed.
