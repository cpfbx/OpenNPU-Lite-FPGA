#!/usr/bin/env bash
# User-operated wrapper; actual shell wait is retained only after Python exits.
set -euo pipefail
if [ "$#" -ne 4 ] || [ "$4" != '--enable-board-candidate' ]; then
  printf 'Default off. Requires KIT_SHA WORK PLAN_SHA --enable-board-candidate.\n' >&2
  exit 2
fi
kit_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
work_dir=$2
test -d "$work_dir"
test ! -L "$work_dir"
test ! -e "$work_dir/launcher_exit.txt"
test ! -L "$work_dir/launcher_exit.txt"
test ! -e "$work_dir/shell_attempt.txt"
test ! -L "$work_dir/shell_attempt.txt"
# Validate canonical work, pinned plan/request and kit BEFORE any shell writes.
python3 -I -B "$kit_dir/shared.py" --kit-manifest-sha "$1" inspect-plan \
  --work "$work_dir" --plan-sha "$3"
# Exclusive shell-attempt record also prevents two wrappers using the same work.
(set -o noclobber; printf '%s\n' "$3" > "$work_dir/shell_attempt.txt")
if python3 -I -B "$kit_dir/shared.py" --kit-manifest-sha "$1" run \
    --work "$work_dir" --plan-sha "$3" --enable-board-candidate; then
  shared_exit=0
else
  shared_exit=$?
fi
(set -o noclobber; printf '%s\n' "$shared_exit" > "$work_dir/launcher_exit.txt")
printf 'ACTUAL_SHARED_LAUNCHER_EXIT=%s\n' "$shared_exit"
exit "$shared_exit"
