"""Fixed ARM child entry; no PC fixture, injected providers, or finite hooks."""
import argparse
import os
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import launch_support as s

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('work','plan-sha','kit-manifest-sha','launch-sha'):p.add_argument('--'+name,required=True)
    p.add_argument('--enable-shared-device-worker',action='store_true');a=p.parse_args()
    s.require(a.enable_shared_device_worker is True,'shared worker default-off')
    s.verify_kit(a.kit_manifest_sha)
    plan,pre,request=s.validate_plan(a.work,a.plan_sha,a.kit_manifest_sha)
    s.require(s.observe(a.kit_manifest_sha)==pre,'child environment/boot/lock drift before acquisition')
    b=s.load_device('device_binding');b.require_arm(request);b.verify(s.CORE_SHA)
    ct=s.load_device('device_contract');work=s.outside(a.work);folder=work/'evidence'
    launch=s.pinned(folder/'launch.json',a.launch_sha)
    s.require(launch==dict(run_id=request['run_id'],request_sha256=plan['request_sha256'],parent=ct.process_identity(os.getppid()),fixture=False),'actual invoking parent creation identity')
    worker=s.load_device('device_worker')
    terminal=worker.run_worker(request,plan['request_sha256'],folder/'worker',launch,enabled=True,fixture=False)
    return 0 if terminal['operation_success'] else 1

if __name__=='__main__':
    try:raise SystemExit(main())
    except (OSError,ValueError,RuntimeError,ImportError,KeyError,TypeError) as error:
        # Exception text can include paths or secrets; only the fixed type is emitted.
        print(s.json.dumps(dict(operation_success=False,error_type=type(error).__name__,promotion=False,automatic_retry=False,automatic_kill=False)),file=sys.stderr)
        raise SystemExit(2)
