"""Pinned bytes, strict records, and read-only live environment observations."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path,PurePosixPath
import platform
import re
import stat
import sys
import uuid
ROOT=Path(__file__).resolve().parent
CORE_SHA='a9b97371db2cae602f1b500384c2f4063436e08772960f05d532dbc62686b403'
LOCK='/tmp/opennpu-kws-chain.lock'
INDICES=[0,30,60,90,120,150,180,210,240,270,300,400]
def require(ok,why):
    if not ok:raise ValueError(why)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def digest(value):
    require(type(value) is str and re.fullmatch('[a-f0-9]{64}',value) is not None,'lowercase SHA256 required');return value
def canonical(path):
    p=Path(path).absolute();require(p.resolve()==p and not p.is_symlink() and not getattr(p,'is_junction',lambda:False)(),'canonical nonalias path');return p
def read(path,limit=16*1024*1024):
    p=canonical(path);s=p.lstat();require(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_size<=limit,'bounded single-link regular file')
    with p.open('rb') as f:b=f.read(limit+1)
    require(len(b)<=limit,'file bound');return b
def parse(raw):
    def pairs(items):
        result={}
        for k,v in items:require(k not in result,'duplicate JSON key');result[k]=v
        return result
    def bad(v):raise ValueError('nonfinite JSON number')
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=bad)
def pinned(path,pin):
    b=read(path);require(sha(b)==digest(pin),'record SHA mismatch');return parse(b)
def write(path,raw):
    p=canonical(path)
    with p.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    return dict(bytes=len(raw),sha256=sha(raw))
def write_json(path,value):return write(path,(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())
def inventory(root):
    result={}
    for p in sorted(canonical(root).rglob('*')):
        require(not p.is_symlink() and not getattr(p,'is_junction',lambda:False)(),'plain tree member')
        if p.is_file():
            b=read(p);result[p.relative_to(root).as_posix()]=dict(bytes=len(b),sha256=sha(b))
    return result
def outside(path):
    p=canonical(path);require(not p.is_relative_to(ROOT) and not ROOT.is_relative_to(p),'output outside immutable kit');return p
def fresh_directory(path,mode=0o700):
    p=outside(path);require(not os.path.lexists(p),'fresh output directory');p.mkdir(mode=mode);return p
def verify_kit(pin):
    m=pinned(ROOT/'kit_manifest.json',pin)
    require(set(m)=={'schema','core_manifest_sha256','files'} and m['schema']=='shared-launch-kit-candidate-v1'
        and m['core_manifest_sha256']==CORE_SHA,'kit manifest shape/core')
    actual=inventory(ROOT);require(set(actual)==set(m['files'])|{'kit_manifest.json'} and all(actual[n]==v for n,v in m['files'].items()),'kit file identity drift')
    require(sha(read(ROOT/'core/candidate_manifest.json'))==CORE_SHA,'reviewed core pin')
    cm=parse(read(ROOT/'core/candidate_manifest.json'))['files']
    core=inventory(ROOT/'core');require(set(core)==set(cm)|{'candidate_manifest.json'} and all(core[n]==v for n,v in cm.items()),'253 device-adapter core unchanged')
    return m
def load_device(name):
    require(name in ('device_binding','device_contract','device_parent','device_worker'),'fixed device module')
    core=ROOT/'core'
    if str(core) not in sys.path:sys.path.insert(0,str(core))
    path=core/(name+'.py')
    if name in sys.modules:
        require(Path(getattr(sys.modules[name],'__file__','')).resolve()==path,'foreign device module');return sys.modules[name]
    if name!='device_binding':load_device('device_binding')
    if name not in ('device_binding','device_contract'):load_device('device_contract')
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module;spec.loader.exec_module(module);return module

def uuid_text(value):
    require(type(value) is str and str(uuid.UUID(value))==value,'canonical UUID');return value
def validate_environment(e):
    require(type(e) is dict and set(e)=={'system','machine','kernel','byteorder','python_version','numpy_version',
        'invoked_executable','prefix','files','boot_id'},'exact environment fields')
    require(e['system']=='Linux' and e['machine']=='armv7l' and e['kernel']=='6.6.10-xilinx-v2024.1-g3c0eca68c652'
        and e['byteorder']=='little' and e['python_version']==[3,10,4] and all(type(x) is int for x in e['python_version'])
        and e['numpy_version']=='1.21.5','original ARM environment only')
    uuid_text(e['boot_id']);require(all(type(e[k]) is str and e[k] for k in ('invoked_executable','prefix')),'executable/prefix')
    require(type(e['files']) is dict and set(e['files'])=={'python','numpy_init','numpy_core'},'three fingerprint files')
    for v in e['files'].values():
        require(type(v) is dict and set(v)=={'path','bytes','sha256'} and type(v['path']) is str and v['path']
            and type(v['bytes']) is int and v['bytes']>0,'fingerprint entry');digest(v['sha256'])
    return e
def fingerprint(path):
    p=Path(path).resolve(strict=True);b=read(p,32*1024*1024);return dict(path=str(p),bytes=len(b),sha256=sha(b))
def collect_environment():
    # Fail before NumPy import on every desktop. Never import PYNQ or touch MMIO.
    require(platform.system()=='Linux' and platform.machine()=='armv7l' and sys.byteorder=='little'
        and platform.release()=='6.6.10-xilinx-v2024.1-g3c0eca68c652' and sys.version_info[:3]==(3,10,4),'read-only probe requires original ARM environment')
    import numpy as np
    require(np.__version__=='1.21.5','original NumPy required')
    module=np.core._multiarray_umath
    return validate_environment(dict(system=platform.system(),machine=platform.machine(),kernel=platform.release(),byteorder=sys.byteorder,
        python_version=list(sys.version_info[:3]),numpy_version=np.__version__,invoked_executable=str(Path(sys.executable).absolute()),prefix=sys.prefix,
        files=dict(python=fingerprint(sys.executable),numpy_init=fingerprint(np.__file__),numpy_core=fingerprint(module.__file__)),
        boot_id=read('/proc/sys/kernel/random/boot_id',128).decode('ascii').strip()))
def lock_observation():
    value=os.lstat(LOCK)
    require(stat.S_ISREG(value.st_mode) and value.st_nlink==1 and value.st_uid==1000 and stat.S_IMODE(value.st_mode)==0o644,'existing canonical lock uid/mode/link required; no repair')
    b=load_device('device_binding');p=b.previous()
    base=p.CORE/'driver/frozen_driver/frozen_hw/legacy/frozen_source'
    b.load('os_evidence',base/'os_evidence.py');fe=b.load('fpga_evidence',p.CORE/'frozen_control/fpga_evidence.py')
    identity=fe.snapshot();release=fe.released(identity)
    return dict(identity=identity,uid=value.st_uid,mode=stat.S_IMODE(value.st_mode),links=value.st_nlink,
        lock_released_same_inode=release['lock_released_same_inode'])
def validate_lock(value):
    require(type(value) is dict and set(value)=={'identity','uid','mode','links','lock_released_same_inode'},'exact lock observation')
    i=value['identity'];require(type(i) is dict and set(i)=={'path','device','inode'} and i['path']==LOCK
        and type(i['device']) is int and i['device']>=0 and type(i['inode']) is int and i['inode']>0,'canonical inode')
    require(type(value['uid']) is int and value['uid']==1000 and type(value['mode']) is int and value['mode']==420
        and type(value['links']) is int and value['links']==1 and value['lock_released_same_inode'] is True,'existing lock metadata/release')
    return value
def validate_preflight(p,kit_pin):
    require(type(p) is dict and set(p)=={'schema','kit_manifest_sha256','core_manifest_sha256','environment','lock',
        'hardware_access','board_test_started','lock_acquired','idle_proven'},'exact preflight fields')
    require(p['schema']=='shared-readonly-preflight-candidate-v1' and p['kit_manifest_sha256']==digest(kit_pin)
        and p['core_manifest_sha256']==CORE_SHA and all(p[k] is False for k in ('hardware_access','board_test_started','lock_acquired','idle_proven')),'preflight scope')
    validate_environment(p['environment']);validate_lock(p['lock']);return p
def observe(kit_pin):
    return validate_preflight(dict(schema='shared-readonly-preflight-candidate-v1',kit_manifest_sha256=kit_pin,core_manifest_sha256=CORE_SHA,
        environment=collect_environment(),lock=lock_observation(),hardware_access=False,board_test_started=False,lock_acquired=False,idle_proven=False),kit_pin)
def confirm(word):require(input('bx only: exact reviewed scope and current declarations approved? Type '+word+': ')==word,'operator declined')

def validate_invocation(work,plan,plan_pin,kit_pin):
    value=parse(read(work/'invocation.json'))
    require(value==dict(schema='shared-launch-invocation-candidate-v1',operator='bx',confirmation='SHARED12',plan_sha256=plan_pin,
        request_sha256=plan['request_sha256'],kit_manifest_sha256=kit_pin,run_id=plan['run_id'],fixture=False,
        approval_is_operator_declaration=True,physical_identity_authenticated=False),'exact declared invocation')
    return value
def validate_plan(work,plan_pin,kit_pin,*,relocated=False):
    work=outside(work);plan=pinned(work/'plan.json',plan_pin)
    require(type(plan) is dict and set(plan)=={'schema','run_id','operator','board_work','kit_manifest_sha256','core_manifest_sha256',
        'preflight_sha256','request_sha256','evidence','scope','board_declaration'},'exact plan')
    require(plan['schema']=='shared-launch-plan-candidate-v1' and plan['operator']=='bx' and plan['kit_manifest_sha256']==digest(kit_pin)
        and plan['core_manifest_sha256']==CORE_SHA and plan['scope']=='fixed12-op2-cpu-dw3-op4-correctness-only'
        and plan['evidence']=='evidence' and type(plan['board_work']) is str and plan['board_work'],'fixed plan scope')
    uuid_text(plan['run_id']);require(type(plan['board_declaration']) is str and 0<len(plan['board_declaration'])<=128 and all(ord(c)>=32 for c in plan['board_declaration']),'declared physical board')
    if not relocated:require(str(work)==plan['board_work'],'original prepared work path')
    pre=validate_preflight(pinned(work/'preflight.json',plan['preflight_sha256']),kit_pin)
    ct=load_device('device_contract');request=ct.validate_request(pinned(work/'request.json',plan['request_sha256']),fixture=False)
    require(request['run_id']==plan['run_id'] and request['candidate_manifest_sha256']==CORE_SHA
        and request['expected_boot']==pre['environment']['boot_id'] and request['expected_lock']==pre['lock']['identity'],'request/plan/preflight binding')
    return plan,pre,request
