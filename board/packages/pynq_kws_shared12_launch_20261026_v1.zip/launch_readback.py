"""Existing bytes only: no observe(), live lock checks, inference or cleanup."""
import io
import os
import tarfile
import uuid
import launch_support as s

def shell_exit(work):
    raw=s.read(work/'launcher_exit.txt',16)
    s.require(raw.endswith(b'\n') and raw[:-1].isdigit(),'shell-observed numeric exit')
    value=int(raw);s.require(0<=value<=255,'shell exit range');return value

def verify(work,plan_pin,kit_pin):
    s.verify_kit(kit_pin);work=s.outside(work);plan,pre,req=s.validate_plan(work,plan_pin,kit_pin,relocated=True)
    s.require(shell_exit(work)==0 and s.read(work/'shell_attempt.txt',65)==(plan_pin+'\n').encode('ascii'),'actual shell wait/attempt not clean')
    inv=s.parse(s.read(work/'invocation.json'))
    s.require(inv==dict(schema='shared-launch-invocation-candidate-v1',operator='bx',confirmation='SHARED12',plan_sha256=plan_pin,
        request_sha256=plan['request_sha256'],kit_manifest_sha256=kit_pin,run_id=req['run_id'],fixture=False,
        approval_is_operator_declaration=True,physical_identity_authenticated=False),'exact invocation binding')
    b=s.load_device('device_binding');b.verify(s.CORE_SHA);b.configure(enabled=True)
    ct=s.load_device('device_contract');parent=s.load_device('device_parent');e=work/'evidence'
    outer=ct.ready(e/'outer_receipt.json',2_000_000)
    s.require(type(outer) is dict,'completed shared outer receipt')
    for key,wanted in dict(operation_success=True,actual_exit_code=0,actual_wait_observed=True,process_group_absent=True,
        group_query_injected=False,process_group_proof_real=True,cleanup_verified=True,lock_released_same_inode=True,
        acquired_lease_release_verified=True,fixture=False,evidence_injected=False,automatic_kill=False,automatic_retry=False,
        finite_supervisor_fixture=False,original_infinite_hold_executed=False,parent_go_sent=True,live_ticket_observed=True,
        stop_seen=False,error_type=None,sources_unchanged=True,board_access=True,real_DMA_executed=True,real_lock_access=True,
        real_cross_layer_PL_execution=True,performance_evaluated=False,energy_evaluated=False,classification_quality_evaluated=False,
        run_ready=False,promotion=False).items():s.require(type(outer.get(key)) is type(wanted) and outer[key]==wanted,'outer '+key)
    clean=dict(stop_signals=[],handler_errors=[],handler_restore_errors=[],original_supervisor_unchanged=True)
    s.require(outer['signals']==clean and outer['run_id']==req['run_id'] and outer['request_sha256']==plan['request_sha256'],'outer signals/request')
    launch=ct.ready(e/'launch.json');started=ct.ready(e/'child_started.json')
    s.require(type(launch) is dict and set(launch)=={'run_id','request_sha256','parent','fixture'} and launch['fixture'] is False
        and launch['run_id']==req['run_id'] and launch['request_sha256']==plan['request_sha256'],'bound launch')
    s.require(type(started) is dict and set(started)=={'pid','process','request_sha256','run_id'} and type(started['pid']) is int and started['pid']>1
        and started['request_sha256']==plan['request_sha256'] and started['run_id']==req['run_id'],'started child')
    for identity in (launch['parent'],started['process']):
        s.require(type(identity) is dict and set(identity)=={'pid','start','kind'} and type(identity['pid']) is int and identity['pid']>1
            and type(identity['start']) is int and identity['start']>0 and identity['kind']=='proc-stat-start-ticks','stored POSIX creation identity')
    s.require(started['process']['pid']==started['pid'],'started identity pid')
    terminal=parent.validate_terminal(e/'worker',started['pid'],req,plan['request_sha256'],fixture=False)
    s.require(terminal==outer['child_terminal'] and terminal['operation_success'] is True and terminal['process']==started['process'],'identical completed child')
    s.require(terminal['completed_indices']==s.INDICES and terminal['session']['completed_driver_returns']==24,'12 windows /24 returns')
    for key in ('board_access','real_DMA_executed','real_lock_access','real_cross_layer_PL_execution'):s.require(terminal[key] is True and terminal['session'][key] is True,'stored real attempt observation '+key)
    ready=ct.ready(e/'worker/ready.json')
    s.require(ready['process']==started['process'] and ready['ticket']==terminal['ticket'] and ready['identity']==req['expected_lock'],'ready/terminal/ticket')
    s.require(terminal['ticket']['process_start_ticks']==started['process']['start'],'acquired ticket exact process creation')
    go=ct.ready(e/'go.json')
    s.require(go==dict(kind='go',pid=started['pid'],parent=launch['parent'],run_id=req['run_id'],request_sha256=plan['request_sha256'],
        ready_sha256=s.sha(ct.read(e/'worker/ready.json')),fixture=False),'bound GO')
    wait=ct.ready(e/'observed_child_exit.json')
    expected_wait_keys={'actual_exit_code','process_group_absent','group_query_injected','actual_wait_observed','automatic_kill','stop_seen','wait_intervals','source','run_id','request_sha256','fixture','evidence_injected'}
    s.require(type(wait) is dict and set(wait)==expected_wait_keys and wait['fixture'] is False and wait['evidence_injected'] is False,'exact stored observer record')
    for key in expected_wait_keys-{'fixture','evidence_injected'}:s.require(type(wait[key]) is type(outer[key]) and wait[key]==outer[key],'observed wait '+key)
    s.require(type(wait['wait_intervals']) is int and wait['wait_intervals']>=0 and wait['source']=='Popen.wait then read-only process-group query','wait source/bound')
    release=dict(req['expected_lock'],lock_released_same_inode=True,source='lstat same inode + no matching FLOCK in proc/locks; no acquisition probe')
    s.require(outer['release_readback']==terminal['session']['release_readback']==release,'stored original same-inode release')
    guardian=outer['parent_guardian']
    s.require(guardian==dict(pid=launch['parent']['pid'],held=False,safety_unresolved=False,lease_retained=False,runner_retained=False,root_buffers_retained=0),'resolved original parent guardian')
    attempt=ct.ready(work/('attempt_'+req['run_id']+'.json'))
    s.require(attempt==dict(run_id=req['run_id'],request_sha256=plan['request_sha256']),'single attempt binding')
    roots={'plan.json','request.json','preflight.json','invocation.json','shell_attempt.txt','launcher_exit.txt','attempt_'+req['run_id']+'.json','attempt_'+req['run_id']+'.json.ready'}
    ev={'launch.json','launch.json.ready','child_started.json','child_started.json.ready','go.json','go.json.ready','observed_child_exit.json','observed_child_exit.json.ready','outer_receipt.json','outer_receipt.json.ready','child.stdout.txt','child.stderr.txt'}
    wanted=roots|{'evidence/'+n for n in ev}|{'evidence/worker/'+n for n in s.inventory(e/'worker')}
    s.require(set(s.inventory(work))==wanted,'exact successful work members')
    return dict(operation_success=True,samples=12,pointwise_requests=24,jobs=48,pointwise_MACs=12288000,depthwise_logical_MACs=864000,
        Op2_raw_values=96000,Op2_corrected_values=96000,Op2_INT8_values=96000,DW3_acc_values=96000,DW3_INT8_values=96000,
        Op4_raw_values=96000,Op4_corrected_values=96000,Op4_INT8_values=96000,
        plan_sha256=plan_pin,request_sha256=plan['request_sha256'],kit_manifest_sha256=kit_pin,core_manifest_sha256=s.CORE_SHA,
        inference_reexecuted=False,full_dot_product_recomputed=False,live_lock_access=False,hardware_access=False,
        source_origin_authenticated=False,operator_exit_record_authenticated=False,performance_evaluated=False,energy_evaluated=False,
        classification_quality_evaluated=False,run_ready=False,promotion=False)

def archive(work,plan_pin,kit_pin,parent,*,preserve_only=False):
    s.require(type(preserve_only) is bool,'strict preserve-only selector')
    work=s.outside(work);s.verify_kit(kit_pin);s.validate_plan(work,plan_pin,kit_pin,relocated=True)
    if preserve_only:
        code=shell_exit(work);ct=s.load_device('device_contract');obs=ct.ready(work/'evidence/observed_child_exit.json')
        s.require(type(obs) is dict and obs.get('actual_wait_observed') is True and obs.get('process_group_absent') is True
            and type(obs.get('actual_exit_code')) is int,'preserve only after stored child exit/group observation')
        result=dict(operation_success=False,scope='preserve ended evidence only; no numerical acceptance',shell_reported_exit=code,
            hardware_access=False,live_lock_access=False,promotion=False,run_ready=False)
    else:result=verify(work,plan_pin,kit_pin)
    parent=s.outside(parent);s.require(parent.is_dir() and not parent.is_relative_to(work),'export parent outside work')
    before=s.inventory(work);target=parent/('shared_return_'+uuid.uuid4().hex);target.mkdir(mode=0o755)
    s.require(target.stat().st_mode&0o005==0o005,'export not traversable/readable; no chmod')
    data=(s.json.dumps(result,sort_keys=True,indent=2)+'\n').encode();path=target/'shared12_evidence_v1.tar.gz'
    with tarfile.open(path,'x:gz') as tar:
        for name,pin in before.items():
            raw=s.read(work/name);s.require(dict(bytes=len(raw),sha256=s.sha(raw))==pin,'archive input drift')
            info=tarfile.TarInfo('work/'+name);info.size=len(raw);info.mode=0o644;tar.addfile(info,io.BytesIO(raw))
        info=tarfile.TarInfo('readback.json');info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
    s.require(before==s.inventory(work),'work changed during archive; not accepted')
    s.require(path.stat().st_mode&0o004,'archive not readable; no chmod');raw=s.read(path)
    return dict(archive=str(path),bytes=len(raw),sha256=s.sha(raw),numerical_acceptance=result['operation_success'],preserve_only=preserve_only,
        hardware_access=False,automatic_retry=False,promotion=False)
