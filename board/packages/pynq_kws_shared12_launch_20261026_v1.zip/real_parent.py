"""Private ARM parent. Fixed child, original supervisor/wait, no fixture hooks."""
import os
from pathlib import Path
import subprocess
import sys
import launch_support as s

def launch(work,plan_pin,kit_pin,*,enabled=False):
    s.require(enabled is True,'shared device parent default-off')
    s.verify_kit(kit_pin)
    plan,pre,request=s.validate_plan(work,plan_pin,kit_pin)
    work=s.outside(work)
    s.validate_invocation(work,plan,plan_pin,kit_pin)
    s.require(s.observe(kit_pin)==pre,'parent current boot/dependency/lock drift')
    s.require(not any(os.path.lexists(work/n) for n in ('evidence','attempt_'+request['run_id']+'.json','attempt_'+request['run_id']+'.json.ready')),'single device attempt')
    b=s.load_device('device_binding');ct=s.load_device('device_contract');parent=s.load_device('device_parent')
    b.require_arm(request);b.verify(s.CORE_SHA)
    proof=parent.ParentEvidenceChecks(request,plan['request_sha256'],enabled=True,fixture=False)
    proof.initial();c=proof.components
    # The exact reviewed Guardian class; no finite fixture supervisor is loaded.
    guardian_type=b.previous().load('shared_process_fixture',b.FROZEN/'shared_process_fixture.py').Guardian
    guardian=guardian_type()
    ct.write_json(work/('attempt_'+request['run_id']+'.json'),dict(run_id=request['run_id'],request_sha256=plan['request_sha256']))
    folder=work/'evidence';folder.mkdir();worker=folder/'worker';worker.mkdir()
    value=dict(run_id=request['run_id'],request_sha256=plan['request_sha256'],parent=ct.process_identity(os.getpid()),fixture=False)
    launch_pin=ct.write_json(folder/'launch.json',value)['sha256']
    go=False;seen=None;phase='before_spawn';terminal=None;primary=None
    record=dict(operation_success=False,run_id=request['run_id'],request_sha256=plan['request_sha256'],actual_exit_code=None,
        actual_wait_observed=False,process_group_absent=None,group_query_injected=False,process_group_proof_real=True,
        cleanup_verified=False,lock_released_same_inode=False,acquired_lease_release_verified=False,parent_go_sent=False,
        live_ticket_observed=False,finite_supervisor_fixture=False,original_infinite_hold_executed=False,**ct.flags(False))
    before=s.inventory(s.ROOT)
    def cancel():
        flag=folder/'stop.flag'
        if os.path.lexists(flag):s.require(ct.read(flag,0)==b'','plain cooperative stop flag')
        else:ct.write(flag,b'')
    def publish(v):ct.write_json(folder/'attention_retained.json',dict(v,fixture=False,request_sha256=plan['request_sha256']))
    def operation(stopped):
        nonlocal go,seen,phase,terminal
        try:
            s.require(stopped() is False,'stop before fixed shared child')
            command=[sys.executable,'-I','-B',str(s.ROOT/'shared_device_entry.py'),'--work',str(work),'--plan-sha',plan_pin,
                '--kit-manifest-sha',kit_pin,'--launch-sha',launch_pin,'--enable-shared-device-worker']
            with (folder/'child.stdout.txt').open('xb') as out,(folder/'child.stderr.txt').open('xb') as err:
                guardian.begin();phase='spawn_pending'
                child=subprocess.Popen(command,stdin=subprocess.DEVNULL,close_fds=True,shell=False,start_new_session=True,stdout=out,stderr=err)
                guardian.retain(child)
                started=dict(pid=child.pid,process=ct.process_identity(child.pid),request_sha256=plan['request_sha256'],run_id=request['run_id'])
                ct.write_json(folder/'child_started.json',started)
                def monitor():
                    nonlocal go,seen
                    if stopped() is not False:return True
                    ready=ct.ready(worker/'ready.json')
                    if ready is not None and not go:
                        proof.ready(ready,child.pid);seen=ready
                        s.require(ready['process']==started['process'],'ready exact spawned child creation identity')
                        ct.write_json(folder/'go.json',dict(kind='go',pid=child.pid,parent=value['parent'],run_id=request['run_id'],
                            request_sha256=plan['request_sha256'],ready_sha256=b.sha(ct.read(worker/'ready.json')),fixture=False));go=True
                    return False
                phase='actual_wait'
                observation=c.observer.observe_exit(child,guardian,monitor,cancel)
                record.update(observation)
            ct.write_json(folder/'observed_child_exit.json',dict(observation,run_id=request['run_id'],request_sha256=plan['request_sha256'],fixture=False,evidence_injected=False))
            phase='validate_terminal'
            terminal=parent.validate_terminal(worker,child.pid,request,plan['request_sha256'],fixture=False)
            s.require(terminal['process']==started['process'],'terminal exact spawned child creation identity')
            record.update(child_terminal=terminal,parent_go_sent=go,live_ticket_observed=seen is not None)
            if seen is not None:s.require(terminal['ticket']==seen['ticket'],'same observed child lease after completion')
            release=proof.release()
            record.update(cleanup_verified=True,lock_released_same_inode=True,acquired_lease_release_verified=terminal['ticket'] is not None,release_readback=release)
            s.require(type(record['actual_exit_code']) is int and record['actual_exit_code']==(0 if terminal['operation_success'] else 1),'actual child exit agrees terminal')
            guardian.forget(child)
            record.update(ct.flags(False,lock_access=terminal['real_lock_access'],board_access=terminal['board_access'],driver_returns=terminal['session']['completed_driver_returns']))
            s.require(terminal['operation_success'] is True and go and record['stop_seen'] is False,'complete normal operation only')
            record['operation_success']=True
            return record
        except BaseException as error:
            partial=getattr(error,'comparison_exit_observation',None)
            if partial is not None:
                record.update(partial)
                ct.write_json(folder/'observed_child_exit.json',dict(partial,run_id=request['run_id'],request_sha256=plan['request_sha256'],fixture=False,evidence_injected=False))
            if guardian.child is not None or guardian.pending:guardian._hold(error)
            raise
    try:
        result=c.supervisor(guardian,operation,publish,lambda:os.path.lexists(folder/'stop.flag'),enabled=True)
        record['signals']=result['signals']
    except BaseException as error:
        primary=error;record['signals']=getattr(error,'supervision_bridge_observation',None)
    s.require(not (guardian.held or guardian.pending or guardian.child is not None),'original parent cannot exit unresolved child')
    record.update(error_type=None if primary is None else type(primary).__name__,last_stage=phase,parent_guardian=guardian.supervision_status,sources_unchanged=before==s.inventory(s.ROOT))
    s.require(record['sources_unchanged'],'kit changed during shared run')
    ct.write_json(folder/'outer_receipt.json',record)
    return record

if __name__=='__main__':raise SystemExit('Private parent library; use reviewed shared.py run.')
